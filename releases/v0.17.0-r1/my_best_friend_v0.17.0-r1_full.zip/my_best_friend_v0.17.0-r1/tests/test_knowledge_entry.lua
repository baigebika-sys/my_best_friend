-- Existing world and production chat harness are prepended by the runner.
local Knowledge=require('ybf_knowledge')
local Pickable=dofile('tests/reference/pickable_v0140.lua')
Prefabs={petals={},petals_evil={},berries={},flower={},flower_evil={},berrybush={},modfruit={},specialfruit={},fruit_a={},fruit_b={},boards={}}
STRINGS.NAMES.PETALS='花瓣';STRINGS.NAMES.PETALS_EVIL='恶魔花瓣';STRINGS.NAMES.BERRIES='浆果';STRINGS.NAMES.MODFRUIT='自定义果实'
STRINGS.NAMES.SPECIALFRUIT='特殊果实';STRINGS.NAMES.FRUIT_A='同名果实';STRINGS.NAMES.FRUIT_B='同名果实'
EntityScript={is_instance=function(e)return type(e)=='table' and e.GUID~=nil end}
SpringGrowthMod=function(t)return t end
local spawned=0
SpawnPrefab=function(prefab)
 spawned=spawned+1
 local e=item(prefab,1)
 function e.components.inventoryitem:InheritWorldWetnessAtTarget()end
 return e
end
local function ordinaryplant(name,product,x,remove)
 local e=entity(name,x or 2);local p=Pickable(e);e.components.pickable=p
 p:SetUp(product,10,1);p.remove_when_picked=remove
 function e:DoTaskInTime()return {Cancel=function()end}end
 -- Use actual SpawnProductLoot/Pick methods, including removal and event order.
 world[#world+1]=e;return e
end
local h=harness();local f1=ordinaryplant('flower','petals',2,true);local f2=ordinaryplant('flower','petals',3,true)
local evil=ordinaryplant('flower_evil','petals_evil',4,true)
local thorn=ordinaryplant('flower','petals',5,true);thorn.tags.thorny=true
local blocked=ordinaryplant('flower','petals',6,true);blocked.components.pickable.caninteractwith=false
-- Native ordinary flower callback can affect sanity; execution must preserve it.
local flower_effect=0;f1.components.pickable.onpickedfn=function(_,picker)assert(picker==friend);flower_effect=flower_effect+1 end
spawned=0;h:send('帮我采集2个花瓣给我');assert(spawned==0 and w.core.job.spec.targets[1].item=='petals')
local j=w.core.job;tick();local a=action;assert(a.action==ACTIONS.PICK);perform()
assert(Inventory.Count(friend,'petals')==1 and j.count==0 and not f1:IsValid())
run();assert(spawned==2 and Inventory.Count(owner,'petals')==2 and Inventory.Count(friend,'petals')==0 and flower_effect==1)
assert(evil:IsValid() and thorn:IsValid() and blocked:IsValid() and Inventory.Count(owner,'petals_evil')==0)
print('PASS PETALS: natural message fixture -> production HTTP decoder/chat/work -> native PICK/Pickable -> actual inventory -> exact delivery; evil/thorny/noninteractive excluded')
h=harness();ordinaryplant('berrybush','berries',2);ordinaryplant('berrybush','berries',3)
h:send('帮我采集2个浆果给我');run();assert(Inventory.Count(owner,'berries')==2)
print('PASS BERRIES: same generic Pickable/PICK/work/delivery path, no plant-specific task')
h=harness();ordinaryplant('modberrybush','modfruit',2)
h:send('帮我采1个自定义果实给我');run();assert(Inventory.Count(owner,'modfruit')==1)
print('PASS third-party standard pickable/product without registering an item or task branch')
h=harness();local b=ordinaryplant('berrybush','berries',2);b.components.pickable.stuck=true
assert(#Resources.Scan(friend,w:Position(),32,'berries','collect')==0)
b.components.pickable.stuck=nil;b.components.pickable.canbepicked=false
Resources.Observe(friend,w:Position(),32);assert(Knowledge.CanAcquire(friend,'berries'))
assert(w:RequestIntent({targets={{item='berries',quantity=1}},deliver=true},owner));run();assert(w.core.job.blocked and Inventory.Count(owner,'berries')==0)
assert(w.core.job.blocked.reason:find('找不到'))
print('PASS unready/stuck plant does not yield imaginary output; remembered supported source with no current usable object is a nearby-source condition')
h=harness();local berry=put(friend,'berries',1)
friend.components.eater={CanEat=function()return true end,PrefersToEat=function()return true end,DoFoodEffects=function()return true end,hungerabsorption=1,healthabsorption=1,sanityabsorption=1}
berry.components.edible={hungervalue=12.5,healthvalue=0,sanityvalue=0,GetHunger=function()return 12.5 end,GetHealth=function()return 0 end,GetSanity=function()return 0 end}
h:send('浆果有什么效果');assert(h:last():find('12.5') and not w.core.job and not action)
local axe=put(friend,'axe');h:send('斧头能做什么');assert(h:last():find('砍伐') and not w.core.job and not action)
h:send('石砖怎么制作');assert(h:last():find('3个石头') and h:last():find('每次产出1个') and h:last():find('科学1级') and not w.core.job and buildcalls==0)
local original=AllRecipes.cutstone.numtogive;AllRecipes.cutstone.numtogive=2
h:send('石砖怎么制作');assert(h:last():find('每次产出2个'));AllRecipes.cutstone.numtogive=original
h:send('花瓣有什么用途');assert(h:last():find('不能确定') and not w.core.job)
print('PASS read-only food actual component effects, tool actions, current material recipe/output/tech; unknown properties explicitly unknown, no job/build/action')
h=harness();local s=ordinaryplant('specialplant','specialfruit',2);s.tags.structure=true
h:send('帮我收集1个特殊果实给我');assert(not w.core.job and not action and h:last():find('不在我能安全采集'))
h:send('帮我弄1个不存在物品');assert(not w.core.job and not action and h:last():find('可靠识别'))
h:send('帮我采集1个同名果实');assert(not w.core.job and not action and h:last():find('多个对象'))
assert(#Knowledge.Names(friend,'同名果实')==2 and Knowledge.Resolve(friend,'fruit_a','明确fruit_a')=='fruit_a')
print('PASS unsupported known source vs unknown ID vs duplicate language name are separated, zero erroneous dispatch')
h=harness();local bad=ordinaryplant('dynamicplant','specialfruit',2);bad.components.pickable.use_lootdropper_for_product=true
bad.components.lootdropper={loot={'specialfruit'},lootsetupfn=function()error('knowledge must never execute custom lootsetupfn')end}
assert(#Knowledge.Sources(friend,bad)==0)
local craftcalls=0;AllRecipes.boards={name='boards',product='boards',ingredients={{type='log',amount=4}},numtogive=1,level={},override_numtogive_fn=function()craftcalls=craftcalls+1;error('do not call for knowledge')end}
local r=Knowledge.Recipes(friend,'boards')[1];assert(r.output_unknown and not r.output and craftcalls==0)
local forbidden=0;local oldspawn=SpawnPrefab;SpawnPrefab=function()forbidden=forbidden+1;error('no knowledge spawning')end
local packet=Knowledge.Context(friend,'石砖怎么制作',Resources.Observe(friend,w:Position(),32));assert(#packet.entries<=8 and #packet.nearby_sources<=12 and forbidden==0)
SpawnPrefab=oldspawn;AllRecipes.boards=nil
print('PASS no prefab spawning or dynamic loot/recipe callback execution during knowledge discovery; explicit unknown + bounded relevant context')
h=harness();plant('sapling','twigs',2);h:send('帮我收集1个树枝给我');run();assert(Inventory.Count(owner,'twigs')==1)
h=harness();ordinaryplant('flower','petals',2,true);ordinaryplant('flower','petals',3,true)
h:send('帮我采集2个花瓣给我');local j=w.core.job;tick();local stale=action
h:send('石砖怎么制作');assert(w.core.job==j and action==stale)
h:send('取消这个任务');assert(not w.core.job and not stale:Do());tick();assert(Inventory.Count(owner,'petals')==0)
print('PASS basic gathering regression; knowledge during work preserves identity/action; cancellation rejects queued PICK and retains inventory')
h=harness();local broken=ordinaryplant('broken_modplant','berries',2)
broken.components.pickable.CanBePicked=function()error('custom read failure')end
assert(#Knowledge.Sources(friend,broken)==0)
Knowledge.Context(friend,'石砖怎么制作',Resources.Observe(friend,w:Position(),32))
assert(not w.core.job and not action)
print('PASS failing custom source getter becomes unknown without disrupting read-only context or starting work')
