import sys,unittest,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'external'))
from decision import parse_decision,DecisionError
class SemanticSchema(unittest.TestCase):
 def query(self,kind='category',**extra):return json.dumps(dict(intent='query_knowledge',action='knowledge',dialogue='我查一下。',item=dict(name='黄金工具',kind=kind,**extra),quantity=None),ensure_ascii=False)
 def test_new_query_kinds(self):
  for kind in ('category','family','condition'):self.assertEqual(parse_decision(self.query(kind))[0],'knowledge')
 def test_grounded_expression_order(self):
  for style in ('direct','overview'):self.assertEqual(parse_decision(self.query(answer_style=style))[3]['answer_style'],style)
 def test_reject_unverified_answer_and_invalid_style(self):
  for extra in ({'answer_style':'invent'},{'facts':['made_up']},{'family_members':['fake']},{'answer_style':None}):
   with self.assertRaises(DecisionError):parse_decision(self.query(**extra))
 def test_queries_cannot_include_action_quantity(self):
  d=json.loads(self.query('condition'));d['quantity']=4
  with self.assertRaises(DecisionError):parse_decision(json.dumps(d))
