"""Real HTTP result receipts and provider envelope, simulated provider only."""
import sys,json,time,threading,unittest,urllib.request,urllib.error
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'external'))
import bridge
class ResultMemory(unittest.TestCase):
 def setUp(self):
  self.s=bridge.BridgeServer(('127.0.0.1',0));self.s.ai=True;self.s.api_key='SIMULATED-KEY';self.calls=[]
  self.thread=threading.Thread(target=self.s.serve_forever,daemon=True);self.thread.start();self.url='http://127.0.0.1:%d'%self.s.server_address[1];self.op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
  owner=self
  class Response:
   def __enter__(self):return self
   def __exit__(self,*a):pass
   def read(self,n):return json.dumps({'choices':[{'message':{'content':json.dumps(dict(intent='query_knowledge',action='knowledge',dialogue='我核对一下。',item={'name':'这个','kind':'identity'},quantity=None))}}]}).encode()
  def provider(req,timeout):owner.calls.append(json.loads(req.data));return Response()
  self.patch=patch.object(bridge,'urlopen',provider);self.patch.start()
 def tearDown(self):self.patch.stop();self.s.shutdown();self.s.server_close();self.thread.join(2)
 def request(self,path,data=None):
  req=urllib.request.Request(self.url+path,data=None if data is None else json.dumps(data).encode())
  try:
   with self.op.open(req,timeout=3) as r:return r.status,json.load(r)
  except urllib.error.HTTPError as e:return e.code,json.load(e)
 def submit(self,key,conversation='world:owner',friend='2',text='你知道独奏乐器吗'):
  data=dict(protocol=bridge.PROTOCOL,request_id=key,friend_id=friend,friend_name='朋友',message=text,conversation_id=conversation,result_receipts=True,game_state={})
  self.assertEqual(self.request('/tasks',data)[0],200)
  for _ in range(100):
   state=self.request('/tasks/'+key+'?instance='+self.s.instance_id)[1]
   if state['state']=='done':return state
   time.sleep(.005)
  self.fail('not done')
 def receipt(self,key,conversation='world:owner',friend='2',answer='独奏乐器会降低理智并让附近猪人和兔人成为随从。'):
  return self.request('/tasks/'+key+'/result?instance='+self.s.instance_id,dict(protocol=bridge.PROTOCOL,request_id=key,friend_id=friend,conversation_id=conversation,reply=answer,topics=['onemanband'],kind='knowledge'))
 def test_final_answer_only_and_idempotent(self):
  self.submit('a');self.assertNotIn(('world:owner','2'),self.s.histories)
  self.assertEqual(self.receipt('a')[0],200);self.assertTrue(self.receipt('a')[1]['duplicate'])
  history=self.s.histories[('world:owner','2')][1];self.assertEqual(len(history),2);self.assertIn('猪人',history[1]['content']);self.assertNotIn('未由聊天历史确认',history[1]['content'])
  self.submit('b',text='它是什么样的');self.assertIn('猪人',self.calls[-1]['messages'][1]['content']);self.assertEqual(len(self.calls),2)
 def test_identity_isolation_and_conflicts(self):
  self.submit('a');self.assertEqual(self.receipt('a',conversation='world:other')[0],403);self.assertEqual(self.receipt('a',friend='3')[0],403)
  self.assertEqual(self.receipt('a')[0],200);self.assertEqual(self.receipt('a',answer='不同答案')[0],409)
  self.submit('b',conversation='world:other');self.assertNotIn('猪人',self.calls[-1]['messages'][1]['content'])
  self.submit('c',friend='3');self.assertNotIn('猪人',self.calls[-1]['messages'][1]['content'])
 def test_non_none_result_never_saved_as_placeholder(self):
  self.submit('a');self.assertFalse(self.s.tasks['a'].get('remembered'));self.assertIsNone(self.s.tasks['a'].get('exchange'))
 def test_receipt_secret_redaction(self):
  self.submit('secret',text='你知道SIMULATED-KEY吗')
  self.assertEqual(self.receipt('secret',answer='SIMULATED-KEY 和 sk-abcdefghijklmnop')[0],200)
  history=json.dumps(self.s.histories[('world:owner','2')][1]);self.assertNotIn('SIMULATED-KEY',history);self.assertNotIn('sk-abcdefghijklmnop',history)
 def test_receipt_after_restart_rejected(self):
  self.submit('a');body=dict(protocol=bridge.PROTOCOL,request_id='a',friend_id='2',conversation_id='world:owner',reply='你好。')
  self.assertEqual(self.request('/tasks/a/result?instance='+'b'*32,body)[0],409)
