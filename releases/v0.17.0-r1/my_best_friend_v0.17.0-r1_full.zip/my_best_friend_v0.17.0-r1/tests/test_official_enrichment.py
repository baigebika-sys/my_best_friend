import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'developer_tools'))
from official_static_enrichment import literal_tree
from import_dst_knowledge import tokens
class StaticChecks(unittest.TestCase):
 def test_literal_tree_preserves_arrays_negative_and_unknown(self):
  v=literal_tree(tokens('{ a={prefab="a", health=100, sanity=-5, deps={"b","c"}, cond=callback(), count=2*3}, b={prefab="b"} }'))
  self.assertEqual(v['a']['deps'],['b','c']);self.assertEqual(v['a']['sanity'],-5)
  self.assertNotIn('cond',v['a']);self.assertNotIn('count',v['a'])
 def test_dotted_reference_not_made_literal(self):
  v=literal_tree(tokens('{ foo = TUNING.HEALTH, flag=true, str="{ callback() }" }'))
  self.assertNotIn('foo',v);self.assertTrue(v['flag']);self.assertEqual(v['str'],'{ callback() }')
