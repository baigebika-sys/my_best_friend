-- Full trusted official predicate tables; no callbacks other than pure test predicates run.
for k,v in pairs(OFFICIAL_TUNING)do TUNING[k]=v end
WORLD_TILES=setmetatable({},{__index=function(_,k)return k end});GROUND=WORLD_TILES;SEASONS=setmetatable({},{__index=function(_,k)return k end});FOODTYPE=setmetatable({},{__index=function(_,k)return k end});FOODGROUP={OMNI={},VEGETARIAN={}};STRINGS.NAMES=OFFICIAL_NAMES;STRINGS.WET_PREFIX={WET='Wet',GENERIC='Wet'}
local text=setmetatable({},{__index=function()return 'official localized effect omitted in simulation'end});STRINGS.UI={COOKBOOK=text}
deepcopy=function(t)if type(t)~='table'then return t end;local o={};for k,v in pairs(t)do o[k]=deepcopy(v)end;return o end
shallowcopy=function(t)local o={};for k,v in pairs(t)do o[k]=v end;return o end
ArrayUnion=function(a,b)local o={};for _,v in ipairs(a)do o[#o+1]=v end;for _,v in ipairs(b)do o[#o+1]=v end;return o end
package.path='tests/official_cooking_756039/?.lua;'..package.path
package.preload.tuning=function()return TUNING end
ACTIONS.COOK={id='COOK'};ACTIONS.HARVEST={id='HARVEST'}
dofile('tests/official_cooking_756039/actions_cooking.lua')
local C=require('cooking');local R=require('ybf_cooking_rules');local E=require('ybf_cooking_executor');local Marker=require('components/ybf_cook_marker');local Stewer=require('components/stewer')
ACTIONS.YBF_COOK_TASK={id='YBF_COOK_TASK',distance=2,fn=E.Perform}
local scheduled={}
local oldsetup=setup
setup=function()
 oldsetup();TheWorld.GUID=700;TheWorld.Map=TheWorld.Map or {};TheWorld.Map.IsPassableAtPoint=function()return true end;TheWorld.Map.IsPointNearHole=function()return false end;AllPlayers={owner};scheduled={}
 owner.userid='tester';owner.components.eater={CanEat=function()return true end,PrefersToEat=function()return true end};friend.components.eater=owner.components.eater
 owner.GetPosition=function()return Vector3(owner.x,0,owner.z)end
 friend.GetPosition=function()return Vector3(friend.x,0,friend.z)end
 SpawnPrefab=function(p)return transferitem(p,1)end
 friend.components.inventory.RemoveItem=remove;owner.components.inventory.RemoveItem=remove
end
local function pot(prefab)
 local e=entity(prefab or 'cookpot',3,0);e.components.container={inst=e,slots={},numslots=4,acceptsstacks=false,canbeopened=true}
 local c=e.components.container
 function c:IsOpenedByOthers()return self.opened or false end
 function c:IsFull()local n=0;for _,v in pairs(self.slots)do n=n+1 end;return n==4 end
 function c:CanTakeItemInSlot(it,slot)return R.Ingredient(it.prefab)and self.canbeopened and(not slot or not self.slots[slot])end
 function c:CanAcceptCount(it,n)local free=0;for k=1,4 do if not self.slots[k]then free=free+1 end end;return self:CanTakeItemInSlot(it)and math.min(n or it.n,free)or 0 end
 function c:GiveItem(it,slot)if not self:CanTakeItemInSlot(it,slot)or it.n~=1 then return false end;if not slot then for k=1,4 do if not self.slots[k]then slot=k;break end end end;if not slot then return false end;self.slots[slot]=it;it.components.inventoryitem.owner=e;return true end
 c.RemoveItem=remove;c.Close=function()end;c.IsOpen=function()return false end
 c.DestroyContents=function(self)for _,v in pairs(self.slots)do v:Remove()end;self.slots={}end
 function e:DoTaskInTime(delay,fn,...)
  local task={when=now+delay,fn=fn,args={...},inst=e};function task:Cancel()self.cancelled=true end;scheduled[#scheduled+1]=task;return task
 end
 e.components.stewer=Stewer(e);e.components.ybf_cook_marker=Marker(e);world[#world+1]=e;return e
end
local function tickcook(n)
 for _=1,n or 1 do now=now+.25;for _,task in ipairs(scheduled)do if not task.cancelled and not task.called and task.when<=now then task.called=true;task.fn(task.inst,table.unpack(task.args))end end
  w:Tick();if action then perform()end
 end
end
local function add(spec)local t,why=w.hub:Add('cook',spec,owner);assert(t,why);return t end
local function foodstock(list)for _,p in ipairs(list)do put(friend,p,1)end end
local function finish(task,n)for _=1,n or 1000 do tickcook();if task.state=='completed'or task.state=='blocked'then return end end;error('task never settles '..task.state..' '..tostring(task.reason))end
setup()
local idx=R.Index();local total=0;local potscount={};for _,row in ipairs(idx)do total=total+1;potscount[row.pot]=(potscount[row.pot]or 0)+1 end
local ingredient_count=0;for _ in pairs(C.ingredients)do ingredient_count=ingredient_count+1 end
print('INDEX ingredient identities='..ingredient_count)
print('INDEX official per-pot rows='..total..' ordinary='..potscount.cookpot..' portable='..potscount.portablecookpot..' spicer='..potscount.portablespicer)
local _,tags=R.Tags({'meat','smallmeat','carrot','berries'});assert(tags.meat==1.5 and tags.veggie==1 and tags.fruit==.5)
for _,list in ipairs({{'froglegs','carrot','berries','ice'},{'dragonfruit','carrot','carrot','twigs'},{'meat','meat','meat','ice'},{'monstermeat','monstermeat','berries','ice'},{'fish','twigs','twigs','ice'},{'egg','carrot','smallmeat','berries'}})do
 local candidates=R.Candidates('cookpot',list);assert(#candidates>0);for _=1,40 do local native=C.CalculateRecipe('cookpot',list);local found=false;for _,r in ipairs(candidates)do if r.name==native then found=true end end;assert(found)end
end
assert(R.Candidates('cookpot',{'froglegs','carrot','berries','ice'})[1].name=='frogglebunwich')
print('PASS official tags/priority and possible products agree with native random CalculateRecipe for unseen combinations')
setup();local p=pot();foodstock({'froglegs','carrot','berries','ice'});local t=add({quantity=1,recipe='frogglebunwich',destination='player',category='any'});finish(t);assert(t.state=='completed',t.reason);assert(Inventory.Count(owner,'frogglebunwich')==1 and t.done==1 and not p.components.stewer.product)
print('PASS unseen requested dish: actual load, native cook, wait, native harvest, actual gift counts')
setup();p=pot();foodstock({'dragonfruit','carrot','carrot','twigs'});t=add({quantity=1,category='vegetarian',destination='player'});finish(t);assert(t.state=='completed',t.reason);assert(t.product=='dragonpie'and Inventory.Count(owner,t.product)==1)
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,category='meat',destination='player'});finish(t);assert(t.state=='completed',t.reason)
print('PASS broad vegetarian/meat chooses deterministic official product from actual available ingredients')
setup();p=pot();t=add({quantity=1,recipe='frogglebunwich',category='any',destination='auto'});finish(t);assert(t.state=='blocked'and not p.components.stewer:IsCooking())
setup();p=pot();p.components.container.opened=true;foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,category='any',destination='auto'});finish(t);assert(t.state=='blocked')
print('PASS missing ingredients/occupied pot never consumes or gathers materials')
setup();p=pot();p.components.container:GiveItem(transferitem('froglegs',1),1);foodstock({'carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});finish(t);assert(t.state=='completed',t.reason)
print('PASS existing pot material reused with exact remaining slots')
setup();p=pot();p.components.stewer.done=true;p.components.stewer.product='dragonpie';foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});finish(t);assert(t.state=='completed'and Inventory.Count(owner,'dragonpie')==1 and t.done==1 and t.target_stored==1 and t.aux_stored==1)
print('PASS preexisting product harvested and preserved, not counted as new requested dish')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});for _=1,200 do tickcook();if t.started then break end end;assert(t.state=='waiting')
local worktask=w.hub:Add('work',spec({{item='twigs',quantity=1}},'player'),owner);put(friend,'twigs',1);tickcook(25);assert(worktask.state=='completed'and t.state=='waiting',worktask.reason)
finish(t);assert(t.state=='completed')
print('PASS long native cooking wait releases existing work engine to finish independent resource task')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});for _=1,200 do tickcook();if t.started then break end end;p.components.stewer.product=nil;tickcook(10);assert(t.state=='blocked'and t.done==0)
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});for _=1,200 do tickcook();if t.started then break end end;p.valid=false;tickcook(10);assert(t.state=='blocked')
print('PASS removed facility/disappearing product blocks without another ingredient consumption')
setup();local h=w.hub;assert(h:ShortReply(owner,'我饿了'));assert(#h.tasks==0);local prop=h:Pending(owner);assert(prop and prop.spec.quantity==1)
assert(h:ShortReply(owner,'要'));assert(#h.tasks==1);h:ShortReply(owner,'要');assert(#h.tasks==1)
setup();h=w.hub;h:ShortReply(owner,'我饿了');local expiry=h:Pending(owner).expires;h:ShortReply(owner,'天气不错');assert(h:Pending(owner).expires==expiry);now=now+61;h:ShortReply(owner,'要');assert(#h.tasks==0)
setup();h=w.hub;h:ShortReply(owner,'我饿了');h:ShortReply(owner,'不要');assert(not h:Pending(owner)and #h.tasks==0)
print('PASS proposal is inert, accepts once, rejects/expires, unrelated chat cannot refresh')
setup();p=pot();h=w.hub;foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});for _=1,200 do tickcook();if t.started then break end end
local saved=w:OnSave();local marker=p.components.ybf_cook_marker:OnSave();p.components.ybf_cook_marker:OnLoad(marker)
w:OnRemoveFromEntity();local nextwork=Work(friend);friend.components.ybf_work=nextwork;w=nextwork;w:OnLoad(saved);local restored=w.hub.tasks[1];finish(restored);assert(restored.state=='completed'and restored.done==1 and Inventory.Count(owner,'frogglebunwich')==1)
print('PASS persisted accepted wait relocates only its local persistent pot batch, native harvest once; short proposals not restored')
setup();h=w.hub;local a=h:Add('cook',{quantity=1},owner);local b=h:Add('work',spec({{item='twigs',quantity=1}},'player'),owner)
assert(h:Control(owner,{type='cancel',kind='cook'}));assert(a.state=='cancelled'and b.state=='queued')
h:Proposal(owner,{quantity=1,destination='player'});local another=entity('player');another.userid='another';assert(not h:Pending(another));local other=Work(friend);assert(not other.hub:Pending(owner))
print('PASS single-kind cancellation preserves independent task; per-player/per-friend proposal isolation')
-- Deterministic source-backed tie, not a fabricated competing recipe.
setup();local tied={'dragonfruit','butterflywings','carrot','berries'};local choices=R.Candidates('cookpot',tied);assert(#choices==2)
local stockrows={};for _,name in ipairs(tied)do stockrows[name]={count=1,cost=1}end
local solver=R.Search('cookpot',stockrows,{recipe='dragonpie'},owner);local plan,why
repeat local ok;ok,plan,why=coroutine.resume(solver);assert(ok)until coroutine.status(solver)=='dead'
assert(not plan and why:find('竞争',1,true));print('PASS equal-priority official competing dishes cannot be promised as deterministic')
setup();p=pot('portablecookpot');foodstock({'froglegs','froglegs','fish','berries'});t=add({quantity=1,recipe='frogfishbowl',destination='player'});finish(t);assert(t.state=='completed',t.reason)
print('PASS deployed portable cooker and an unseen special recipe use same executor')
setup();p=pot();local vault=chest('treasurechest',true);for _,name in ipairs({'froglegs','carrot','berries','ice'})do vault.components.container:GiveItem(transferitem(name,1))end
local icebox=chest('icebox',true);icebox.components.container.CanTakeItemInSlot=function()return true end
local saltbox=chest('saltbox',true);saltbox.components.container.CanTakeItemInSlot=function()return true end
local full=chest('icebox',true,nil,nil,0);full.components.container.CanTakeItemInSlot=function()return true end
t=add({quantity=1,recipe='frogglebunwich',destination='auto'});finish(t);assert(t.state=='completed'and stock(icebox,'frogglebunwich')==1 and stock(saltbox,'frogglebunwich')==0)
print('PASS friendship-only ingredient withdrawal and cooked-food refrigerator preference over saltbox; full alternative skipped')
setup();p=pot();p.components.container:GiveItem(transferitem('twigs',1),1);foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});finish(t);assert(t.state=='completed'and Inventory.Count(friend,'twigs')==1)
print('PASS incompatible pot ingredient returned to owned inventory, never destroyed to make a recipe')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});for _=1,200 do tickcook();if t.started then break end end
assert(w.hub:Control(owner,{type='cancel',target=t.id}));local batch=p.components.ybf_cook_marker.batch;tickcook(300);assert(t.state=='cancelled'and p.components.stewer:IsDone()and p.components.ybf_cook_marker.batch==batch and Inventory.Count(owner,'frogglebunwich')==0)
print('PASS cancelling processing leaves native cooking/product intact and stops automatic harvest')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});for _=1,200 do tickcook();if t.started then break end end
assert(w.hub:Control(owner,{type='pause',target=t.id}));tickcook(300);assert(t.paused and p.components.stewer:IsDone());assert(w.hub:Control(owner,{type='resume',target=t.id}));finish(t);assert(t.state=='completed')
setup();h=w.hub;h:Proposal(owner,{quantity=1,destination='player'});local prop=h:Pending(owner)
assert(h:Operations(owner,{{type='modify_proposal',quantity=2,category='vegetarian'}},nil,''));assert(prop.spec.quantity==2 and prop.spec.category=='vegetarian')
local oldid=prop.id;h:Proposal(owner,{quantity=1,destination='player'});h:ShortReply(owner,'要',oldid);assert(#h.tasks==0)
print('PASS processing pause/resume, proposal quantity/category edits and stale confirmation identity guard')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});for _=1,200 do tickcook();if t.started then break end end
p.components.stewer.done=true;p.components.stewer.targettime=nil;p.components.stewer:Harvest(owner);tickcook(12);assert(t.state=='blocked'and t.done==0)
print('PASS player harvest of original batch detected; not credited, not automatically recooked')
-- Both an ordinary and portable cooker: select the applicable native recipe table.
setup();local ordinary=pot();local portable=pot('portablecookpot');portable.x=5;foodstock({'froglegs','froglegs','fish','berries'});t=add({quantity=1,recipe='frogfishbowl',destination='player'});finish(t);assert(t.state=='completed'and portable.components.ybf_cook_marker.batch==1 and ordinary.components.ybf_cook_marker.batch==0)
print('PASS special dish selects compatible portable cooker instead of failing at nearer ordinary pot')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});vault=chest('treasurechest',true);for _,name in ipairs({'froglegs','carrot','berries','ice'})do vault.components.container:GiveItem(transferitem(name,1))end
t=add({quantity=1,recipe='frogglebunwich',destination='player',source='warehouse_only'});finish(t);assert(t.state=='completed',t.reason);for _,name in ipairs({'froglegs','carrot','berries','ice'})do assert(Inventory.Count(friend,name)==1 and stock(vault,name)==0)end
print('PASS warehouse-only uses four authorized withdrawn units, preserving preexisting identical owned ingredients')
setup();p=pot();local ordinarybox=chest('treasurechest',false);for _,name in ipairs({'froglegs','carrot','berries','ice'})do ordinarybox.components.container:GiveItem(transferitem(name,1))end;t=add({quantity=1,recipe='frogglebunwich',destination='player'});finish(t);assert(t.state=='blocked'and stock(ordinarybox,'froglegs')==1)
print('PASS ordinary chest never becomes a cooking material source')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice','froglegs','carrot','berries','ice'});t=add({quantity=2,recipe='frogglebunwich',destination='player'});finish(t);assert(t.state=='completed'and t.done==2 and t.stored==2 and p.components.ybf_cook_marker.batch==2)
print('PASS quantity two cooks two verified batches without reusing previous receipt')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='friend'});finish(t);assert(t.state=='completed'and w.hub:Protected('frogglebunwich')==1)
local fresh=add({quantity=1,category='any',destination='player'});local rows=E.Stock(w.hub,fresh,p);assert(not rows.frogglebunwich or rows.frogglebunwich.count==0)
print('PASS retained final food protected from future cooking stock and automatic eating')
setup();p=pot();vault=chest('treasurechest',true,1,'froglegs');t=add({quantity=1});t.friend=friend;t.external_reservation=true
local reserved=vault.components.container.slots[1];assert(Warehouse.Reserve(friend,w,t,reserved,1));local another=add({quantity=1});local rows=E.Stock(w.hub,another,p);assert(not rows.froglegs or rows.froglegs.count==0);E.Release(t);rows=E.Stock(w.hub,another,p);assert(rows.froglegs.count==1)
print('PASS shared live warehouse reservation prevents duplicate counting and cancellation releases stock')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});tickcook();assert(t.plan and action==nil or t.plan)
-- Change the native pot between planning and start; fingerprint forces a replan.
assert(p.components.container:GiveItem(transferitem('twigs',1)));finish(t);assert(t.state=='completed'and Inventory.Count(friend,'twigs')==1)
print('PASS player changes pot after planning: actual slots revalidated and incompatible material preserved')
local original=C.recipes.cookpot.frogglebunwich;local invoked=0;local overridden=shallowcopy(original);overridden.test=function()invoked=invoked+1;return true end;C.recipes.cookpot.frogglebunwich=overridden
R.Candidates('cookpot',{'froglegs','carrot','berries','ice'});assert(invoked==0);C.recipes.cookpot.frogglebunwich=original
print('PASS mod/replaced non-official predicate is never executed as knowledge probing')
setup();p=pot();foodstock({'royal_jelly','carrot','carrot','berries'});local native_spawn=SpawnPrefab
SpawnPrefab=function(name)local it=native_spawn(name);if it.components.stackable then it.components.stackable.SetStackSize=function(_,n)it.n=n end end;return it end
local refrigerator=chest('icebox',true,nil,nil,1);refrigerator.components.container.CanTakeItemInSlot=function()return true end
owner.components.inventory.CanAcceptCount=function()return 0 end
owner.components.trader.AcceptGift=function()error('full player must not be offered gift')end
t=add({quantity=3,recipe='jellybean',destination='auto'});finish(t);assert(t.state=='completed'and t.done==3 and t.stored==3 and stock(refrigerator,'jellybean')==1)
local ground=0;for _,it in ipairs(world)do if it.prefab=='jellybean'and not it.components.inventoryitem.owner then ground=ground+Inventory.Size(it)end end;assert(ground==2 and t.ground)
print('PASS official yield three: partial refrigerator storage, full player, verified safe-ground fallback without discarding equipment')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});w:Tick();assert(action and t.plan)
local stolen=I and I.Find and I.Find(friend,action.invobject.prefab)or Inventory.Find(friend,action.invobject.prefab);friend.components.inventory:RemoveItem(stolen,true);perform();finish(t);assert(t.state=='blocked'and p.components.ybf_cook_marker.batch==0 and t.done==0)
print('PASS player removes reserved ingredient before action: actual state fails safely and replans without starting wrong dish')
-- A distinct live friend shares the same authorized container and reservation table.
setup();p=pot();vault=chest('treasurechest',true,1,'froglegs');t=add({quantity=1});t.friend=friend;t.external_reservation=true;reserved=vault.components.container.slots[1];assert(Warehouse.Reserve(friend,w,t,reserved,1))
local firstfriend=friend;local firstwork=w;local firsttask=t;local shared=vault
setup();world[#world+1]=shared;p=pot();t=add({quantity=1});rows=E.Stock(w.hub,t,p);assert(friend~=firstfriend and w~=firstwork and(not rows.froglegs or rows.froglegs.count==0));E.Release(firsttask);rows=E.Stock(w.hub,t,p);assert(rows.froglegs.count==1)
print('PASS two distinct friends coordinate shared ingredients without locking out player container access')
setup();p=pot();foodstock({'froglegs','froglegs','carrot','red_cap','berries','berries','ice','ice'});t=add({quantity=2,recipe='frogglebunwich',destination='player'});finish(t);assert(t.state=='completed'and t.done==2)
print('PASS multiple batches may use different official valid ingredient combinations; no single fixed recipe tuple required')
setup();p=pot();vault=chest('treasurechest',true);for _,name in ipairs({'froglegs','carrot','berries','ice'})do vault.components.container:GiveItem(transferitem(name,1))end;t=add({quantity=1,recipe='frogglebunwich',source='warehouse_only',destination='player'});w:Tick();assert(action and action.ybf_cook.step=='withdraw');vault.components.container:RemoveItem(action.invobject,true);perform();finish(t);assert(t.state=='blocked'and p.components.ybf_cook_marker.batch==0)
print('PASS player removes actual reserved warehouse ingredient before withdrawal; no duplicate or wrong native cook')
local NativeEater=dofile('tests/official_cooking_756039/eater_conditions.lua')
local vegetarian={components={eater=setmetatable({caneat={FOODTYPE.VEGGIE},preferseating={FOODTYPE.VEGGIE},inst={HasTag=function()return true end}},{__index=NativeEater})}}
assert(R.Edible(C.recipes.cookpot.dragonpie,vegetarian)and not R.Edible(C.recipes.cookpot.frogglebunwich,vegetarian))
vegetarian.components.eater.preferseatingtags={'preparedfood'};assert(R.Edible(C.recipes.cookpot.dragonpie,vegetarian));vegetarian.components.eater.preferseatingtags={'unprovided_special_tag'};assert(not R.Edible(C.recipes.cookpot.dragonpie,vegetarian))
print('PASS actual official eater foodtype/preference methods enforce vegetarian and special-tag acceptance conservatively')
setup();Prefabs=Prefabs or {};Prefabs.twigs={};local waitingwork=w.hub:Add('work',spec({{item='twigs',quantity=1}},'player'),owner);waitingwork.paused=true;waitingwork.state='paused';put(friend,'twigs',1)
local first=w.hub:Add('work',spec({{item='twigs',quantity=1}},'player'),owner)
assert(w.hub:Operations(owner,{{type='status'},{type='resume',target=waitingwork.id,depends_on=1}},nil,''))
-- A status dependency has no work result and is immediate by definition.
assert(not waitingwork.paused)
setup();APP_VERSION='756039';Prefabs.twigs={};local paused=w.hub:Add('work',spec({{item='twigs',quantity=1}},'player'),owner);paused.paused=true;paused.state='paused';put(friend,'twigs',2)
local deferred_message=w.hub:Operations(owner,{{type='goal',goal=spec({{item='twigs',quantity=1}},'player')},{type='resume',target=paused.id,depends_on=1}},nil,'先给我树枝，再继续原任务');assert(deferred_message:find('已安排',1,true),deferred_message)
assert(paused.paused and #w.hub.tasks==3 and w.hub.tasks[3].kind=='control','deferred tasks='..#w.hub.tasks..' paused='..tostring(paused.paused));tickcook(40);assert(not paused.paused and Inventory.Count(owner,'twigs')==2 and w.hub.tasks[3].state=='completed')
print('PASS explicit deferred resume waits for prior real goal completion; status dependency remains immediate')

assert(R.Resolve('bonestew','煮一份肉汤给我')=='bonestew');assert(not R.Resolve('bonestew','来一份素菜'))
print('PASS cooking alias binds verified prefab to original expression, unrelated selected dish is rejected')

setup();local one=w.hub:Add('cook',{quantity=1,recipe='dragonpie'},owner);local two=w.hub:Add('cook',{quantity=1,recipe='dragonpie'},owner)
w.hub:Operations(owner,{{type='cancel',target=one.id}},nil,'取消刚才那个料理');assert(one.state~='cancelled'and two.state~='cancelled')
w.hub:Operations(owner,{{type='cancel',target=one.id}},nil,'取消任务 '..one.id);assert(one.state=='cancelled'and two.state~='cancelled')
print('PASS model-chosen task ID cannot bypass ambiguous current wording; explicit stable ID controls just one task')
setup();p=pot();p.components.container:GiveItem(transferitem('froglegs',1),1);vault=chest('treasurechest',true);for _,name in ipairs({'froglegs','carrot','berries','ice'})do vault.components.container:GiveItem(transferitem(name,1))end
t=add({quantity=1,recipe='frogglebunwich',source='warehouse_only',destination='player'});finish(t);assert(t.state=='completed'and Inventory.Count(friend,'froglegs')==1 and stock(vault,'froglegs')==0)
print('PASS warehouse-only preserves original pot ingredient instead of silently counting it as authorized warehouse supply')
setup();Prefabs.twigs={};local queued=w.hub:Add('work',spec({{item='twigs',quantity=1}},'player'),owner);assert(w.hub:Control(owner,{type='modify',target=queued.id,item='twigs',quantity=1,operation='add'}));assert(queued.spec.targets[1].quantity==2);put(friend,'twigs',2);tickcook(30);assert(queued.state=='completed'and Inventory.Count(owner,'twigs')==2)
setup();local removed=w.hub:Add('work',spec({{item='twigs',quantity=1}},'player'),owner);w.hub:Control(owner,{type='modify',target=removed.id,item='twigs',operation='remove'});assert(removed.state=='cancelled'and not w.core.job)
print('PASS queued goal add/remove reuses structured targets; stable task count and cancellation persisted without dispatch')
setup();queued=w.hub:Add('work',spec({{item='twigs',quantity=2}},'player'),owner);put(friend,'twigs',3);tickcook();assert(queued.job and (queued.job.given.twigs or 0)>0,'modified fixture must have delivered before edit');assert(w.hub:Control(owner,{type='modify',target=queued.id,item='twigs',quantity=3,operation='set'}));assert(queued.spec.targets[1].quantity==3);local serialized=w:OnSave();assert(serialized.tasks[1].spec.targets[1].quantity==3);tickcook(30);assert(queued.state=='completed'and not w.core.job and Inventory.Count(owner,'twigs')==3)
print('PASS running goal modification updates saved spec and cannot resurrect completed core job')
assert(not R.Resolve('bonestew','给我做一份辣的肉汤'));assert(not R.Resolve('dragonpie','帮我做一个极致火龙果派'));assert(R.Resolve('dragonpie','帮我弄一份火龙果派吧')=='dragonpie')
print('PASS cooking identity spans preserve unverified recipe qualifiers while allowing normal quantified speech')

-- r1: controlled preparation/action failures and real inventory-backed recovery.
setup();p=pot();vault=chest('icebox',true);vault.components.container.CanTakeItemInSlot=function(_,it)return R.Ingredient(it.prefab)end;for _,name in ipairs({'froglegs','carrot','berries','ice'})do vault.components.container:GiveItem(transferitem(name,1))end
t=add({quantity=1,recipe='frogglebunwich',source='warehouse_only',destination='player'});finish(t);assert(t.state=='completed'and t.done==1 and Inventory.Count(owner,'frogglebunwich')==1 and stock(vault,'froglegs')==0)
print('PASS r1 authorized refrigerator: actual withdraw/load/native start/wait/harvest/give full loop')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});w:Tick();local stale=action;assert(w.hub.inflight)
-- Native StopAction may synchronously fail the action. The old callback MUST already be invalid.
local clear=friend.ClearBufferedAction;friend.ClearBufferedAction=function(self)local old=action;clear(self);if old then old:Fail()end end
now=21;w:Tick();assert(t.state=='blocked'and not w.hub.inflight and not t.watch and not action);local attempt=t.attempt;stale:Fail();assert(t.state=='blocked'and t.attempt==attempt and not t.failures);assert(#notices>0)
local probe=add({quantity=1});assert(E.Stock(w.hub,probe,p).froglegs.count==1)
print('PASS r1 timeout announces, invalidates synchronous and late callbacks, releases ingredient/pot/listener claims')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich',destination='player'});sgtags.busy=true
for _=1,90 do now=now+.25;w:Tick()end
assert(t.state=='blocked'and not w.hub.inflight and sgtags.busy and #notices>0)
sgtags={};Prefabs.twigs={};put(friend,'twigs',1);local independent=w.hub:Add('work',spec({{item='twigs',quantity=1}},'player'),owner);tickcook(40);assert(independent.state=='completed'and Inventory.Count(owner,'twigs')==1)
print('PASS r1 pre-inflight long busy state bounded, not forcibly interrupted; independent goal still completes')
setup();local closed=add({quantity=1});closed.state='completed';local cancelled=add({quantity=1});cancelled.state='cancelled';local oldblocked=add({quantity=1});oldblocked.state='blocked';local current=add({quantity=1});current.state='running'
local msg,ok=w.hub:Control(owner,{type='cancel'});assert(ok and current.state=='cancelled'and oldblocked.state=='blocked'and closed.state=='completed')
print('PASS r1 unique executing cancellation ignores terminal history and does not cancel independent blocked task')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich'});w:Tick();stale=action;clear=friend.ClearBufferedAction;friend.ClearBufferedAction=function(self)local old=action;clear(self);if old then old:Fail()end end
assert(w.hub:Control(owner,{type='cancel',target=t.id}));stale:Fail();assert(t.state=='cancelled'and not w.hub.inflight and not t.failures and not t.watch)
print('PASS r1 cancel invalidates before synchronous failure, preserving actual materials without retry')

setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich'});for _=1,3 do w:Tick();assert(action);local failed=action;action=nil;failed:Fail()end
assert(t.state=='blocked'and not w.hub.inflight and not t.watch and #notices>0)
print('PASS r1 three unreachable/failed buffered actions report blocked stage and release claims')
setup();p=pot();foodstock({'froglegs','carrot','berries','ice'});t=add({quantity=1,recipe='frogglebunwich'});for _=1,3 do w:Tick();assert(t.plan and action);local stale=action;w.hub.inflight=nil;action=nil;t.attempt=t.attempt+1;p.components.container:GiveItem(transferitem('twigs',1));E.Replan(w.hub,t,'锅内材料反复变化')end
assert(t.state=='blocked'and #notices>0)
print('PASS r1 repeated planning invalidation has bounded retries without extending timeout')
