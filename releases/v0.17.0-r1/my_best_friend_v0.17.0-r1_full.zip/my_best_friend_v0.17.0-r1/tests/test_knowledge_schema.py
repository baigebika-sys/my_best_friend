"""Production read-only knowledge protocol and bounded state filtering."""
import json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'external'))
from decision import parse_decision,DecisionError
from dialogue import conversation_state
from intent_prompt import SYSTEM
class KnowledgeSchema(unittest.TestCase):
    def decision(self,**changes):
        data=dict(intent='query_knowledge',action='knowledge',dialogue='我查一下实际数据。',item={'name':'花瓣','kind':'properties'},quantity=None)
        data.update(changes);return json.dumps(data,ensure_ascii=False)
    def test_categories_and_original_localized_name(self):
        for kind in ('identity','properties','uses','recipe','sources','mechanisms','difference'):
            result=parse_decision(self.decision(item={'name':'第三方物品名','kind':kind}))
            self.assertEqual(result[0],'knowledge');self.assertEqual(result[3],{'name':'第三方物品名','kind':kind})
    def test_multiple_objects_and_limits(self):
        value={'names':['灼烧园艺锄','园艺锄','科学机器','独眼巨鹿'],'kind':'difference'}
        self.assertEqual(parse_decision(self.decision(item=value))[3],value)
        for names in ([],['x']*5,'axe',[True],['a'*121]):
            with self.subTest(names=names),self.assertRaises(DecisionError):parse_decision(self.decision(item={'names':names,'kind':'uses'}))
        with self.assertRaises(DecisionError):parse_decision(self.decision(item={'name':'斧头','names':['斧头'],'kind':'uses'}))
    def test_debug_redaction(self):
        from bridge import redacted_trace
        secret='actual-private-fixture-secret'
        result=redacted_trace({'original':'ask '+secret,'key':secret,'output':'sk-123456789abc','facts':['normal']},secret)
        self.assertNotIn(secret,json.dumps(result));self.assertNotIn('sk-123456789abc',json.dumps(result));self.assertEqual(result['facts'],['normal'])
    def test_query_cannot_carry_work_fields(self):
        for changes in ({'quantity':1},{'deliver':True},{'action':'goal'},{'mode':'obtain'},{'item':{'name':'花瓣','kind':'craft'}},{'item':{'name':'花瓣','kind':'properties','execute':True}}):
            with self.subTest(changes=changes),self.assertRaises(DecisionError):parse_decision(self.decision(**changes))
    def test_name_limits_and_types(self):
        for name in ('', 'a'*121, '花\n瓣', True, None, ['petals']):
            with self.subTest(name=name),self.assertRaises(DecisionError):parse_decision(self.decision(item={'name':name,'kind':'properties'}))
    def test_context_preserves_evidence_without_internal_task_fields(self):
        state={'knowledge':{'entries':[{'prefab':'petals','facts':{},'unknown':['完整用途'],'sources':[{'action':'pick','supported':True}]}]},'work':{'task':{'control_revision':3,'delivered':{'petals':1}}}}
        filtered=conversation_state(state)
        self.assertEqual(filtered['knowledge'],state['knowledge']);self.assertNotIn('control_revision',filtered['work']['task'])
    def test_prompt_separates_knowledge_and_execution(self):
        for phrase in ('query_knowledge','不执行挖植物','未知不是','knowledge.entries','重名'):
            if phrase=='未知不是':
                self.assertIn('属性未知',SYSTEM)
            else:self.assertIn(phrase,SYSTEM)
