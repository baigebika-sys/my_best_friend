"""Canned provider decisions for integration tests; NOT proof of model understanding."""
def goal(item='log',n=1,deliver=True,mode='obtain',existing=False,reference=None,forbidden=None):
    d=dict(intent='command_goal',action='goal',dialogue='我会检查后准备。',item=item,quantity=n,deliver=deliver,
           mode=mode,recipient='player' if deliver else 'friend',constraints=dict(existing_only=existing,forbidden=forbidden or []))
    if reference:d['reference']=reference
    return d

def reply(intent,action,item=None,n=None,reference=None,text='好，我在呢。'):
    d=dict(intent=intent,action=action,dialogue=text,item=item,quantity=n)
    if reference:d['reference']=reference
    return d

CASES={text:goal() for text in ['我想要1个木头','能给我1个木头吗','帮我弄一个木头','检一个木头']}
CASES.update({
 '收集1个木头，留在你那里':goal(deliver=False),
 '给我两个石砖':goal('cutstone',2),
 '给我制作两个石砖的材料':goal('cutstone',2,mode='materials'),
 '用现有材料做两个石砖':goal('cutstone',2,False,mode='craft',existing=True),
 '你会砍树吗':reply('question','none',text='会，我会准备斧头再砍树。'),
 '能帮我砍一棵树吗':reply('command_plan','plan',[dict(kind='tree',item='log',quantity=1)]),
 '别砍树了':reply('command_pause','pause','chop'),
 '如果以后缺木头，可以砍树':reply('chat','none',text='好，需要时再告诉我。'),
 '你好，今天开心吗':reply('chat','none',text='见到你很开心。'),
 '做到哪了':reply('query_progress','status'),
 '你带了些什么':reply('query_inventory','inventory'),
 '继续':reply('command_resume','resume',reference='current'),
 '改成两个':reply('command_modify','modify',n=2,reference='current'),
 '把木头改成两个':reply('command_modify','modify','log',2,reference='clarification'),
 '先别做了':reply('command_pause','pause',reference='current'),
 '取消这个任务':reply('command_cancel','cancel',reference='current'),
 '弄一个那个':reply('clarify','clarify',text='你说的是哪一种物品？'),
 '是木头，给我':goal(reference='clarification'),
 '这个还没确认的不要了':reply('command_cancel','cancel',reference='clarification'),
 '我想要一个石砖':goal('cutstone'),
 '我要3个木头':goal('log',3),
 '要两个木头两个草':goal([dict(item='log',quantity=2),dict(item='cutgrass',quantity=2)],None),
 '只捡一个木头，不砍树':goal(forbidden=['chop']),
 '帮我烹饪肉汤':reply('unsupported','unsupported',text='我知道你想要肉汤，但我目前还不会烹饪。'),
})
