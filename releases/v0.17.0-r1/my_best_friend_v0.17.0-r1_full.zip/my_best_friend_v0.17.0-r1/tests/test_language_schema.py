"""Strict goal/control protocol tests. No real model or DST claims."""
import sys,json,unittest
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'external'),str(Path(__file__).resolve().parent)]
from decision import parse_decision,DecisionError
from dialogue import conversation_state
from language_cases import goal,reply
class LanguageSchema(unittest.TestCase):
    def test_goal_dimensions(self):
        for mode in ('obtain','materials','craft'):
            for deliver in (False,True):
                d=goal('cutstone',2,deliver,mode,True)
                result=parse_decision(json.dumps(d));spec=result[3]
                self.assertEqual((spec['mode'],spec['deliver'],spec['recipient']),(mode,deliver,'player' if deliver else 'friend'))
                self.assertTrue(spec['constraints']['existing_only'])
    def test_invalid_constraints_references_and_quantities(self):
        changes=[{'mode':'cook'},{'recipient':'unknown','deliver':False},{'constraints':{'existing_only':'yes'}},
                 {'constraints':{'forbidden':['combat']}},{'constraints':{'extra':'SECRET-KEY'}},
                 {'reference':None},{'reference':'history'},{'quantity':True},{'quantity':0},{'quantity':'2'}]
        for change in changes:
            d=goal();d.update(change)
            with self.subTest(change=change),self.assertRaises(DecisionError) as ctx:parse_decision(json.dumps(d))
            self.assertNotIn('SECRET-KEY',json.dumps(ctx.exception.diagnostic()))
    def test_controls_normalized(self):
        for action in ('pause','resume','cancel','modify'):
            d=reply('command_'+action,action,n=2 if action=='modify' else None,reference='clarification')
            result=parse_decision(json.dumps(d));self.assertEqual(result[3]['reference'],'clarification')
        with self.assertRaises(DecisionError):parse_decision(json.dumps(reply('command_modify','modify',n=2.5)))
        with self.assertRaises(DecisionError):parse_decision(json.dumps(reply('command_pause','pause','combat')))
    def test_read_only_answers_reject_arguments(self):
        for intent,action in [('query_inventory','inventory'),('query_progress','status'),('clarify','clarify'),('unsupported','unsupported')]:
            self.assertEqual(parse_decision(json.dumps(reply(intent,action)))[0],action)
            with self.assertRaises(DecisionError):parse_decision(json.dumps(reply(intent,action,'log',1)))
    def test_context_keeps_local_progress_not_internal_revision(self):
        state={'work':{'task':{'status':'paused','control_revision':2,'delivered':{'log':1},'intent':{'targets':[{'item':'log','quantity':2}]}}},
               'conversation':{'clarification':{'original':'改成两个','question':'哪一个？'}}}
        clean=conversation_state(state);self.assertNotIn('control_revision',clean['work']['task'])
        self.assertEqual(clean['work']['task']['delivered']['log'],1);self.assertIn('clarification',clean['conversation'])
    def test_legacy_work_actions_rejected_at_provider_boundary(self):
        import bridge,time
        from unittest.mock import patch
        for action,item in [('pickup','log'),('collect','log'),('craft','cutstone'),('give','log')]:
            server=bridge.BridgeServer(('127.0.0.1',0));server.ai=True;server.api_key='SIMULATED-SECRET-KEY'
            decision=reply('command_'+action,action,item,1)
            class Provider:
                def __enter__(self):return self
                def __exit__(self,*args):pass
                def read(self,n):return json.dumps({'choices':[{'message':{'content':json.dumps(decision)}}]}).encode()
            try:
                with patch.object(bridge,'urlopen',lambda *args,**kw:Provider()):
                    server.submit(dict(protocol=bridge.PROTOCOL,request_id='legacy',friend_id='2',friend_name='朋友',message='协议检查'))
                    for attempt in range(100):
                        if not server.running:break
                        time.sleep(.005)
                result=server.lookup('legacy',server.instance_id)[1]
                self.assertEqual(result['diagnostic']['code'],'goal_contract_required');self.assertNotIn('action',result)
                self.assertNotIn(server.api_key,json.dumps(result))
            finally:server.server_close()
