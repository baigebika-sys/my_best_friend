"""Preset provider responses: these do not validate real language understanding."""
from language_cases import goal,reply
CASES={
 '帮我采集2个花瓣给我':goal('petals',2),
 '帮我采集2个浆果给我':goal('berries',2),
 '帮我采1个自定义果实给我':goal('modfruit',1),
 '花瓣有什么用途':reply('query_knowledge','knowledge',{'name':'花瓣','kind':'properties'}),
 '浆果有什么效果':reply('query_knowledge','knowledge',{'name':'浆果','kind':'properties'}),
 '斧头能做什么':reply('query_knowledge','knowledge',{'name':'斧头','kind':'properties'}),
 '石砖怎么制作':reply('query_knowledge','knowledge',{'name':'石砖','kind':'recipe'}),
 '帮我收集1个特殊果实给我':goal('specialfruit',1),
 '帮我弄1个不存在物品':goal('made_up_thing',1),
 '帮我采集1个同名果实':goal('fruit_a',1),
 '取消这个任务':reply('command_cancel','cancel',reference='current'),
 '帮我收集1个树枝给我':goal('twigs',1),
}

# Adversarial normalization responses and expanded read-only schemas (canned).
CASES.update({
 '灼烧园艺锄有什么用':reply('query_knowledge','knowledge',{'name':'园艺锄','kind':'uses'}),
 '园艺锄（灼烧）有什么用':reply('query_knowledge','knowledge',{'name':'园艺锄','kind':'uses'}),
 '园艺锄升级版有什么用':reply('query_knowledge','knowledge',{'name':'园艺锄','kind':'uses'}),
 '园艺锄和斧头有什么用':reply('query_knowledge','knowledge',{'names':['园艺锄','斧头'],'kind':'uses'}),
 '花瓣和斧头有什么用':reply('query_knowledge','knowledge',{'name':'花瓣','kind':'uses'}),
 '科学机器是什么':reply('query_knowledge','knowledge',{'name':'科学机器','kind':'identity'}),
 '独眼巨鹿有什么机制':reply('query_knowledge','knowledge',{'name':'独眼巨鹿','kind':'mechanisms'}),
 '斧孑有什么用':reply('query_knowledge','knowledge',{'name':'斧孑','kind':'uses'}),
 '灼烧园艺锄怎么获得':reply('query_knowledge','knowledge',{'name':'灼烧园艺锄','kind':'sources'}),
 '灼烧园艺锄和园艺锄有什么区别':reply('query_knowledge','knowledge',{'names':['灼烧园艺锄','园艺锄'],'kind':'difference'}),
 '帮我收集1个灼烧园艺锄':goal('fixture_hoe',1),
 '测试新增物和斧头有什么用':reply('query_knowledge','knowledge',{'names':['测试新增物','斧头'],'kind':'uses'}),
 '花瓣有什么用':reply('query_knowledge','knowledge',{'name':'斧头','kind':'uses'}),
 '园艺锄有什么用':reply('query_knowledge','knowledge',{'name':'园艺锄','kind':'uses'}),
})

CASES.update({
 '斧头有什么用':reply('question','none',text='斧头可以点火。'),
 '未识别测试对象有什么用':reply('question','none',text='编造的确定用途。'),
 '给我花瓣和斧头':goal('petals',1),
})
