"""Synthetic official-shaped inputs test analysis; not official coverage evidence."""
import ctypes as c, ctypes.util, hashlib,json,tempfile,unittest,zipfile,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'developer_tools'))
from import_dst_knowledge import import_data,audit,lua,po_names,literal,FACETS,write_bundle
from collect_dst_knowledge import collect
class ImportChecks(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  self.version=self.root/'version.txt';self.version.write_text('999001')
  self.source=self.root/'scripts.zip'
  with zipfile.ZipFile(self.source,'w') as z:
   z.writestr('scripts/prefabs/sample.lua', '''-- Prefab("comment_fake", fn)\nlocal s="Prefab('string_fake', fn)"\nlocal function fn()\n inst:AddComponent("pickable")\n inst.components.pickable:SetUp("fixture_petals", 10)\n error("never execute this")\nend\nreturn Prefab("fixture_flower",fn), Prefab("fixture_new",fn), Prefab(prefix.."dynamic",fn)''')
   z.writestr('scripts/strings.lua','STRINGS={NAMES={FIXTURE_FLOWER="Fixture flower",FIXTURE_NEW="New fixture"}}')
   z.writestr('scripts/languages/chinese_s.po','msgctxt "STRINGS.NAMES.FIXTURE_FLOWER"\nmsgid "Fixture flower"\nmsgstr "测试花"\n')
   z.writestr('scripts/recipes.lua','AddRecipe2("fixture_new", {Ingredient("fixture_petals", 3)}, TECH.SCIENCE_ONE)')
 def test_literal_identity_comments_strings_dynamic_and_names(self):
  data=import_data(self.source,self.version,None)
  self.assertEqual(set(data['entries']),{'fixture_flower','fixture_new'})
  row=data['entries']['fixture_flower'];self.assertEqual(row['names'],{'en':'Fixture flower','zh':'测试花'})
  self.assertTrue(data['manifest']['unresolved']);self.assertIsNone(data['manifest']['official_total'])
 def test_candidates_not_complete_and_no_execute(self):
  data=import_data(self.source,self.version,None);report=audit(data)
  self.assertEqual(report['complete_knowledge_records'],0);self.assertFalse(report['all_official_content_complete'])
  self.assertEqual(report['facets']['sources']['verified_objects'],0)
  self.assertEqual(report['facets']['sources']['candidate_only_objects'],2)
  self.assertTrue(data['entries']['fixture_new']['recipes'])
 def test_version_and_adapter_provenance_validation(self):
  adapter=self.root/'adapter.json';adapter.write_text(json.dumps({'build':'old','entries':{}}))
  with self.assertRaises(ValueError):import_data(self.source,self.version,None,adapter)
  adapter.write_text(json.dumps({'build':'999001','entries':{'fixture_flower':{'uses':[{'value':'unproven','certainty':'verified','version':'999001','kind':'reviewed_wiki','url':'https://example.org'}]}}}))
  with self.assertRaises(ValueError):import_data(self.source,self.version,None,adapter)
  self.version.write_text('v0.14.0')
  with self.assertRaises(ValueError):import_data(self.source,self.version,None)
 def test_verified_cited_adapter_separate_from_candidates(self):
  data=import_data(self.source,self.version,None);identity=data['entries']['fixture_flower']['identity']
  fact={**identity,'field':'description','value':'测试采摘来源','certainty':'verified'}
  adapter=self.root/'adapter.json';adapter.write_text(json.dumps({'build':'999001','entries':{'fixture_flower':{'uses':[fact]}}}))
  data=import_data(self.source,self.version,None,adapter);report=audit(data)
  self.assertEqual(report['facets']['uses']['verified_objects'],1)
  self.assertEqual(report['complete_knowledge_records'],0)
 def test_field_presence_does_not_mean_complete(self):
  data=import_data(self.source,self.version,None);identity=data['entries']['fixture_flower']['identity']
  adapter={'build':'999001','entries':{'fixture_flower':{'applicable_facets':list(FACETS),**{k:[{**identity,'field':'present','value':'one narrow fact','certainty':'verified'}] for k in FACETS}}}}
  path=self.root/'adapter.json';path.write_text(json.dumps(adapter))
  data=import_data(self.source,self.version,None,path)
  self.assertFalse(data['entries']['fixture_flower']['knowledge_complete']);self.assertEqual(audit(data)['complete_knowledge_records'],0)
 def test_dynamic_id_expansion_is_cited_and_universe_still_unknown(self):
  data=import_data(self.source,self.version,None);proof=data['entries']['fixture_flower']['identity']
  adapter={'build':'999001','identity_expansions':[{'prefab':'fixture_dynamic','source':proof,'reviewed_reason':'Synthetic loop expansion reviewed in test'}]}
  path=self.root/'adapter.json';path.write_text(json.dumps(adapter))
  data=import_data(self.source,self.version,None,path)
  self.assertIn('fixture_dynamic',data['entries']);self.assertIsNone(data['manifest']['official_total'])
 def test_lua_escape_semantics_are_not_python_octal(self):
  self.assertEqual(literal('"\\123"'),'{')
  self.assertIsNone(literal('"\\999"'))
  self.assertIn('\\001',lua({'control':'\x01'}))
 def test_po_multiline_and_fuzzy_translation(self):
  self.assertEqual(po_names('msgctxt "STRINGS.NAMES.X"\nmsgid "X"\nmsgstr "中"\n"文"\n\n#, fuzzy\nmsgctxt "STRINGS.NAMES.Y"\nmsgid "Y"\nmsgstr "不可信"\n'),{'x':'中文'})
 def test_collector_only_whitelisted_files_and_integrity(self):
  (self.root/'data').mkdir();(self.root/'data/scripts.zip').write_bytes(self.source.read_bytes())
  (self.root/'api_key.txt').write_text('DO-NOT-COLLECT');(self.root/'save').mkdir();(self.root/'save/world').write_text('private')
  output=self.root/'collected.zip';result=collect(self.root,output)
  with zipfile.ZipFile(output) as z:
   self.assertNotIn('api_key.txt',z.namelist());self.assertNotIn('save/world',z.namelist())
   for name,fact in result['files'].items():self.assertEqual(hashlib.sha256(z.read(name)).hexdigest(),fact['sha256'])
 def test_generated_bundle_loads_lazily_without_executing_source(self):
  library=c.util.find_library('lua5.4')
  if not library:self.skipTest('Lua 5.4 library unavailable; generated-data execution not verified')
  data=import_data(self.source,self.version,None);output=self.root/'generated';index=write_bundle(data,output)
  self.assertIn('detail_module',index['fixture_flower'])
  self.assertNotIn('properties',index['fixture_flower'])
  scripts=Path(__file__).resolve().parents[1]/'my_best_friend/scripts'
  program=('package.path='+lua(str(output/'?.lua')+';'+str(scripts/'?.lua'))+'; APP_VERSION="999001"; '
      'local store=require("ybf_knowledge_store"); local identity=store.Identity("fixture_flower"); '
      'assert(identity.names.zh=="测试花"); assert(package.loaded[identity.detail_module]==nil); '
      'local row=store.Entry("fixture_flower"); assert(package.loaded[identity.detail_module]~=nil); '
      'assert(row.prefab=="fixture_flower" and #row.sources>0); assert(#store.Facts("fixture_flower","sources")==0)')
  lib=c.CDLL(library);lib.luaL_newstate.restype=c.c_void_p
  lib.luaL_openlibs.argtypes=[c.c_void_p];lib.luaL_loadbufferx.argtypes=[c.c_void_p,c.c_char_p,c.c_size_t,c.c_char_p,c.c_char_p]
  lib.lua_pcallk.argtypes=[c.c_void_p,c.c_int,c.c_int,c.c_int,c.c_longlong,c.c_void_p]
  lib.lua_tolstring.argtypes=[c.c_void_p,c.c_int,c.POINTER(c.c_size_t)];lib.lua_tolstring.restype=c.c_char_p;lib.lua_close.argtypes=[c.c_void_p]
  state=lib.luaL_newstate();lib.luaL_openlibs(state);raw=program.encode()
  try:
   status=lib.luaL_loadbufferx(state,raw,len(raw),b'generated data safety',None)
   if not status:status=lib.lua_pcallk(state,0,0,0,0,None)
   self.assertEqual(status,0,lib.lua_tolstring(state,-1,None).decode() if status else '')
  finally:lib.lua_close(state)
 def test_actual_po_literal_tab_and_incomplete_record(self):
  from import_dst_knowledge import po_records
  text='msgctxt "STRINGS.SCRAPBOOK.SPECIALINFO.X"\nmsgid "Description"\nmsgstr "机制\t说明"\n'
  self.assertEqual(po_records(text)['STRINGS.SCRAPBOOK.SPECIALINFO.X']['msgstr'],'机制\t说明')
  with self.assertRaises(ValueError):po_records('msgctxt "STRINGS.NAMES.X"\nmsgid "X"\n')
 def test_generated_lua_cannot_inject_code(self):
  text=lua({'value':'"; error("execute") --\n','certainty':'candidate'})
  self.assertIn('\\n',text);self.assertIn('\\"',text)
if __name__=='__main__':unittest.main()
