APP_VERSION='756039'
Prefabs={cutstone={},boards={},rope={},twigs={}}
local h=harness()
h=harness();friend.components.inventory.RemoveItem=remove;owner.components.inventory.RemoveItem=remove;local e=chest('treasurechest',true,3,'rocks');friend.components.builder.known.cutstone=true
h:send('请给我一个石砖，材料箱子里有');assert(w.core.job,h:last());assert(w.core.job.source=='warehouse_first');run(200);assert(Inventory.Count(owner,'cutstone')==1)
h=harness();friend.components.inventory.RemoveItem=remove;owner.components.inventory.RemoveItem=remove;local e=chest('treasurechest',true,6,'rocks');friend.components.builder.known.cutstone=true
h:send('做两块石砖，只用箱子里的材料，做完放箱子里');assert(w.core.job,h:last());assert(w.core.job.source=='warehouse_only' and w.core.job.destination=='warehouse');run(300);assert(stock(e,'cutstone')==2)
h=harness();friend.components.inventory.RemoveItem=remove;owner.components.inventory.RemoveItem=remove;recipe('boards',{log=4},0);recipe('rope',{cutgrass=3},0);put(friend,'log',4);put(friend,'cutgrass',3)
h:send('做一个木板和一根绳子，我想修点东西');assert(w.core.job,h:last());assert(#w.core.job.targets==2);run(300);assert(Inventory.Count(owner,'boards')==1 and Inventory.Count(owner,'rope')==1)
h=harness();friend.components.inventory.RemoveItem=remove;owner.components.inventory.RemoveItem=remove;local e=chest('treasurechest',true,4,'log');plant('sapling','twigs',2);plant('sapling','twigs',3);plant('sapling','twigs',4)
h:send('帮忙备好一个木板和三根树枝，先用箱子里的，不够再找');assert(w.core.job,h:last());assert(#w.core.job.targets==2)
h:send('再加两个木板');assert(w.core.job.targets[1].quantity==3,h:last())
h:send('不要木板了');assert(#w.core.job.targets==1,h:last());h:send('加上两根树枝');assert(w.core.job.targets[1].quantity==5,h:last());w:Cancel()
print('PASS 0.15 storage permission/source/destination and mixed targets/control through production natural chat entry with canned model')
