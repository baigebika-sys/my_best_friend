-- Source-extracted DST build 756039 functions. Game entities/networking remain mocked.
return function(G)
 local ACTIONS=G.ACTIONS
 local GetGameModeProperty=function()return false end
 local EntityScript={};local PlayerActionPicker={};local Vector3={}
 local BufferedAction=G.BufferedAction
 local ACTION_COMPONENT_IDS={inventoryitem=1,container=2}
 local ACTION_COMPONENT_NAMES={'inventoryitem','container'}
 local COMPONENT_ACTIONS={USEITEM={inventoryitem = function(inst, doer, target, actions, right)
            local inventoryitem = inst.replica.inventoryitem

			if inventoryitem ~= nil and (inventoryitem:CanOnlyGoInPocket() or inventoryitem:IsLockedInSlot()) then
                --not tradable
            elseif inventoryitem ~= nil
                and (not inventoryitem:CanOnlyGoInPocketOrPocketContainers() or target.replica.inventoryitem ~= nil and target.replica.inventoryitem:CanOnlyGoInPocket())
                and (   (target.replica.container ~= nil and target.replica.container:CanBeOpened() and not target.replica.container:IsReadOnlyContainer()) or
                        (target.components.container_proxy ~= nil and target.components.container_proxy:CanBeOpened())
                        --container_proxy exists on clients too
                    )
                and inventoryitem:IsGrandOwner(doer) then
                if not (GetGameModeProperty("non_item_equips") and inst.replica.equippable ~= nil) and
                    (   (inst.prefab ~= "spoiled_food" and inst:HasTag("quagmire_stewable") and target:HasTag("quagmire_stewer") and target.replica.container:IsOpenedBy(doer)) or
                        not (target:HasTag("BURNABLE_fueled") and inst:HasTag("BURNABLE_fuel")) and
                        not target:HasTag("no_container_store")
                    ) then
					if target:HasTag("bundle") then
						table.insert(actions, ACTIONS.BUNDLESTORE)
					else
						--STORE action is mount_valid, but only allow for portable containers in our bags when mounted
						local rider = doer.replica.rider
						if rider and rider:IsRiding() then
							local target_inventoryitem = target.replica.inventoryitem
							if target_inventoryitem and target_inventoryitem:IsGrandOwner(doer) then
								table.insert(actions, ACTIONS.STORE)
							end
						else
							table.insert(actions, ACTIONS.STORE)
						end
					end
                end
            elseif inventoryitem and inventoryitem:CanOnlyGoInPocketOrPocketContainers() then
                -- Not tradable.
			elseif target.replica.constructionsite ~= nil and target.replica.constructionsite:IsEnabled() then
                if not (GetGameModeProperty("non_item_equips") and inst.replica.equippable ~= nil) and
                    not (target:HasTag("BURNABLE_fueled") and inst:HasTag("BURNABLE_fuel")) then
                    table.insert(actions, target.replica.constructionsite:IsBuilder(doer) and ACTIONS.BUNDLESTORE or ACTIONS.CONSTRUCT)
                end
            elseif target:HasTag("playerghost") then
                if inst:HasTag("reviver") then
                    table.insert(actions, ACTIONS.GIVETOPLAYER)
                end
            elseif target:HasAnyTag("player", "possessedbody") then
				if not right then
					local rider = target.replica.rider
					if not (rider and rider:IsRiding()) and
						not target:HasTag("wereplayer") and
                        (target:HasTag("possessedbody") or not (GetGameModeProperty("non_item_equips") and inst.replica.equippable))
					then
						local giveall
						if not (doer.components.playercontroller and doer.components.playercontroller:IsControlPressed(CONTROL_FORCE_STACK)) then
							local stackable = inst.replica.stackable
							giveall = stackable ~= nil and stackable:IsStack()
						end
						table.insert(actions, giveall and ACTIONS.GIVEALLTOPLAYER or ACTIONS.GIVETOPLAYER)
					end
                else
                    if target:HasTag("possessedbody") -- TODO: only for possessed bodies for now, but can expand to others?
                        and inst.replica.equippable ~= nil
                        and not inst.replica.equippable:IsRestricted(target) then
                        table.insert(actions, ACTIONS.EQUIPONBODY)
                    end
				end
			else
				local rider = doer.replica.rider
				if not (rider and rider:IsRiding()) then
					if target:HasTag("alltrader") then
						if not right then
							table.insert(actions, ACTIONS.GIVE)
						elseif doer.components.playercontroller and doer.components.playercontroller.isclientcontrollerattached then
							--V2C: -added this for trading torch to warg shrine, conflicts with LIGHT action.
							--     -kept this separate in case it breaks something else.
							table.insert(actions, ACTIONS.GIVE)
						end
					elseif inst:HasTag("reviver") and target:HasTag("ghost") then
						table.insert(actions, ACTIONS.GIVE)
					elseif inst:HasTag("boatcannon_ammo") and target:HasTag("boatcannon") and not target:HasAnyTag("burnt", "fire", "ammoloaded") then
						table.insert(actions, ACTIONS.BOAT_CANNON_LOAD_AMMO)
					elseif target:HasTag("inventoryitemholder_give") and not target:HasAnyTag("burnt", "fire") then
						table.insert(actions, ACTIONS.GIVE)
					end
				end
            end
        end},SCENE={container = function(inst, doer, actions, right)
            if inst:HasTag("bundle") then
                if right and inst.replica.container:IsOpenedBy(doer) then
                    table.insert(actions, doer.components.constructionbuilderuidata ~= nil and doer.components.constructionbuilderuidata:GetContainer() == inst and ACTIONS.APPLYCONSTRUCTION or ACTIONS.WRAPBUNDLE)
                end
            elseif not inst:HasTag("burnt")
                and inst.replica.container:CanBeOpened()
                and doer.replica.inventory ~= nil
                and (not inst:HasTag("oceantrawler") or not inst:HasTag("trawler_lowered"))
                and not (doer.replica.rider ~= nil and doer.replica.rider:IsRiding()) then
                table.insert(actions, ACTIONS.RUMMAGE)
            end
        end}}
 local AddComponentAction
 local MOD_COMPONENT_ACTIONS = {}
local MOD_ACTION_COMPONENT_NAMES = {}
local MOD_ACTION_COMPONENT_IDS = {}

local function ModComponentWarning(self, modname)
    print("ERROR: Mod component actions are out of sync for mod "..(modname or "unknown")..". This is likely a result of your mod's calls to AddComponentAction not happening on both the server and the client.")
    print("self.modactioncomponents is\n"..(dumptable(self.modactioncomponents) or ""))
    print("MOD_COMPONENT_ACTIONS is\n"..(dumptable(MOD_COMPONENT_ACTIONS) or ""))
end

local function CheckModComponentActions(self, modname)
    return MOD_COMPONENT_ACTIONS[modname] or ModComponentWarning(self, modname)
end

local function CheckModComponentNames(self, modname)
    return MOD_ACTION_COMPONENT_NAMES[modname] or ModComponentWarning(self, modname)
end

local function CheckModComponentIds(self, modname)
    return MOD_ACTION_COMPONENT_IDS[modname] or ModComponentWarning(self, modname)
end

function AddComponentAction(actiontype, component, fn, modname)
    if MOD_COMPONENT_ACTIONS[modname] == nil then
        MOD_COMPONENT_ACTIONS[modname] = { [actiontype] = {} }
        MOD_ACTION_COMPONENT_NAMES[modname] = {}
        MOD_ACTION_COMPONENT_IDS[modname] = {}
    elseif MOD_COMPONENT_ACTIONS[modname][actiontype] == nil then
        MOD_COMPONENT_ACTIONS[modname][actiontype] = {}
    end
    MOD_COMPONENT_ACTIONS[modname][actiontype][component] = fn
    table.insert(MOD_ACTION_COMPONENT_NAMES[modname], component)
    MOD_ACTION_COMPONENT_IDS[modname][component] = #MOD_ACTION_COMPONENT_NAMES[modname]
end

function EntityScript:RegisterComponentActions(name)
    local id = ACTION_COMPONENT_IDS[name]
    if id ~= nil then
        table.insert(self.actioncomponents, id)
        if self.actionreplica ~= nil then
            self.actionreplica.actioncomponents:set(self.actioncomponents)
        end
    end
    for modname, idmap in pairs(MOD_ACTION_COMPONENT_IDS) do
        id = idmap[name]
        if id ~= nil then
            if self.modactioncomponents == nil then
                self.modactioncomponents = { [modname] = {} }
            elseif self.modactioncomponents[modname] == nil then
                self.modactioncomponents[modname] = {}
            end
            table.insert(self.modactioncomponents[modname], id)
            if self.actionreplica ~= nil then
                self.actionreplica.modactioncomponents[modname]:set(self.modactioncomponents[modname])
            end
        end
    end
end


 function EntityScript:CollectActions(actiontype, ...)
    local t = COMPONENT_ACTIONS[actiontype]
    if t == nil then
        print("Action type", actiontype, "doesn't exist in the table of component actions. Is your component name correct in AddComponentAction?")
        return
    end
    for i, v in ipairs(self.actioncomponents) do
        local collector = t[ACTION_COMPONENT_NAMES[v]]
        if collector ~= nil then
            collector(self, ...)
        end
    end
    if self.modactioncomponents ~= nil then
        for modname, cmplist in pairs(self.modactioncomponents) do
            t = CheckModComponentActions(self, modname)
            t = t and t[actiontype] or nil
            if t ~= nil then
                local namemap = CheckModComponentNames(self, modname)
                for i, v in ipairs(cmplist) do
                    local collector = t[namemap[v]]
                    if collector ~= nil then
                        collector(self, ...)
                    end
                end
            end
        end
    end
end


 local function OrderByPriority(l, r)
    return l.priority > r.priority
end

-- All the action picker functions that do the heavy lifting run their resulting table through the SortActionList function
-- so we can just do the ghost action selection here, rather than littering it throughout the component.
function PlayerActionPicker:SortActionList(actions, target, useitem)
    if #actions == 0 then
        return actions
    end

    table.sort(actions, OrderByPriority)

    local ret = {}

    for i, v in ipairs(actions) do
        if self.actionfilter == nil or self.actionfilter(self.inst, v) then
            local distance = v == ACTIONS.CASTAOE and useitem ~= nil and useitem.components.aoetargeting ~= nil and useitem.components.aoetargeting:GetRange() or nil
            if target == nil then
                table.insert(ret, BufferedAction(self.inst, nil, v, useitem, nil, nil, distance, nil, nil))
            elseif target:is_a(EntityScript) then
                table.insert(ret, BufferedAction(self.inst, target, v, useitem, nil, nil, distance, nil, nil))
            elseif target:is_a(Vector3) then
                table.insert(ret, BufferedAction(self.inst, nil, v, useitem, target, nil, distance, nil, nil))
            end
        end
    end

    return ret
end


 function PlayerActionPicker:GetSceneActions(useitem, right)
    local actions = {}

    useitem:CollectActions("SCENE", self.inst, actions, right)

    if useitem ~= self.inst then
        if not right and useitem.inherentsceneaction ~= nil then
            table.insert(actions, useitem.inherentsceneaction)
        elseif right and useitem.inherentscenealtaction ~= nil then
            table.insert(actions, useitem.inherentscenealtaction)
        end
    end

    local sorted_acts = self:SortActionList(actions, useitem)

    if #sorted_acts == 0 and
        useitem ~= self.inst and
        (self.inst.CanExamine == nil or self.inst:CanExamine()) and
        useitem:HasTag("inspectable") and
        (self.inst.sg == nil or self.inst.sg:HasStateTag("moving") or self.inst.sg:HasStateTag("idle")) and
        (self.inst:HasTag("moving") or self.inst:HasTag("idle")) then

		--@V2C: #FORGE_AOE_RCLICK *searchable*
		--      -Forge used to strip ALL r.click actions, so now we manually strip WALKTO action.
		if not right or (self.inst.components.playercontroller ~= nil and not self.inst.components.playercontroller:HasAOETargeting()) then
			sorted_acts = self:SortActionList({ ACTIONS.WALKTO }, useitem)
		end
    end

    return sorted_acts
end


function PlayerActionPicker:GetUseItemActions(target, useitem, right)
    local actions = {}

    useitem:CollectActions("USEITEM", self.inst, target, actions, right)

    return self:SortActionList(actions, target, useitem)
end


 return {AddComponentAction=AddComponentAction,EntityScript=EntityScript,Picker=PlayerActionPicker}
end
