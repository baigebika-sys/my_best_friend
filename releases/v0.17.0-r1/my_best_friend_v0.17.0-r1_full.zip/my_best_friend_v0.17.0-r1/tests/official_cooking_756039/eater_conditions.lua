-- Exact official 756039 read-only food acceptance methods.
local Eater={}
function Eater:TestFood(food, testvalues)
    if food ~= nil and food.components.edible ~= nil then
        for i, v in ipairs(testvalues) do
            if type(v) == "table" then
                for i2, v2 in ipairs(v.types) do
                    if food:HasTag("edible_"..v2) then
                        return true
                    end
                end
            elseif food:HasTag("edible_"..v) then
                return true
            end
        end
    end
end

function Eater:PrefersToEat(food)
    if food.prefab == "winter_food4" and self.inst:HasTag("player") then
        --V2C: fruitcake hack. see how long this code stays untouched - _-"
        return false
    elseif self.nospoiledfood and (food.components.perishable and food.components.perishable:IsSpoiled()) then
        return false
    elseif self.preferseatingtags ~= nil then
        --V2C: now it has the warly hack for only eating prepared foods ;-D
        local preferred = food:HasAnyTag(self.preferseatingtags)
        if not preferred then
            return false
        end
    end
    return self:TestFood(food, self.preferseating)
end

function Eater:CanEat(food)
    return self:TestFood(food, self.caneat)
end


return Eater
