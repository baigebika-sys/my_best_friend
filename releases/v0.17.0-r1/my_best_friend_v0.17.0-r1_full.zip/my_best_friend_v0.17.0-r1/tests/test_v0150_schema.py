import json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'external'))
from decision import parse_decision,DecisionError
class StorageSchema(unittest.TestCase):
 def goal(self,**kw):
  d=dict(intent='command_goal',action='goal',dialogue='核对后处理',item='backpack',quantity=1,deliver=True);d.update(kw);return parse_decision(json.dumps(d))
 def test_shared_storage_fields_and_mixed_modes(self):
  r=self.goal(item=[{'item':'boards','quantity':2,'mode':'craft','destination':'warehouse'},{'item':'log','quantity':3,'mode':'obtain','destination':'player'}],quantity=None,destination='auto',constraints={'source':'warehouse_only'})
  self.assertEqual(r[3]['constraints']['source'],'warehouse_only');self.assertEqual(len(r[3]['targets']),2)
 def test_unknown_permissions_rejected(self):
  for kwargs in ({'constraints':{'source':'all_chests'}},{'destination':'ordinary_chest'},{'destination_guid':True},{'constraints':{'take_player_inventory':True}}):
   with self.subTest(kwargs=kwargs),self.assertRaises(DecisionError):self.goal(**kwargs)
 def test_target_changes(self):
  for op,n in [('add',2),('append',2),('remove',None)]:
   r=parse_decision(json.dumps(dict(intent='command_modify',action='modify',dialogue='调整',item='boards',quantity=n,operation=op)));self.assertEqual(r[3]['operation'],op)
 def test_remove_cannot_hide_quantity(self):
  with self.assertRaises(DecisionError):parse_decision(json.dumps(dict(intent='command_modify',action='modify',dialogue='调整',item='boards',quantity=2,operation='remove')))
