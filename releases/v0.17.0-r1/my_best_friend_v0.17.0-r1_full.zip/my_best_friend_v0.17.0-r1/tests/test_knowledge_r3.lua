-- Production ChatServer/Communication/Knowledge + actual 756039 catalog.
-- LANGUAGE_FIXTURES are production bridge-normalized canned model decisions.
APP_VERSION='756039'
local Knowledge=require('ybf_knowledge')
Prefabs={petals={},flower={},berries={},berrybush={},twigs={},pickaxe={},goldenpickaxe={}}
STRINGS.NAMES.PETALS='花瓣';STRINGS.NAMES.BERRIES='浆果'
local function cleananswer(text)
 assert(not text:find('prefab') and not text:find('TECH.') and not text:find('_') and not text:find('…'),text)
 assert(#text<=600,text)
end
local h=harness()
h:send('你知道独奏乐器吗');assert(h:last():find('猪人') and h:last():find('随从') and not w.core.job);cleananswer(h:last())
h:send('请简单介绍一下独奏乐器');assert(h:last():find('随从') and not w.core.job);cleananswer(h:last())
h:send('独奏乐器有什么用');assert(h:last():find('降低理智') and not w.core.job);cleananswer(h:last())
h:send('独奏乐器怎么做');assert(h:last():find('金') and h:last():find('猪皮') and h:last():find('4个噩梦燃料'))
local _,copies=h:last():gsub('制作独奏乐器需要','');assert(copies==1);cleananswer(h:last())
h:send('皮弗娄牛是牛吗');assert(h:last():find('皮弗娄牛') and not h:last():find('限定词'));cleananswer(h:last())
h:send('普通镐和黄金镐有什么区别');assert(h:last():find('33') and h:last():find('132') and h:last():find('材料'));cleananswer(h:last())
h:send('它怎么做');assert(h:last():find('哪一个') and h:last():find('黄金鹤嘴锄'));cleananswer(h:last())
h:send('黄金镐子');assert(h:last():find('4个树枝') and h:last():find('2个金') and not w.core.job)
h:send('水獭是什么');assert(h:last():find('生物') and h:last():find('食物'));cleananswer(h:last())
h:send('这是怎样的一种生物');assert(h:last():find('水獭') and h:last():find('食物'));cleananswer(h:last())
h:send('水獭在哪里');assert(h:last():find('窝点') and h:last():find('当前地图'));cleananswer(h:last())
h:send('暗影操控器是什么');assert(h:last():find('设施') and not w.core.job)
h:send('这个怎么做的');assert(h:last():find('3个活木') and h:last():find('1个紫宝石') and h:last():find('7个噩梦燃料'));cleananswer(h:last())
owner.userid='second-player';h:send('这个怎么做的');assert(h:last():find('哪一个') and not h:last():find('7个噩梦燃料'))
owner.userid='owner';h:send('这个怎么做的');assert(h:last():find('7个噩梦燃料'))
h:send('暗影甲有什么用');assert(h:last():find('暗夜甲') and h:last():find('虚空长袍') and not w.core.job);cleananswer(h:last())
h:send('科技是什么');assert(h:last():find('配方') and not h:last():find('识别'))
h:send('烧灼园艺锄怎么做');assert(h:last():find('4个树枝') and not h:last():find('普通版本'));cleananswer(h:last())
h:send('给我损坏的黄金镐');assert(not w.core.job and h:last():find('限定词'))
local Pickable=dofile('tests/reference/pickable_v0140.lua')
EntityScript={is_instance=function(e)return type(e)=='table' and e.GUID~=nil end};SpringGrowthMod=function(t)return t end
SpawnPrefab=function(prefab)local e=item(prefab,1);function e.components.inventoryitem:InheritWorldWetnessAtTarget()end;return e end
local flower=entity('flower',2);flower.components.pickable=Pickable(flower);flower.components.pickable:SetUp('petals',10,1);flower.components.pickable.remove_when_picked=true;function flower:DoTaskInTime()return {Cancel=function()end}end;world[#world+1]=flower
local second=entity('flower',3);second.components.pickable=Pickable(second);second.components.pickable:SetUp('petals',10,1);second.components.pickable.remove_when_picked=true;function second:DoTaskInTime()return {Cancel=function()end}end;world[#world+1]=second
h:send('你给我采点花瓣呗');assert(w.core.job and w.core.job.spec.targets[1].item=='petals');run();assert(Inventory.Count(owner,'petals')==1)
h:send('能不能帮我采一点花瓣呀');run();assert(Inventory.Count(owner,'petals')==2)
h:send('黄金镐子怎么制作');assert(h:last():find('4个树枝') and not w.core.job);cleananswer(h:last())
put(friend,'twigs',5);h:send('麻烦你捡一点树枝吧');run();assert(Inventory.Count(owner,'twigs')==1)
h:send('给我3个树枝');local j=w.core.job;tick();local stale=action;assert(j and stale)
h:send('先暂停一下');assert(w.core.job==j and j.blocked and not stale:Do())
h:send('取消任务吧');assert(not w.core.job)
assert(#h:receipts()>=18)
local receipt=h:receipts()[1];assert(receipt.reply:find('猪人') and receipt.topics[1]=='onemanband')
assert(not receipt.reply:find('执行结果未由聊天历史确认'))
print('PASS R3 natural chat entry: tone/qualified collection, introduction/uses/recipe, unified tool comparison, alias disambiguation, pronoun/pending follow-up, creature habitat, facility, concept, read-only and pause/cancel regressions; actual catalog, canned provider and mocked world')

local offline=h:send('你知道独奏乐器吗',true);h:fail(offline);assert(h:last():find('随从') and not w.core.job)
assert(not friend._ybf_knowledge_debug)
h:send('开启知识诊断');assert(h:last():find('已开启'))
h:send('普通镐和黄金镐有什么区别');assert(h:last():find('132') and not w.core.job)
local traces=Knowledge.Trace(friend);local original,selection,retrieval,final=false,false,false,false
for _,t in ipairs(traces) do
 assert(t.request_id)
 original=original or t.original=='普通镐和黄金镐有什么区别'
 selection=selection or t.model_selection~=nil
 retrieval=retrieval or t.retrieval~=nil
 final=final or t.final_answer~=nil
end
assert(original and selection and retrieval and final)
h:send('关闭知识诊断');assert(h:last():find('已关闭') and not w.core.job)
print('PASS provider transport unavailable: grounded local read-only answer; diagnostic toggles bypass provider')
