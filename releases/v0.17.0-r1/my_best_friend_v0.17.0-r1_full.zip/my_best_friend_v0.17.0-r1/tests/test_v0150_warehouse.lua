local original_perform=perform
perform=function()
 if action and action.target==nil then local a=action;local p=a.pos:GetPosition();friend.x=p.x;friend.z=p.z;local ok=a:Do();action=nil;return ok,a end
 return original_perform()
end
local Auth=require('ybf_friendship_containers');local Warehouse=require('ybf_warehouse')
local Grant=require('components/ybf_friendship_container')
TheWorld.Map={IsPassableAtPoint=function()return true end,IsPointNearHole=function()return false end}
for _,id in ipairs({'YBF_WITHDRAW','YBF_DEPOSIT','YBF_DROP'})do ACTIONS[id]={id=id,distance=2}end
ACTIONS.YBF_WITHDRAW.fn=function(a)return a.doer.components.ybf_work:PerformWarehouse(a)end
ACTIONS.YBF_DEPOSIT.fn=ACTIONS.YBF_WITHDRAW.fn
ACTIONS.YBF_DROP.fn=function(a)return a.doer.components.ybf_work:PerformGroundDelivery(a)end
local olditem=item
item=function(p,n)
 local e=olditem(p,n)
 e.Transform.SetPosition=function(_,x,y,z)e.x=x;e.z=z end
 if e.components.stackable then e.components.stackable.CanStackWith=function(_,it)return e.prefab==it.prefab end end
 e.components.inventoryitem.OnDropped=function()e.components.inventoryitem.owner=nil;world[#world+1]=e end
 return e
end
local function transferitem(p,n)
 local e=item(p,n);e.components.inventoryitem.OnDropped=function()e.components.inventoryitem.owner=nil;world[#world+1]=e end
 e.components.inventoryitem.OnRemoved=function()e.components.inventoryitem.owner=nil end
 return e
end
local function remove(c,it,whole)
 local slots=c.slots or c.itemslots
 for slot,v in pairs(slots)do if v==it then
  if not whole and it.components.stackable and it.n>1 then it.n=it.n-1;return transferitem(it.prefab,1) end
  slots[slot]=nil;it.components.inventoryitem.owner=nil;return it
 end end
end
local function setup()
 reset();friend.components.inventory.RemoveItem=remove;owner.components.inventory.RemoveItem=remove
end
local function chest(p,enabled,n,prefab,limit)
 local e=entity(p,2,0);e.components.ybf_friendship_container=Grant(e);e._ybf_friendship_net={set=function(_,v)e.net=v end,value=function()return e.net end}
 local c={inst=e,slots={},numslots=9,capacity=limit or 1000};e.components.container=c
 function c:CanTakeItemInSlot(it)
  return not self.readonlycontainer and (p~='icebox' and p~='saltbox' or it.prefab=='berries' or it.prefab=='petals')
 end
 function c:CanAcceptCount(it,n)local sum=0;for _,v in pairs(self.slots)do sum=sum+v.n end;return self:CanTakeItemInSlot(it) and math.min(n or it.n,self.capacity-sum) or 0 end
 function c:GiveItem(it)
  if self:CanAcceptCount(it,it.n)<it.n then return false end
  for _,v in pairs(self.slots)do if v.prefab==it.prefab and v.components.stackable then v.n=v.n+it.n;it:Remove();return true end end
  for k=1,self.numslots do if not self.slots[k]then self.slots[k]=it;it.components.inventoryitem.owner=e;return true end end
  return false
 end
 c.RemoveItem=remove
 e.components.ybf_friendship_container:SetEnabled(enabled)
 if n then local it=transferitem(prefab,n);c:GiveItem(it)end
 world[#world+1]=e;return e
end
local function stock(e,p)local n=0;for _,v in pairs(e.components.container.slots)do if v.prefab==p then n=n+v.n end end;return n end
local function spec(targets,destination,mode,source)
 return {targets=targets,deliver=destination=='player',destination=destination,mode=mode or 'obtain',constraints={source=source or 'default'}}
end
local function request(targets,destination,mode,source)return w:RequestIntent(spec(targets,destination,mode,source),owner)end
setup()
for _,p in ipairs({'treasurechest','dragonflychest','icebox','saltbox'})do
 local e=chest(p,true);local saved=e.components.ybf_friendship_container:OnSave();e.components.ybf_friendship_container:SetEnabled(false);assert(not Auth.Authorized(e));e.components.ybf_friendship_container:OnLoad(saved);assert(Auth.Authorized(e))
 local c=e.components.container;c.infinitestacksize=true;assert(Auth.Authorized(e) and e.components.container==c);e.components.ybf_friendship_container:SetEnabled(false);assert(not Auth.Authorized(e) and c.infinitestacksize)
end
print('PASS all four container grants/revokes/persistence; in-place infinite-stack upgrade preserves component; actual client and game upgrade animation NOT tested')
setup();local regular=chest('treasurechest',false,10,'rocks');assert(request({{item='rocks',quantity=1}},'player',nil,'warehouse_only'));run();assert(w.core.job.blocked and stock(regular,'rocks')==10 and Inventory.Count(owner,'rocks')==0)
setup();local e=chest('treasurechest',true,8,'rocks');friend.components.builder.known.cutstone=true;assert(request({{item='cutstone',quantity=2}},'warehouse','craft','warehouse_only'));run(300);assert(stock(e,'cutstone')==2 and stock(e,'rocks')==2 and buildcalls==2)
print('PASS ordinary container denied; authorized materials, real transfer quantity, generic craft and storage')
setup();local general=chest('treasurechest',true);local ice=chest('icebox',true);local salt=chest('saltbox',true);put(friend,'berries',3);put(friend,'twigs',2)
assert(request({{item='berries',quantity=3},{item='twigs',quantity=2}},'auto'));run(300);assert(stock(salt,'berries')==3 and stock(general,'twigs')==2 and stock(ice,'berries')==0)
setup();local full=chest('treasurechest',true,nil,nil,0);local partial=chest('dragonflychest',true,nil,nil,1);put(friend,'twigs',3)
assert(request({{item='twigs',quantity=3}},'auto'));run(200);assert(stock(partial,'twigs')==1 and Inventory.Count(owner,'twigs')==2)
setup();owner.components.inventory.capacity=0;chest('treasurechest',true,nil,nil,1);put(friend,'twigs',3);assert(request({{item='twigs',quantity=3}},'auto'));run(200)
local grounded=0;for _,it in ipairs(world)do if it.prefab=='twigs' and not it.components.inventoryitem.owner then grounded=grounded+it.n end end;assert(grounded==2 and notices[#notices]:find('放置位置'))
print('PASS salt/ice/general acceptance routing, full alternative, partial storage/player delivery and safe ground fallback')
setup();local e=chest('treasurechest',true,3,'rocks');assert(request({{item='rocks',quantity=3}},'player'));tick();local j=w.core.job;assert(j.step=='withdraw')
local other=entity('wilson',1);inventory(other);local oj={center={x=0,z=0},failed={}};local ow={radius=32,core={job=oj}};assert(Warehouse.Stock(other,oj,32,'rocks')==0)
assert(Warehouse.WithdrawTarget(other,ow,oj,'rocks',1)==nil);assert(w:PauseTask());assert(Warehouse.Stock(other,oj,32,'rocks')==3)
assert(w:ResumeGoal());tick();local stolen=e.components.container:RemoveItem(j.warehouse_item,true);assert(stolen);assert(not perform());run();assert(w.core.job.blocked and Inventory.Count(owner,'rocks')==0)
setup();local e=chest('treasurechest',true,3,'rocks');assert(request({{item='rocks',quantity=3}},'player'));tick();e.components.ybf_friendship_container:SetEnabled(false);assert(not perform());run();assert(Inventory.Count(owner,'rocks')==0)
print('PASS contested stock reservation, pause release, player removal recheck and revoke in flight')
setup();recipe('test_lens',{cutstone=2,twigs=1},0);put(friend,'rocks',9);put(friend,'twigs',3);friend.components.builder.known.cutstone=true
assert(w:RequestGoal({{item='test_lens',quantity=1},{item='rocks',quantity=3}},true,owner));run(300);assert(Inventory.Count(owner,'rocks')==3 and Inventory.Count(owner,'test_lens')==1 and buildcalls==3)
setup();recipe('test_band',{rope=1,boards=1},0);recipe('boards',{log=4},0);recipe('rope',{cutgrass=3},0);put(friend,'log',8);put(friend,'cutgrass',6)
assert(w:RequestGoal({{item='test_band',quantity=2}},true,owner));run(300);assert(Inventory.Count(owner,'test_band')==2 and buildcalls==6)
setup();recipe('test_denied',{rocks=1},0);AllRecipes.test_denied.builder_tag='not_a_friend';put(friend,'rocks',1);put(friend,'twigs',2)
assert(w:RequestGoal({{item='test_denied',quantity=1},{item='twigs',quantity=2}},true,owner));run(300);assert(Inventory.Count(owner,'twigs')==2 and buildcalls==0 and w.core.job.blocked)
print('PASS unlisted recipe families, multilevel intermediates, mixed raw/final protection and independent target progress when another is forbidden')
setup();plant('sapling','twigs',2);plant('sapling','twigs',3);plant('sapling','twigs',4);assert(w:RequestGoal({{item='twigs',quantity=3}},true,owner));local start=now
for i=1,3 do tick(35);assert(action);perform()end;run();assert(now-start>60 and Inventory.Count(owner,'twigs')==3)
setup();put(friend,'twigs',4);assert(w:RequestGoal({{item='twigs',quantity=1}},true,owner));assert(w:ModifyTask('twigs',2,'add'));assert(w.core.job.targets[1].quantity==3);assert(w:PauseTask());assert(w:ResumeGoal());run();assert(Inventory.Count(owner,'twigs')==3)
setup();put(friend,'twigs',2);assert(w:RequestGoal({{item='twigs',quantity=1},{item='rocks',quantity=1}},true,owner));w.core.job.spec=spec(w.core.job.targets,'player');assert(w:ModifyTask('rocks',nil,'remove'));run();assert(Inventory.Count(owner,'twigs')==1)
print('PASS progress beyond one minute, quantity add, target removal, pause/resume and cancellation regression remains in foundation suite')

local OFFICIAL_CASES={{["prefab"]="backpack",["recipe"]={["id"]="backpack",["ingredients"]={{["prefab"]="cutgrass",["amount"]=4},{["prefab"]="twigs",["amount"]=4}},["technology_expression"]="TECH.SCIENCE_ONE",["output_count"]=1,["conditions"]={},["condition_excerpts"]={},["requires_runtime_condition_check"]=true,["technology_levels"]={["SCIENCE"]=1}},["evidence"]={["path"]="scripts/recipes.lua",["line"]=515,["sha256"]="613747afca00328f1505a8fb174618e25976558010379d4d24e291d599d9d407",["version"]="756039"}},{["prefab"]="armorslurper",["recipe"]={["id"]="armorslurper",["ingredients"]={{["prefab"]="slurper_pelt",["amount"]=6},{["prefab"]="rope",["amount"]=2},{["prefab"]="nightmarefuel",["amount"]=2}},["technology_expression"]="TECH.MAGIC_THREE",["output_count"]=1,["conditions"]={},["condition_excerpts"]={},["requires_runtime_condition_check"]=true,["technology_levels"]={["MAGIC"]=3}},["evidence"]={["path"]="scripts/recipes.lua",["line"]=521,["sha256"]="613747afca00328f1505a8fb174618e25976558010379d4d24e291d599d9d407",["version"]="756039"}},{["prefab"]="razor",["recipe"]={["id"]="razor",["ingredients"]={{["prefab"]="twigs",["amount"]=2},{["prefab"]="flint",["amount"]=2}},["technology_expression"]="TECH.SCIENCE_ONE",["output_count"]=1,["conditions"]={},["condition_excerpts"]={},["requires_runtime_condition_check"]=true,["technology_levels"]={["SCIENCE"]=1}},["evidence"]={["path"]="scripts/recipes.lua",["line"]=404,["sha256"]="613747afca00328f1505a8fb174618e25976558010379d4d24e291d599d9d407",["version"]="756039"}},{["prefab"]="goldenpitchfork",["recipe"]={["id"]="goldenpitchfork",["ingredients"]={{["prefab"]="twigs",["amount"]=4},{["prefab"]="goldnugget",["amount"]=2}},["technology_expression"]="TECH.SCIENCE_TWO",["output_count"]=1,["conditions"]={},["condition_excerpts"]={},["requires_runtime_condition_check"]=true,["technology_levels"]={["SCIENCE"]=2}},["evidence"]={["path"]="scripts/recipes.lua",["line"]=403,["sha256"]="613747afca00328f1505a8fb174618e25976558010379d4d24e291d599d9d407",["version"]="756039"}},{["prefab"]="footballhat",["recipe"]={["id"]="footballhat",["ingredients"]={{["prefab"]="pigskin",["amount"]=1},{["prefab"]="rope",["amount"]=1}},["technology_expression"]="TECH.SCIENCE_TWO",["output_count"]=1,["conditions"]={},["condition_excerpts"]={},["requires_runtime_condition_check"]=true,["technology_levels"]={["SCIENCE"]=2}},["evidence"]={["path"]="scripts/recipes.lua",["line"]=504,["sha256"]="613747afca00328f1505a8fb174618e25976558010379d4d24e291d599d9d407",["version"]="756039"}},{["prefab"]="multitool_axe_pickaxe",["recipe"]={["id"]="multitool_axe_pickaxe",["ingredients"]={{["prefab"]="goldenaxe",["amount"]=1},{["prefab"]="goldenpickaxe",["amount"]=1},{["prefab"]="thulecite",["amount"]=2}},["technology_expression"]="TECH.ANCIENT_FOUR",["output_count"]=1,["conditions"]={["nounlock"]=true},["condition_excerpts"]={"{ nounlock = true }"},["requires_runtime_condition_check"]=true,["technology_levels"]={["ANCIENT"]=4}},["evidence"]={["path"]="scripts/recipes.lua",["line"]=806,["sha256"]="613747afca00328f1505a8fb174618e25976558010379d4d24e291d599d9d407",["version"]="756039"}}}
for _,sample in ipairs(OFFICIAL_CASES) do
 setup()
 local ingredients={};for _,v in ipairs(sample.recipe.ingredients)do ingredients[v.prefab]=v.amount end
 recipe(sample.prefab,ingredients,0,sample.recipe.output_count or 1)
 for p,n in pairs(ingredients)do put(friend,p,n)end
 assert(w:RequestGoal({{item=sample.prefab,quantity=1}},true,owner));run(400)
 assert(Inventory.Count(owner,sample.prefab)==1 and buildcalls==1,sample.prefab)
 print('PASS official unlisted item '..sample.prefab..' with source-backed recipe and simulated builder')
end

local OFFICIAL_UPGRADES={}
do
local DoUpgradeVisuals=function()end
local function OnUpgrade(inst, performer, upgraded_from_item)
    local numupgrades = inst.components.upgradeable.numupgrades
    if numupgrades == 1 then
        inst._chestupgrade_stacksize = true
        if inst.components.container ~= nil then -- NOTES(JBK): The container component goes away in the burnt load but we still want to apply builds.
            inst.components.container:Close()
            inst.components.container:EnableInfiniteStackSize(true)
            inst.components.inspectable.getstatus = regular_getstatus
        end
        if upgraded_from_item then
            -- Spawn FX from an item upgrade not from loads.
            local x, y, z = inst.Transform:GetWorldPosition()
            local fx = SpawnPrefab("chestupgrade_stacksize_fx")
            fx.Transform:SetPosition(x, y, z)
            -- Delay chest visual changes to match fx.
            local total_hide_frames = 6 -- NOTES(JBK): Keep in sync with fx.lua! [CUHIDERFRAMES]
            inst:DoTaskInTime(total_hide_frames * FRAMES, DoUpgradeVisuals)
        else
            DoUpgradeVisuals(inst)
        end
    end
    inst.components.upgradeable.upgradetype = nil

    if inst.components.lootdropper ~= nil then
        inst.components.lootdropper:SetLoot({ "alterguardianhatshard" })
    end
	inst.components.workable:SetOnWorkCallback(regular_Upgrade_OnHit)
	inst.components.workable:SetOnFinishCallback(regular_Upgrade_OnHammered)
	inst:ListenForEvent("restoredfromcollapsed", regular_Upgrade_OnRestoredFromCollapsed)
end

OFFICIAL_UPGRADES["treasurechest"]=OnUpgrade
end
do
local DoUpgradeVisuals=function()end
local function OnUpgrade(inst, performer, upgraded_from_item)
    local numupgrades = inst.components.upgradeable.numupgrades
    if numupgrades == 1 then
        inst._chestupgrade_stacksize = true
        if inst.components.container ~= nil then -- NOTES(JBK): The container component goes away in the burnt load but we still want to apply builds.
            inst.components.container:Close()
            inst.components.container:EnableInfiniteStackSize(true)
            inst.components.inspectable.getstatus = getstatus
        end
        if upgraded_from_item then
            -- Spawn FX from an item upgrade not from loads.
            local x, y, z = inst.Transform:GetWorldPosition()
            local fx = SpawnPrefab("chestupgrade_stacksize_taller_fx")
            fx.Transform:SetPosition(x, y, z)
            -- Delay chest visual changes to match fx.
            local total_hide_frames = 6 -- NOTES(JBK): Keep in sync with fx.lua! [CUHIDERFRAMES]
            inst:DoTaskInTime(total_hide_frames * FRAMES, DoUpgradeVisuals)
        else
            DoUpgradeVisuals(inst)
        end
    end
    inst.components.upgradeable.upgradetype = nil

    if inst.components.lootdropper ~= nil then
        inst.components.lootdropper:SetLoot({ "alterguardianhatshard" })
    end
	inst.components.workable:SetOnWorkCallback(upgrade_onhit)
	inst.components.workable:SetOnFinishCallback(upgrade_onhammered)
	inst:ListenForEvent("restoredfromcollapsed", OnRestoredFromCollapsed)
end

OFFICIAL_UPGRADES["dragonflychest"]=OnUpgrade
end
for _,p in ipairs({'treasurechest','dragonflychest'}) do
 setup();local e=chest(p,true,3,'rocks');local c=e.components.container
 c.EnableInfiniteStackSize=function(_,v)c.infinitestacksize=v end;c.Close=function()end
 e.components.upgradeable={numupgrades=1};e.components.inspectable={};e.components.workable={SetOnWorkCallback=function()end,SetOnFinishCallback=function()end}
 OFFICIAL_UPGRADES[p](e,nil,false)
 assert(e.components.container==c and c.infinitestacksize and stock(e,'rocks')==3 and Auth.Authorized(e))
 e.components.ybf_friendship_container:OnLoad(e.components.ybf_friendship_container:OnSave());assert(Auth.Authorized(e))
end
print('PASS actual supplied official chest upgrade function branches preserve original authorization/content; visual helper stubbed')
