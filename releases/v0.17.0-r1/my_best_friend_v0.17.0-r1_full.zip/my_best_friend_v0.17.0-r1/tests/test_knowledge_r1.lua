-- Synthetic scenarios exercise identity semantics, not actual special-hoe lore.
-- No current official build or new-content source is available in this workspace.
Prefabs.fixture_hoe={};STRINGS.NAMES.FIXTURE_HOE='园艺锄'
h=harness();put(friend,'fixture_hoe');put(friend,'axe')
h:send('灼烧园艺锄有什么用');assert(h:last():find('限定词') and not w.core.job and not action)
h:send('园艺锄（灼烧）有什么用');assert(h:last():find('限定词') and not w.core.job)
h:send('园艺锄升级版有什么用');assert(h:last():find('限定词') and not w.core.job)
h:send('园艺锄和斧头有什么用');assert(h:last():find('园艺锄') and h:last():find('斧头') and h:last():find('砍伐') and not w.core.job)
local names=Knowledge.Mentions(friend,'园艺锄和斧头有什么用');assert(#names==2)
assert(not Knowledge.Resolve(friend,'axe','花瓣有什么用'))
h:send('花瓣有什么用');assert(h:last():find('原句不一致') and not w.core.job)
h:send('斧孑有什么用');assert(h:last():find('错字') and not w.core.job)
print('PASS R1 unresolved prefix/suffix/bracket qualifiers cannot silently normalize; multiple spans survive; unrelated model ID rejected; typo requires confirmation')
-- Independent prefab, same-prefab display state, and skin are three separate scenarios.
Prefabs.fixture_scorched_hoe={};STRINGS.NAMES.FIXTURE_SCORCHED_HOE='灼烧园艺锄'
Knowledge.ObserveInventory(friend)
assert(Knowledge.Resolve(friend,'fixture_hoe','灼烧园艺锄有什么用')==nil)
assert(Knowledge.Resolve(friend,'fixture_scorched_hoe','灼烧园艺锄有什么用')=='fixture_scorched_hoe')
Prefabs.fixture_scorched_hoe=nil;STRINGS.NAMES.FIXTURE_SCORCHED_HOE=nil
h=harness();local hoe=put(friend,'fixture_hoe');hoe.GetDisplayName=function()return '灼烧园艺锄' end
h:send('灼烧园艺锄怎么获得');assert(h:last():find('来源') and not w.core.job)
h:send('灼烧园艺锄和园艺锄有什么区别');assert(h:last():find('共用同一 prefab') and not w.core.job)
h:send('帮我收集1个灼烧园艺锄');assert(not w.core.job and not action and h:last():find('变体'))
print('PASS R1 independent-prefab fixture is not base prefab; observed display name stays same prefab and cannot authorize base-version work; comparison retains both expressions')
local Store=require('ybf_knowledge_store');local oldmanifest=Store.data.manifest
Store.data.manifest={build='999001',status='synthetic_fixture'};APP_VERSION='999001'
local function staticrow(p,n,facet,value)
 Store.data.entries[p]={prefab=p,names={zh=n},category='fixture',knowledge_complete=false,identity={kind='synthetic_test',version='999001'},[facet]={{field='description',value=value,certainty='verified',kind='synthetic_test',version='999001'}}}
end
staticrow('fixture_new','测试新增物','uses','合成测试资料：此对象没有普通配方，用途来自集中知识条目。')
staticrow('deerclops','独眼巨鹿','mechanisms','合成测试资料：此处验证生物机制检索，不代表游戏实测。')
staticrow('petals','花瓣','uses','合成测试资料：普通花的采摘产物。')
Prefabs.researchlab={};STRINGS.NAMES.RESEARCHLAB='科学机器';Prefabs.deerclops={};STRINGS.NAMES.DEERCLOPS='独眼巨鹿'
h=harness();put(friend,'axe')
local machine=entity('researchlab',2);machine.tags.structure=true;machine.components.prototyper={};world[#world+1]=machine
local giant=entity('deerclops',3);giant.components.health={maxhealth=4000};giant.components.combat={};world[#world+1]=giant
h:send('科学机器是什么');assert(h:last():find('设施') and not w.core.job and not action)
h:send('独眼巨鹿有什么机制');assert(h:last():find('生物机制检索') and not w.core.job and not action)
h:send('测试新增物和斧头有什么用');assert(h:last():find('没有普通配方') and h:last():find('砍伐') and not w.core.job)
h:send('花瓣和斧头有什么用');assert(h:last():find('花瓣') and h:last():find('斧头') and h:last():find('砍伐') and not w.core.job)
assert(not h:last():find('配方'))
APP_VERSION='different_build';Knowledge.ObserveInventory(friend)
local result=Knowledge.Answer(friend,'测试新增物','uses','测试新增物有什么用')
assert(not result:find('合成测试资料') and result:find('构建版本'))
APP_VERSION='999001';Store.data.entries.fixture_new.variants={{value={kind='skin',name='装饰测试新增物'},summary='合成皮肤说明',certainty='verified',version='999001'}}
Knowledge.ObserveInventory(friend)
assert(Knowledge.Resolve(friend,'装饰测试新增物','装饰测试新增物有什么用')=='fixture_new')
local p,code=Knowledge.Resolve(friend,'装饰测试新增物','装饰测试新增物给我',true);assert(not p and code=='variant_execution_unsupported')
print('PASS R1 item/facility/creature read-only retrieval, recipe-less identity, mixed fixture-era query; version mismatch suppresses facts; explicit skin binding does not create independent prefab')
Knowledge.SetDebug(friend,true);Knowledge.Answer(friend,'科学机器','identity','科学机器是什么')
local trace=Knowledge.Trace(friend);assert(#trace>=2 and trace[1].original=='科学机器是什么' and trace[1].prefab=='researchlab' and trace[1].expressions)
Knowledge.SetDebug(friend,false);assert(#Knowledge.Trace(friend)==0)
Store.data.entries.fixture_new=nil;Store.data.entries.deerclops=nil;Store.data.entries.petals=nil;Store.data.manifest=oldmanifest;APP_VERSION=nil
h=harness();ordinaryplant('flower','petals',2,true);h:send('帮我采集2个花瓣给我');tick();local j=w.core.job;local pending=action
h:send('园艺锄有什么用');assert(w.core.job==j and action==pending)
h:send('取消这个任务');assert(not w.core.job and not pending:Do())
print('PASS R1 debug trace opt-in/clear, query preserves live gather/action, cancellation rejects queued action; all are local simulations')

h=harness();local rawfood=put(friend,'berries',1)
rawfood.components.edible={hungervalue=12.5,healthvalue=0,sanityvalue=0,GetHunger=function()error('knowledge must not execute arbitrary food getter')end}
local rawaxe=put(friend,'axe');rawaxe.components.tool.GetEffectiveness=function()error('knowledge must read actions table, not custom getter')end
rawaxe.components.finiteuses.GetUses=function()error('knowledge must read numeric current field')end
Knowledge.ObserveInventory(friend)
assert(Knowledge.Entry(friend,'berries').facts.food_base.hunger==12.5)
assert(#Knowledge.Entry(friend,'axe').facts.tool_actions==1)
local coverage=Knowledge.Coverage(friend);assert(coverage.runtime_is_not_official_universe and coverage.official_total==nil and coverage.static_identity_records==0)
print('PASS R1 knowledge reads plain food/tool/durability fields without custom callback execution; runtime coverage is not claimed as official completeness')

h=harness();put(friend,'axe');h:send('斧头有什么用')
assert(h:last():find('砍伐') and not h:last():find('点火') and not w.core.job and not action)
h:send('未识别测试对象有什么用');assert(h:last():find('可靠识别') and not h:last():find('编造'))
h:send('给我花瓣和斧头');assert(not w.core.job and h:last():find('所有目标'))
STRINGS.NAMES.FIXTURE_HOE='Garden Hoe';Knowledge.ObserveInventory(friend)
assert(Knowledge.Resolve(friend,'garden hoe','what is garden hoe')=='fixture_hoe')
STRINGS.NAMES.FIXTURE_HOE='园艺锄'
print('PASS R1 local read-only fallback blocks model lore in chat route, unknown object stays unknown, omitted work target requires confirmation, English name matching folds case')

assert(Knowledge.GenericTreeRequest(friend,'能帮我砍一棵树吗'))
assert(not Knowledge.GenericTreeRequest(friend,'砍一棵灼烧树'))
assert(not Knowledge.GenericTreeRequest(friend,'砍一棵常青树'))
print('PASS R1 generic tree intent remains available, unresolved named/tree variants cannot authorize arbitrary ordinary trees')

local original_manifest=Store.data.manifest;Store.data.manifest={build='999001'};APP_VERSION='999001'
Store.data.entries.fixture_conflict={properties={
 {semantic_key='damage',value=10,certainty='verified',version='999001',kind='reviewed_wiki'},
 {semantic_key='damage',value=20,certainty='verified',version='999001',kind='reviewed_wiki'},
 {semantic_key='damage',value=30,certainty='verified',version='999001',kind='official_script'}}}
local selected=Store.Facts('fixture_conflict','properties');assert(#selected==1 and selected[1].value==30)
table.insert(Store.data.entries.fixture_conflict.properties,{semantic_key='damage',value=40,certainty='verified',version='999001',kind='official_script'})
local facts,conflicts=Store.Facts('fixture_conflict','properties');assert(#facts==0 and #conflicts==1)
Store.data.entries.fixture_conflict=nil;Store.data.manifest=original_manifest;APP_VERSION=nil
print('PASS R1 current implementation outranks conflicting external facts; unresolved implementation conflicts become gaps, not invented certainty')

Knowledge.SetDebug(friend,true);Knowledge.Diagnostic(friend,{original='sk-test-secret-fixture',token='private-token-fixture'})
local log=Knowledge.Trace(friend);assert(log[#log].original=='[redacted]' and log[#log].token=='[redacted]')
Knowledge.SetDebug(friend,false)
print('PASS R1 in-memory and printed knowledge diagnostics redact key-shaped strings and credential fields')

h=harness();local repeat_names=string.rep('花瓣和',30)..'斧头有什么用'
local limited=Knowledge.Context(friend,repeat_names,{})
assert(#limited.name_expressions<=8 and #limited.name_issues<=8 and limited.expression_count>8 and limited.name_context_truncated)
assert(#Knowledge.Expressions(friend,repeat_names)>8)
print('PASS R1 request name metadata bounded; full original expressions remain available to authoritative local resolver')

h=harness();local far=ordinaryplant('far_fixture_flower','petals',1000,true)
local farpacket=Knowledge.Context(friend,'花瓣怎么获得',{far})
assert(#farpacket.nearby_sources==0 and not Knowledge.Perceived(friend,far))
print('PASS R1 knowledge positions and newly observed objects require current friend perception, not task-origin or static-map guesses')
