-- Prepended with the existing world fixture. LANGUAGE_FIXTURES are actual HTTP
-- results from production bridge + decoder with a canned provider, not plans.
local Communication=require('ybf_communication')
local ChatServer=require('ybf_chat_server')
local function harness()
 reset()
 owner.userid='owner';friend.components.health={IsDead=function()return false end}
 local flower=entity('ybf_friendship_flower');flower.tags.ybf_friendship_flower=true
 flower.components.inventoryitem={GetGrandOwner=function()return owner end};flower._ybf_friend=friend
 friend.components.ybf_friend.flower=flower;friend.components.ybf_friend.name='朋友';friend.components.ybf_friend.active=true
 local game=entity('world');game.state={cycles=0};local seq=0;local wires={};local pending={};local replies={}
 local function encode(d)seq=seq+1;wires[tostring(seq)]=d;return tostring(seq)end
 local G={Ents={[flower.GUID]=flower},EQUIPSLOTS=EQUIPSLOTS,math=math,GetTimeReal=function()return now*1000 end,
  json={encode_compliant=encode,decode=function(raw)return wires[raw]end},TheNet={Announce=function()end},GetClientModRPC=function()return {}end,
  SendModRPCToClient=function(_,_,raw)local r=wires[raw];if r.kind=='reply' or r.kind=='error' then replies[#replies+1]=r.text end end,
  TheSim={QueryServer=function(_,url,cb,method,body)
   if method=='POST' and url:match('/tasks$') then pending[#pending+1]={packet=wires[body],callback=cb}
   elseif url:find('/cancel',1,true) then cb('',true,200) end
  end}}
 local chat=ChatServer.New(G,game,Communication);local count=0
 local h={}
 function h:send(text,defer)
  now=now+1;count=count+1
  chat:Send(owner,text,'朋友','natural-'..count,friend.GUID)
  local request=pending[#pending];assert(request.packet.message==text)
  if not defer then self:finish(request)end
  return request
 end
 function h:finish(request,override)
  local normalized=override or assert(LANGUAGE_FIXTURES[request.packet.message]);local p=request.packet
  local result={protocol=p.protocol,request_id=p.request_id,friend_id=p.friend_id,task_id=p.request_id,instance_id=string.rep('a',32),state='done'}
  for key,value in pairs(normalized) do result[key]=value end
  request.callback(encode(result),true,200)
 end
 function h:last()return replies[#replies]end
 return h
end
for _,text in ipairs({'我想要1个木头','能给我1个木头吗','帮我弄一个木头','检一个木头'}) do
 local h=harness();put(friend,'log',2);h:send(text)
 assert(w.core.job.targets[1].quantity==1 and w.core.job.deliver and w.core.job.spec.mode=='obtain')
 run();assert(Inventory.Count(owner,'log')==1 and Inventory.Count(friend,'log')==1)
end
local h=harness();drop('log',1);h:send('检一个木头');run();assert(Inventory.Count(owner,'log')==1)
h=harness();drop('log',1);h:send('收集1个木头，留在你那里');run();assert(Inventory.Count(owner,'log')==0 and Inventory.Count(friend,'log')==1)
print('PASS SAME player receipt target for three phrasings + typo through actual chat RPC; owned/acquired/explicit held semantics (SIMULATED model)')
h=harness();put(friend,'cutstone',2);h:send('给我两个石砖');run();assert(Inventory.Count(owner,'cutstone')==2 and buildcalls==0)
h=harness();put(friend,'cutstone',2);drop('rocks',6);h:send('给我制作两个石砖的材料');assert(w.core.job.targets[1].item=='rocks' and w.core.job.targets[1].quantity==6);run()
assert(Inventory.Count(owner,'rocks')==6 and Inventory.Count(friend,'cutstone')==2 and buildcalls==0)
h=harness();put(friend,'cutstone',1);put(friend,'rocks',6);friend.components.builder.known.cutstone=true;h:send('用现有材料做两个石砖');run()
assert(buildcalls==2 and Inventory.Count(friend,'cutstone')==3 and Inventory.Count(friend,'rocks')==0 and Inventory.Count(owner,'cutstone')==0)
h=harness();put(friend,'cutstone',3);drop('rocks',6);friend.components.builder.known.cutstone=true;h:send('用现有材料做两个石砖');run()
assert(w.core.job.blocked.code=='missing_materials' and buildcalls==0 and Inventory.Count(friend,'rocks')==0)
print('PASS finished goods vs actual recipe materials vs NEW crafting with existing-only; no unintended resource acquisition')
h=harness();h:send('你会砍树吗');assert(not w.core.job)
h:send('如果以后缺木头，可以砍树');assert(not w.core.job)
source('chop',false,4,3);put(friend,'axe');h:send('能帮我砍一棵树吗');assert(w.core.job.kind=='tree' and w.core.job.goal==1)
tick();local stale=action;h:send('别砍树了');assert(w.core.job.blocked and not stale:Do());h:send('继续');run();assert(w.last_result.count==1)
h=harness();source('chop',false);h:send('只捡一个木头，不砍树');run();assert(w.core.job.blocked.code=='restricted_action' and buildcalls==0)
print('PASS capability/hypothesis only reply; polite tree request executes; negated chop PAUSES and invalidates old action; explicit restriction respected')
h=harness();put(friend,'twigs',1);source('chop',false,4,2);h:send('我要3个木头');run();local j=w.core.job
assert(j.blocked and Inventory.Count(friend,'twigs')==1 and h:last():find('准备'))
h:send('做到哪了');assert(h:last():find('燧石') and w.core.job==j)
put(friend,'flint',1);h:send('做到哪了');assert(not h:last():find('现在还缺1个燧石'));h:send('继续');assert(w.core.job==j and not j.blocked);run()
assert(Inventory.Count(owner,'log')==3 and buildcalls==1)
print('PASS real blocked state/progress queried through chat; material supplied then resume SAME task, no duplicated acquisition/build')
h=harness();put(friend,'log',3);h:send('我要3个木头');local j=w.core.job
-- Simulate a real confirmed partial delivery using the actual gift action, then modify TOTAL.
owner.components.inventory.capacity=1;tick();perform();assert(j.given.log==1 and Inventory.Count(owner,'log')==1)
owner.components.inventory.capacity=99;h:send('我要3个木头');assert(w.core.job==j and j.given.log==1);h:send('改成两个');assert(w.core.job==j and j.targets[1].quantity==2 and j.given.log==1);run()
assert(Inventory.Count(owner,'log')==2 and Inventory.Count(friend,'log')==1)
h=harness();put(friend,'log',3);h:send('我要3个木头');local j=w.core.job;tick();local stale=action
h:send('先别做了');assert(w.core.job==j and j.blocked.code=='user_pause' and not stale:Do())
h:send('你好，今天开心吗');assert(w.core.job==j and j.blocked and h:last()=='见到你很开心。')
h:send('做到哪了');assert(w.core.job==j and j.blocked)
h:send('继续');tick();local stale=action;h:send('取消这个任务');assert(not w.core.job and not stale:Do());tick();assert(Inventory.Count(friend,'log')==3)
print('PASS total modification includes delivered count; pause preserves job, chat/query preserves pause; resume/cancel reject stale action')
h=harness();h:send('要两个木头两个草');local j=w.core.job;h:send('改成两个');assert(w.core.job==j and h:last():find('哪一种'))
h:send('把木头改成两个');assert(w.core.job==j)
-- An overshot lowered target cannot count toward ANOTHER missing target.
j.given.log=3;assert(w:ModifyTask('log',1));assert(w.core.job==j and j.count==1 and j.goal==3)
print('PASS ambiguous modification asks without replacement; confirmed choice adjusts same job; excess deliveries not credited to unrelated target')
h=harness();h:send('弄一个那个');assert(not w.core.job);h:send('你好，今天开心吗');assert(not w.core.job)
put(friend,'log',1);h:send('是木头，给我');assert(w.core.job);run();assert(Inventory.Count(owner,'log')==1)
h=harness();h:send('弄一个那个');now=now+91;h:send('是木头，给我');assert(not w.core.job and h:last():find('过期'))
h=harness();h:send('弄一个那个');h:send('这个还没确认的不要了');assert(not w.core.job)
h:send('是木头，给我');assert(not w.core.job)
print('PASS uncertain target executes only after explicit local confirmation; ordinary chat, timeout and confirmation cancel cannot trigger goal')
h=harness();local old=h:send('我要3个木头',true);h:send('你好，今天开心吗');assert(not w.core.job);h:finish(old);assert(w.core.job)
local j=w.core.job;h:send('你带了些什么');assert(w.core.job==j)
local old=h:send('先别做了',true);h:send('我想要1个木头');local fresh=w.core.job;h:finish(old);assert(w.core.job==fresh and not fresh.blocked)
h=harness();h:send('我要3个木头');local j=w.core.job;local old=h:send('改成两个',true)
assert(w:RequestIntent({targets={{item='twigs',quantity=1}},deliver=false},owner));local fresh=w.core.job
h:finish(old);assert(w.core.job==fresh and fresh.targets[1].quantity==1 and h:last():find('任务已经变了'))
h:send('帮我烹饪肉汤');assert(w.core.job==fresh and h:last():find('还不会'))
print('PASS chat does not cancel pending goal; latest accepted task invalidates old controls; binding rejects changed job; unsupported request preserves work')

h=harness();local pending=h:send('我要3个木头',true);h:send('取消这个任务');h:finish(pending);assert(not w.core.job)
h=harness();local pending=h:send('我要3个木头',true);h:send('先别做了');h:finish(pending);assert(not w.core.job)
h=harness();h:send('能帮我砍一棵树吗');run();local j=w.core.job;assert(j and j.blocked and j.workdone==nil)
source('chop',false,4,1);put(friend,'axe');h:send('继续');assert(w.core.job==j);run();assert(w.last_result.count==1)
print('PASS pause/cancel also suppress not-yet-parsed requests; missing tree target retains actual task and resumes after condition supplied')

h=harness();put(friend,'log',3);h:send('我要3个木头');local j=w.core.job;tick();local existing=action
local bad=h:send('你好，今天开心吗',true);h:finish(bad,{state='error',diagnostic={category='decision_schema',code='invalid_quantity',reason='数量必须是整数'}})
assert(w.core.job==j and action==existing and h:last():find('解析') and not h:last():find('invalid_quantity'))
run();assert(Inventory.Count(owner,'log')==3)
print('PASS invalid model format has zero new dispatch, preserves ongoing work, public error has natural text and no validation code')
