import unittest,json
from decision import parse_decision,DecisionError
class OperationsSchema(unittest.TestCase):
 def parse(self,ops):return parse_decision(json.dumps(dict(intent='command_operations',action='operations',dialogue='先核实',item=ops,quantity=None)))[3]
 def test_defaults_and_order(self):
  r=self.parse([dict(type='cancel',kind='cook'),dict(type='goal',goal=dict(targets=[dict(item='rocks',quantity=2)],deliver=True)),dict(type='resume',kind='work')])
  self.assertEqual([v['type']for v in r],['cancel','goal','resume']);self.assertEqual(r[1]['goal']['targets'][0]['item'],'rocks')
  self.assertEqual(self.parse([dict(type='cook')])[0]['quantity'],1)
 def test_no_identity_or_side_effects_from_schema(self):
  r=self.parse([dict(type='cook',recipe='蛙腿三明治',quantity=2,destination='player')]);self.assertEqual(r[0]['recipe'],'蛙腿三明治')
 def test_limits_and_bad_dependencies(self):
  for ops in [[],[dict(type='status')]*7,[dict(type='cook',quantity=True)],[dict(type='cook',quantity=21)],[dict(type='cook',depends_on=1)],[dict(type='cancel',scope='world')],[dict(type='cook',category='vegan')],[dict(type='cook',coordinates=[1,2])],[dict(type='goal',goal=dict(targets=[dict(item='twigs',quantity=1)],coordinates=[1,2]))]]:
   with self.subTest(ops=ops),self.assertRaises(DecisionError):self.parse(ops)
 def test_proposal_changes_and_dependencies(self):
  self.assertEqual(self.parse([dict(type='accept',proposal_id='friend-1'),dict(type='cook',depends_on=1)])[1]['depends_on'],1)
  self.assertEqual(self.parse([dict(type='modify_proposal',quantity=2,category='vegetarian')])[0]['quantity'],2)

 def test_remove_one_goal_uses_existing_modifier(self):
  self.assertEqual(self.parse([dict(type='modify',target='friend-1',item='rocks',operation='remove',quantity=None)])[0]['operation'],'remove')
