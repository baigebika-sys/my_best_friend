APP_VERSION='756039'
local K=require('ybf_knowledge');local Store=require('ybf_knowledge_store');local Semantic=require('ybf_knowledge_semantic')
local function clean(t)assert(t and #t<=600 and not t:find('prefab') and not t:find('TECH%.') and not t:find('_') and not t:find('…'),t)end
Prefabs={petals={},twigs={},flower={},sapling={}}
local h=harness();local covered,gaps=0,0
for _,s in ipairs(UNSEEN_SAMPLES) do
 h:send('能介绍一下'..s.name..'吗');clean(h:last());assert(not w.core.job)
 local actual=s.basic_declared and not h:last():find('还没有可靠补齐') and not h:last():find('没有可靠识别') and not h:last():find('请确认') and not h:last():find('对应多个') and #h:last()>#s.name+20
 if actual then covered=covered+1 else gaps=gaps+1 end
 print('UNSEEN_RESULT '..s.category..' '..s.prefab..' declared='..tostring(s.basic_declared)..' rendered='..tostring(actual)..' answer='..h:last())
end
for i=1,math.min(4,#UNSEEN_SAMPLES) do
 local s=UNSEEN_SAMPLES[i];local cs={};for c in s.name:gmatch('[%z\1-\127\194-\244][\128-\191]*') do cs[#cs+1]=c end
 if #cs>=4 then table.remove(cs,2);local typo=table.concat(cs);h:send('你认识'..typo..'吗');clean(h:last());assert(not w.core.job);print('UNSEEN_TYPO_RESULT '..s.prefab..' answer='..h:last()) end
end
h:send('黄金工具有哪些');clean(h:last());assert(h:last():find('黄金') and h:last():find('配方') and not w.core.job)
h:send('你知道哪些建材');clean(h:last());assert(h:last():find('建筑材料') and h:last():find('配方') and not w.core.job)
h:send('有哪些恢复精神的食物');clean(h:last());assert(h:last():find('精神') and h:last():find('基准') and not w.core.job)
local first=h:last();h:send('继续展开');clean(h:last());assert(first~=h:last())
h:send('介绍全部墨荒');clean(h:last());assert(h:last():find('墨荒') and not h:last():find('请说明是哪一种') and not w.core.job)
h:send('天体英雄有哪些阶段');clean(h:last());assert(h:last():find('阶段') and not w.core.job)
h:send('普通毒菌蟾蜍和特殊版本有什么区别');clean(h:last());assert(h:last():find('生命上限') and not w.core.job)
h:send('猪人吃了4个怪物肉会怎样');clean(h:last());assert(h:last():find('狂暴变身') and h:last():find('零开始') and not w.core.job)
h:send('如果猪人吃了三个怪物肉会怎么样');clean(h:last());assert(h:last():find('尚未达到') and not w.core.job)
h:send('猪人吃了4个浆果会怎样');clean(h:last());assert(h:last():find('不满足') and not w.core.job)
h:send('你知道黄金斧子吗');clean(h:last());assert(h:last():find('砍伐') and not h:last():find('请确认'))
h:send('蝙蝠是什么');clean(h:last());assert(h:last():find('洞穴蝙蝠') and not h:last():find('请确认'))
h:send('你知道指南针吗');clean(h:last());assert(h:last():find('判断方向') and not h:last():find('武器攻击') and h:last():sub(1,#'装备在手上')=='装备在手上')
h:send('遮阳棚有什么用');assert(h:last():find('确认') and h:last():find('遮阳篷'))
h:send('是的，就是这个');clean(h:last());assert(not h:last():find('玻璃刀') and (h:last():find('白天') or h:last():find('休息') or h:last():find('精神')))
h:send('暗影甲有什么用');local question=h:last();h:send('是的');assert(h:last():find('多个候选') and not h:last():find('玻璃刀') and not w.core.job)
h:send('取消查询');assert(h:last():find('取消'))
h:send('是的，就是这个');assert(h:last():find('没有待确认'))
h:send('遮阳棚有什么用');now=now+91;h:send('是的，就是这个');assert(h:last():find('没有待确认') or h:last():find('过期'))
h:send('暗影甲有什么用');h:send('你知道指南针吗');h:send('是的');assert(h:last():find('没有待确认'))
owner.userid='other';h:send('是的，就是这个');assert(h:last():find('没有待确认'));owner.userid='owner'
-- Actual gather/cancel only; no new action authorization.
plant('flower','petals',2);h:send('给我1个花瓣');run();assert(Inventory.Count(owner,'petals')==1)
plant('sapling','twigs',2);h:send('给我1个树枝');tick();local stale=action;assert(stale);local job=w.core.job;h:send('猪人吃了4个怪物肉会怎样');assert(w.core.job==job);h:send('取消任务吧');assert(not w.core.job and not stale:Do())
print('PASS semantic category/family/condition queries, semantic name rank, pending query confirmation isolation, no query work, gather/cancel regression')
print('UNSEEN_SUMMARY rendered='..covered..' gaps='..gaps..' total='..#UNSEEN_SAMPLES)

h:send(EXTRA_QUERIES.material);print("EXTRA_MATERIAL "..h:last());clean(h:last());assert(h:last():find("材料") and not w.core.job)
h:send(EXTRA_QUERIES.dish);clean(h:last());assert(h:last():find("食材条件") and not w.core.job)
print("PASS unseen reverse material use and scoped cooking predicate via actual chat entry")
