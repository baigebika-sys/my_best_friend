import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'developer_tools'))
from scoped_lua_reader import Reader,tuning_values,U,unknown
class Scoped(unittest.TestCase):
 def test_factory_binding_and_overrides(self):
  r=Reader({'USES':100,'GOLD':4})
  r.read('''local function gold(inst) inst.components.finiteuses:SetConsumption(ACTIONS.CHOP, 1/TUNING.GOLD) end
local function make(name, post, data)
 local count=data and data.uses or TUNING.USES
 local function fn() local inst=CreateEntity(); if not TheWorld.ismastersim then return inst end
 inst:AddComponent("tool");inst.components.tool:SetAction(ACTIONS.CHOP,1)
 inst:AddComponent("finiteuses");inst.components.finiteuses:SetMaxUses(count)
 if post ~= nil then post(inst) end;return inst end
 return Prefab(name,fn) end
return make("axe",nil,nil),make("goldenaxe",gold,{uses=200})''')
  a=r.descriptors['axe']['events'];g=r.descriptors['goldenaxe']['events']
  self.assertFalse(any(x['method']=='SetConsumption' for x in a));self.assertEqual(next(x['args'] for x in g if x['method']=='SetConsumption'),['CHOP',.25]);self.assertEqual(next(x['args'][0] for x in g if x['method']=='SetMaxUses'),200)
 def test_unknown_branch_not_promoted(self):
  r=Reader();r.read('local function fn() local inst=CreateEntity(); if unknownstate then inst:AddComponent("armor") else inst:AddComponent("tool") end;return inst end;return Prefab("x",fn)')
  self.assertEqual(r.descriptors['x']['components'],[]);self.assertTrue(r.gaps)
 def test_callback_not_executed(self):
  r=Reader();r.read('local function callback(inst) inst:AddComponent("armor") end;local function fn() local inst=CreateEntity();inst:AddComponent("equippable");inst.components.equippable:SetOnEquip(callback);return inst end;return Prefab("x",fn)')
  self.assertNotIn('armor',r.descriptors['x']['components'])
 def test_multientity_file_scope(self):
  r=Reader();r.read('local function a()local inst=CreateEntity();inst:AddComponent("armor");return inst end;local function b()local inst=CreateEntity();inst:AddComponent("container");return inst end;return Prefab("a",a),Prefab("b",b)')
  self.assertEqual(r.descriptors['a']['components'],['armor']);self.assertEqual(r.descriptors['b']['components'],['container'])
 def test_unknown_tuning_not_defaulted(self):
  t=tuning_values('function Tune() local day=30*16;TUNING={KNOWN=day,UNKNOWN=callback()} end')
  self.assertEqual(t['KNOWN'],480);self.assertTrue(unknown(t['UNKNOWN']))
  r=Reader(t);r.read('local function f()local inst=CreateEntity(); if TUNING.UNKNOWN then inst:AddComponent("armor") end;return inst end;return Prefab("x",f)');self.assertEqual(r.descriptors['x']['components'],[])
 def test_comments_and_loop_gaps(self):
  r=Reader();r.read('local function f()local inst=CreateEntity();--inst:AddComponent("armor")\nfor i=1,2 do inst:AddComponent("tool") end;return inst end;return Prefab("x",f)');self.assertEqual(r.descriptors['x']['components'],[]);self.assertTrue(any(g['reason']=='loop_excluded' for g in r.gaps))

 def test_secondary_entity_cannot_pollute_returned_instance(self):
  r=Reader();r.read('local function f()local inst=CreateEntity();inst:AddComponent("tool");local c=inst.components.tool;local fx=CreateEntity();fx:AddComponent("armor");c:SetAction(ACTIONS.CHOP,1);return inst end;return Prefab("x",f)')
  self.assertEqual(r.descriptors['x']['components'],['tool']);self.assertTrue(any(e['path']=='inst.components.tool' and e['method']=='SetAction' for e in r.descriptors['x']['events']))
