"""Checks upload preparation, preserving source bytes and excluding PO files."""
import hashlib,json,tempfile,unittest,zipfile,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'developer_tools'))
from repack_dst_scripts import repack
class RepackChecks(unittest.TestCase):
 def test_independent_parts_preserve_every_script_and_paths(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);src=root/'scripts.zip';files={'scripts/prefabs/a.lua':b'return Prefab("a",fn)','scripts/components/b.lua':b'error("must not execute")'*10,'scripts/strings.lua':b'STRINGS={NAMES={A="A"}}'}
   with zipfile.ZipFile(src,'w') as z:
    for n,raw in files.items():z.writestr(n,raw)
    z.writestr('scripts/languages/chinese_s.po','already supplied');z.writestr('scripts/readme.txt','not executed')
   original=src.read_bytes();out=root/'parts';m=repack(src,out,target_bytes=100);self.assertGreater(len(m['parts']),1)
   actual={}
   for part in m['parts']:
    p=out/part['file'];self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),part['sha256'])
    with zipfile.ZipFile(p) as z:
     self.assertIsNone(z.testzip())
     for n in z.namelist():actual[n]=z.read(n)
   self.assertEqual(actual,files);self.assertEqual(src.read_bytes(),original)
   self.assertEqual(json.loads((out/'scripts_parts_manifest.json').read_text())['selected_file_count'],3)
   with self.assertRaises(ValueError):repack(src,out)
 def test_unsafe_source_paths_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);src=root/'scripts.zip'
   with zipfile.ZipFile(src,'w') as z:z.writestr('scripts/prefabs/a.lua','return 1');z.writestr('../outside.lua','return 2')
   with self.assertRaises(ValueError):repack(src,root/'parts')
   self.assertFalse((root/'parts').exists())
if __name__=='__main__':unittest.main()
