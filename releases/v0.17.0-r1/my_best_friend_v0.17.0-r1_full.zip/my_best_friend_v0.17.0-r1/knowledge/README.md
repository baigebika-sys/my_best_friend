当前 r4 审计以 coverage.json／current_coverage.json 为准。official_knowledge.json 为完整事实与候选；语义索引见 semantic_index.json；逐项缺口见 extraction_gaps.json 和 semantic_extraction_gaps.json。基本介绍不是完整百科，旧报告在历史交接中。
