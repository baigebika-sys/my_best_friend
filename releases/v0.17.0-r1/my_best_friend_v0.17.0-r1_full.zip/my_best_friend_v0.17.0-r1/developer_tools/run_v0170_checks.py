from pathlib import Path
import ctypes as c,json,os
root=Path(__file__).resolve().parents[1];os.chdir(root)
def lua(x):
 if x is None:return 'nil'
 if x is True:return 'true'
 if x is False:return 'false'
 if isinstance(x,str):return json.dumps(x,ensure_ascii=False)
 if isinstance(x,(int,float)):return str(x)
 if isinstance(x,list):return '{'+','.join(lua(v)for v in x)+'}'
 return '{'+','.join('['+lua(k)+']='+lua(v)for k,v in x.items())+'}'
setup=(root/'tests/test_foundation.lua').read_text().split("reset();put(friend,'twigs',3);plant",1)[0]
base=(root/'tests/test_v0150_warehouse.lua').read_text().split('setup()\nfor _,p',1)[0]
tuning=json.loads((root/'tests/official_cooking_756039/tuning_values.json').read_text())
names=json.loads((root/'knowledge/official_knowledge.json').read_text())['entries'];names={p.upper():v.get('names',{}).get('zh',p)for p,v in names.items()}
prelude='OFFICIAL_TUNING='+lua(tuning)+'\nOFFICIAL_NAMES='+lua(names)+'\n'
source=prelude+setup+base+(root/'tests/test_v0170_cooking.lua').read_text()
(Path('/tmp')/'v0170-check-source.lua').write_text(source)
lib=c.CDLL('liblua5.4.so.0');lib.luaL_newstate.restype=c.c_void_p;lib.luaL_openlibs.argtypes=[c.c_void_p];lib.luaL_loadbufferx.argtypes=[c.c_void_p,c.c_char_p,c.c_size_t,c.c_char_p,c.c_char_p];lib.lua_pcallk.argtypes=[c.c_void_p,c.c_int,c.c_int,c.c_int,c.c_int,c.c_void_p];lib.lua_tolstring.argtypes=[c.c_void_p,c.c_int,c.POINTER(c.c_size_t)];lib.lua_tolstring.restype=c.c_char_p;lib.lua_close.argtypes=[c.c_void_p]
state=lib.luaL_newstate();lib.luaL_openlibs(state);raw=source.encode()
try:
 code=lib.luaL_loadbufferx(state,raw,len(raw),b'v0170 official cooking and task integration',None)
 if not code:code=lib.lua_pcallk(state,0,-1,0,0,None)
 if code:raise AssertionError(lib.lua_tolstring(state,-1,None).decode())
finally:lib.lua_close(state)
print('Official rules/native stewer and buffered action executed; engine/world/provider mocked. NOT actual DST/live model.')
