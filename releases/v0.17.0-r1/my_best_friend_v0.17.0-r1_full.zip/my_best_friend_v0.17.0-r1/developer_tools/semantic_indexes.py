"""Derived read-only relations. All lists are from verified edges, never model lists."""
from pathlib import Path
import json,re,hashlib
from import_dst_knowledge import effective_facts,lua
from scoped_lua_reader import ast,N,Reader,Function,line,name,clean

def build(data,source,bindings,output):
 E=data['entries'];build=data['manifest']['build'];hashes=data['manifest']['source_sha256']
 def proof(p,l=1):return dict(kind='official_script',path=p,line=l,sha256=hashes[p],version=build,certainty='verified')
 collections={k:[] for k in ['tools','equipment','food','buildings','creatures','natural','materials','building_materials','gold_tools','sanity_foods']};reverse={};labels={};families={};conditions=[];gaps=[]
 def facts(r,f):return effective_facts(r,f)[0]
 for p,r in E.items():
  properties=[f['value'] for f in facts(r,'properties') if isinstance(f.get('value'),dict)]
  uses=facts(r,'uses');material=[f['value'] for f in uses if f.get('semantic_key','').startswith('recipe_material_')]
  if material:reverse[p]=material;collections['materials'].append(p)
  if any(E.get(v['product'],{}).get('category')=='facility' for v in material):collections['building_materials'].append(p)
  category=r['category'];c={'tool':'tools','food':'food','facility':'buildings','creature':'creatures','natural_or_interactive':'natural'}.get(category)
  if c:collections[c].append(p)
  if any(f.get('semantic_key','').startswith(('equipment_','primary_scrapbook_equipment')) for f in facts(r,'properties')+uses):collections['equipment'].append(p)
  if category=='food' and any(isinstance(v.get('sanityvalue'),(float,int)) and v['sanityvalue']>0 for v in properties):collections['sanity_foods'].append(p)
  if any(f.get('semantic_key','').startswith('primary_tool_') for f in uses):
   recipes=facts(r,'recipes')
   if any(any(x.get('prefab')=='goldnugget' for x in f['value'].get('ingredients',[])) for f in recipes if isinstance(f.get('value'),dict)):collections['gold_tools'].append(p)
 # Same formal name + shared prefab root + class yields a name-family, not
 # an asserted biological genealogy. Unrelated homonyms remain ungrouped.
 names={}
 for p,r in E.items():
  n=r.get('names',{}).get('zh')
  if n:names.setdefault(n,[]).append(p)
 for n,ids in names.items():
  ids=sorted(ids)
  if len(ids)>1:
   categories={'creature':'生物','facility':'设施','item':'物品','natural_or_interactive':'自然交互对象','auxiliary_or_effect':'辅助实体'}
   for i,p in enumerate(ids):labels[p]=n+'（'+categories.get(E[p]['category'],'对象')+str(i+1)+'）'
  roots={p.rsplit('_',1)[0] for p in ids};cats={E[p]['category'] for p in ids}
  if len(ids)>1 and len(roots)==1 and len(next(iter(roots)))>=6 and len(cats)==1:
   family={'name':n,'kind':'name_group','members':ids,'evidence':[E[p]['identity'] for p in ids],'relation_scope':'same official name and related identity stem; detailed relationships not inferred'}
   families[n]=family
   for i,p in enumerate(ids):labels[p]=n+'（形态'+str(i+1)+'）'
 # Phase identities require literal transition evidence, not name-only phase
 # suffixes. Keep conditional later phase separate from normal three phases.
 phasegroups={}
 for p,r in E.items():
  m=re.fullmatch(r'(.+)_phase(\d+)(_lunarrift)?',p)
  if not m or r['category'] not in ('creature','natural_or_interactive'):continue
  path=r['identity']['path'];text=(source/path).read_text(encoding='utf-8-sig',errors='replace')
  stage=int(m[2]);title=r.get('names',{}).get('zh')
  if not title:continue
  phasegroups.setdefault(m[1],[]).append((p,stage,m[3],path))
 for root,members in phasegroups.items():
  if len(members)<2:continue
  members.sort(key=lambda x:x[1]);base=E[members[0][0]]['names']['zh'];proofs=[];accepted=[]
  for p,stage,conditional,path in members:
   # Own identity is phase-literal; transitions verified against all sources
   # in the same prefab/stategraph family, no callback execution.
   related=sorted((source/'scripts/prefabs').glob(root+'_phase*.lua'))+sorted((source/'scripts/stategraphs').glob('SG'+root+'_phase*.lua'))
   if conditional and stage>1:related+=sorted((source/'scripts/stategraphs').glob('*.lua'))
   links=[]
   for fp in related:
    text=fp.read_text(encoding='utf-8-sig',errors='replace')
    matches=list(re.finditer(r'SpawnPrefab\(\s*["\']'+re.escape(p)+r'["\']',text))
    for m in matches:links.append(proof(fp.relative_to(source).as_posix(),text.count('\n',0,m.start())+1))
   if stage==1 or links:
    accepted.append(p);proofs.extend(links or [E[p]['identity']]);labels[p]=base+'（第'+str(stage)+'阶段'+('，另有条件或战斗分支' if conditional else '')+'）'
  if len(accepted)>1:families[base]={'name':base,'kind':'boss_phases','members':accepted,'evidence':proofs,'conditional_members':[p for p,s,c,path in members if c and p in accepted],'relation_scope':'normal phase transitions plus separately sourced encounter branches; detailed activation conditions incomplete'}
 # Related constructor versions (normal/dark) are identity variants, not skins.
 for p in sorted(E):
  if p.endswith('_dark') and p[:-5] in E and E[p]['identity'].get('path')==E[p[:-5]]['identity'].get('path'):
   base=p[:-5];title=E[base].get('names',{}).get('zh')
   if title and E[p]['category']==E[base]['category'] and E[p]['category']!='auxiliary_or_effect':families.setdefault(title,{'name':title,'kind':'independent_versions','members':[base,p],'evidence':[E[base]['identity'],E[p]['identity']],'relation_scope':'distinct returned Prefab identities sharing one official factory source'})
 # Generic trigger-counter contract combines constructor binding, complete
 # callback predicate and component threshold implementation.
 for p,(path,d) in bindings.items():
  ev=d['events'];on=[e for e in ev if e.get('callback_contract')];limits=[e for e in ev if e['path']=='inst.components.werebeast' and e['method']=='SetTriggerLimit' and e['args'] and isinstance(e['args'][0],(int,float))];states=[e for e in ev if e.get('state_contract')]
  if on and limits and states:
   e=on[-1];limit=limits[-1]['args'][0];contract=e['callback_contract'];rule={'subject':p,'verb':'eat','food_type':'MEAT','health_lt':0,'delta':contract['delta'],'threshold':limit,'requires_normal_state':True,'initial_counter_assumption':0,'reset_conditions_unknown':True,'result':'were_state','kind':'same_object_state','evidence':[proof(path,e['line']),proof(path,contract['callback_line']),proof(path,limits[-1]['line']),proof(path,states[-1]['state_contract']['callback_line']),proof('scripts/components/werebeast.lua',100)]};conditions.append(rule)
 # Exact crockpot predicates -> structured boolean IR, never run test callback.
 def ir(n):
  if isinstance(n,N.Number):return {'literal':n.n}
  if isinstance(n,N.Index) and isinstance(n.value,N.Name) and n.value.id in ('names','tags') and isinstance(n.idx,N.Name):return {'field':n.value.id,'key':n.idx.id}
  typ=type(n).__name__;operators={'AndLoOp':'and','OrLoOp':'or','EqToOp':'eq','NotEqToOp':'ne','GreaterOrEqThanOp':'ge','GreaterThanOp':'gt','LessThanOp':'lt','LessOrEqThanOp':'le'}
  if typ=='ULNotOp':
   v=ir(n.operand);return {'op':'not','value':v} if v else None
  if typ in operators:
   a,b=ir(n.left),ir(n.right);return {'op':operators[typ],'left':a,'right':b} if a and b else None
  return None
 cooking={};r=Reader()
 for row in E.values():row['sources']=[f for f in row['sources'] if f.get('semantic_key')!='crockpot_predicate']
 for path,cookers in [('scripts/preparedfoods.lua',['cookpot','portablecookpot','archive_cookpot']),('scripts/preparedfoods_warly.lua',['portablecookpot'])]:
  try:
   tree=ast.parse((source/path).read_text(encoding='utf-8-sig'));tab=next((n.values[0] for n in tree.body.body if isinstance(n,N.LocalAssign) and n.targets[0].id=='foods'),None)
   if not isinstance(tab,N.Table):continue
   for item in tab.fields:
    p=item.key.id if isinstance(item.key,N.Name) else ''
    if p not in E or not isinstance(item.value,N.Table):continue
    fields={f.key.id:f.value for f in item.value.fields if isinstance(f.key,N.Name)};fn=fields.get('test')
    if not isinstance(fn,N.AnonymousFunction) or len(fn.body.body)!=1 or not isinstance(fn.body.body[0],N.Return):gaps.append({'prefab':p,'reason':'cooking_test_not_simple_return'});continue
    predicate=ir(fn.body.body[0].values[0])
    if not predicate:gaps.append({'prefab':p,'reason':'cooking_predicate_not_supported'});continue
    record={'predicate':predicate,'cookers':cookers,'priority':clean(r.expr(fields.get('priority'),{})),'evidence':[proof(path,line(fn)),proof('scripts/cooking.lua',189)],'all_ingredients_and_priority_must_be_checked':True}
    cooking[p]=record
    E[p]['sources'].append({'field':'crockpot_predicate','semantic_key':'crockpot_predicate','value':record,**proof(path,line(fn)),'rule':'cooking_boolean_ir_v1','basic_role':True,'summary':'可用烹饪锅加工组合食材获得；需要满足食材条件，并按食谱优先级确定最终产物。'})
  except Exception as e:gaps.append({'path':path,'reason':'cooking_parse_gap','error':type(e).__name__})
 for k,v in collections.items():collections[k]=sorted(set(v),key=lambda p:(E[p].get('names',{}).get('zh','~'),p))
 from enrich_mechanisms import assess_basic
 assess_basic(data)
 # Lightweight functional catalog, separate from inventory and model prompt.
 index={'build':build,'collections':collections,'reverse_recipes':reverse,'families':families,'candidate_labels':labels,'conditions':conditions,'cooking':cooking,'categories':{p:r['category'] for p,r in E.items()},'basic':{p:r['basic_understanding'] for p,r in E.items() if 'basic_understanding' in r},'scope':'verified static catalog, not inventory or live positions'}
 output.mkdir(parents=True,exist_ok=True);(output/'semantic_index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');(output/'ybf_knowledge_semantic_data.lua').write_text('-- Generated verified semantic index.\nreturn '+lua(index)+'\n');(output/'semantic_extraction_gaps.json').write_text(json.dumps(gaps,ensure_ascii=False,indent=2)+'\n')
 return index
