from pathlib import Path
root=Path(__file__).resolve().parents[1]
old=(root/'developer_tools/run_knowledge_r3_checks.py').read_text();a=old.index('D={}');b=old.index('server=bridge.BridgeServer',a)
D={}
def goal(t,item,n=1,mode='obtain',**kw):D[t]=dict(intent='command_goal',action='goal',dialogue='我核对实际条件。',item=item,quantity=n if isinstance(item,str) else None,deliver=True,mode=mode,**kw)
goal('请给我一个石砖，材料箱子里有','cutstone')
goal('做两块石砖，只用箱子里的材料，做完放箱子里','cutstone',2,'craft')
goal('帮忙备好一个木板和三根树枝，先用箱子里的，不够再找',[{'item':'boards','quantity':1},{'item':'twigs','quantity':3}])
goal('做一个木板和一根绳子，我想修点东西',[{'item':'boards','quantity':1},{'item':'rope','quantity':1}],mode='craft')
for t,operation,item,n in [('再加两个木板','add','boards',2),('不要木板了','remove','boards',None),('加上两根树枝','append','twigs',2)]:D[t]=dict(intent='command_modify',action='modify',dialogue='好。',item=item,quantity=n,operation=operation)
source=old[:a]+'D='+repr(D)+'\n'+old[b:]
source=source.replace("(root/'tests/test_knowledge_r3.lua').read_text()", "(root/'tests/test_v0150_language.lua').read_text()")
source=source.replace("setup+'\\nlocal LANGUAGE_FIXTURES='", "setup+'\\n'+(root/'tests/test_v0150_warehouse.lua').read_text().split('setup()\\nfor _,p',1)[0]+'\\nlocal LANGUAGE_FIXTURES='")
exec(compile(source,str(root/'developer_tools/run_knowledge_r3_checks.py'),'exec'),{'__file__':str(root/'developer_tools/run_knowledge_r3_checks.py'),'__name__':'__main__'})
