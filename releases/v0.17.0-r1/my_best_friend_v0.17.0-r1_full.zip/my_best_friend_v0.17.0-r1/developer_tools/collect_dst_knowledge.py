"""Copy only build marker, scripts and localization from an official DST install.
Run on the machine with the tested game. Never collects saves, mods or credentials.
"""
import argparse, hashlib, json, zipfile
from pathlib import Path

def collect(game_dir,output):
    game_dir=game_dir.resolve();scripts=game_dir/'data'/'scripts.zip'
    versions=[p for p in (game_dir/'version.txt',game_dir/'data'/'version.txt') if p.is_file()]
    if not scripts.is_file() or not versions:raise ValueError('Missing data/scripts.zip or version.txt. Select the official game installation, not a mod folder.')
    files={'version.txt':versions[0].read_bytes(),'scripts.zip':scripts.read_bytes()}
    for folder in (game_dir/'data'/'scripts'/'languages',game_dir/'data'/'languages'):
        if folder.is_dir():
            for p in folder.glob('chinese*.po'):files['localization/'+p.name]=p.read_bytes()
    with zipfile.ZipFile(scripts) as z:
        for name in z.namelist():
            if name.endswith(('chinese_s.po','chinese_t.po','chinese.po')):files['localization/'+Path(name).name]=z.read(name)
    manifest={'source':'user_official_game_installation','build_marker':files['version.txt'].decode('utf-8-sig').strip(),'files':{n:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for n,raw in files.items()},'missing_localization':not any(n.startswith('localization/') for n in files)}
    files['collection_manifest.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        for name,raw in files.items():z.writestr(name,raw)
    return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--game-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    print(json.dumps(collect(a.game_dir,a.output),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
