"""Batch semantic extraction from scoped constructor AST, tuning and components.
Development-only dependency luaparser==4.0.0. Runtime mod/bridge need no parser.
"""
import argparse,json,hashlib,re,contextlib,io,concurrent.futures
from pathlib import Path
from scoped_lua_reader import Reader,tuning_values,ast,N,name,line,clean
from import_dst_knowledge import audit,write_bundle,effective_facts,FACETS
from official_static_enrichment import literal_tree

ACTION={'CHOP':'砍伐','MINE':'开采','DIG':'挖掘','HAMMER':'敲拆','TILL':'耕地','NET':'捕捉','FISH':'钓鱼','SHAVE':'剃毛'}

def parse_file(job):
 path,text,tuning=job
 try:
  r=Reader(tuning)
  with contextlib.redirect_stderr(io.StringIO()),contextlib.redirect_stdout(io.StringIO()):tree,env=r.read(text)
  return path,r.descriptors,r.shared,r.gaps,None
 except Exception as e:return path,{},{},[],type(e).__name__

def enrich(data,source,workers=4):
 entries=data['entries'];build=data['manifest']['build'];hashes=data['manifest']['source_sha256'];gaps=[]
 def proof(path,ln=1):return dict(kind='official_script',path=path,line=ln,sha256=hashes[path],version=build,certainty='verified')
 def evidence_for(path,component):
  p='scripts/components/'+component+'.lua'
  return [proof(p)] if p in hashes else []
 def fact(row,facet,key,val,path,ln=1,summary=None,primary=False,component=None,extra=None):
  f=dict(field=key,semantic_key=key,value=val,**proof(path,ln),rule='scoped_ast_v1',scope='default_server_constructor_base; callbacks/world overrides/state changes excluded')
  if summary:f['summary']=summary
  if primary:f['basic_role']=True
  if component:f['additional_evidence']=evidence_for(path,component)
  if extra:f.setdefault('additional_evidence',[]).extend(extra)
  row[facet].append(f)
  return f
 def label(p):return entries.get(p,{}).get('names',{}).get('zh',p)
 text=(source/'scripts/tuning.lua').read_text(encoding='utf-8-sig');tuning=tuning_values(text)
 files=sorted(p for p in (source/'scripts/prefabs').glob('*.lua') if len(p.read_bytes())<220000)
 jobs=[(p.relative_to(source).as_posix(),p.read_text(encoding='utf-8-sig',errors='replace'),tuning) for p in files]
 descriptors={};shared={};file_count=0
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
  for path,rows,loots,unresolved,error in pool.map(parse_file,jobs,chunksize=3):
   file_count+=1
   if error:gaps.append({'path':path,'reason':'parser_or_unsupported_ast','error':error});continue
   for p,d in rows.items():
    if p in entries:descriptors[p]=(path,d)
   for k,v in loots.items():shared[k]=(path,v)
   if unresolved:gaps.append({'path':path,'reason':'conditional_paths_excluded','count':len(unresolved),'examples':unresolved[:4]})
   if file_count%150==0:print('Parsed',file_count,'files; bound',len(descriptors),'identities',flush=True)
 # Baseline component contracts used below are facts about configuration, not
 # automatic authorization. No hidden gameplay conditions are guessed.
 children=[];brains={};primary_counts={}
 for p,(path,d) in descriptors.items():
  row=entries[p];events=d['events'];components=set(d['components']);fields=d['fields'];row['constructor_bound']={'path':path,'binding_line':d['binding_line'],'components':d['components'],'scope':'default_server_base_only'}
  def ev(c,m):return [e for e in events if e['path']=='inst.components.'+c and e['method']==m]
  def last(c,m):
   xs=ev(c,m);return xs[-1] if xs else None
  def add(facet,key,v,summary,primary=False,c=None,e=None):
   return fact(row,facet,key,v,path,e['line'] if e else d['binding_line'],summary,primary,c,extra=[proof('scripts/tuning.lua')] if e else None)
  tags=[e['args'][0] for e in events if e['method']=='AddTag' and e['args'] and isinstance(e['args'][0],str)]
  row['verified_tags']=tags
  if row['category']=='unclassified':
   category='auxiliary_or_effect' if any(t in tags for t in ('FX','CLASSIFIED','NOCLICK')) else 'creature' if {'health','combat'}<=components else 'facility' if 'structure' in tags or 'prototyper' in components else 'tool' if 'tool' in components else 'food' if 'edible' in components else 'item' if 'inventoryitem' in components else 'natural_or_interactive'
   row['category']=category;row['category_evidence']=proof(path,d['binding_line'])
  actions={}
  for e in ev('tool','SetAction'):
   a=e['args']
   if a and a[0] in ACTION:actions[a[0]]=e
  for act,e in actions.items():
   eff=e['args'][1] if len(e['args'])>1 else 1
   val={'action':act,'effectiveness':eff};uses=last('finiteuses','SetMaxUses');cons=[x for x in ev('finiteuses','SetConsumption') if x['args'] and x['args'][0]==act]
   if uses and cons and isinstance(uses['args'][0],(int,float)) and isinstance(cons[-1]['args'][1],(int,float)) and cons[-1]['args'][1]>0:val['base_action_uses']=uses['args'][0]/cons[-1]['args'][1]
   summary='可作为'+ACTION[act]+'工具；需要目标支持对应动作，特殊状态和角色条件仍需核对。'
   add('uses','primary_tool_'+act,val,summary,True,'tool',e)
   add('properties','tool_action_'+act,val,None,False,'tool',e)
  for c,action,summary in [('farmtiller','TILL','可用于耕地；目标地点必须满足可耕作土壤条件。'),('fishingrod','FISH','可用于钓鱼；需要可钓鱼目标并满足距离和工具状态条件。'),('oceanfishingrod','OCEAN_FISH','可用于海钓；需要有效浮标、诱饵和海钓目标条件。')]:
   if c in components:
    add('uses','primary_tool_'+action,{'action':action},summary,True,c)
  if 'lighter' in components and 'inventoryitem' in components:
   add('uses','primary_lighting',{'action':'light','authorization_required':True},'具有点燃目标的用途；目标必须支持点燃，认识此用途不表示当前任务允许点火。',True,'lighter')
  if 'equippable' in components:
   slot=fields.get('inst.components.equippable.equipslot',None if 'inst.components.equippable.equipslot' in d.get('unknown_fields',[]) else 'HANDS');val={'slot':slot,'dapperness':fields.get('inst.components.equippable.dapperness')}
   add('properties','equipment_configuration',val,None,False,'equippable')
   summaries=[]
   dapperness=fields.get('inst.components.equippable.dapperness')
   if isinstance(dapperness,(int,float)) and dapperness!=0:summaries.append('精神变化')
   if isinstance(fields.get('inst.components.equippable.walkspeedmult'),(int,float)) and fields['inst.components.equippable.walkspeedmult']!=1:summaries.append('移动速度变化')
   for component,method,label_ in [('armor','InitCondition','护甲防护'),('insulator','SetInsulation','保温'),('waterproofer','SetEffectiveness','防水'),('heater','SetThermics','温度调节')]:
    e=last(component,method)
    if component in components:
     args=e['args'] if e else [];summaries.append(label_)
     add('properties','equipment_'+component,{'configuration':args},None,False,component,e)
   # A weapon component alone is not a main function (e.g. compass).
   sub=row.get('scrapbook',{}).get('subcat')
   if sub=='weapon':summaries.append('武器攻击')
   if 'compass' in tags:
    f=add('uses','primary_navigation',{'equipment_tag':'compass','slot':'HANDS'},'装备在手上后显示指南针，可帮助判断方向；使用时消耗剩余使用时间。',True,'equippable');f.setdefault('additional_evidence',[]).append(proof('scripts/widgets/hudcompass.lua',4))
   if summaries:add('uses','primary_equipment',val,'装备后可提供'+ '、'.join(summaries)+'；须使用对应装备位置，效果受实际状态影响。',True,'equippable')
  if 'container' in components:
   add('uses','primary_container',{'function':'storage','open_required':True},'可用于储存物品；打开后才能取放，接受哪些物品还需按该容器规则检查。',True,'container')
  for c,summary in {'prototyper':'可作为科技制作设施；制作仍需满足材料、角色与对应科技条件。','stewer':'可使用烹饪容器加工组合食材；结果取决于食谱条件和优先级。','cooker':'可烹饪可加工食材；需要食材支持烹饪转换。','dryer':'可晾晒支持干燥加工的材料；加工需要时间且受天气和工作状态影响。','teleporter':'可作为传送交互对象；需要已建立有效的传送目标，具体代价尚需核对。','tent':'提供睡眠休息交互；可否使用取决于角色、时间和对象状态。'}.items():
   if c in components:add('uses','primary_facility_'+c,{'component':c,'runtime_conditions_required':True},summary,True,c)
  workable=last('workable','SetWorkAction')
  if workable and workable['args'] and workable['args'][0] in ACTION:
   a=workable['args'][0];add('mechanisms','workable_interaction',{'action':a},'它接受'+ACTION[a]+'交互；需要对应工具且满足对象状态和授权条件。',True,'workable',workable)
  fuel=last('fueled','InitializeFuelLevel')
  if fuel:
   ft=fields.get('inst.components.fueled.fueltype');add('restrictions','fuel_condition',{'type':ft,'initial':fuel['args'][0] if fuel['args'] else None},'带有燃料或使用时间机制；何时消耗和可补充方式需按对象状态检查。',False,'fueled',fuel)
  for c,m,kind in [('pickable','SetUp','pick'),('lootdropper','SetLoot','loot'),('cookable','SetCookedPrefab','cook'),('dryable','SetProduct','dry')]:
   e=last(c,m)
   if not e or not e['args']:continue
   v=e['args'][0]
   products=[v] if isinstance(v,str) and c in ('pickable','cookable','dryable') else list(v.values()) if isinstance(v,dict) else []
   products=[x for x in products if isinstance(x,str) and x in entries]
   if products:
    add('mechanisms','object_products_'+c,{'products':products,'method':kind},({'pick':'可采摘产出','cook':'可经烹饪加工变成','dry':'可经晾晒加工变成'}.get(kind,'初始化掉落列表包含'))+'、'.join(label(x) for x in products[:4])+'；可用状态和额外条件仍需检查。',True,c,e)
    for product in products:
     fact(entries[product],'sources','from_'+p+'_'+kind,{'object':p,'method':kind},path,e['line'],({'pick':'可通过采摘','cook':'可通过烹饪加工','dry':'可通过晾晒加工'}.get(kind,'该生物或对象的初始掉落中包含：'))+label(p)+'。实际数量和特殊状态需核对。',True,c)
  e=last('lootdropper','SetChanceLootTable')
  if e and e['args'] and e['args'][0] in shared:
   lp,table_=shared[e['args'][0]];products=[]
   for v in table_.values() if isinstance(table_,dict) else []:
    if isinstance(v,dict) and v.get('1') in entries and isinstance(v.get('2'),(int,float)):products.append({'prefab':v['1'],'chance':v['2']})
   if products:
    f=add('mechanisms','shared_loot',products,'基础概率掉落表包含'+ '、'.join(label(x['prefab']) for x in products[:4])+'；不表示每次必定掉落，额外状态条件需核对。',True,'lootdropper',e);f.setdefault('additional_evidence',[]).append(proof(lp))
    for product in sorted({v['prefab'] for v in products}):
     rolls=[v['chance'] for v in products if v['prefab']==product]
     fact(entries[product],'sources','chance_from_'+p,{'object':p,'roll_chances':rolls,'independence_unverified':True},path,e['line'],'可能来自'+label(p)+'的基础概率掉落；不保证每次获得。',True,'lootdropper',extra=[proof(lp)])
  for comp,method in [('cookable','cook'),('dryable','dry')]:
   product=fields.get('inst.components.'+comp+'.product')
   if isinstance(product,str) and product in entries:
    add('uses','primary_transform_'+comp,{'product':product,'method':method},'可经'+('烹饪' if method=='cook' else '晾晒')+'加工变成'+label(product)+'；需要加工方式和当前材料状态允许。',True,comp)
    fact(entries[product],'sources','transform_from_'+p,{'object':p,'method':method},path,d['binding_line'],'可通过'+('烹饪' if method=='cook' else '晾晒')+'加工'+label(p)+'获得。',True,comp)
  child=fields.get('inst.components.childspawner.childname')
  if isinstance(child,str) and child in entries:children.append((p,child,path,d['binding_line']))
  brain=next((e for e in events if e['method']=='SetBrain' and e['args']),None)
  if brain and isinstance(brain['args'][0],dict) and brain['args'][0].get('reference','').startswith('brains/'):
   bp='scripts/'+brain['args'][0]['reference']+'.lua';brains[p]=(bp,path,brain['line'])
 # Read actual linked behavior trees. Presence is a behavior capability, NOT
 # proof of always-hostility or a fully reconstructed state machine.
 cache={};bmap={'ChaseAndAttack':'追击和攻击','Wander':'游荡','RunAway':'逃离威胁','Follow':'跟随','FaceEntity':'面向关注对象','StandStill':'停留','Panic':'惊慌行为'}
 for p,(bp,path,ln) in brains.items():
  if bp not in hashes:continue
  if bp not in cache:
   try:
    tree=ast.parse((source/bp).read_text(encoding='utf-8-sig',errors='replace'))
    onstart=[n for n in ast.walk(tree) if type(n).__name__=='Method' and name(n.name)=='OnStart']
    root=onstart[0].body if onstart else None
    cache[bp]=[(name(n.func),line(n)) for n in ast.walk(root) if isinstance(n,N.Call) and name(n.func) in bmap] if root else []
   except Exception:cache[bp]=[]
  nodes=cache[bp]
  if nodes:
   vals=sorted(set(n for n,l in nodes),key=lambda n: ['ChaseAndAttack','Follow','RunAway','Wander','FaceEntity','StandStill','Panic'].index(n));f=fact(entries[p],'behaviors','linked_brain_behavior',{'nodes':vals,'activation_conditions':'not_fully_reconstructed'},path,ln,'行为树具有'+ '、'.join(bmap[n] for n in vals[:3])+'；何时触发取决于状态与目标条件，不能据此认定它总会主动攻击。',True,'combat',extra=[proof(bp,nodes[0][1])])
 # Literal worldgen room distributions: environment eligibility, not map coords.
 habitats={}
 for fp in sorted((source/'scripts/map/rooms').rglob('*.lua')):
  path=fp.relative_to(source).as_posix()
  try:
   tree=ast.parse(fp.read_text(encoding='utf-8-sig',errors='replace'));r=Reader(tuning)
   for n in ast.walk(tree):
    if not isinstance(n,N.Call) or name(n.func)!='AddRoom' or len(n.args)<2:continue
    room=r.expr(n.args[1],{});roomname=r.expr(n.args[0],{})
    if not isinstance(room,dict):continue
    contents=room.get('contents',{})
    if not isinstance(contents,dict):continue
    for k in ('distributeprefabs','countprefabs'):
     for p,v in contents.get(k,{}).items() if isinstance(contents.get(k),dict) else []:
      if p in entries and isinstance(v,(int,float)) and v>0:
       habitats.setdefault(p,[]).append({'path':path,'line':line(n),'room':roomname,'realm':'cave' if '/cave/' in path else 'surface','amount_or_weight':v})
  except Exception as e:gaps.append({'path':path,'reason':'worldgen_parse_gap','error':type(e).__name__})
 for p,rows in habitats.items():
  realms=sorted(set(r['realm'] for r in rows));desc='洞穴' if realms==['cave'] else '地表' if realms==['surface'] else '地表或洞穴'
  fact(entries[p],'habitats','worldgen_distribution',{'realms':realms,'room_rules':rows},rows[0]['path'],rows[0]['line'],'官方世界生成规则允许它出现在'+desc+'的部分区域；取决于世界生成配置，不代表当前地图位置。',True)
 for parent,child,path,ln in children:
  fact(entries[child],'sources','child_of_'+parent,{'spawner':parent},path,ln,'可由'+label(parent)+'的生物生成组件产生；数量和时间条件需按世界状态核对。',True,'childspawner')
  if parent in habitats:
   h=habitats[parent][0];fact(entries[child],'habitats','spawner_environment_'+parent,{'spawner':parent,'realm':h['realm']},path,ln,'它的生成来源'+label(parent)+'可出现在'+('洞穴' if h['realm']=='cave' else '地表')+'的部分生成区域；不代表当前坐标。',True,'childspawner',extra=[proof(h['path'],h['line'])])
 # Reverse confirmed recipes, no deps/name guesses. Each edge cites its recipe.
 for product,row in list(entries.items()):
  for f in effective_facts(row,'recipes')[0]:
   if not isinstance(f['value'],dict):continue
   for ing in f['value'].get('ingredients',[]):
    if ing['prefab'] not in entries:continue
    target=entries[ing['prefab']];edge={'product':product,'recipe':f['value'].get('id'),'amount':ing['amount'],'conditions':f['value'].get('conditions',{})}
    fact(target,'uses','recipe_material_'+str(edge['recipe']),edge,f['path'],f['line'],'可作为制作'+label(product)+'的材料；成品制作仍需满足其配方条件。',True,extra=[{k:v for k,v in f.items() if k in ('kind','path','line','sha256','version','certainty')}])
 # Generated scrapbook already proves food/equipment numeric fields. Convert
 # them to functions, not numeric-only "introductions".
 for p,row in entries.items():
  for f in effective_facts(row,'properties')[0]:
   v=f.get('value');sub=row.get('scrapbook',{}).get('subcat')
   if f.get('semantic_key')!='scrapbook_baseline' or not isinstance(v,dict):continue
   if row['category']=='food' and any(k in v for k in ('hungervalue','sanityvalue','healthvalue')):
    effect={k:v[k] for k in ('hungervalue','sanityvalue','healthvalue') if k in v};fact(row,'uses','primary_food',effect,f['path'],f['line'],'可作为食物影响饥饿、生命或精神；有些效果可能为负，能否食用和最终效果取决于角色与状态。',True,'edible')
   if sub in ('armor','clothing') and any(k in v for k in ('armor','insulator','waterproofer')):fact(row,'uses','primary_scrapbook_equipment',v,f['path'],f['line'],'属于可穿戴装备，可提供'+ ('护甲防护' if 'armor' in v else '保温' if 'insulator' in v else '防水')+'；需要装备后使用，实际效果受状态影响。',True,'equippable')
 assess_basic(data)
 data['manifest']['mechanism_extraction']={'rule_version':'scoped_ast_v1','parser':'luaparser 4.0.0','bound_constructors':len(descriptors),'parsed_prefab_files':file_count,'excluded_paths':len(gaps),'default_mode':'survival_server_baseline','no_callback_execution':True}
 return data,gaps,descriptors

def assess_basic(data):
 entries=data['entries']
 # Basic understanding audit excludes identity, isolated numbers, and generic
 # "is a tool". Official prose qualifies conservatively by functional language.
 basic={};categories={};verbs=('可以','能够','用于','用来','恢复','降低','提高','增加','减少','吸引','攻击','逃','跟随','生产','制作','获取','转化','传送','存储','储存','容器','采集','种植','掉落','驯服','食用','保护')
 for p,row in entries.items():
  applicable={'creature':('behaviors','habitats','mechanisms'),'facility':('uses','mechanisms'),'tool':('uses','mechanisms'),'auxiliary_or_effect':()}.get(row['category'],('uses','sources','mechanisms'))
  candidates=[f for facet in applicable for f in effective_facts(row,facet)[0]]
  qualifying=[f for f in candidates if f.get('basic_role') or isinstance(f.get('value'),dict) and f['value'].get('method')=='craft' and f['value'].get('recipe') or f.get('semantic_key')=='official_scrapbook_note' and isinstance(f.get('value'),str) and any(w in f['value'] for w in verbs)]
  # Facilities must expose a verified interaction/working condition. Pure
  # crafting-source or material-recipe edges do not explain facility function.
  if row.get('scrapbook',{}).get('subcat') in ('armor','clothing','weapon') or 'equippable' in row.get('constructor_bound',{}).get('components',[]):qualifying=[f for f in qualifying if f.get('semantic_key','').startswith('primary_') or f.get('semantic_key')=='official_scrapbook_note']
  if row['category']=='unclassified':qualifying=[]
  if row['category']=='creature':qualifying=[f for f in qualifying if f.get('semantic_key') not in ('shared_loot','object_products_lootdropper')]
  if row['category']=='tool':qualifying=[f for f in qualifying if f.get('semantic_key','').startswith('primary_') or f.get('semantic_key')=='official_scrapbook_note']
  if row['category']=='facility':qualifying=[f for f in qualifying if f.get('semantic_key','').startswith('primary_') or isinstance(f.get('value'),str) and any(w in f['value'] for w in ('需要','放入','燃料','打开','使用','制作','烹饪'))]
  if row['category']=='auxiliary_or_effect':row.setdefault('not_applicable',{})['basic_introduction']={'reason':'auxiliary/effect identity is outside ordinary object basic-introduction audit','scope':'classified official base identity','evidence':row.get('category_evidence')}
  row['basic_understanding']={'covered':bool(qualifying),'definition':'category_minimum_v1','facts':[f['semantic_key'] for f in qualifying[:8]],'not_complete_encyclopedia':True}
  c=categories.setdefault(row['category'],{'identity':0,'basic':0});c['identity']+=1;c['basic']+=bool(qualifying)
  if qualifying:basic[p]=row['basic_understanding']
 data['manifest']['basic_audit']={'definition':'category_minimum_v1','basic_records':len(basic),'by_category':categories,'complete_knowledge_records':0}
 return data['manifest']['basic_audit']

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--knowledge',type=Path,required=True);ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--workers',type=int,default=4);a=ap.parse_args()
 data=json.loads(a.knowledge.read_text());data,gaps,descriptors=enrich(data,a.source,a.workers);a.output.mkdir(parents=True,exist_ok=True)
 from semantic_indexes import build as build_semantic
 index=build_semantic(data,a.source,descriptors,a.output)
 assess_basic(data)
 report=audit(data);report['basic_understanding']=data['manifest']['basic_audit']
 for fname,obj in [('official_knowledge.json',data),('coverage.json',report),('extraction_gaps.json',gaps),('constructor_bindings.json',descriptors)]: (a.output/fname).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
 write_bundle(data,a.output);print(json.dumps(data['manifest']['basic_audit'],ensure_ascii=False))
if __name__=='__main__':main()
