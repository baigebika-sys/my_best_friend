"""Natural Chinese -> production HTTP/provider decoder -> production game entry.
Provider responses are canned; actual imported knowledge, mocked game world.
"""
import sys,json,threading,time,urllib.request,ctypes as c,os
from pathlib import Path
from unittest.mock import patch
root=Path(__file__).resolve().parents[1];os.chdir(root);sys.path[:0]=[str(root/'external'),str(root/'tests')]
import bridge
D={}
def query(text,name,kind='properties'):D[text]=dict(intent='query_knowledge',action='knowledge',dialogue='我核对一下。',item={'name':name,'kind':kind},quantity=None)
for text,name,kind in [('你知道独奏乐器吗','onemanband','properties'),('独奏乐器有什么用','onemanband','uses'),('独奏乐器怎么做','onemanband','recipe'),('皮弗娄牛是牛吗','beefalo','identity'),('普通镐和黄金镐有什么区别','pickaxe','difference'),('它怎么做','这个','recipe'),('黄金镐子','goldenpickaxe','recipe'),('水獭是什么','otter','identity'),('这是怎样的一种生物','这个','identity'),('水獭在哪里','otter','habitats'),('暗影操控器是什么','researchlab3','identity'),('这个怎么做的','这个','recipe'),('暗影甲有什么用','暗影甲','uses'),('科技是什么','科技','identity'),('烧灼园艺锄怎么做','fumarole_farm_hoe','recipe')]:query(text,name,kind)
query('请简单介绍一下独奏乐器','onemanband','identity')
query('黄金镐子怎么制作','goldenpickaxe','recipe')
for text,item,n in [('给我损坏的黄金镐','goldenpickaxe',1),('你给我采点花瓣呗','petals',1),('能不能帮我采一点花瓣呀','petals',1),('麻烦你捡一点树枝吧','twigs',1),('给我3个树枝','twigs',3)]:D[text]=dict(intent='command_goal',action='goal',dialogue='我会核对目标。',item=item,quantity=n,deliver=True)
for text,action in [('先暂停一下','pause'),('取消任务吧','cancel')]:D[text]=dict(intent='command_'+action,action=action,dialogue='好。',item=None,quantity=None)
server=bridge.BridgeServer(('127.0.0.1',0));server.ai=True;server.api_key='SIMULATED-PRIVATE-KEY';thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();endpoint='http://127.0.0.1:%d'%server.server_address[1];opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));results={};calls=[]
class Provider:
 def __init__(self,content):self.content=content
 def __enter__(self):return self
 def __exit__(self,*a):pass
 def read(self,n):return json.dumps({'choices':[{'message':{'content':json.dumps(self.content,ensure_ascii=False)}}]}).encode()
def provider(req,timeout):
 payload=json.loads(req.data);current=json.loads(payload['messages'][-1]['content']);calls.append(current['current_instruction']);return Provider(D[current['current_instruction']])
try:
 with patch.object(bridge,'urlopen',provider):
  for i,(text,decision) in enumerate(D.items()):
   packet=dict(protocol=bridge.PROTOCOL,request_id='r3-'+str(i),friend_id='2',friend_name='朋友',message=text,conversation_id='test:player',result_receipts=True,game_state={})
   with opener.open(urllib.request.Request(endpoint+'/tasks',data=json.dumps(packet).encode()),timeout=2) as r:json.load(r)
   for _ in range(100):
    with opener.open(endpoint+'/tasks/'+packet['request_id']+'?instance='+server.instance_id,timeout=2) as r:result=json.load(r)
    if result['state']!='pending':break
    time.sleep(.005)
   assert result['state']=='done',(text,result);results[text]={k:result.get(k) for k in ('action','item','quantity','reply')}
  assert len(calls)==len(D)
finally:server.shutdown();server.server_close();thread.join(2)


def lua(v):
 if v is None:return 'nil'
 if isinstance(v,bool):return 'true' if v else 'false'
 if isinstance(v,(int,float)):return str(v)
 if isinstance(v,str):return '\"'+v.replace('\\','\\\\').replace('\"','\\\"').replace('\n','\\n').replace('\r','\\r')+'\"'
 if isinstance(v,list):return '{'+','.join(map(lua,v))+'}'
 return '{'+','.join('['+lua(k)+']='+lua(x) for k,x in v.items())+'}'
lib=c.CDLL('liblua5.4.so.0');lib.luaL_newstate.restype=c.c_void_p;lib.luaL_openlibs.argtypes=[c.c_void_p];lib.luaL_loadbufferx.argtypes=[c.c_void_p,c.c_char_p,c.c_size_t,c.c_char_p,c.c_char_p];lib.lua_pcallk.argtypes=[c.c_void_p,c.c_int,c.c_int,c.c_int,c.c_longlong,c.c_void_p];lib.lua_tolstring.argtypes=[c.c_void_p,c.c_int,c.POINTER(c.c_size_t)];lib.lua_tolstring.restype=c.c_char_p;lib.lua_close.argtypes=[c.c_void_p]
setup=(root/'tests/test_foundation.lua').read_text().split("reset();put(friend,'twigs',3);plant",1)[0]
harness=(root/'tests/test_language_entry.lua').read_text().split("for _,text in ipairs({'我想要1个木头'",1)[0]
harness=harness.replace('local pending={};local replies={}', 'local pending={};local replies={};local receipts={}')
harness=harness.replace("elseif url:find('/cancel',1,true)", "elseif url:find('/result',1,true) then receipts[#receipts+1]=wires[body];cb('',true,200)\n   elseif url:find('/cancel',1,true)")
harness=harness.replace('local request=pending[#pending];assert(request.packet.message==text)', 'local request=pending[#pending];if text=="开启知识诊断" or text=="关闭知识诊断" then return end;assert(request.packet.message==text)')
harness=harness.replace('function h:last()return replies[#replies]end', 'function h:last()return replies[#replies]end\n function h:receipts()return receipts end\n function h:fail(request)request.callback(\"\",false,503)end')
source=setup+'\nlocal LANGUAGE_FIXTURES='+lua(results)+'\n'+harness+'\n'+(root/'tests/test_knowledge_r3.lua').read_text()
state=lib.luaL_newstate();lib.luaL_openlibs(state)
try:
 raw=source.encode();code=lib.luaL_loadbufferx(state,raw,len(raw),b'r3 natural entry',None)
 if not code:code=lib.lua_pcallk(state,0,-1,0,0,None)
 if code:raise AssertionError(lib.lua_tolstring(state,-1,None).decode())
finally:lib.lua_close(state)
print('PASS '+str(len(calls))+' natural messages through real HTTP/model decoder then real game chat entry; model provider and world simulated, NOT live model/DST')
