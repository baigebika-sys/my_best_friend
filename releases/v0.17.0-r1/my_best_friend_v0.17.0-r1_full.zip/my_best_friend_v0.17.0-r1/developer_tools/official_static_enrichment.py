"""Read official generated scrapbook tables and literal recipes, without Lua execution.
Relations called deps are NOT interpreted as sources. Static baseline is NOT live state.
"""
import hashlib,re
from import_dst_knowledge import tokens,literal,value,split_args,table,po_records,FACETS,ID

def literal_tree(ts):
    """Complete literal-only tree. Unknown expressions stay absent, never evaluated."""
    def atom(i):
        if ts[i][0]=='{':return obj(i)
        if ts[i][0]=='-' and i+1<len(ts):
            x=literal(ts[i+1][0]);return (-x if isinstance(x,(int,float)) else None),i+2
        return literal(ts[i][0]),i+1
    def obj(i):
        out={};array=[];i+=1
        while i<len(ts) and ts[i][0]!='}':
            if ts[i][0] in (',',';'):i+=1;continue
            key=None
            if i+1<len(ts) and ts[i+1][0]=='=':key=ts[i][0];i+=2
            elif ts[i][0]=='[' and i+3<len(ts) and ts[i+2][0]==']' and ts[i+3][0]=='=':key=literal(ts[i+1][0]);i+=4
            v,j=atom(i)
            # Only accept an entire literal expression, not its first token.
            if j<len(ts) and ts[j][0] not in (',',';','}'):
                depth=0
                while j<len(ts):
                    t=ts[j][0]
                    if depth==0 and t in (',',';','}'):break
                    if t in ('{','(','['):depth+=1
                    elif t in ('}',')',']'):depth-=1
                    j+=1
                v=None
            if v is not None:
                if key is not None:out[key]=v
                else:array.append(v)
            i=j
        return (out if out or not array else array),i+1
    return obj(0)[0]

def enrich(data,source,localization):
    files={p.relative_to(source).as_posix():p for p in source.rglob('*.lua')}
    entries=data['entries'];build=data['manifest']['build'];po=po_records(localization.read_text(encoding='utf-8-sig')) if localization else {}
    def proof(path,line=1,kind='official_script'):
        return dict(kind=kind,path=path,line=line,sha256=data['manifest']['source_sha256'][path],version=build,certainty='verified')
    def make(prefab,evidence):
        if prefab not in entries:entries[prefab]=dict(prefab=prefab,names={},aliases=[],category='unclassified',identity=evidence,name_evidence={},knowledge_complete=False,**{f:[] for f in FACETS})
        return entries[prefab]
    def fact(row,facet,key,val,evidence,summary=None):
        row[facet].append(dict(field=key,semantic_key=key,value=val,**evidence,**({'summary':summary} if summary else {})))
    path=next(p for p in files if p.endswith('screens/redux/scrapbookdata.lua'))
    text=files[path].read_text(encoding='utf-8-sig');ts=tokens(text);start=next(i for i,t in enumerate(ts) if t[0]=='{');book=literal_tree(ts[start:]);variants=[]
    for key,obj in book.items():
        if not isinstance(obj,dict) or not ID.fullmatch(str(obj.get('prefab',''))):continue
        prefab=obj['prefab'];match=re.search(r'\b'+re.escape(key)+r'\s*=\s*\{',text);evidence=proof(path,text.count('\n',0,match.start())+1 if match else 1);row=make(prefab,evidence)
        namekey=str(obj.get('name',prefab)).upper();displaycontext='STRINGS.NAMES.'+namekey
        basecontext='STRINGS.NAMES.'+prefab.upper();base=po.get(basecontext);display=po.get(displaycontext)
        record=base or display;context=basecontext if base else displaycontext
        if record and not record.get('fuzzy'):
            for lang,field in [('zh','msgstr'),('en','msgid')]:
                # Actual script canonical names win; generated scrapbook name
                # overrides describe a display state, never rename its identity.
                if lang not in row['names'] and record.get(field):
                    row['names'][lang]=record[field];row['name_evidence'][lang]={**proof('provided/'+localization.name,record['line'],'official_localization'),'context':context}
        if namekey!=prefab.upper() and display and not display.get('fuzzy'):
            for lang,field in [('zh','msgstr'),('en','msgid')]:
                if display.get(field) and display[field]!=row['names'].get(lang):
                    fact(row,'variants','scrapbook_display_'+key+'_'+lang,{'kind':'state','name':display[field],'base_prefab':prefab,'name_key':namekey},evidence,'官方图鉴使用显示名 '+display[field]+'，底层对象仍是 '+prefab+'；不能据显示名称推断独立 prefab。')
        if key!=prefab:
            variants.append({'entry':key,'prefab':prefab,'display_name_key':namekey,'evidence':evidence})
            fact(row,'variants','scrapbook_variant_'+key,{'kind':'state','scrapbook_entry':key,'base_prefab':prefab,'name_key':namekey},evidence)
        kind=obj.get('type');sub=obj.get('subcat');category='creature' if kind in ('creature','giant') else 'food' if kind=='food' else 'tool' if sub=='tool' else 'item' if kind=='item' else 'facility' if sub in ('container','craftingstation','structure','decoration') else 'natural_or_interactive'
        row['category']=category;row['category_evidence']=evidence
        row['scrapbook']={'entry':key,'type':kind,'subcat':sub,'baseline_only':True,'related_entities_not_sources':obj.get('deps',[])}
        labels={'hungervalue':'基础饥饿','healthvalue':'基础生命','sanityvalue':'基础精神','health':'基准生命上限','damage':'基准攻击伤害','weapondamage':'基准武器伤害','planardamage':'基准位面伤害','finiteuses':'基准使用次数','armor':'基准护甲耐久','armorabsorb':'基准护甲吸收','waterproofer':'基准防水','insulator':'基准保温','stacksize':'基准堆叠上限','perishable':'基准保质期（游戏秒）'}
        props={k:obj[k] for k in labels if k in obj and isinstance(obj[k],(int,float,str))}
        if props:fact(row,'properties','scrapbook_baseline',props,evidence,'官方图鉴基准值：'+'、'.join(labels[k]+str(v) for k,v in props.items())+'。这些不是当前对象的实时状态，角色、模式和状态可能改变实际效果。')
        if props and kind=='food':fact(row,'uses','scrapbook_food_type',obj.get('foodtype'),evidence,'官方图鉴将它列为食物；能否食用及最终效果取决于角色和食物状态。')
        if sub=='tool':fact(row,'uses','scrapbook_tool_category',sub,evidence,'官方图鉴将它列为工具；具体动作和限制需结合对象组件或机制说明。')
        special=obj.get('specialinfo') or prefab.upper();context='STRINGS.SCRAPBOOK.SPECIALINFO.'+special;record=po.get(context)
        if record and record.get('msgstr') and not record.get('fuzzy'):
            ev={**proof('provided/'+localization.name,record['line'],'official_localization'),'context':context,'mapping':evidence,'mapping_rule_source':'scripts/screens/redux/scrapbookscreen.lua:1803'}
            # Prose is documented mechanics; do not guess its semantic facet.
            fact(row,'mechanisms','official_scrapbook_note',record['msgstr'],ev)
            fact(row,'uses','official_scrapbook_note',record['msgstr'],ev)
            # Reuse the exact official prose, never promote code excerpts.
            # These are searchable documented statements, not complete AI models.
            note=record['msgstr']
            if category=='creature' and any(word in note for word in ('攻击','跟随','逃跑','随从','驯服','敌对','睡觉')):
                fact(row,'behaviors','documented_behavior',note,ev)
            if any(word in note for word in ('只能','无法','不能','仅在','消耗','必须','需要')):
                fact(row,'restrictions','documented_restriction',note,ev)
            if any(word in note for word in ('栖息','出现于','生成于')):
                fact(row,'habitats','documented_environment',note,ev)
    # Literal constructors in shared factories remain unresolved unless an
    # authoritative generated scrapbook entry independently confirms identity.
    # Add localized names for literal identities as well.
    for prefab,row in entries.items():
        record=po.get('STRINGS.NAMES.'+prefab.upper())
        if record and not record.get('fuzzy'):
            for lang,field in [('zh','msgstr'),('en','msgid')]:
                if lang not in row['names'] and record.get(field):row['names'][lang]=record[field];row['name_evidence'][lang]={**proof('provided/'+localization.name,record['line'],'official_localization'),'context':'STRINGS.NAMES.'+prefab.upper()}
    tech_values={}
    cp=files.get('scripts/constants.lua')
    if cp:
        cts=tokens(cp.read_text(encoding='utf-8-sig'))
        for i,t in enumerate(cts):
            if t[0]=='TECH' and i+2<len(cts) and cts[i+1][0]=='=' and cts[i+2][0]=='{':
                tech_values=literal_tree(cts[i+2:]);break
    # Recipe2 and AddRecipe2 use (name, ingredients, tech, config).
    for path,p in files.items():
        if path!='scripts/recipes.lua':continue
        ts=tokens(p.read_text(encoding='utf-8-sig'))
        for i,t in enumerate(ts):
            if t[0] not in ('Recipe2','AddRecipe2') or i+1>=len(ts) or ts[i+1][0]!='(':continue
            args,_=split_args(ts,i+1)
            if len(args)<3:continue
            rid=value(args[0]);cfg=table(args[3]) if len(args)>3 else {};cfg=cfg or {};prefab=cfg.get('product',rid)
            if prefab not in entries:continue
            rawcfg=' '.join(x[0] for x in args[3]) if len(args)>3 else ''
            if re.search(r'\bproduct\s*=',rawcfg) and 'product' not in cfg:continue
            ing=[];complete=True;a=args[1];j=1
            if not a or a[0][0]!='{':continue
            while j<len(a)-1:
                if a[j][0]==',':j+=1;continue
                if a[j][0]!='Ingredient' or j+1>=len(a) or a[j+1][0]!='(':complete=False;break
                ia,end=split_args(a,j+1);name=value(ia[0]) if ia else None;n=value(ia[1]) if len(ia)>1 else None
                if not isinstance(name,str) or not isinstance(n,(int,float)):complete=False;break
                ing.append({'prefab':name,'amount':n});j=end+1
            if not complete or not ing:continue
            tech=''.join(x[0] for x in args[2]);condition_excerpts=[' '.join(x[0] for x in arg)[:700] for arg in args[3:]]
            val={'id':rid,'ingredients':ing,'technology_expression':tech,'output_count':cfg.get('numtogive',None if re.search(r'\bnumtogive\s*=',rawcfg) else 1),'conditions':cfg,'condition_excerpts':condition_excerpts,'requires_runtime_condition_check':True}
            label=lambda x:entries.get(x,{}).get('names',{}).get('zh',x)
            levels=tech_values.get(tech.removeprefix('TECH.'),{})
            tech_labels={'SCIENCE':'科学','MAGIC':'魔法','ANCIENT':'远古','SEAFARING':'航海','CELESTIAL':'天体','MOON_ALTAR':'月亮祭坛','SHADOW':'暗影'}
            naturaltech='、'.join(tech_labels.get(k,k)+str(v)+'级' for k,v in levels.items() if isinstance(v,(int,float)) and v>0) if isinstance(levels,dict) else ''
            if tech=='TECH.NONE':naturaltech='无科技要求'
            val['technology_levels']=levels
            summary='脚本配方：'+ '、'.join(label(x['prefab'])+'×'+str(x['amount']) for x in ing)+'；产出'+(str(val['output_count']) if val['output_count'] is not None else '数量需运行时核对')+'；科技条件 '+(naturaltech or tech)+'。角色、设施及附加条件仍以游戏实际配方检查为准。'
            fact(entries[prefab],'recipes','literal_recipe_'+str(rid),val,proof(path,t[2]),summary)
            fact(entries[prefab],'sources','crafting_source_'+str(rid),{'method':'craft','recipe':rid,'requires_runtime_condition_check':True},proof(path,t[2]),'可以通过脚本中的制作配方 '+str(rid)+' 获取；科技、角色、设施及其他条件需按实际配方检查。')
    data['manifest']['scrapbook_entries']=len(book);data['manifest']['scrapbook_variants']=variants;data['manifest']['indexed_prefab_count']=len(entries)
    data['manifest']['scope_note']='literal prefab declarations plus official generated scrapbook; dynamic factories and full semantic completeness require review; not a proven full universe'
    return data
