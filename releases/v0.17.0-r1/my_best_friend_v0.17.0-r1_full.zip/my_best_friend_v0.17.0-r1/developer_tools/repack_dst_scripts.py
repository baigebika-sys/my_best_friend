"""Make independent uploadable ZIPs from official scripts.zip (no code execution).
Keeps all .lua files and their paths, omits translations already uploaded separately.
Checks original ZIP CRC and records hashes. Never edits the original scripts.zip.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

LIMIT = 32 * 1024 * 1024

def sha_file(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def repack(source,output,target_bytes=16*1024*1024):
    if not 1<=target_bytes<=24*1024*1024:raise ValueError('Part payload must be between 1 byte and 24 MiB')
    with zipfile.ZipFile(source) as z:
        bad=z.testzip()
        if bad:raise ValueError('Original ZIP CRC check failed: '+bad)
        infos=sorted((i for i in z.infolist() if not i.is_dir() and i.filename.endswith('.lua')),key=lambda i:i.filename)
        if not infos or not any('/prefabs/' in '/'+i.filename for i in infos):raise ValueError('Not a complete scripts ZIP: missing .lua files or prefabs directory')
        for i in infos:
            path=PurePosixPath(i.filename)
            if path.is_absolute() or '..' in path.parts or '\\' in i.filename or ':' in i.filename:raise ValueError('Unsafe archive path')
        if len({i.filename for i in infos})!=len(infos):raise ValueError('Duplicate Lua file paths in source ZIP')
        if output.exists():raise ValueError('Output directory exists; choose a new directory to preserve previous files')
        output.mkdir(parents=True)
        manifest={'format':'independent_zip_parts','original_zip_sha256':sha_file(source),'original_crc':'PASS','selected_file_count':len(infos),'selection':'all .lua files with unchanged archive paths and bytes; translation files are separate','files':{},'parts':[]}
        archive=None;part_path=None;payload=0
        def finish():
            if archive is None:return
            archive.close()
            if part_path.stat().st_size>=LIMIT:raise ValueError('A part still exceeds 32 MiB; use a smaller --part-mib')
            manifest['parts'].append({'file':part_path.name,'bytes':part_path.stat().st_size,'sha256':sha_file(part_path)})
        try:
            for info in infos:
                if archive is None or (payload and payload+info.file_size>target_bytes):
                    finish();part_path=output/('dst_scripts_%03d.zip'%(len(manifest['parts'])+1));archive=zipfile.ZipFile(part_path,'w',zipfile.ZIP_DEFLATED);payload=0
                raw=z.read(info);archive.writestr(info.filename,raw);payload+=len(raw)
                manifest['files'][info.filename]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'CRC32':'%08x'%info.CRC}
            finish();archive=None
        finally:
            if archive is not None:archive.close()
    (output/'scripts_parts_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--part-mib',type=int,default=16,choices=range(1,25));a=p.parse_args()
    try:
        result=repack(a.source,a.output,a.part_mib*1024*1024)
    except (OSError,ValueError,zipfile.BadZipFile) as e:
        p.exit(1,'Cannot repack: '+str(e)+'\n')
    print('Original ZIP CRC: PASS. Original file unchanged.')
    print('Upload ALL files below, including the manifest:')
    for part in result['parts']:print(str(a.output/part['file'])+' (%d bytes)'%part['bytes'])
    print(a.output/'scripts_parts_manifest.json')
if __name__=='__main__':main()
