"""Local HTTP + real provider decoder + real chat handler/work, simulated model/world."""
import sys, json, threading, time, urllib.request, ctypes as c, os
from pathlib import Path
from unittest.mock import patch
root=Path(__file__).resolve().parent.parent
os.chdir(root);sys.path[:0]=[str(root/'external'),str(root/'tests')]
import bridge
from knowledge_cases import CASES

def lua(value):
    if value is None:return 'nil'
    if isinstance(value,bool):return 'true' if value else 'false'
    if isinstance(value,(int,float)):return str(value)
    if isinstance(value,str):return '"'+value.replace('\\','\\\\').replace('"','\\"').replace('\n','\\n').replace('\r','\\r')+'"'
    if isinstance(value,list):return '{'+','.join(map(lua,value))+'}'
    return '{'+','.join('['+lua(k)+']='+lua(v) for k,v in value.items())+'}'

server=bridge.BridgeServer(('127.0.0.1',0));server.ai=True;server.api_key='SIMULATED-PRIVATE-KEY'
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
endpoint='http://127.0.0.1:%d'%server.server_address[1]
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));results={};calls=[]
class Provider:
    def __init__(self,content):self.content=content
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def read(self,n):return json.dumps({'choices':[{'message':{'content':json.dumps(self.content,ensure_ascii=False)}}]}).encode()
def provider(req,timeout):
    payload=json.loads(req.data);current=json.loads(payload['messages'][-1]['content'])
    calls.append(current['current_instruction'])
    return Provider(CASES[current['current_instruction']])
try:
    with patch.object(bridge,'urlopen',provider):
        for i,(text,decision) in enumerate(CASES.items()):
            packet=dict(protocol=bridge.PROTOCOL,request_id='lang-'+str(i),friend_id='2',friend_name='朋友',message=text,conversation_id='test',game_state={})
            with opener.open(urllib.request.Request(endpoint+'/tasks',data=json.dumps(packet).encode()),timeout=2) as r:first=json.load(r)
            for attempt in range(100):
                with opener.open(endpoint+'/tasks/'+packet['request_id']+'?instance='+server.instance_id,timeout=2) as r:result=json.load(r)
                if result['state']!='pending':break
                time.sleep(.005)
            assert result['state']=='done',(text,result)
            results[text]={k:result.get(k) for k in ('action','item','quantity','reply')}
            with opener.open(urllib.request.Request(endpoint+'/tasks',data=json.dumps(packet).encode()),timeout=2) as r:assert json.load(r)['task_id']==packet['request_id']
        assert len(calls)==len(CASES)
finally:server.shutdown();server.server_close();thread.join(2)
print('PASS %d natural input fixtures through real local HTTP/model response validation; provider SIMULATED; repeated request IDs not executed twice'%len(results),flush=True)
lib=c.CDLL('liblua5.4.so.0');lib.luaL_newstate.restype=c.c_void_p
lib.luaL_openlibs.argtypes=[c.c_void_p];lib.luaL_loadbufferx.argtypes=[c.c_void_p,c.c_char_p,c.c_size_t,c.c_char_p,c.c_char_p]
lib.lua_pcallk.argtypes=[c.c_void_p,c.c_int,c.c_int,c.c_int,c.c_longlong,c.c_void_p];lib.lua_tolstring.argtypes=[c.c_void_p,c.c_int,c.POINTER(c.c_size_t)];lib.lua_tolstring.restype=c.c_char_p;lib.lua_close.argtypes=[c.c_void_p]
def run(text,label,execute=True):
    state=lib.luaL_newstate();lib.luaL_openlibs(state);data=text.encode()
    try:
        status=lib.luaL_loadbufferx(state,data,len(data),label.encode(),None)
        if not status and execute:status=lib.lua_pcallk(state,0,-1,0,0,None)
        if status:raise AssertionError(label+': '+lib.lua_tolstring(state,-1,None).decode())
    finally:lib.lua_close(state)
for path in (root/'my_best_friend').rglob('*.lua'):run(path.read_text(),str(path),False)
# Reuse only fixture setup, not the old unrelated gameplay tests.
setup=(root/'tests/test_foundation.lua').read_text().split("reset();put(friend,'twigs',3);plant",1)[0]
# R1 scenarios intentionally use their original empty official-data fixture.
# Current official generated data is checked separately in run_official_checks.py.
run("package.preload['ybf_official_knowledge']=function()return {manifest={},entries={}}end\n"+setup+'\nlocal LANGUAGE_FIXTURES='+lua(results)+'\n'+(root/'tests/test_language_entry.lua').read_text().split("for _,text in ipairs({'我想要1个木头'",1)[0]+'\n'+(root/'tests/test_knowledge_entry.lua').read_text()+'\n'+(root/'tests/test_knowledge_r1.lua').read_text(),'knowledge and generic gathering entry')
for name in []:
    run((root/'tests'/name).read_text(),name)
print('PASS v0.14 knowledge/gathering production entry checks; canned provider + mocked world, NOT real model/DST',flush=True)
