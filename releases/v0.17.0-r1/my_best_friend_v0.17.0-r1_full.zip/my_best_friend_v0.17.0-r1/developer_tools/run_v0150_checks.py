from pathlib import Path
import ctypes as c,os
root=Path(__file__).resolve().parents[1];os.chdir(root)
setup=(root/'tests/test_foundation.lua').read_text().split("reset();put(friend,'twigs',3);plant",1)[0]
checks=(root/'tests/test_v0150_warehouse.lua').read_text()
lib=c.CDLL('liblua5.4.so.0');lib.luaL_newstate.restype=c.c_void_p;lib.luaL_openlibs.argtypes=[c.c_void_p];lib.luaL_loadbufferx.argtypes=[c.c_void_p,c.c_char_p,c.c_size_t,c.c_char_p,c.c_char_p];lib.lua_pcallk.argtypes=[c.c_void_p,c.c_int,c.c_int,c.c_int,c.c_longlong,c.c_void_p];lib.lua_tolstring.argtypes=[c.c_void_p,c.c_int,c.POINTER(c.c_size_t)];lib.lua_tolstring.restype=c.c_char_p;lib.lua_close.argtypes=[c.c_void_p]
state=lib.luaL_newstate();lib.luaL_openlibs(state);raw=(setup+checks).encode()
try:
 code=lib.luaL_loadbufferx(state,raw,len(raw),b'v0150 warehouse and goals',None)
 if not code:code=lib.lua_pcallk(state,0,-1,0,0,None)
 if code:raise AssertionError(lib.lua_tolstring(state,-1,None).decode())
finally:lib.lua_close(state)
print('World, pathing, container and builder simulated; production work modules. NOT actual DST or live model.')
