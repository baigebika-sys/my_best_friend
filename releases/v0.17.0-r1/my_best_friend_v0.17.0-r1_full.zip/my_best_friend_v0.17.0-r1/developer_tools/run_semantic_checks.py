"""R4 actual Chinese chat entry using real local HTTP bridge/canned provider.
Unseen samples are selected AFTER rules; no object-specific adaptations added.
"""
import sys,json,hashlib,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'knowledge/official_knowledge.json').read_text());index=json.loads((root/'knowledge/semantic_index.json').read_text());E=data['entries']
adapted=set(json.loads((root/'knowledge/reviewed_adapters_756039.json').read_text())['entries'])
strata={k:index['collections'][v] for k,v in [('tool','tools'),('equipment','equipment'),('material','materials'),('food','food'),('building','buildings'),('creature','creatures'),('natural','natural')]}
samples=[]
for category,ids in strata.items():
 eligible=[p for p in ids if p not in adapted and E[p].get('names',{}).get('zh')]
 eligible.sort(key=lambda p:hashlib.sha256(('756039:r4-unseen-v1:'+category+':'+p).encode()).hexdigest())
 for p in eligible[:8]:samples.append({'category':category,'prefab':p,'name':E[p]['names']['zh'],'basic_declared':E[p]['basic_understanding']['covered']})
# Use existing tested HTTP/provider + game-entry harness with new corpus.
old=(root/'developer_tools/run_knowledge_r3_checks.py').read_text();a=old.index('D={}');b=old.index('server=bridge.BridgeServer',a)
D={}
def q(text,name,kind='identity'):D[text]=dict(intent='query_knowledge',action='knowledge',dialogue='我查阅资料。',item={'name':name,'kind':kind},quantity=None)
for s in samples:q('能介绍一下'+s['name']+'吗',s['prefab'])
queries=[('黄金工具有哪些','黄金工具','category'),('你知道哪些建材','建材','category'),('有哪些恢复精神的食物','恢复精神的食物','category'),('继续展开','这个分类','category'),('介绍全部墨荒','墨荒','family'),('天体英雄有哪些阶段','天体英雄','family'),('普通毒菌蟾蜍和特殊版本有什么区别','毒菌蟾蜍','difference'),('猪人吃了4个怪物肉会怎样','猪人','condition'),('如果猪人吃了三个怪物肉会怎么样','猪人','condition'),('猪人吃了4个浆果会怎样','猪人','condition'),('你知道黄金斧子吗','goldenaxe','identity'),('蝙蝠是什么','bat','identity'),('遮阳棚有什么用','siestahut','uses'),('是的，就是这个','glasscutter','identity'),('暗影甲有什么用','暗影甲','uses'),('是的','glasscutter','identity'),('取消查询','这个','identity'),('你知道指南针吗','compass','identity'),('这个有什么用','这个','uses'),('全部介绍一下','这个','family'),('不问了','这个','identity'),('你知道遮阳棚吗','siestahut','identity'),('这个怎么做','这个','recipe'),('黄金斧和普通斧有什么区别','goldenaxe','difference')]
material=next(s for s in samples if s['category']=='material' and s['prefab'] in index['reverse_recipes'])
dish=next(p for p in sorted(index['cooking']) if p not in adapted and E[p].get('names',{}).get('zh'))
extra={'material':material['name']+'能用来制作什么','dish':E[dish]['names']['zh']+'怎么烹饪'}
q(extra['material'],material['prefab'],'uses');q(extra['dish'],dish,'recipe')
for args in queries:q(*args)
D['你知道指南针吗']['item']['answer_style']='direct'
D['猪人吃了4个怪物肉会怎样']=dict(intent='command_goal',action='goal',dialogue='好。',item='monstermeat',quantity=4,deliver=True)
# Include typo/deletion phrases for fresh samples without special aliases.
for s in samples[:4]:
 cs=list(s['name'])
 if len(cs)>=4:q('你认识'+''.join(cs[:1]+cs[2:])+'吗',s['prefab'])
for text,item,n in [('给我1个花瓣','petals',1),('给我1个树枝','twigs',1)]:D[text]=dict(intent='command_goal',action='goal',dialogue='好。',item=item,quantity=n,deliver=True)
D['取消任务吧']=dict(intent='command_cancel',action='cancel',dialogue='好。',item=None,quantity=None)
D['先暂停一下']=dict(intent='command_pause',action='pause',dialogue='好。',item=None,quantity=None)
source=old[:a]+'D='+repr(D)+'\n'+old[b:]
source=source.replace("(root/'tests/test_knowledge_r3.lua').read_text()", "(root/'tests/test_semantic_entry.lua').read_text()")
source=source.replace("source=setup+'\\nlocal LANGUAGE_FIXTURES='", "source=setup+'\\nlocal EXTRA_QUERIES='+lua("+repr(extra)+")+'\\nlocal UNSEEN_SAMPLES='+lua("+repr(samples)+")+'\\nlocal LANGUAGE_FIXTURES='")
source=source.replace("state=lib.luaL_newstate();lib.luaL_openlibs(state)", "Path('/tmp/r4-entry-source.lua').write_text(source)\nstate=lib.luaL_newstate();lib.luaL_openlibs(state)")
# old script __file__ must point at the developer tool for root discovery.
exec(compile(source,str(root/'developer_tools/run_knowledge_r3_checks.py'),'exec'),{'__file__':str(root/'developer_tools/run_knowledge_r3_checks.py'),'__name__':'__main__'})
(root/'tests/v0140_r4_unseen_selection.json').write_text(json.dumps({'algorithm':'SHA256 lexical order of 756039:r4-unseen-v1:<stratum>:<prefab>; first 8 named entries per stratum, excludes all reviewed object adapters; no coverage prefilter','strata':list(strata),'samples':samples,'provider':'canned','world':'mocked','real_model':False,'dst_game':False},ensure_ascii=False,indent=2)+'\n')
