"""Non-executing, bounded Lua AST data-flow reader. No Lua VM, eval or callbacks.
Only constructor-bound statements and pure expressions are reduced. Unknown
branches are excluded; post-init hooks passed to factories are followed as AST.
Event/equip/use callbacks are NOT followed. Unsupported paths are audited.
"""
from dataclasses import dataclass
from luaparser import ast
from luaparser import astnodes as N
import math

class Unknown:pass
U=Unknown()
def unknown(v):return isinstance(v,Unknown)
@dataclass
class Function:
 node:object
 env:dict
@dataclass
class Instance:
 fields:dict
 components:set
 events:list
@dataclass
class Reference:
 path:str
 owner:object=None

def name(n):
 if isinstance(n,N.Name):return n.id
 if isinstance(n,N.Index):
  k=n.idx.id if isinstance(n.idx,N.Name) else n.idx.s.decode() if isinstance(n.idx,N.String) else ''
  return name(n.value)+'.'+str(k)
 return ''
def line(n):return getattr(getattr(n,'_first_token',None),'line',1) or 1

class Reader:
 def __init__(self,tuning=None):self.tuning=tuning or {};self.descriptors={};self.shared={};self.gaps=[];self.steps=0;self.depth=0
 def expr(self,n,env):
  if n is None:return None
  if isinstance(n,N.Name):return env.get(n.id,U)
  if isinstance(n,N.Number):return n.n
  if isinstance(n,N.String):return n.s.decode('utf-8',errors='replace') if isinstance(n.s,bytes) else n.s
  if isinstance(n,N.Nil):return None
  if isinstance(n,N.TrueExpr):return True
  if isinstance(n,N.FalseExpr):return False
  if isinstance(n,N.Table):
   out={};seq=1
   for f in n.fields:
    k=f.key.id if isinstance(f.key,N.Name) and not f.between_brackets else self.expr(f.key,env) if f.key else seq
    if f.key is None:seq+=1
    if not unknown(k):out[k]=self.expr(f.value,env)
   return out
  if isinstance(n,N.Index):
   base=self.expr(n.value,env);key=n.idx.id if isinstance(n.idx,N.Name) and n.notation==N.IndexNotation.DOT else self.expr(n.idx,env)
   if isinstance(base,dict):return base.get(key,None)
   if isinstance(base,Instance):
    if key=='components':return {k:Reference('inst.components.'+k,base) for k in base.components}
    return base.fields.get(str(key),U)
   if isinstance(base,Reference):
    path=base.path+'.'+str(key);inst=base.owner or env.get('__instance')
    if isinstance(inst,Instance) and path.startswith('inst.components.'):return inst.fields.get(path,U)
    return Reference(path)
   return U
  typ=type(n).__name__
  if typ in ('AndLoOp','OrLoOp'):
   a=self.expr(n.left,env)
   if unknown(a):return U
   truth=a is not None and a is not False
   return self.expr(n.right,env) if (truth if typ=='AndLoOp' else not truth) else a
  if typ in ('UMinusOp','ULNotOp'):
   a=self.expr(n.operand,env)
   if unknown(a):return U
   return -a if typ=='UMinusOp' and isinstance(a,(int,float)) else (a is None or a is False) if typ=='ULNotOp' else U
  operations={'AddOp':lambda a,b:a+b,'SubOp':lambda a,b:a-b,'MultOp':lambda a,b:a*b,'FloatDivOp':lambda a,b:a/b,'FloorDivOp':lambda a,b:a//b,'ExpoOp':lambda a,b:a**b,'ModOp':lambda a,b:a%b,'Concat':lambda a,b:str(a)+str(b),'EqToOp':lambda a,b:a==b,'NotEqToOp':lambda a,b:a!=b,'LessThanOp':lambda a,b:a<b,'GreaterThanOp':lambda a,b:a>b,'LessOrEqThanOp':lambda a,b:a<=b,'GreaterOrEqThanOp':lambda a,b:a>=b}
  if typ in operations:
   a=self.expr(n.left,env);b=self.expr(n.right,env)
   if unknown(a) or unknown(b):return U
   try:return operations[typ](a,b)
   except (TypeError,ValueError,ZeroDivisionError,OverflowError):return U
  if isinstance(n,N.AnonymousFunction):return Function(n,env.copy())
  if isinstance(n,N.Call):
   fn=name(n.func);args=[self.expr(a,env) for a in n.args]
   if fn=='require' and args and isinstance(args[0],str):return Reference(args[0])
   if fn=='CreateEntity':
    inst=Instance({},set(),[]);env['__instance']=inst;return inst
   if fn=='Prefab' and len(args)>1 and isinstance(args[0],str):
    factory=args[1]
    if isinstance(factory,Function):
     child=factory.env.copy();done,result=self.block(factory.node.body,child)
     inst=result[0] if done and result and isinstance(result[0],Instance) else child.get('__instance')
     if isinstance(inst,Instance):self.descriptors[args[0]]={'events':inst.events,'components':sorted(inst.components),'fields':clean(inst.fields),'unknown_fields':[k for k,v in inst.fields.items() if unknown(v)],'binding_line':line(n)}
    return U
   if fn=='SetSharedLootTable' and len(args)>1 and isinstance(args[0],str):self.shared[args[0]]=clean(args[1]);return U
   if fn in ('math.floor','math.ceil','math.min','math.max') and all(isinstance(a,(int,float)) for a in args):
    try:return {'math.floor':math.floor,'math.ceil':math.ceil,'math.min':min,'math.max':max}[fn](*args)
    except (ValueError,TypeError):return U
   f=self.expr(n.func,env)
   if isinstance(f,Function) and self.depth<7:
    child=f.env.copy()
    for a in args:
     if isinstance(a,Instance):child['__instance']=a
    for p,v in zip(f.node.args,args):
     if isinstance(p,N.Name):child[p.id]=v
    self.depth+=1
    result=self.block(f.node.body,child);self.depth-=1
    if isinstance(child.get('__instance'),Instance):env['__instance']=child['__instance']
    return result[1][0] if result[0] and result[1] else U
   return U
  if isinstance(n,N.Invoke):
   method=n.func.id;src=self.expr(n.source,env);args=[self.expr(a,env) for a in n.args]
   if name(n.source)=='TheNet' and method=='GetServerGameMode':return 'survival'
   inst=src if isinstance(src,Instance) else src.owner if isinstance(src,Reference) and src.owner else env.get('__instance')
   if isinstance(inst,Instance):
    path='inst' if isinstance(src,Instance) else src.path if isinstance(src,Reference) else name(n.source)
    if path=='inst' and method=='AddComponent' and args and isinstance(args[0],str):
     inst.components.add(args[0]);inst.events.append({'path':path,'method':method,'args':[args[0]],'line':line(n)})
     return Reference('inst.components.'+args[0],inst)
    if path=='inst' or path.startswith('inst.components.'):
     event={'path':path,'method':method,'args':clean(args),'line':line(n)}
     # Inspect a registered callback AST; never invoke it. Only the exact
     # trigger-counter pattern is admitted, with all predicate tokens retained.
     if method=='SetOnEatFn' and args and isinstance(args[0],Function):
      fn=args[0].node
      for branch in ast.walk(fn.body):
       if not isinstance(branch,N.ElseIf):continue
       calls=[x for x in branch.body.body if isinstance(x,N.Invoke) and x.func.id=='TriggerDelta' and name(x.source).endswith('.werebeast')]
       if len(calls)!=1:continue
       leaves=[]
       def flatten(t):
        if type(t).__name__=='AndLoOp':flatten(t.left);flatten(t.right)
        else:leaves.append(t)
       flatten(branch.test)
       rendered=ast.to_lua_source(branch.test).replace(' ','').replace('\n','')
       required=['food.components.edible.foodtype==FOODTYPE.MEAT','inst.components.werebeast~=nil','notinst.components.werebeast:IsInWereState()','food.components.edible:GetHealth(inst)<0']
       if len(leaves)==4 and all(t in rendered for t in required):
        delta=self.expr(calls[0].args[0],{}) if calls[0].args else U
        if isinstance(delta,(int,float)):event['callback_contract']={'pattern':'harmful_meat_were_counter','delta':delta,'callback_line':line(fn),'guard_source':rendered,'guard_complete':True}
     if method=='SetOnWereFn' and args and isinstance(args[0],Function):
      fn=args[0].node
      tags=[self.expr(x.args[0],{}) for x in fn.body.body if isinstance(x,N.Invoke) and x.func.id=='AddTag' and name(x.source)=='inst' and x.args]
      if 'werepig' in tags:event['state_contract']={'tag':'werepig','callback_line':line(fn)}
     inst.events.append(event)
   return U
  return U
 def assign(self,t,v,env):
  if isinstance(t,N.Name):env[t.id]=v;return
  if isinstance(t,N.Index):
   base=self.expr(t.value,env);key=t.idx.id if isinstance(t.idx,N.Name) and t.notation==N.IndexNotation.DOT else self.expr(t.idx,env)
   if isinstance(base,dict) and not unknown(key):base[key]=v
   inst=base.owner if isinstance(base,Reference) and base.owner else base if isinstance(base,Instance) else env.get('__instance')
   if isinstance(inst,Instance):
    path=(base.path if isinstance(base,Reference) else 'inst' if isinstance(base,Instance) else '')+'.'+str(key)
    if path.startswith('inst.'):inst.fields[path]=v
 def block(self,b,env):
  if not isinstance(b,N.Block):return False,[]
  for s in b.body:
   self.steps+=1
   if self.steps>80000:return False,[]
   if isinstance(s,(N.LocalAssign,N.Assign)):
    vals=[self.expr(v,env) for v in s.values]
    for i,t in enumerate(s.targets):self.assign(t,vals[i] if i<len(vals) else None,env)
   elif isinstance(s,(N.LocalFunction,N.Function)) and isinstance(s.name,N.Name):
    f=Function(s,env.copy());env[s.name.id]=f;f.env[s.name.id]=f
   elif isinstance(s,N.Return):return True,[self.expr(v,env) for v in s.values]
   elif isinstance(s,(N.Call,N.Invoke)):self.expr(s,env)
   elif isinstance(s,(N.If,N.ElseIf)):
    cur=s
    while isinstance(cur,(N.If,N.ElseIf)):
     test=self.expr(cur.test,env)
     if unknown(test):self.gaps.append({'line':line(cur),'reason':'unknown_condition_excluded'});cur=None;break
     if test is not False and test is not None:
      done,result=self.block(cur.body,env)
      if done:return done,result
      cur=None;break
     cur=cur.orelse
    if isinstance(cur,N.Block):
     done,result=self.block(cur,env)
     if done:return done,result
   elif isinstance(s,(N.Forin,N.Fornum,N.While,N.Repeat)):
    self.gaps.append({'line':line(s),'reason':'loop_excluded'})
   elif isinstance(s,N.Do):
    done,result=self.block(s.body,env)
    if done:return done,result
  return False,[]
 def read(self,text):
  tree=ast.parse(text);env={'TUNING':self.tuning,'TheWorld':{'ismastersim':True},'ACTIONS':{k:k for k in ('CHOP','MINE','DIG','HAMMER','TILL','NET','FISH','SHAVE')},'EQUIPSLOTS':{k:k for k in ('HANDS','HEAD','BODY','BEARD')},'FOODTYPE':{k:k for k in ('MEAT','VEGGIE','GENERIC','SEEDS','BERRY','BURNT','ELEMENTAL','GOODIES','HORRIBLE','ROUGHAGE')},'FUELTYPE':{k:k for k in ('BURNABLE','NIGHTMARE','USAGE','CHEMICAL','MAGIC','ONEMANBAND','CAVE')},'TECH':{}}
  self.block(tree.body,env);return tree,env

def clean(v):
 if unknown(v) or isinstance(v,Function):return None
 if isinstance(v,Reference):return {'reference':v.path}
 if isinstance(v,Instance):return None
 if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items() if not unknown(x)}
 if isinstance(v,list):return [clean(x) for x in v]
 return v

def tuning_values(text):
 tree=ast.parse(text);r=Reader();env={}
 tune=next((n for n in tree.body.body if isinstance(n,N.Function) and name(n.name)=='Tune'),None)
 if tune:
  # Only top-level pure assignments in Tune's defaults. No overrides/callbacks.
  for s in tune.body.body:
   if isinstance(s,(N.LocalAssign,N.Assign)):
    for t,v in zip(s.targets,s.values):r.assign(t,r.expr(v,env),env)
 def pure(v):
  if isinstance(v,dict):return {k:pure(x) for k,x in v.items()}
  return v if v is None or isinstance(v,(str,int,float,bool)) else U
 return pure(env.get('TUNING',{}))
