"""Audit source-backed placer metadata; counts are not successful task coverage."""
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1];data=json.loads((root/'knowledge/official_knowledge.json').read_text());rows=[]
for p,e in data['entries'].items():
 for f in e.get('recipes',[]):
  if f.get('certainty')!='verified' or not f.get('field','').startswith('literal_recipe'):continue
  r=f['value'];c=r.get('conditions',{});placer=c.get('placer')
  if not isinstance(placer,str):continue
  reasons=[]
  if c.get('sg_state') or c.get('buildingstate'):reasons.append('special_stategraph')
  if c.get('manufactured') or c.get('dropitem'):reasons.append('nonstandard_production')
  if c.get('unlocks_from_skin'):reasons.append('skin_unlock')
  if c.get('build_mode') not in (None,'BUILDMODE.LAND',1):reasons.append('build_mode_requires_runtime')
  if any(w in placer for w in ('boat','dock','turf')):reasons.append('boat_dock_turf_category')
  if r.get('output_count')!=1:reasons.append('nonunit_or_unknown_output')
  if any(x in str(r.get('condition_excerpts')) for x in ('overridecandeployrecipeatpointfn','override_numtogive_fn','CHARACTER_INGREDIENT')):reasons.append('custom_placement_or_cost')
  rows.append(dict(prefab=p,recipe=r['id'],placer=placer,conditional_candidate=not reasons,restrictions=reasons,source={k:f[k] for k in ('path','line','sha256','version')}))
unique={r['recipe']:r for r in rows};rows=list(unique.values());report={'build':data['manifest']['build'],'baseline':'0.15.0-r1','counts':{'source_backed_literal_placer_recipes':len(rows),'conditional_candidates':sum(r['conditional_candidate'] for r in rows),'deferred_or_runtime_review':sum(not r['conditional_candidate'] for r in rows)},'meaning':'Static candidate audit only. Current AllRecipes, actor qualifications, native map checks, native buffer and verified entity determine actual completion. No total task completion rate asserted. Dynamic/unknown metadata needs runtime review. Inventory deployer items are outside this placer audit.','recipes':rows}
(root/'tests/v0160_building_recipe_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report['counts']))
