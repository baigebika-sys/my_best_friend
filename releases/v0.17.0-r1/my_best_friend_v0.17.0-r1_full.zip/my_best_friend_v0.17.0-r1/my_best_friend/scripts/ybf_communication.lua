local Core = require("ybf_comm_core")
local Inventory = require("ybf_work_inventory")
local ChatServer = require("ybf_chat_server")
local Knowledge=require('ybf_knowledge')
local Resources=require('ybf_work_resources')
local M = {}
local function Trim(s) return s:match("^%s*(.-)%s*$") end

function M.Parse(text)
    if type(text) ~= "string" then return nil end
    text = Trim(text)
    if text ~= "/friend" and not text:match("^/friend%s") then return nil end
    local content = Trim(text:sub(8))
    local name, message = content:match("^(.-)|(.*)$")
    if name then return Trim(message), Trim(name) end
    return content, nil
end

function M.Context(G, player, name, guid)
    local matches = {}
    for _, flower in pairs(G.Ents) do
        if flower:IsValid() and flower:HasTag("ybf_friendship_flower")
            and flower.components.inventoryitem
            and flower.components.inventoryitem:GetGrandOwner() == player then
            local friend = flower._ybf_friend
            if friend and friend:IsValid() and friend.components.ybf_friend
                and not friend.components.health:IsDead()
                and (not name or friend.components.ybf_friend.name == name)
                and (not guid or friend.GUID == guid) then
                matches[#matches + 1] = { friend = friend, flower = flower, player = player,
                    playerkey = player.userid or tostring(player.GUID),
                    playername = player:GetDisplayName(), name = friend.components.ybf_friend.name }
            end
        end
    end
    if #matches == 0 then return nil, "请持有一朵对应活着朋友的友谊小花（可放背包）；名字须完全一致" end
    if #matches > 1 then return nil, "有多位同名或未指定的朋友；请用 /friend 朋友名字|你好，并给朋友不同名字" end
    return matches[1]
end

function M.New(G, world)
    local function valid(r)
        local f, flower, p = r.friend, r.flower, r.player
        return world:IsValid() and f:IsValid() and flower:IsValid() and p:IsValid()
            and not p:HasTag("playerghost") and not f:HasTag("ybf_dead")
            and f.components.health and not f.components.health:IsDead()
            and f.components.ybf_friend and f.components.ybf_friend.active
            and not f.components.ybf_friend.dead
            and f.components.ybf_friend.flower == flower and flower._ybf_friend == f
            and flower.components.inventoryitem:GetGrandOwner() == p
    end
    local function clean(s) return tostring(s):gsub("[%c]", " ") end
    local conversations={}
    local function conversation(f,playerkey)
        local key=tostring(f.GUID)..':'..tostring(playerkey or '')
        local c=conversations[key];if not c then c={topics={}};conversations[key]=c end
        if c.pending and G.GetTimeReal()/1000>=c.pending.expires then c.pending=nil end
        if c.knowledge_pending and G.GetTimeReal()/1000>=(c.knowledge_pending.expires or math.huge) then c.knowledge_pending=nil end
        return c
    end
    local function capture(ctx)
        local w=ctx.friend.components.ybf_work
        local j=w and w.core and w.core.job
        local c=conversation(ctx.friend,ctx.playerkey)
        local proposal=w and w.hub and w.hub:Pending(ctx.player)
        local topics={};for _,p in ipairs(c.topics or {}) do topics[#topics+1]=p end
        local px,pz
        if ctx.player.Transform then local x,_,z=ctx.player.Transform:GetWorldPosition();px,pz=x,z end
        return {hub_revision=w and w.hub and w.hub.revision,proposal_id=proposal and proposal.id or '__none__',build_origin=px and {x=px,z=pz,world=require('ybf_build_positions').World()},job=j,revision=j and (j.control_revision or 0),pending=c.pending,knowledge={topics=topics,pending=c.knowledge_pending,last_answer=c.last_answer,semantic=c.semantic}}
    end
    local function clarify(r,text)
        print("[YBF INTENT] category=unclear")
        local c=conversation(r.friend,r.playerkey)
        local b=r.binding or {}
        c.pending={original=r.text,question=text,expires=G.GetTimeReal()/1000+90,job=b.job,revision=b.revision}
        return text,false
    end
    local function current(r,reference)
        local b=r.binding or {};local c=conversation(r.friend,r.playerkey)
        local w=r.friend.components.ybf_work;local j=w and w.core and w.core.job
        if reference=="clarification" then
            if not c.pending or c.pending~=b.pending then return false end
            b=c.pending
        end
        return b.job==j and b.revision==(j and (j.control_revision or 0))
    end
    local function apply_logic(r,action,reply,d)
            local hub=r.friend.components.ybf_work and r.friend.components.ybf_work.hub
            if hub then
                local short,applied=hub:ShortReply(r.player,r.text,r.binding and r.binding.proposal_id or '__none__',r.binding and r.binding.hub_revision);if short then return short,applied end
                if action=='operations'and not Knowledge.QuestionKind(r.text)then
                    for _,op in ipairs(d.item or {})do if op.type=='accept'and not op.proposal_id then op.proposal_id=r.binding and r.binding.proposal_id or '__none__'end end
                    return hub:Operations(r.player,d.item,r.binding and r.binding.build_origin,r.text)end
            end
            r.friend._ybf_answer_style=type(d.item)=='table' and d.item.answer_style or nil
            if r.text=='开启知识诊断' or r.text=='关闭知识诊断' then
                Knowledge.SetDebug(r.friend,r.text=='开启知识诊断');r.friend._ybf_diagnostic_encode=G.json.encode_compliant
                return r.text=='开启知识诊断' and '知识诊断已开启。' or '知识诊断已关闭。',false
            end
            local KCNames=require('ybf_knowledge_names')
            local kc=r.binding and r.binding.knowledge or {}
            if KCNames.IsCancelQuery(r.text) then r.knowledge_query=true;r.knowledge_topics={};r.knowledge_pending=nil;r.semantic_query=nil;return '好，这个知识查询取消了。',false end
            if KCNames.IsConfirmation(r.text) then
                r.knowledge_query=true
                if kc.pending and (conversation(r.friend,r.playerkey).knowledge_pending~=kc.pending or G.GetTimeReal()/1000>=(kc.pending.expires or 0)) then r.knowledge_topics={};return '待确认的知识查询已变化或过期，请重新说明问题。',false end
                if not kc.pending then r.knowledge_topics=kc.topics or {};return '当前没有待确认的知识查询；请再说明要了解什么。',false end
                local selected=Knowledge.PendingChoice(r.friend,r.text,kc.pending)
                if not selected then r.knowledge_pending=kc.pending;return '还有多个候选，请用中文名字或序号说明：'..Knowledge.CandidateText(kc.pending.candidates)..'。',false end
                r.knowledge_topics={selected};r.knowledge_pending=nil
                return Knowledge.OneAnswer(r.friend,selected,kc.pending.kind or 'identity',kc.pending.original or r.text),false
            end
            local semantic=require('ybf_knowledge_semantic')
            local query=semantic.Parse(r.text,kc)
            if query then
                Knowledge.Diagnostic(r.friend,{request_id=r.id,category='semantic_entry',original=r.text,expressions=Knowledge.Expressions(r.friend,r.text),model_selection=d.item,parsed_query=query})
                r.knowledge_query=true;r.knowledge_pending=nil
                local answer,topics,next=semantic.Answer(r.friend,query,r.text,Knowledge)
                r.knowledge_topics=topics or {};r.semantic_query=next
                return answer,false
            end
            local question=Knowledge.QuestionKind(r.text)
            local refs=Knowledge.Expressions(r.friend,r.text)
            local choice=(action=='none' or action=='knowledge' or action=='clarify') and Knowledge.PendingChoice(r.friend,r.text,kc.pending)
            if choice then question=kc.pending.kind end
            if not question and kc.pending and #refs>0 and #r.text<=120 and (action=='none' or action=='knowledge' or action=='clarify') then
                local candidates=kc.pending.candidates or {};local fits=false
                for _,hit in ipairs(refs) do for _,v in ipairs(hit.candidates) do for _,p in ipairs(candidates) do if p==v.prefab then fits=true end end end end
                if fits then question=kc.pending.kind or 'identity' end
            end
            local concept,concept_source
            if #refs==0 and Knowledge.ConceptAnswer then concept,concept_source=Knowledge.ConceptAnswer(r.text) end
            if concept then
                r.knowledge_query=true;r.knowledge_topics={}
                Knowledge.Diagnostic(r.friend,{request_id=r.id,original=r.text,model_selection=d.item,stage='concept',source=concept_source,final_answer=concept})
                return concept,false
            end
            if question or action=='knowledge' then
                r.knowledge_query=true
                Knowledge.Diagnostic(r.friend,{request_id=r.id,stage='language_entry',original=r.text,expressions=refs,model_selection=d.item,context_topics=kc.topics})
                local kind=question or d.item.kind
                local names={}
                if choice then
                    r.knowledge_topics={choice};r.knowledge_pending=nil
                    return Knowledge.OneAnswer(r.friend,choice,kc.pending.kind or kind,kc.pending.original or r.text),false
                elseif #refs==1 and (refs[1].unresolved_prefix or refs[1].unresolved_suffix) then names={require('ybf_knowledge_names').NounText(r.text)}
                elseif #refs>0 then for _,hit in ipairs(refs) do names[#names+1]=hit.text end
                elseif require('ybf_knowledge_names').HasPronoun(r.text) then names={'这个'}
                elseif action=='knowledge' then local raw=Knowledge.QuestionName(r.text);names=raw and #raw>0 and {raw} or d.item.names or {d.item.name}
                else local raw=Knowledge.QuestionName(r.text);if raw and #raw>0 then names={raw} end end
                if #names>0 then
                    r.knowledge_topics={};local issue
                    for _,name in ipairs(names) do
                        local p,code,candidates=Knowledge.Resolve(r.friend,name,r.text)
                        if p then r.knowledge_topics[#r.knowledge_topics+1]=p;if code=='knowledge_inferred' then r.inferred_name=true end
                        else issue={kind=kind,reason=code,candidates=candidates or {},original=r.text,request_id=r.id,names=names,expires=G.GetTimeReal()/1000+90};break end
                    end
                    r.knowledge_pending=issue
                    if issue then Knowledge.Diagnostic(r.friend,{request_id=r.id,original=r.text,reason=issue.reason,candidates=issue.candidates,stage='local_validation'});return Knowledge.FailureText(issue.reason,issue.candidates),false end
                    local answer;if kind=='recipe'and #r.knowledge_topics==1 then local ok,result=pcall(require('ybf_cooking_rules').RecipeAnswer,r.knowledge_topics[1]);if ok then answer=result;if result then Knowledge.Diagnostic(r.friend,{request_id=r.id,stage='official_cooking_recipe',original=r.text,prefab=r.knowledge_topics[1],source='current cooking predicate and verified card_def',final_answer=result})end end end
                    answer=answer or Knowledge.AnswerMany(r.friend,names,kind,r.text)
                    if r.inferred_name and #r.knowledge_topics==1 then answer='你说的应该是'..Knowledge.Label(r.knowledge_topics[1])..'。'..answer end
                    return answer,false
                end
                if action=='none' and not require('ybf_knowledge_names').HasPronoun(r.text) then r.knowledge_query=false;return reply,false end
                return '请告诉我你想了解哪个对象。',false
            end
            if action=="none" then
                if r.text:find("持有什么",1,true) or r.text:find("手上有什么",1,true) or r.text:find("手里有什么",1,true) then
                    local inv=r.friend.components.inventory
                    local hand=inv and inv:GetEquippedItem(G.EQUIPSLOTS and G.EQUIPSLOTS.HANDS or "hands")
                    return hand and ("我手上拿着"..hand:GetDisplayName().."。") or "我现在空着手。"
                end
                return reply,false
            end
            local work=r.friend.components.ybf_work
            local needs=r.friend.components.ybf_needs
            local c=conversation(r.friend,r.playerkey)
            local reference=type(d.item)=='table' and d.item.reference or 'current'
            if action=="clarify" then return clarify(r,reply) end
            if action=="unsupported" then print("[YBF INTENT] category=unsupported");return reply,false end

            if action=="status" and hub then return hub:List(r.player),false end
            if action=="status" then return work and work:ProgressText() or "我现在没有工作任务。",false end
            if action=="inventory" then
                local parts={}
                for _,item in ipairs(Inventory.Items(r.friend,true)) do
                    local inv=r.friend.components.inventory
                    local inhand=inv and inv:GetEquippedItem(G.EQUIPSLOTS and G.EQUIPSLOTS.HANDS or "hands")==item
                    parts[#parts+1]=Inventory.Size(item).."个"..item:GetDisplayName()..(inhand and "（拿在手上）" or "")
                end
                return #parts>0 and "我带着"..table.concat(parts,"、").."。" or "我现在没有带东西。",false
            end
            local named_item=action=='modify' and type(d.item)=='table' and d.item.item or d.item
            if (action=='eat' or action=='equip' or action=='modify') and type(named_item)=='string' then
                local resolved,code,candidates=Knowledge.Resolve(r.friend,named_item,r.text,true)
                if not resolved then return clarify(r,Knowledge.FailureText(code,candidates)) end
                if action=='modify' and type(d.item)=='table' then d.item.item=resolved else d.item=resolved end
            end
            if hub and (action=='resume'or action=='pause'or action=='cancel')then
                hub:Adopt();local count=0;local cooking=false;for _,t in ipairs(hub.tasks)do if t.ownerkey==r.player.userid and t.state~='completed'and t.state~='cancelled'then count=count+1;cooking=cooking or t.kind=='cook'end end
                if cooking or count>1 then return hub:Control(r.player,{type=action,scope='single'})end
            end
            if action=="resume" or action=="pause" or action=="cancel" or action=="modify" then
                if not current(r,reference) then return clarify(r,"刚才的任务已经变了，你现在指的是哪个任务？") end
                if reference=='clarification' and action=='cancel' then c.pending=nil;return '好，这个还没确认的要求先取消。',true end
                if action=='cancel' and (not work or not work:HasTask()) then c.pending=nil;return '好，我取消还没开始的请求，已有物品会保留。',true end
                if action=='pause' and (not work or not work:HasTask()) then c.pending=nil;return '好，我先不开始工作。',true end
                if not work then return "我现在没有可以调整的工作任务。",false end
                local ok,why,category
                if action=='resume' then ok,why=work:ResumeTask()
                elseif action=='pause' then ok,why=work:PauseTask(d.item and d.item.filter)
                elseif action=='modify' then ok,why,category=work:ModifyTask(d.item and d.item.item,d.quantity,d.item and d.item.operation)
                else
                    if not work:HasTask() then return '我现在没有工作任务。',false end
                    work:Cancel(true);ok=true;why='好，这个任务取消了，已经拿到的东西我会保留。'
                end
                if category=='unclear' then return clarify(r,why) end
                if ok then c.pending=nil end
                return why or (ok and '好，我继续。' or '现在没有可以继续的任务。'),ok
            end
            if action=='goal' and reference=='clarification' and not current(r,reference) then
                return clarify(r,'刚才的问题已过期或任务已变化，请再说一次你想要什么。')
            end
            if action=="eat" then
                if not needs then error("补给组件未就绪") end
                local ok,err=needs:RequestEat(d.item,d.quantity)
                if not ok then error(err) end
                return "好，我会吃"..d.quantity.."份，吃完再告诉你。"
            end
            if action=="goal" then
                if not work or type(d.item)~='table' then return '现在还不能接上工作，请稍后再试。',false end
                for _,target in ipairs(d.item.targets or {}) do
                    local resolved,code,candidates=Knowledge.Resolve(r.friend,target.item,r.text,true)
                    if not resolved then
                        print('[YBF KNOWLEDGE] category='..tostring(code))
                        return clarify(r,Knowledge.FailureText(code,candidates))
                    end
                    target.item=resolved
                end
                local selected={};for _,target in ipairs(d.item.targets or {}) do selected[target.item]=true end
                for _,expression in ipairs(Knowledge.Expressions(r.friend,r.text)) do
                   if not require('ybf_task_language').StorageMention(expression,r.text) then
                    local explicit,code,candidates=Knowledge.Resolve(r.friend,expression.text,r.text,true)
                    if not explicit then return clarify(r,Knowledge.FailureText(code,candidates)) end
                    if not selected[explicit] then return clarify(r,'你提到了多个对象，但这次解析没有保留所有目标，请确认要哪些对象。') end
                   end
                end
                require('ybf_task_language').Apply(r.text,d.item,r.player,r.binding and r.binding.build_origin)
                local ok,why,category
                if work.hub then
                    local t,msg=work.hub:Add('work',d.item,r.player,false);ok=t~=nil;why=t and ('已安排任务 '..t.id..'，会保留其他任务的进度。')or msg
                    if t and not work.core.job and not work.hub.inflight then
                        local started,detail,kind=work:RequestIntent(d.item,r.player)
                        if started then t.job=work.core.job;t.state='running'else t.state='blocked';t.reason=detail;ok=false;why=detail;category=kind end
                    end
                else ok,why,category=work:RequestIntent(d.item,r.player)end
                if not ok then
                    print("[YBF INTENT] category="..tostring(category or "execution_blocked"))
                    if category=="unclear" then return clarify(r,tostring(why)) end
                    return tostring(why),false
                end
                c.pending=nil
                if why then return why,true end
                if needs then needs:CancelExplicit() end
                local parts={};for _,target in ipairs(d.item.targets) do parts[#parts+1]=target.quantity..'个'..Inventory.Label(target.item) end
                local verb=d.item.mode=='materials' and '准备制作材料，按' or d.item.mode=='craft' and '制作' or '准备'
                return '好，我帮你'..verb..table.concat(parts,'、')..(d.item.destination=='warehouse' and '，做好后存进友谊容器。' or d.item.destination=='auto' and '，做好后优先存进友谊容器。' or d.item.deliver and '，好了就给你。' or '，先放在我这里。'),true
            elseif action=="equip" then
                if needs then needs:CancelExplicit() end
                c.pending=nil
                local ok,why=work:RequestPlan({{kind='equip',item=d.item,quantity=d.quantity}},r.player)
                return ok and '好，我检查并装备已有物品。' or tostring(why)
            elseif action=="plan" then
                for _,step in ipairs(d.item or {}) do
                    if step.kind=='tree' and not Knowledge.GenericTreeRequest(r.friend,r.text) then
                        return clarify(r,'当前砍树任务只支持普通树的通用流程，不能忽略你指定的名称、变体或状态。请确认是否要普通砍树任务。')
                    end
                end
                if needs then needs:CancelExplicit() end
                c.pending=nil
                local ok,why=work:RequestPlan(d.item,r.player)
                if not ok then return why end
                local parts={}
                local verbs={collect="收集",craft="制作",give="交付",tree="砍倒",equip="装备"}
                for _,e in ipairs(d.item) do
                    parts[#parts+1]=(e.ensure and "备齐" or verbs[e.kind] or "处理")..e.quantity..(e.kind=="tree" and "棵树" or "个"..Inventory.Label(e.item))
                end
                return "好，我按顺序"..table.concat(parts,"，").."；实际结果稍后汇报。"
            elseif action=="pickup" then
                if not work or not work:Start(d.item,d.quantity) then error("拾取参数无效") end
                return "好，我检查已有库存，再捡附近缺少的部分；整叠可能多拿一点。"
            elseif action=="collect" or action=="craft" or action=="give" then
                if not work then return "工作组件未就绪。" end
                local ok,why=work:Request(action,d.item,d.quantity,r.player)
                if not ok then return why or "工作参数无效。" end
                return action=="collect" and "好，我检查已有库存、附近目标和工具，按实际入包数量收集。"
                    or action=="craft" and "好，我按实际配方检查材料和科技，制作结果稍后告诉你。"
                    or "好，我只交付指定数量；不能接收时会保留剩余物品。"
            elseif action=="stop" then
                if work and ((work.HasTask and work:HasTask()) or work:IsBusy()) then work:Cancel(true);return "好，我停下任务，回到原来的安排。" end
                return "目前没有正在执行的工作任务。"
            end
            if needs then needs:CancelExplicit() end
            c.pending=nil
            if work then work:Cancel(false) end
            local ok,err=r.friend.components.ybf_friend:SetMode(action)
            if not ok then error(err or "mode change failed") end
            -- Only authoritative engine execution confirms an action.
            return action=="wait" and "好，我在这里等你。" or "好，我继续跟着你。"
    end
    local core = Core.New({
        capture=capture,
        session = tostring(world.GUID) .. "-" .. tostring(G.GetTimeReal()) .. "-"
            .. tostring(G.math.random(100000, 999999)) .. "-" .. tostring(G.math.random(100000, 999999)),
        apply = function(r,action,reply,d)
            local old=r.friend._ybf_query_context;local oldid=r.friend._ybf_trace_id
            r.friend._ybf_query_context=r.binding and r.binding.knowledge
            r.friend._ybf_trace_id=r.id
            local ok,result,applied=pcall(apply_logic,r,action,reply,d)
            r.friend._ybf_query_context=old;r.friend._ybf_trace_id=oldid
            if not ok then error(result) end
            return result,applied
        end,
        local_reply = function(r)
            if r.text=='开启知识诊断' or r.text=='关闭知识诊断' then return apply_logic(r,'none','',{item={}}) end
        end,
        fallback = function(r)
            if Knowledge.QuestionKind(r.text) or require('ybf_knowledge_semantic').Parse(r.text,r.binding and r.binding.knowledge) or r.text=='开启知识诊断' or r.text=='关闭知识诊断' then
                local old=r.friend._ybf_query_context;r.friend._ybf_query_context=r.binding and r.binding.knowledge
                r.friend._ybf_trace_id=r.id
                local ok,reply=pcall(apply_logic,r,'none','',{item={}})
                r.friend._ybf_query_context=old;r.friend._ybf_trace_id=nil
                if ok then return reply end
            end
        end,
        snapshot = function(ctx,message)
            local f = ctx.friend
            local function stat(key)
                local c=f.components[key]
                if not c then return {available=false} end
                local value=c.currenthealth or c.current or c.currentsanity
                local maximum=c.maxhealth or c.max or c.maxsanity
                return {available=value~=nil, current=value, maximum=maximum}
            end
            local knowledge
            if f.components.ybf_work and f.components.ybf_work.Position then
                local w=f.components.ybf_work
                local entities=Resources.Observe(f,w:Position(),w.radius)
                local old=f._ybf_query_context
                local c=conversation(f,ctx.playerkey);f._ybf_query_context={topics=c.topics or {},pending=c.knowledge_pending,semantic=c.semantic}
                knowledge=Knowledge.Context(f,message,entities)
                f._ybf_query_context=old
                -- Hard JSON byte cap in addition to entry limits.
                while #G.json.encode_compliant(knowledge)>9000 and (#knowledge.entries>0 or #knowledge.nearby_sources>0 or #knowledge.name_expressions>0 or #knowledge.name_issues>0) do
                    if #knowledge.nearby_sources>0 then table.remove(knowledge.nearby_sources)
                    elseif #knowledge.entries>0 then table.remove(knowledge.entries)
                    elseif #knowledge.name_issues>0 then table.remove(knowledge.name_issues);knowledge.name_context_truncated=true
                    else table.remove(knowledge.name_expressions);knowledge.name_context_truncated=true end
                    knowledge.truncated=true
                end
            end
            local cooking;local cookingok,cookingcontext=pcall(require('ybf_cooking_rules').Context,f,message);if cookingok then cooking=cookingcontext end
            local items={}
            local inv=f.components.inventory
            if inv then
                for _,item in ipairs(Inventory.Items(f,true)) do
                    if #items<60 then
                        local equipped=false
                        for _,v in pairs(inv.equipslots or {}) do if v==item then equipped=true end end
                        items[#items+1]={name=item:GetDisplayName(),prefab=item.prefab,
                            aliases=Knowledge.Aliases(item.prefab),
                            equipped=equipped,location=equipped and "装备中" or item==inv.activeitem and "鼠标持有" or "库存",
                            count=Inventory.Size(item)}
                    end
                end
            end
            return {behavior_mode=f.components.ybf_friend.mode or "follow",health=stat("health"),hunger=stat("hunger"),sanity=stat("sanity"),
                inventory={available=inv~=nil,items=items},knowledge=knowledge,
                conversation={topics=conversation(f,ctx.playerkey).topics,last_answer=conversation(f,ctx.playerkey).last_answer,knowledge_pending=conversation(f,ctx.playerkey).knowledge_pending,semantic=conversation(f,ctx.playerkey).semantic,clarification=conversation(f,ctx.playerkey).pending and {original=conversation(f,ctx.playerkey).pending.original,question=conversation(f,ctx.playerkey).pending.question} or nil},
                work=f.components.ybf_work and f.components.ybf_work:Snapshot() or nil,
                cooking=cooking,
                task_hub=f.components.ybf_work and f.components.ybf_work.hub and f.components.ybf_work.hub:Snapshot(ctx.player),
                supplies=f.components.ybf_needs and f.components.ybf_needs:Snapshot() or nil,
                time={day=(world.state.cycles or 0)+1,phase=world.state.phase,season=world.state.season},
                location=world:HasTag("cave") and "洞穴" or "地面"}
        end,
        timeout = 45,
        http_timeout = 8,
        poll_interval = 2,
        now = function() return G.GetTimeReal() / 1000 end,
        valid = valid,
        encode = G.json.encode_compliant,
        decode = G.json.decode,
        query = function(body, callback)
            G.TheSim:QueryServer("http://127.0.0.1:8765/tasks", callback, "POST", body)
        end,
        poll = function(taskid, instance, callback)
            G.TheSim:QueryServer("http://127.0.0.1:8765/tasks/" .. taskid .. "?instance=" .. instance, callback, "GET")
        end,
        cancel = function(taskid, instance)
            G.TheSim:QueryServer("http://127.0.0.1:8765/tasks/" .. taskid .. "/cancel?instance=" .. instance,
                function(_, success, code)
                    print("[YBF COMM] cancel_best_effort task=" .. taskid .. " success=" .. tostring(success) .. " http=" .. tostring(code))
                end, "POST", "{}")
        end,
        log = function(id, status, ms, detail)
            print(string.format("[YBF COMM] id=%s status=%s rtt_ms=%.0f detail=%s", id, status, ms, clean(detail)))
        end,
        notify = function(r, status, ms, detail, reply)
            local currentname=clean(r.name)
            if status=="sent" then
                G.TheNet:Announce("["..clean(r.playername).." → "..currentname.."] "..clean(r.text))
                ChatServer.Emit(G,r.player,{kind="sent",tag=r.clienttag,id=r.id,name=currentname})
            elseif status=="reply" then
                local c=conversation(r.friend,r.playerkey)
                if (c.received_order or 0)<r.order then
                    c.received_order=r.order;c.last_answer={question=r.text,answer=reply}
                    if r.knowledge_query then
                        if not r.knowledge_pending and r.knowledge_topics then c.topics=r.knowledge_topics end
                        c.knowledge_pending=r.knowledge_pending;c.semantic=r.semantic_query
                    else c.knowledge_pending=nil;c.semantic=nil end
                end
                if r.friend.components.talker then r.friend.components.talker:Say(clean(reply)) end
                G.TheNet:Announce("["..currentname.."] "..clean(reply))
                ChatServer.Emit(G,r.player,{kind="reply",tag=r.clienttag,id=r.id,name=currentname,text=clean(reply)})
                if r.taskid and r.instance then
                    local receipt={protocol='ybf-task-v1',request_id=r.id,friend_id=tostring(r.friend.GUID),conversation_id=r.conversation_id,reply=clean(reply),topics=r.knowledge_topics or {},pending=r.knowledge_pending,kind=r.knowledge_query and 'knowledge' or 'action_result'}
                    G.TheSim:QueryServer('http://127.0.0.1:8765/tasks/'..r.taskid..'/result?instance='..r.instance,function(_,success,code)
                        if not success or code~=200 then print('[YBF KNOWLEDGE] result_sync_failed id='..r.id) end
                    end,'POST',G.json.encode_compliant(receipt))
                end
            elseif status=="accepted" then
                ChatServer.Emit(G,r.player,{kind="accepted",tag=r.clienttag,id=r.id})
            elseif status=="cancelled" then
                ChatServer.Emit(G,r.player,{kind="cancelled",tag=r.clienttag,id=r.id})
            else
                ChatServer.Emit(G,r.player,{kind="error",tag=r.clienttag,id=r.id.."-error",text=ChatServer.ErrorText(status,detail)})
            end
        end,
        watch = function(r, cancel)
            r.listeners = {}
            for _, v in ipairs({ {r.friend, "death"}, {r.friend, "onremove"},
                {r.flower, "onremove"}, {r.player, "onremove"} }) do
                local fn = function() cancel("朋友死亡、被移除或持有人已离开；请求已取消") end
                world:ListenForEvent(v[2], fn, v[1])
                r.listeners[#r.listeners + 1] = { source = v[1], event = v[2], fn = fn }
            end
        end,
        unwatch = function(r)
            for _, v in ipairs(r.listeners or {}) do world:RemoveEventCallback(v.event, v.fn, v.source) end
            r.listeners = nil
        end,
    })
    local task = world:DoPeriodicTask(0.25, function() core:Tick() end)
    world:ListenForEvent("onremove", function() task:Cancel(); core:Close() end)
    return core
end
return M
