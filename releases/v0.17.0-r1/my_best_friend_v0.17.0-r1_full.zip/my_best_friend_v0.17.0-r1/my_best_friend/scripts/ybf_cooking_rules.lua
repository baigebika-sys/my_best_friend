-- Read-only official rule evaluation. Only trusted official test predicates are called.
local C=setmetatable({},{__index=function(_,k)return require('cooking')[k]end});local I=require('ybf_work_inventory');local M={BUILD='756039',POTS={cookpot=true,portablecookpot=true}}
local aliases={cookedsmallmeat='smallmeat_cooked',cookedmonstermeat='monstermeat_cooked',cookedmeat='meat_cooked'}
local trusted_sources=setmetatable({},{__mode='k'})
function M.PredicateSource(r)
 if type(r.test)~='function'then return end
 local cached=trusted_sources[r.test];if cached~=nil then return cached or nil end
 local d=rawget(_G,'debug');if not d or not d.getinfo then return end
 local info=d.getinfo(r.test,'S');local source=info and info.source or ''
 local base=d.getinfo(C.CalculateRecipe,'S');local cooking_source=base and base.source or ''
 local prefix=cooking_source:match('^(.*[/\\])cooking%.lua$')
 if not prefix or source:find('/mods/',1,true)or source:find('\\mods\\',1,true)then trusted_sources[r.test]=false;return end
 for _,name in ipairs({'preparedfoods.lua','preparedfoods_warly.lua','preparednonfoods.lua','spicedfoods.lua'})do if source==prefix..name then trusted_sources[r.test]=source;return source end end
 trusted_sources[r.test]=false
end
function M.Official(r)return r and C.IsModCookerFood and not C.IsModCookerFood(r.name) and M.PredicateSource(r)~=nil end
function M.Food(r)local source=M.PredicateSource(r);return source and not r.noprefab and source:sub(-20)~='preparednonfoods.lua' and not source:find('preparednonfoods.lua',1,true)end
function M.Tags(list)
 local n,t={},{}
 for _,p in ipairs(list)do p=aliases[p]or p;n[p]=(n[p]or 0)+1;for k,v in pairs(C.ingredients[p]and C.ingredients[p].tags or {})do t[k]=(t[k]or 0)+v end end
 return n,t
end
function M.Resolve(input,text,inst)
 local matches={};local index={};local alias={['肉汤']='bonestew'}
 local function bind(name,prefab)if type(name)=='string'and name~=''then index[name]=index[name]or {};index[name][#index[name]+1]={prefab=prefab,kind='official_cooking_name'}end end
 for _,recipes in pairs(C.recipes)do for _,r in pairs(recipes)do if M.Official(r)then
  local name=STRINGS.NAMES[r.name:upper()];bind(name,r.name);bind(r.name,r.name)
  if input==r.name or input==name or alias[input]==r.name then
   local expressed=text:find(r.name,1,true)or name and text:find(name,1,true);for short,prefab in pairs(alias)do if prefab==r.name and text:find(short,1,true)then expressed=true end end;if expressed then matches[r.name]=true end
  end
 end end end
 for short,prefab in pairs(alias)do bind(short,prefab)end
 if not next(matches)and inst then local p,code,candidates=require('ybf_knowledge').Resolve(inst,input,text,true);if p then for _,recipes in pairs(C.recipes)do if recipes[p]and M.Official(recipes[p])then matches[p]=true end end elseif code=='name_typo_confirmation'or code=='name_ambiguous'then return nil,require('ybf_knowledge').FailureText(code,candidates)end end
 local name;for p in pairs(matches)do if name then return nil,'料理名称有歧义，请用完整中文名称确认。'end;name=p end
 if name then local seen=false;local clean=false;for _,hit in ipairs(require('ybf_knowledge_names').Scan(text,index))do for _,candidate in ipairs(hit.candidates)do if candidate.prefab==name then seen=true;local bounded={grammar={before=hit.grammar and hit.grammar.before or '',after=hit.unresolved_suffix and(hit.grammar and hit.grammar.after or '')or ''}};if not(hit.unresolved_prefix or hit.unresolved_suffix)or require('ybf_task_language').QuantifiedName(bounded)then clean=true end end end end;if seen and not clean then return nil,'料理名称含尚未核实的限定词或状态，不能静默改做普通版本，请确认完整名称。'end end
 return name,name and nil or '料理名称没有与当前原句及官方目录一致的依据，请确认完整名称。'
end
function M.Ingredient(p)return C.IsCookingIngredient(p)end
function M.TrustedCooker(pot)for _,r in pairs(C.recipes[pot]or {})do if not M.Official(r)then return false end end;return true end
function M.Candidates(pot,list)
 if #list~=4 then return {},'需要四槽各一份食材' end
 if not M.TrustedCooker(pot)then return {},'该锅存在未核验的新增或替换食谱，不能保证原版实际产物；本轮不开锅' end
 local names,tags=M.Tags(list);local best=-math.huge;local out={}
 for _,r in pairs(C.recipes[pot]or {})do if M.Official(r)then
  local ok,result=pcall(r.test,pot,names,tags)
  if not ok then return {},'当前官方判定无法读取' end
  if result then local priority=r.priority or 0;if priority>best then best=priority;out={}end;if priority==best then out[#out+1]=r end end
 end end
 table.sort(out,function(a,b)return a.name<b.name end);return out,nil,tags
end
function M.Index()
 local out={};for pot,recipes in pairs(C.recipes)do for _,r in pairs(recipes)do if M.Official(r)then
  out[#out+1]={name=r.name,pot=pot,priority=r.priority or 0,weight=r.weight or 1,cooktime=(r.cooktime or 1)*TUNING.BASE_COOK_TIME,quantity=r.stacksize or 1,foodtype=r.foodtype,pot_executor_supported=M.POTS[pot]or false,executable=M.POTS[pot]and M.Food(r)and r.foodtype~='INVALID' or false,version=APP_VERSION or M.BUILD,reference_build=M.BUILD,source='cooking/preparedfoods official predicate',predicate_source=M.PredicateSource(r),conditions='official test predicate; see bundled rule index'}
 end end end;return out
end
-- Meat/seafood includes fish, egg and dairy; plantmeat follows vanilla meat tags.
-- Vegetarian excludes all four animal-tag groups; no promises about vegan lifestyles.
function M.Category(tags)
 return (tags.meat or 0)>0 or (tags.fish or 0)>0 or (tags.egg or 0)>0 or (tags.dairy or 0)>0
end
function M.Edible(r,recipient)
 local e=recipient and recipient.components.eater
 if not e then return false end
  if e.CanEat and e.PrefersToEat then
  local mock={prefab=r.name,HasTag=function(_,tag)return tag=='preparedfood' or tag=='edible_'..tostring(r.foodtype) or r.secondaryfoodtype and tag=='edible_'..tostring(r.secondaryfoodtype)end,HasAnyTag=function(self,tags)for _,tag in ipairs(tags)do if self:HasTag(tag)then return true end end;return false end,components={edible={foodtype=r.foodtype,secondaryfoodtype=r.secondaryfoodtype}}}
  local ok,can=pcall(function()return e:CanEat(mock) and e:PrefersToEat(mock)end)
  return ok and can
 end
 return false
end
function M.RecipeAnswer(name)
 local r,pot;for _,candidate in ipairs({'cookpot','portablecookpot'})do local recipe=C.recipes[candidate]and C.recipes[candidate][name];if recipe and M.Official(recipe)then r=recipe;pot=candidate;break end end
 if not r then return end
 local tool=pot=='portablecookpot'and '已部署的便携烹饪锅'or '烹饪锅'
 local card=r.card_def and r.card_def.ingredients;local list,parts={},{}
 if card then for _,entry in ipairs(card)do if type(entry[1])~='string'or type(entry[2])~='number'then break end;parts[#parts+1]=entry[2]..'份'..I.Label(entry[1]);for _=1,entry[2]do list[#list+1]=entry[1]end end end
 local candidates=M.Candidates(pot,list);local verified=false;for _,choice in ipairs(candidates)do if choice.name==name then verified=true end end
 local answer=I.Label(name)..'需要用'..tool..'的四个槽位烹饪。'
 if verified then answer=answer..'原版参考组合是'..table.concat(parts,'、')..'。'..(#candidates==1 and '这组按当前规则可确定产物；其他配料组合也可能成立。'or '这组存在同优先级竞争产物，不能保证一定产出这道菜。')
 else answer=answer..'它按实际食材标签和优先级判定，不是固定的材料合成配方；当前没有可直接核验的官方参考组合。'end
 return answer..'每锅产出'..(r.stacksize or 1)..'份；基准加工约'..((r.cooktime or 1)*TUNING.BASE_COOK_TIME)..'秒，实际完成仍以锅状态为准。'
end
function M.Gap(pot,stock,request)
 local total=0;for _,row in pairs(stock)do total=total+row.count end
 if total<4 then return '现有可用食材共'..total..'份，四槽至少还缺'..(4-total)..'份。'end
 local r=request.recipe and C.recipes[pot]and C.recipes[pot][request.recipe]
 local card=r and r.card_def and r.card_def.ingredients
 if card then
  local list={};for _,entry in ipairs(card)do for _=1,entry[2]do list[#list+1]=entry[1]end end
  local candidates=M.Candidates(pot,list)
  if #candidates==1 and candidates[1].name==request.recipe then
   local needed={};for _,p in ipairs(list)do needed[p]=(needed[p]or 0)+1 end
   local missing={};for p,n in pairs(needed)do local lack=n-(stock[p]and stock[p].count or 0);if lack>0 then missing[#missing+1]=lack..'份'..I.Label(p)end end
   table.sort(missing);if #missing>0 then return '一种已验证参考组合还缺'..table.concat(missing,'、')..'；其他组合仍以本轮实际搜索为准。'end
  end
 end
 return '现有数量足够四槽，但尚未找到符合料理、优先级与接收者条件的可靠组合。'
end
function M.Context(inst,message)
 local entries={};for pot in pairs(M.POTS)do for _,r in pairs(C.recipes[pot]or {})do
  local name=STRINGS.NAMES[r.name:upper()]
  if #entries<8 and M.Official(r)and(name and message:find(name,1,true)or message:find(r.name,1,true))then entries[#entries+1]={name=name,prefab=r.name,pot=pot,quantity=r.stacksize or 1,seconds=(r.cooktime or 1)*TUNING.BASE_COOK_TIME,source='current_official_runtime_recipe',static_reference_build=M.BUILD}end
 end end
 local ingredients={};for _,item in ipairs(I.Items(inst))do if #ingredients<12 and M.Ingredient(item.prefab)then local _,tags=M.Tags({item.prefab});ingredients[#ingredients+1]={name=item:GetDisplayName(),prefab=item.prefab,count=I.Size(item),tags=tags,freshness=item.components.perishable and item.components.perishable:GetPercent()}end end
 return {entries=entries,ingredients=ingredients,scope='existing owned and friendship-container ingredients only; deployed cookpot/portablecookpot; no gathering',alias={['肉汤']='炖肉汤'},sources_bounded=true}
end
function M.Search(pot,stock,request,recipient)
 local names={};for p,row in pairs(stock)do if row.count>0 and M.Ingredient(p)then names[#names+1]=p end end
 table.sort(names,function(a,b)return (stock[a].cost or 0)<(stock[b].cost or 0)or (stock[a].cost==stock[b].cost and a<b)end)
 local truncated=#names>40;while #names>40 do table.remove(names)end
 return coroutine.create(function()
  if request.recipe and C.recipes[pot]and C.recipes[pot][request.recipe]and not M.Food(C.recipes[pot][request.recipe])then return nil,'认识该锅产物，但本阶段只执行食物料理，不制作非食物锅产物' end
  if not M.TrustedCooker(pot)then return nil,'该锅存在未核验的新增或替换食谱，不能保证实际产物；本轮不开锅' end
  local used,list={},{};local best,score;local checked=0;local competition=false;local alternatives={};local alternative_limited=false
  local function visit(start,depth)
   if depth==5 then
    checked=checked+1;if checked%256==0 then coroutine.yield()end
    if checked>40000 then truncated=true;return end
    local candidates,why,tags=M.Candidates(pot,list);if why then return end
    if request.recipe then for _,r in ipairs(candidates)do if r.name==request.recipe and #candidates>1 then competition=true end end end
    if #candidates~=1 then return end
    local r=candidates[1]
    if request.recipe and request.recipe~=r.name then return end
    if not M.Food(r)or not M.Edible(r,recipient)then return end
    if not request.recipe and ((r.hunger or 0)<=0 or not M.Edible(r,recipient))then return end
    if request.category=='meat' and not M.Category(tags)or request.category=='vegetarian' and M.Category(tags)then return end
    local batches=math.max(1,math.ceil((request.remaining or request.quantity or 1)/(r.stacksize or 1)))
    local repeated=true;if batches>1 then for p,n in pairs(used)do if stock[p].count<n*batches then repeated=false end end end
    local cost=0;for _,p in ipairs(list)do cost=cost+(stock[p].cost or 0)end
    local plan={recipe=r.name,ingredients={list[1],list[2],list[3],list[4]},quantity=r.stacksize or 1,cooktime=(r.cooktime or 1)*TUNING.BASE_COOK_TIME,tags=tags}
    if repeated and(not score or cost<score)then score=cost;best=plan end
    if batches>1 then if #alternatives<1024 then local counts={};for p,n in pairs(used)do counts[p]=n end;alternatives[#alternatives+1]={plan=plan,counts=counts,cost=cost}else alternative_limited=true end end
    return
   end
   for k=start,#names do if checked>40000 then return end;local p=names[k];if (used[p]or 0)<stock[p].count then used[p]=(used[p]or 0)+1;list[depth]=p;visit(k,depth+1);used[p]=used[p]-1 end end
  end
  visit(1,1)
  -- Only if no repeatable combination exists, bounded backtracking permits
  -- different legal combinations across batches; it never consumes ingredients.
  if not best and #alternatives>0 then
   table.sort(alternatives,function(a,b)return a.cost<b.cost end)
   local allocated={};local attempts=0
   local function assign(remaining,start,first)
    if remaining<=0 then return first end
    for index=start,#alternatives do
     attempts=attempts+1;if attempts%256==0 then coroutine.yield()end;if attempts>20000 then truncated=true;return end
     local option=alternatives[index];local fits=true;for p,n in pairs(option.counts)do if n+(allocated[p]or 0)>stock[p].count then fits=false;break end end
     if fits then
      for p,n in pairs(option.counts)do allocated[p]=(allocated[p]or 0)+n end
      local result=assign(remaining-option.plan.quantity,index,first or option.plan)
      for p,n in pairs(option.counts)do allocated[p]=allocated[p]-n end
      if result then return result end
     end
    end
   end
   best=assign(request.remaining or request.quantity or 1,1)
  end
  truncated=truncated or alternative_limited
  return best,competition and '有同优先级竞争产物，不能保证指定料理' or truncated and '本轮组合搜索预算已用完，尚不能断言没有配方' or '现有食材没有可保证目标的四槽组合',checked
 end)
end
return M
