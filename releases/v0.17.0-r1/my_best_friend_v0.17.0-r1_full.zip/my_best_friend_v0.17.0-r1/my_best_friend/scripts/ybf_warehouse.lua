-- Shard-local bounded discovery. Reservations coordinate friends, never lock players.
local Auth=require('ybf_friendship_containers')
local Inv=require('ybf_work_inventory')
local M={};local claims=setmetatable({},{__mode='k'})
local function now()return GetTime()end
local function live(token)return token and token.inst and token.inst:IsValid() and token.inst.components.ybf_friend and token.inst.components.ybf_friend.active and token.work and (token.work.core.job==token.job or token.job.external_reservation and token.job.state~='cancelled' and token.job.state~='completed' and not token.job.paused) and not token.job.blocked and token.untiltime>now()end
function M.Release(job)
 for item,rows in pairs(claims) do rows[job]=nil;if not next(rows) then claims[item]=nil end end
end
local function free(item,job)
 local reserved=0
 for j,t in pairs(claims[item] or {}) do if not live(t) then claims[item][j]=nil elseif j~=job then reserved=reserved+t.amount end end
 return math.max(0,Inv.Size(item)-reserved)
end
function M.Available(item,job)return free(item,job)end
function M.Reserve(inst,work,job,item,amount)
 if amount<1 or free(item,job)<amount then return false end
 claims[item]=claims[item]or {};claims[item][job]={inst=inst,work=work,job=job,amount=amount,untiltime=now()+25};return true
end
function M.Discover(inst,job,radius)
 if job._warehouse_cache and now()-(job._warehouse_time or 0)<.5 then
  local out={};for _,e in ipairs(job._warehouse_cache) do if Auth.Authorized(e) and (job.failed[e] or 0)<2 then out[#out+1]=e end end;return out
 end
 inst._ybf_warehouses=inst._ybf_warehouses or setmetatable({},{__mode='k'})
 local x,y,z=inst.Transform:GetWorldPosition();local seen=inst._ybf_warehouses
 for _,e in ipairs(TheSim:FindEntities(x,y,z,radius,nil,{'INLIMBO'})) do
  if Auth.Authorized(e) and inst:GetDistanceSqToInst(e)<=radius*radius then seen[e]=now() end
 end
 local recent={};for e,t in pairs(seen) do recent[#recent+1]={e=e,t=t} end
 table.sort(recent,function(a,b)return a.t>b.t end);for i=65,#recent do seen[recent[i].e]=nil end
 local out={}
 for e,t in pairs(seen) do
  if not Auth.Authorized(e) or now()-t>600 then seen[e]=nil else
   local ex,_,ez=e.Transform:GetWorldPosition()
   if (ex-job.center.x)^2+(ez-job.center.z)^2<=radius*radius and inst:GetDistanceSqToInst(e)<=radius*radius and (job.failed[e] or 0)<2 then out[#out+1]=e end
  end
 end
 table.sort(out,function(a,b)return inst:GetDistanceSqToInst(a)<inst:GetDistanceSqToInst(b) end)
 while #out>32 do table.remove(out) end
 job._warehouse_cache=out;job._warehouse_time=now()
 return out
end
function M.Stock(inst,job,radius,prefab)
 local total=0
 for _,e in ipairs(M.Discover(inst,job,radius)) do for _,it in pairs(e.components.container.slots) do if it.prefab==prefab then total=total+free(it,job) end end end
 return total
end
function M.WithdrawTarget(inst,work,j,prefab,amount)
 for _,e in ipairs(M.Discover(inst,j,work.radius)) do
  for _,item in pairs(e.components.container.slots) do
   if item.prefab==prefab and free(item,j)>0 and not item.components.inventoryitem.islockedinslot then
    local n=math.min(amount,free(item,j),10,inst.components.inventory:CanAcceptCount(item,amount))
    if n>0 then
     claims[item]=claims[item] or {};claims[item][j]={inst=inst,work=work,job=j,amount=n,untiltime=now()+20}
     j.step='withdraw';j.collectitem=prefab;j.warehouse_item=item;j.warehouse_amount=n;j.invobject=nil
     return e
    end
   end
  end
 end
end
function M.DepositTargets(inst,work,j,item)
 local rows=M.Discover(inst,j,work.radius);local eligible={}
 for _,e in ipairs(rows) do
  local c=e.components.container
  if (not j.destination_guid or e.GUID==j.destination_guid) and c:CanTakeItemInSlot(item) and c:CanAcceptCount(item,1)>0 then
   local rank=j.prefer_ice and(e.prefab=='icebox'and 0 or e.prefab=='saltbox'and 1 or 2)or(e.prefab=='saltbox'and 0 or e.prefab=='icebox'and 1 or 2)
   local merge=false;for _,s in pairs(c.slots) do if s.components.stackable and s.components.stackable:CanStackWith(item) and s.components.stackable:RoomLeft()>0 then merge=true end end
   eligible[#eligible+1]={e=e,rank=rank,merge=merge}
  end
 end
 table.sort(eligible,function(a,b)if a.rank~=b.rank then return a.rank<b.rank elseif a.merge~=b.merge then return a.merge end;return inst:GetDistanceSqToInst(a.e)<inst:GetDistanceSqToInst(b.e) end)
 return eligible[1] and eligible[1].e
end
local function count(c,p)local n=0;for _,i in pairs(c.slots or {}) do if i.prefab==p then n=n+Inv.Size(i) end end;return n end
function M.Transfer(inst,j,target,take)
 if not Auth.Authorized(target) or inst:GetDistanceSqToInst(target)>16 then M.Release(j);return false,'容器授权或距离已变化' end
 local c=target.components.container;local inv=inst.components.inventory;local p=take and j.collectitem or j.giveitem
 local n=math.min(10,take and j.warehouse_amount or j.givegoal)
 local before=Inv.Count(inst,p,true);local chest=count(c,p);local moved=0
 for _=1,n do
  local item=take and j.warehouse_item or Inv.Find(inst,p,true)
  if not item or not item:IsValid() or item.prefab~=p then break end
  if take then
   local owned=false;for _,v in pairs(c.slots) do if v==item then owned=true end end
   if not owned or free(item,j)<1 or inv:CanAcceptCount(item,1)<1 then break end
  elseif not c:CanTakeItemInSlot(item) or c:CanAcceptCount(item,1)<1 then break end
  local part=(take and c or inv):RemoveItem(item,false)
  if not part then break end
  if take then inv:GiveItem(part) else
   if not c:GiveItem(part,nil,inst:GetPosition(),false) and part:IsValid() and part.components.inventoryitem.owner==nil then inv:GiveItem(part) end
  end
  local after=Inv.Count(inst,p,true);local updated=count(c,p)
  local delta=take and after-before or before-after
  if delta~=math.abs(updated-chest) or delta<0 or delta>n then M.Release(j);return false,'存取收发数量不一致，需要检查实际库存' end
  moved=delta
 end
 M.Release(j)
 return moved>0,moved
end
return M
