-- Read-only semantic query layer. Data are offline verified, never model lists.
local Store=require('ybf_knowledge_store')
local Data=require('ybf_knowledge_semantic_data')
local Names=require('ybf_knowledge_names')
local M={}
function M.Categories()return Data.categories end
function M.Aliases(prefab)
 local out={}
 if Store.Compatible() then for name,f in pairs(Data.families) do if f.kind=='independent_versions' and f.members[1]==prefab then out[#out+1]='普通'..name end end end
 return out
end
function M.Label(p,K)return Store.Compatible() and Data.candidate_labels[p] or K.Label(p) end
local groups={
 {id='gold_tools',title='黄金工具',words={'黄金工具','金工具'},scope='依据工具动作和含金块的实际配方'},
 {id='building_materials',title='建筑材料',words={'建材','建筑材料'},scope='依据已确认建筑配方的材料关系'},
 {id='sanity_foods',title='恢复精神的食物',words={'恢复精神的食物','回精神的食物','补精神的食物','恢复理智的食物'},scope='依据食物基准精神效果大于零；实际效果与可食用性受角色和状态影响'},
 {id='equipment',title='装备',words={'装备有哪些','哪些装备'},scope='依据装备位置及主要装备效果'},
 {id='tools',title='工具',words={'工具有哪些','哪些工具'},scope='依据已确认工具类别'},
 {id='materials',title='制作材料',words={'材料有哪些','哪些材料'},scope='依据配方反向关系'},
}
function M.Parse(message,context)
 for _,g in ipairs(groups) do for _,w in ipairs(g.words) do if message:find(w,1,true) and (message:find('哪些',1,true) or message:find('列',1,true) or message:find('介绍',1,true)) then return {kind='category',target=g.id,offset=0,title=g.title,scope=g.scope} end end end
 if message:find('会怎样',1,true) or message:find('会怎么样',1,true) or message:find('会变成',1,true) or message:find('有什么后果',1,true) then return {kind='condition'} end
 for name,f in pairs(Data.families) do
  if message:find(name,1,true) and (message:find('全部',1,true) or message:find('所有',1,true) or message:find('阶段',1,true) or message:find('家族',1,true) or message:find('其他形态',1,true)) then return {kind='family',target=name,offset=0} end
  if f.kind=='independent_versions' and message:find(name,1,true) and message:find('特殊版本',1,true) and (message:find('区别',1,true) or message:find('比较',1,true)) then return {kind='family_compare',target=name,offset=0} end
 end
 if context and context.semantic then
  local old=context.semantic
  if message:find('继续展开',1,true) or message:find('还有哪些',1,true) or message:find('接着介绍',1,true) or message:find('更多',1,true) then local next={};for k,v in pairs(old) do next[k]=v end;return next end
 end
 if message:find('其他形态',1,true) or message:find('全部介绍一下',1,true) then
  local found
  for name,f in pairs(Data.families) do for _,p in ipairs(f.members) do for _,topic in ipairs(context and context.topics or {}) do if topic==p then if found and found~=name then return {kind='family_ambiguous'} end;found=name end end end end
  if found then return {kind='family',target=found,offset=0} end
  return {kind='family_missing'}
 end
end
local function paginate(ids,offset,K)
 local parts={};local taken={};local bytes=0
 for i=offset+1,math.min(#ids,offset+8) do
  local label=M.Label(ids[i],K)
  if label~='该对象' then
   if bytes+#label>370 and #parts>0 then break end
   bytes=bytes+#label+3;parts[#parts+1]=label;taken[#taken+1]=ids[i]
  end
 end
 return parts,taken
end
function M.Category(query,K)
 local ids=Data.collections[query.target] or {};local parts,taken=paginate(ids,query.offset or 0,K)
 local next={};for k,v in pairs(query) do next[k]=v end;next.offset=(query.offset or 0)+#taken
 local answer='本地官方知识目录中已确认'..#ids..'种'..query.title..'，'..query.scope..'。'
 if #parts>0 then answer=answer..'例如：'..table.concat(parts,'、')..'。' else answer=answer..'这一页没有更多成员。' end
 if next.offset<#ids then answer=answer..'可说“继续展开”查看下一批。' end
 return answer,{},next
end
function M.Family(inst,query,K)
 local f=Data.families[query.target]
 if not f then return '尚未核实这个家族的成员关系。',{} end
 if query.kind=='family_compare' then return require('ybf_knowledge_presentation').Compare(inst,{{prefab=f.members[1]},{prefab=f.members[2]}},query.target,K),f.members end
 local parts={};local topics={};local offset=query.offset or 0;local last=offset
 for i=offset+1,math.min(#f.members,offset+4) do
  local p=f.members[i];local text=M.Label(p,K)
  local facts=Store.Facts(p,'behaviors');if #facts==0 then facts=Store.Facts(p,'uses') end
  local chosen
  for _,fact in ipairs(facts) do if fact.basic_role and fact.summary then chosen=fact.summary:match('^(.-。)');break end end
  if chosen and #chosen<=165 then text=text..'：'..chosen end
  if #table.concat(parts)+#text>365 and #parts>0 then break end
  parts[#parts+1]=text;topics[#topics+1]=p;last=i
 end
 local relation=f.kind=='boss_phases' and '这是同一首领的阶段关联，不能把阶段当作皮肤。' or f.kind=='name_group' and '这是同名目录分组，成员是独立对象，具体家族关系和机制差异还需核验。' or '这些是有关联的独立对象，不能仅凭同名认定机制相同。'
 local answer=query.target..'当前已核实'..#f.members..'个成员／阶段。'..table.concat(parts,'；')..'。'..relation
 if #(f.conditional_members or {})>0 then answer=answer..'裂隙相关版本或第四阶段另有条件与战斗分支，不能当作正常前三阶段自动顺延。' end
 if last<#f.members then answer=answer..'可说“继续展开”查看其他成员。' end
 return answer,topics,{kind='family',target=query.target,offset=last}
end
local function unique_hits(inst,message,K)
 local ids={};local seen={}
 for _,h in ipairs(K.Expressions(inst,message)) do
  local own={};for _,v in ipairs(h.candidates) do own[v.prefab]=true end
  local n=0;local p;for v in pairs(own) do n=n+1;p=v end
  if n==1 and not seen[p] then seen[p]=true;ids[#ids+1]=p end
 end
 return ids
end
function M.Condition(inst,message,K)
 local ids=unique_hits(inst,message,K);local subject,food
 for _,p in ipairs(ids) do if Data.categories[p]=='creature' then subject=subject and 'ambiguous' or p elseif Data.categories[p]=='food' then food=food and 'ambiguous' or p end end
 if not subject or subject=='ambiguous' or not food or food=='ambiguous' then return '这项条件问题需要明确参与的生物和食物；请说明是哪一种。',ids end
 local n;for _,unit in ipairs({'个','块','份'}) do local v=message:match('(%d+)%s*'..unit);if v then n=tonumber(v);break end end
 if not n then for zh,num in pairs({['一']=1,['二']=2,['两']=2,['三']=3,['四']=4,['五']=5,['六']=6}) do if message:find(zh..'个',1,true) or message:find(zh..'块',1,true) then n=num end end end
 local rule
 for _,r in ipairs(Data.conditions) do if r.subject==subject and message:find('吃',1,true) then rule=r;break end end
 if not rule then return '我识别到了'..K.Label(subject)..'和'..K.Label(food)..'，但这项条件交互还没有确认规则。',ids end
 if not n then return '需要明确实际吃下的数量，才能核对这个变化条件。',ids end
 local nutrition,foodtype
 for _,f in ipairs(Store.Facts(food,'properties')) do if f.semantic_key=='scrapbook_baseline' then nutrition=f.value end end
 for _,f in ipairs(Store.Facts(food,'uses')) do if f.semantic_key=='scrapbook_food_type' then foodtype=f.value end end
 if not nutrition or type(nutrition.healthvalue)~='number' or not foodtype then return '该变化需要肉类食物且对它的生命效果为负；这份食物的适用效果还未核实。',ids end
 if foodtype~=rule.food_type or nutrition.healthvalue>=rule.health_lt then return '按已确认的基准属性，这份食物不满足“肉类且生命效果为负”的变化触发条件。',ids end
 local result=n*rule.delta>=rule.threshold and '会触发狂暴变身，是同一对象的状态变化。' or '尚未达到狂暴变身的触发量。'
 local answer='如果'..K.Label(subject)..'实际吃下'..n..'个'..K.Label(food)..'，且从正常形态、累计量为零开始，'..result..'阈值是'..rule.threshold..'次有效进食；已有累计量、重置、先前变身或食物效果变化会改变结果。'
 K.Diagnostic(inst,{category='verified_condition',original=message,participants=ids,quantity=n,rule=rule,final_answer=answer})
 return answer,ids
end
function M.Context(inst,message,K)
 if not Store.Compatible() then return {available=false,reason='version_mismatch'} end
 local query=M.Parse(message,inst._ybf_query_context)
 if not query then return nil end
 local ids=query.kind=='category' and Data.collections[query.target] or (query.kind=='family' or query.kind=='family_compare') and Data.families[query.target] and Data.families[query.target].members or unique_hits(inst,message,K)
 local result={query=query,scope=Data.scope,build=Data.build,entries={},matched_count=#(ids or {})}
 for i=1,math.min(4,#(ids or {})) do
  local p=ids[i];local row={prefab=p,name=M.Label(p,K),category=Data.categories[p],facts={}}
  for _,facet in ipairs({'uses','behaviors','habitats','sources'}) do for _,f in ipairs(Store.Facts(p,facet)) do
   if #row.facts<3 and f.summary and #f.summary<=360 then row.facts[#row.facts+1]={facet=facet,summary=f.summary,source={path=f.path,line=f.line,sha256=f.sha256,version=f.version,certainty=f.certainty}} end
  end end
  result.entries[#result.entries+1]=row
 end
 return result
end
function M.CookingRecipe(prefab,K)
 if not Store.Compatible() then return nil end
 local r=Data.cooking[prefab];if not r then return nil end
 local tags={meat='肉度',veggie='蔬菜度',fruit='水果度',sweetener='甜度',egg='蛋度',fish='鱼度',monster='怪物度',inedible='非食材成分',decoration='装饰成分',frozen='冰类成分',fat='脂肪度',dairy='乳制品度',magic='魔法成分'}
 local function describe(n)
  if n.literal~=nil then return tostring(n.literal) end
  if n.field=='names' then return K.Label(n.key)..'数量' end
  if n.field=='tags' then return tags[n.key] end
  if n.op=='not' then local v=describe(n.value);return v and '不含'..v end
  local a,b=n.left and describe(n.left),n.right and describe(n.right)
  if not a or not b then return nil end
  local joins={['and']='且',['or']='或',eq='等于',ne='不等于',ge='至少',gt='大于',le='不超过',lt='小于'}
  return '('..a..(joins[n.op] or '')..b..')'
 end
 local condition=describe(r.predicate)
 local answer=K.Label(prefab)..'可由烹饪锅加工组合食材获得。'
 if condition and #condition<=300 then answer=answer..'食材条件：'..condition..'。' else answer=answer..'完整食材组合条件尚不能简明表达。' end
 if r.priority~=nil then answer=answer..'该食谱优先级为'..r.priority..'；其他更高优先级的食谱可能改变结果。' end
 if #r.cookers==1 then answer=answer..'这条食谱要求便携烹饪锅。' end
 return answer
end
function M.Answer(inst,query,message,K)
 if not Store.Compatible() or tostring(Data.build)~=tostring(Store.Manifest().build) then return '当前版本尚未匹配这些静态关系资料。',{} end
 local answer,topics,next
 if query.kind=='category' then answer,topics,next=M.Category(query,K)
 elseif query.kind=='condition' then answer,topics=M.Condition(inst,message,K)
 elseif query.kind=='family' or query.kind=='family_compare' then answer,topics,next=M.Family(inst,query,K)
 elseif query.kind=='family_ambiguous' then answer='刚才涉及多个家族，你想介绍哪一个？';topics={}
 else answer='我尚未核实刚才对象的其他形态或家族关系。';topics={} end
 local category=answer:find('没有确认规则',1,true) or answer:find('尚未核实',1,true) or answer:find('未核实',1,true) or answer:find('还未核实',1,true)
 K.Diagnostic(inst,{category=category and 'knowledge_missing' or 'semantic_query',original=message,query=query,identities=topics,source_scope=Data.scope,related_sources=query.target and Data.families[query.target] and Data.families[query.target].evidence,final_answer=answer})
 return answer,topics,next
end
return M
