-- Persistent batch identity observes all native starts/harvests, including players.
local Marker=Class(function(self,inst)
 self.inst=inst;self.id=tostring(TheWorld.GUID)..':'..tostring(GetTime())..':'..tostring(math.random(100000,999999));self.batch=0;self.harvests=0
 local s=inst.components.stewer;if not s then return end
 local done=s.ondonecooking;s.ondonecooking=function(e,...)if done then done(e,...)end;e:PushEvent('ybf_cook_change')end
 local start=s.StartCooking;s.StartCooking=function(c,doer)local before=c:IsCooking();local result=start(c,doer);if not before and c:IsCooking()then self.batch=self.batch+1;inst:PushEvent('ybf_cook_change')end;return result end
 local harvest=s.Harvest;s.Harvest=function(c,doer)local before=c:IsDone();local result=harvest(c,doer);if before and not c:IsDone()then self.harvests=self.harvests+1;inst:PushEvent('ybf_cook_change')end;return result end
end)
function Marker:OnSave()return {id=self.id,batch=self.batch,harvests=self.harvests}end
function Marker:OnLoad(d)if d then self.id=d.id or self.id;self.batch=d.batch or 0;self.harvests=d.harvests or 0 end end
return Marker
