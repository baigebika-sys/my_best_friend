-- Authorization only. Vanilla container, upgrades, contents and skins untouched.
local C=Class(function(self,inst)self.inst=inst;self.enabled=false end)
function C:SetEnabled(value)
 self.enabled=value==true
 if self.inst._ybf_friendship_net then self.inst._ybf_friendship_net:set(self.enabled) end
 if self.enabled then self.inst:AddTag('ybf_friendship_container') else self.inst:RemoveTag('ybf_friendship_container') end
 self.inst:PushEvent('ybf_friendship_changed')
end
function C:OnSave()return {enabled=self.enabled} end
function C:OnLoad(data)self:SetEnabled(data and data.enabled==true)end
return C
