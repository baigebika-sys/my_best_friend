-- Controlled natural renderer. Only verified/version-matched facts and live
-- component fields enter answers; no raw code or model memory is prose evidence.
local Store=require('ybf_knowledge_store')
local P={}
local facetlabels={properties='具体属性',sources='获取来源',uses='用途',mechanisms='特殊机制',habitats='出现环境',recipes='配方'}
local function sentences(text)
 local out={};for line in (text or ''):gmatch('[^\n]+') do
  local from=1
  while from<=#line do local a,b=line:find('。',from,true)
   if a then out[#out+1]=line:sub(from,b);from=b+1 else out[#out+1]=line:sub(from);break end
  end
 end
 return out
end
local function safe(text,K)
 text=text:gsub('独立 prefab','不同的物品身份'):gsub('prefab','对象身份')
 text=text:gsub('[a-z][a-z0-9_]+',function(id)
  if Store.Identity(id) or K.Aliases(id) then return K.Label(id) end
  if id=='craft' then return '制作' end
  return ''
 end)
 return text:gsub('%s+',' '):gsub('^%s+',''):gsub('%s+$','')
end
local function texts(prefab,facets,K,max)
 local out={};local seen={}
 for _,facet in ipairs(facets) do
  local candidates=Store.Facts(prefab,facet)
  table.sort(candidates,function(a,b)
   local function priority(f)if type(f.value)=='table' and f.value.conditions and facet=='sources' then return -1 elseif f.basic_role and tostring(f.semantic_key):find('^primary_') then return 0 elseif f.semantic_key=='official_scrapbook_note' then return 1 elseif f.basic_role then return 2 else return 3 end end
   if priority(a)==priority(b) then return tostring(a.semantic_key)<tostring(b.semantic_key) end;return priority(a)<priority(b)
  end)
  local has_scoped_equipment=false
  for _,f in ipairs(candidates) do if f.semantic_key=='primary_equipment' then has_scoped_equipment=true end end
  for _,fact in ipairs(candidates) do
   local t=fact.summary or (type(fact.value)=='string' and fact.value)
   if type(fact.value)=='table' and fact.value.method=='craft' then t='可通过制作获得；材料、科技、角色和设施条件需按对应配方核对。' end
   -- Technical summaries belong to logs. Numeric structured facts below are
   -- rendered directly; this avoids database headings and duplicated recipes.
   if t and not (has_scoped_equipment and fact.semantic_key=='primary_scrapbook_equipment') and not tostring(fact.semantic_key):find('^recipe_material_') and fact.semantic_key~='scrapbook_tool_category' and fact.semantic_key~='scrapbook_baseline' and not t:find('脚本配方',1,true) then
    for _,sentence in ipairs(sentences(safe(t,K))) do
     if #sentence>0 and #sentence<=360 and not seen[sentence] then
      out[#out+1]=sentence;seen[sentence]=true;if #out>=(max or 2) then return out end
     end
    end
   end
  end
 end
 return out
end
local function props(row,prefab)
 local result={observed={},live_keys={}}
 for _,fact in ipairs(Store.Facts(prefab,'properties')) do
  if fact.semantic_key=='scrapbook_baseline' and type(fact.value)=='table' then for k,v in pairs(fact.value) do result[k]=v end end
 end
 local f=row.facts or {};local live={weapon_damage='weapondamage',health_maxhealth='health',armor_absorb_percent='armorabsorb'}
 for field,key in pairs(live) do if f[field]~=nil then result.observed[key]=f[field];if result[key]==nil then result[key]=f[field];result.live_keys[key]=true end end end
 if f.food_base then
  for _,pair in ipairs({{'hungervalue','hunger'},{'healthvalue','health'},{'sanityvalue','sanity'}}) do result.observed[pair[1]]=f.food_base[pair[2]];result[pair[1]]=f.food_base[pair[2]];result.live_keys[pair[1]]=true end
 end
 result.currentuses=f.remaining_uses
 return result
end
local function recipe(row,prefab)
 if row.recipes and row.recipes[1] then
  local r=row.recipes[1];local ing={}
  for _,v in ipairs(r.ingredients) do ing[#ing+1]={prefab=v.item,amount=v.amount} end
  return {ingredients=ing,technology_levels=r.technology,output_count=r.output,conditions_unknown=r.character_condition_unknown or r.special_conditions_unknown or r.facility_unknown,live=true}
 end
 for _,fact in ipairs(Store.Facts(prefab,'recipes')) do if type(fact.value)=='table' and fact.value.ingredients then return fact.value end end
end
local function technology(r)
 local labels={SCIENCE='科学',MAGIC='魔法',ANCIENT='远古',SEAFARING='航海',CELESTIAL='天体',MOON_ALTAR='月亮祭坛',SHADOW='暗影',LUNARFORGING='辉煌铁匠铺',SHADOWFORGING='暗影术基座'};local result={}
 for k,v in pairs(r.technology_levels or {}) do if type(v)=='number' and v>0 then result[#result+1]=(labels[k] or '特殊科技')..v..'级' end end
 table.sort(result);return table.concat(result,'、')
end
local function materials(r,K)
 local result={};for _,v in ipairs(r.ingredients or {}) do result[#result+1]=tostring(v.amount)..'个'..K.Label(v.prefab) end
 return table.concat(result,'、')
end
local function append(out,text)
 if not text or text=='' then return end
 for _,old in ipairs(out) do if old==text then return end end
 local bytes=0;for _,old in ipairs(out) do bytes=bytes+#old end
 -- Whole semantic units only. No byte cutting or ellipsis masquerading as a
 -- summary. The UI budget is maintained by selecting fewer complete facts.
 if bytes+#text<=(out._budget or 550) then out[#out+1]=text end
end
function P.Answer(inst,prefab,kind,message,K,budget)
 local row=K.Entry(inst,prefab);local title=K.Label(prefab);local out={_budget=budget};local v=props(row,prefab)
 if kind=='recipe' then
  local r=recipe(row,prefab)
  if r then
   append(out,'制作'..title..'需要'..materials(r,K)..'。')
   if r.output_count then append(out,'每次产出'..r.output_count..'个。') end
   local tech=technology(r);if tech~='' then append(out,'需要'..tech..'。') end
   if r.conditions and r.conditions.builder_tag then append(out,'还要求对应角色的制作资格。') end
   if r.conditions and r.conditions.placer then append(out,'制成后需要选择合适位置放置。') end
   if r.conditions_unknown then append(out,'特殊角色或设施条件还需核对。') end
  else
   local cooked=require('ybf_knowledge_semantic').CookingRecipe(prefab,K)
   if cooked then append(out,cooked) else append(out,'我没查到'..title..'的普通制作配方。') end
   for _,t in ipairs(texts(prefab,{'sources'},K,1)) do append(out,t) end
  end
 elseif kind=='properties' then
  if v.hungervalue then
   local effects={};for _,pair in ipairs({{'hungervalue','饥饿'},{'healthvalue','生命'},{'sanityvalue','精神'}}) do if v[pair[1]]~=nil then effects[#effects+1]=pair[2]..v[pair[1]] end end
   append(out,title..'的'..(v.live_keys.hungervalue and '当前基础效果' or '基准食物效果')..'是：'..table.concat(effects,'、')..'。')
  elseif v.health then append(out,title..'的'..(v.live_keys.health and '当前生命上限' or '基准生命上限')..'为'..v.health..'。') end
  if v.weapondamage then
   append(out,(v.live_keys.weapondamage and '当前基础武器伤害为' or '基准武器伤害为')..v.weapondamage..'。')
   if v.observed.weapondamage and v.observed.weapondamage~=v.weapondamage then append(out,'这件实际对象的基础武器伤害为'..v.observed.weapondamage..'，与基准值不同。') end
  end
  if v.finiteuses then append(out,'标准使用次数为'..v.finiteuses..'次。') end
  if v.damage then append(out,'基准攻击伤害为'..v.damage..'。') end
  if v.currentuses then append(out,'这件实际对象目前剩余'..v.currentuses..'次。') end
  for _,fact in ipairs(Store.Facts(prefab,'properties')) do
   local d=fact.value
   if tostring(fact.semantic_key):find('^tool_action_') and type(d)=='table' and type(d.effectiveness)=='number' then
    append(out,'基础动作效率为'..d.effectiveness..'，对应'..(({CHOP='砍伐',MINE='开采',DIG='挖掘',HAMMER='敲拆',TILL='耕地'})[d.action] or '工具动作')..'；特殊状态可能改变实际效率。')
   end
  end

  if #out==0 then for _,t in ipairs(texts(prefab,{'properties','mechanisms','uses'},K,2)) do append(out,t) end end
 elseif kind=='habitats' then
  for _,t in ipairs(texts(prefab,{'habitats'},K,2)) do append(out,t) end
  if #out==0 then append(out,'我认识'..title..'，但通常出现的环境还没有可靠记录。') end
  append(out,'这说明通常出现的条件，不代表我知道它在当前地图的位置。')
 elseif kind=='sources' then
  for _,t in ipairs(texts(prefab,{'sources'},K,2)) do append(out,t) end
  if #out==0 then
   for _,source in ipairs(row.sources or {}) do if source.action~='drop' then append(out,'我实际发现过'..K.Label(source.object)..'这个来源，需要重新确认它现在是否可用。');break end end
  end
 else
  local reverse={};local seen={}
  for _,f in ipairs(Store.Facts(prefab,'uses')) do
   if tostring(f.semantic_key):find('^recipe_material_') and type(f.value)=='table' then local p=f.value.product;if p and not seen[p] then seen[p]=true;reverse[#reverse+1]=p end end
  end
  if (kind=='identity' or kind=='uses') and #reverse>0 then
   local primary=false;for _,f in ipairs(Store.Facts(prefab,'uses')) do if f.basic_role and tostring(f.semantic_key):find('^primary_') then primary=true end end
   if not primary then
    local labels={};for i=1,math.min(3,#reverse) do labels[#labels+1]=K.Label(reverse[i]) end
    append(out,'可用作制作'..table.concat(labels,'、')..'等成品的材料；已确认'..#reverse..'种配方用途，制作仍需满足各自条件。')
   end
  end
  local facets=kind=='identity' and {'uses','behaviors','habitats','sources','mechanisms'} or kind=='difference' and {'variants','mechanisms'} or kind=='mechanisms' and {'mechanisms','behaviors','restrictions'} or {'uses','mechanisms','restrictions'}
  for _,t in ipairs(texts(prefab,facets,K,2)) do append(out,t) end
  if kind=='identity' then
   local labels={creature='生物',tool='工具',food='食物',facility='设施',item='物品',auxiliary_or_effect='辅助实体或视觉特效',natural_or_interactive='自然或交互对象',harvestable_object='自然采集对象'}
   local label=labels[row.category]
   if label then table.insert(out,1,title..'是一种'..label..'。') end
   if #out==1 and label then append(out,'它的主要功能、行为或来源还没有可靠补齐。') end
  end
  if #out==0 then
   for _,a in ipairs(row.facts.tool_actions or {}) do append(out,title..'可用于'..(({CHOP='砍伐',MINE='开采',DIG='挖掘',HAMMER='敲拆',TILL='耕地'})[a.action] or '对应工具动作')..'。') end
   if row.facts.has_container then append(out,title..'可用于储存物品，具体存放限制还需核对。') end
  end
 end
 if #out==0 then
  append(out,'我认识'..title..'，但'..(facetlabels[kind] or '这部分知识')..'还没有可靠补齐。')
  if kind~='recipe' and kind~='habitats' then for _,t in ipairs(texts(prefab,{'behaviors','uses','mechanisms'},K,1)) do append(out,'已确认的信息是：'..t) end end
 end
 if Store.Entry(prefab) and not Store.Compatible() then append(out,'已有静态资料尚未与当前游戏版本核对。') end
 if kind=='identity' and inst._ybf_answer_style=='direct' and #out>1 and out[1]:find('是一种',1,true) then local identity=table.remove(out,1);out[#out+1]=identity end
 while #table.concat(out)>570 and #out>1 do table.remove(out) end
 return table.concat(out)
end
function P.Compare(inst,targets,message,K)
 if #targets<2 then return '你想把它和哪一个比较？请告诉我另一个名字。' end
 if #targets>2 then return '请先选两种对象，我会按用途、耐久和制作条件比较。' end
 local a,b=targets[1].prefab,targets[2].prefab;local an,bn=K.Label(a),K.Label(b);local out={}
 if a==b then return '这两个名称指向同一种对象；状态或皮肤差异需要依据具体对象核对。' end
 local ar,br=K.Entry(inst,a),K.Entry(inst,b);local av,bv=props(ar,a),props(br,b)
 local au=texts(a,{'uses'},K,1);local bu=texts(b,{'uses'},K,1)
 if au[1] and au[1]==bu[1] then append(out,'两者'..au[1])
 elseif ar.category=='tool' and br.category=='tool' then append(out,an..'和'..bn..'都是工具。') end
 local labels={finiteuses='标准使用次数',weapondamage='基准武器伤害',health='基准生命上限',armorabsorb='基准护甲吸收比例'};local known=0
 for _,key in ipairs({'finiteuses','weapondamage','health','armorabsorb'}) do
  if av[key]~=nil and bv[key]~=nil then
   known=known+1
   if av[key]==bv[key] then append(out,'两者的'..labels[key]..'相同，都是'..av[key]..'。')
   else append(out,labels[key]..'分别为'..av[key]..'和'..bv[key]..'。') end
  elseif av[key]~=nil or bv[key]~=nil then append(out,labels[key]..'只查到了其中一种，另一种还不能确定。') end
 end
 for _,pair in ipairs({{'armor','基准护甲耐久'},{'insulator','基准保温'}}) do if av[pair[1]] and bv[pair[1]] and av[pair[1]]~=bv[pair[1]] then append(out,pair[2]..'：'..an..av[pair[1]]..'，'..bn..bv[pair[1]]..'。');known=known+1 end end
 local ra,rb=recipe(ar,a),recipe(br,b)
 if ra and rb then
  append(out,'制作材料：'..an..'需'..materials(ra,K)..'；'..bn..'需'..materials(rb,K)..'。')
  local ta,tb=technology(ra),technology(rb)
  if ta~=tb then append(out,'科技条件：前者'..(ta~='' and ta or '无已确认科技要求')..'，后者'..(tb~='' and tb or '无已确认科技要求')..'。') end
 end
 if known==0 then
  for _,t in ipairs(texts(a,{'uses','mechanisms'},K,1)) do append(out,an..'：'..t) end
  for _,t in ipairs(texts(b,{'uses','mechanisms'},K,1)) do append(out,bn..'：'..t) end
 end
 local am,bm=texts(a,{'mechanisms'},K,1),texts(b,{'mechanisms'},K,1)
 if am[1] and am[1]~=bm[1] then append(out,an..'的特殊机制：'..am[1]) end
 if bm[1] and bm[1]~=am[1] then append(out,bn..'的特殊机制：'..bm[1]) end
 if #am==0 and #bm==0 then append(out,'其他特殊效果尚未核实。') end
 if #out==0 then append(out,'我认识这两种对象，但可比较的差异还没有可靠补齐。') end
 K.Diagnostic(inst,{original=message,kind='difference',comparison={a,b},retrieval={K.Retrieve(inst,a,'difference'),K.Retrieve(inst,b,'difference')},final_answer=table.concat(out)})
 return table.concat(out)
end
return P
