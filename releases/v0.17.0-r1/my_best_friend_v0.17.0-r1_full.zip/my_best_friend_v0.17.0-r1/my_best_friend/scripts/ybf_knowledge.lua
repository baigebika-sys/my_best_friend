-- Runtime facts and conservative capability rules. Never instantiate prefabs,
-- run prefab factories, GenerateLoot/lootsetupfn, or recipe callbacks for discovery.
local M={}
local Store=require('ybf_knowledge_store')
local Names=require('ybf_knowledge_names')
-- Runtime recipe capability, deliberately separate from static recipe knowledge.
function M.ExecutionRecipe(name)
 local r=GetValidRecipe and GetValidRecipe(name) or AllRecipes and AllRecipes[name]
 if r then return r end
 local selected
 for _,candidate in pairs(AllRecipes or {}) do
  if candidate.product==name and not candidate.placer and not candidate.dropitem and not candidate.manufactured then
   if selected then return nil end;selected=candidate
  end
 end
 return selected
end
M.craft_allowed=setmetatable({}, {__index=function(_,name)
 local r=M.ExecutionRecipe(name)
 return r~=nil and not r.placer and not r.dropitem and not r.manufactured and type(r.ingredients)=='table'
end})
function M.ExecutionCandidate(name)
 if M.craft_allowed[name]then return true end
 local b=require('ybf_building');local r=b.Recipe(name);return r and b.Supported(r)==true or false
end

local aliases={twigs={'树枝','枝条'},cutgrass={'草','割下的草'},log={'木头','原木'},rocks={'石头','岩石'},flint={'燧石'},goldnugget={'金子','金块'},axe={'斧头','斧子'},pickaxe={'鹤嘴锄','镐子'},cutstone={'石砖'},boards={'木板'},rope={'绳子'},torch={'火把'},bonestew={'炖肉汤','肉汤'},petals={'花瓣'}}
-- Explicit fallbacks retain the tested basic capabilities before first sighting.
local basic={twigs=true,cutgrass=true,log=true,rocks=true,flint=true,goldnugget=true}
local trees={evergreen=true,evergreen_sparse=true,deciduoustree=true,twiggytree=true}
local function id(s)return type(s)=='string' and #s<=80 and s:match('^[a-z0-9_]+$')~=nil end
local function text(s,fallback)return type(s)=='string' and #s<=120 and s or fallback end
local function tag(e,t)return e:HasTag(t)end
function M.Aliases(prefab)return aliases[prefab]end
function M.Label(prefab)
 local names=STRINGS and STRINGS.NAMES or {}
 local stored=Store.Identity(prefab)
 local label=text(names[string.upper(prefab)],stored and stored.names and stored.names.zh or aliases[prefab] and aliases[prefab][1] or '该对象')
 label=label:gsub('{[%w_]+}',''):gsub('^%s+',''):gsub('%s+$','')
 return label
end
local function state(inst)
 if not inst._ybf_knowledge then inst._ybf_knowledge={observed={},order={},items={},displays={}} end
 inst._ybf_knowledge.displays=inst._ybf_knowledge.displays or {}
 return inst._ybf_knowledge
end
function M.DisplayName(inst,prefab)
 local e=state(inst).items[prefab]
 if e and e:IsValid() and e.GetDisplayName then
  local ok,name=pcall(e.GetDisplayName,e)
  if ok and type(name)=='string' and #name>0 and #name<=120 and name~=prefab then return name end
 end
 return M.Label(prefab)
end
function M.RecordName(inst,e)
 local s=state(inst)
 if not e.GetDisplayName then return end
 local ok,name=pcall(e.GetDisplayName,e)
 if not ok or type(name)~='string' or #name==0 or #name>120 or name==e.prefab then return end
 s.displays=s.displays or {};s.displays[e.prefab]=s.displays[e.prefab] or {}
 local map=s.displays[e.prefab];local count=0;for _ in pairs(map) do count=count+1 end
 if count<8 or map[name] then map[name]=e;s.name_index=nil end
end
function M.Known(inst,prefab)
 if not id(prefab) then return false end
 local s=state(inst)
 if Store.Entry(prefab) or basic[prefab] or M.craft_allowed[prefab] or s.items[prefab] or s.observed[prefab] then return true end
 if Prefabs and Prefabs[prefab] then return true end
 for name,r in pairs(AllRecipes or {}) do
  if r.product==prefab or (r.product==nil and name==prefab) then return true end
  for _,v in ipairs(r.ingredients or {}) do if v.type==prefab then return true end end
 end
 return false
end
function M.Catalog(inst)
 local out={}
 for name in pairs(Store.data.entries) do out[name]=true end
 for name in pairs(Prefabs or {}) do if id(name) then out[name]=true end end
 for name,r in pairs(AllRecipes or {}) do
  if id(r.product) then out[r.product]=true end
  for _,v in ipairs(r.ingredients or {}) do if id(v.type) then out[v.type]=true end end
 end
 for name in pairs(basic) do out[name]=true end
 for name in pairs(M.craft_allowed) do out[name]=true end
 for name in pairs(state(inst).items) do out[name]=true end
 for name in pairs(state(inst).observed) do out[name]=true end
 return out
end
function M.Index(inst)
 local s=state(inst);if s.name_index then return s.name_index end
 local index={}
 local function add(name,prefab,kind,entity)
  if type(name)~='string' or #name<2 or #name>120 then return end
  name=name:lower()
  index[name]=index[name] or {}
  for _,v in ipairs(index[name]) do if v.prefab==prefab and v.kind==kind then return end end
  index[name][#index[name]+1]={prefab=prefab,kind=kind,instance=entity and entity.GUID or nil,skin=entity and entity.skinname or nil}
 end
 for prefab in pairs(M.Catalog(inst)) do
  add(prefab,prefab,'prefab');add(M.Label(prefab),prefab,'runtime_name')
  for _,alias in ipairs(aliases[prefab] or {}) do add(alias,prefab,'alias') end
  local static=Store.Identity(prefab)
  if static then
   for _,name in pairs(static.names or {}) do add(name,prefab,'versioned_name');for _,alias in ipairs(Names.Morphology(name,static.category)) do add(alias,prefab,'versioned_alias') end end
   for _,alias in ipairs(static.aliases or {}) do add(alias,prefab,'versioned_alias') end
   for _,alias in ipairs(require('ybf_knowledge_semantic').Aliases(prefab)) do add(alias,prefab,'versioned_alias') end
   for _,fact in ipairs(static.variant_index or static.variants or {}) do
    local v=fact.value
    if Store.Compatible() and fact.certainty=='verified' and fact.version==Store.Manifest().build and type(v)=='table' and (v.kind=='state' or v.kind=='skin') then add(v.name,prefab,v.kind) end
   end
  end
  for display,e in pairs((s.displays or {})[prefab] or {}) do
   if e:IsValid() and display~=M.Label(prefab) then add(display,prefab,'observed_display',e) end
  end
 end
 s.name_index=index;return index
end
function M.Names(inst,query)
 local out={};local seen={}
 for _,v in ipairs((M.Index(inst)[query] or M.Index(inst)[type(query)=='string' and query:lower() or '']) or {}) do if not seen[v.prefab] then seen[v.prefab]=true;out[#out+1]=v.prefab end end
 table.sort(out);return out
end
function M.Expressions(inst,message)return Names.Scan(message or '',M.Index(inst))end
function M.Mentions(inst,message)
 local out={};local seen={}
 for _,hit in ipairs(M.Expressions(inst,message)) do
  for _,binding in ipairs(hit.candidates) do if not seen[binding.prefab] then seen[binding.prefab]=true;out[#out+1]=binding.prefab end end
 end
 return out
end
local function resolve(inst,query,message,for_execution)
 local context=inst._ybf_query_context
 if not for_execution and Names.HasPronoun(message) and #M.Expressions(inst,message)==0 and not (context and context.pending and M.PendingChoice(inst,message,context.pending)) then
  local topics=context and context.topics or {}
  if #topics~=1 then return nil,'reference_ambiguous',topics end
  local valid=M.Names(inst,query)
  if Names.IsPronoun(query) or query==topics[1] or (#valid==1 and valid[1]==topics[1]) then return topics[1] end
  return nil,'name_expression_mismatch',topics
 end
 if not for_execution and context and context.pending then
  local choice=M.PendingChoice(inst,message or '',context.pending)
  if choice then local ids=M.Names(inst,query);if query==choice or (#ids==1 and ids[1]==choice) then return choice end end
 end
 local candidates=M.Names(inst,query)
 if #candidates==0 then
  local similar=Names.Suggestions(query or '',M.Index(inst))
  return nil,#similar>0 and 'name_typo_confirmation' or 'name_unknown',similar
 end
 if #candidates>1 and for_execution and message and (message:find('制作',1,true) or message:find('做',1,true) or message:find('建',1,true) or message:find('造',1,true)) then
  local craftable={};for _,p in ipairs(candidates) do if M.ExecutionCandidate(p) then craftable[#craftable+1]=p end end
  if #craftable==1 then candidates=craftable end
 end
 if #candidates>1 then return nil,'name_ambiguous',candidates end
 local prefab=candidates[1]
 local matches=M.Index(inst)[query] or M.Index(inst)[type(query)=='string' and query:lower() or ''] or {}
 for _,binding in ipairs(matches) do
  if for_execution and (binding.kind=='observed_display' or binding.kind=='state' or binding.kind=='skin') then return nil,'variant_execution_unsupported',candidates end
 end
 if message and #message>0 then
  local grounded=false;local dynamic=false;local current_binding=false
  for _,hit in ipairs(M.Expressions(inst,message)) do
   local same=false;local unique={};local count=0
   for _,v in ipairs(hit.candidates) do
    if not unique[v.prefab] then unique[v.prefab]=true;count=count+1 end
    if v.prefab==prefab then
     same=true;dynamic=dynamic or v.kind=='observed_display' or v.kind=='skin' or v.kind=='state'
     if v.kind~='versioned_name' and v.kind~='versioned_alias' or Store.Compatible() then current_binding=true end
    end
   end
   if same then
    local noun=not for_execution and Names.QuestionName(message)
    local grammar_bound=(noun and noun==hit.text and count==1) or (for_execution and require('ybf_task_language').QuantifiedName(hit))
    if (hit.unresolved_prefix or hit.unresolved_suffix) and not grammar_bound then
     local similar=Names.Suggestions((hit.unresolved_prefix or '')..hit.text..(hit.unresolved_suffix or ''),M.Index(inst))
     if #similar>0 then return nil,'name_typo_confirmation',similar end
     return nil,'qualified_name_unresolved',candidates
    end
    if count>1 and hit.text~=prefab then
     -- A crafting request can distinguish a craftable item from a same-named
     -- scenery/helper identity, never two craftable variants or real qualifiers.
     local crafting_frame=for_execution and (message:find('制作',1,true) or message:find('做',1,true) or message:find('建',1,true) or message:find('造',1,true))
     if crafting_frame and M.ExecutionCandidate(prefab) then
      local executable=0;for p in pairs(unique) do if M.ExecutionCandidate(p) then executable=executable+1 end end
      if executable==1 then count=1 end
     end
    end
    if count>1 and hit.text~=prefab then
     local all={} ;for k in pairs(unique) do all[#all+1]=k end;table.sort(all)
     return nil,'name_ambiguous',all
    end
    grounded=true
   end
  end
  if not grounded then return nil,'name_expression_mismatch',candidates end
  if for_execution and dynamic then return nil,'variant_execution_unsupported',candidates end
  if for_execution and not current_binding then return nil,'identity_version_unconfirmed',candidates end
 end
 if for_execution and Store.Entry(prefab) and not (Prefabs and Prefabs[prefab]) then return nil,'identity_version_unconfirmed',candidates end
 return prefab
end
local function redact(value,depth)
 if depth>8 then return '[truncated]' end
 if type(value)=='string' then return value:gsub('sk%-[%w_%-]+','[redacted]'):gsub('[Bb]earer%s+[%w_%.%-]+','[redacted]'):sub(1,1200) end
 if type(value)=='table' then
  local out={};local count=0
  for key,v in pairs(value) do
   count=count+1;if count>64 then break end
   local name=tostring(key):lower()
   out[key]=(name=='key' or name=='api_key' or name=='token' or name=='authorization' or name=='password') and '[redacted]' or redact(v,depth+1)
  end
  return out
 end
 return value
end
function M.Diagnostic(inst,data)
 if not inst._ybf_knowledge_debug then return end
 data=redact(data,0)
 if not data.category then data.category=data.reason=='reference_ambiguous' and 'reference_ambiguous' or data.reason and 'name_failure' or data.retrieval and type(data.retrieval.facts)=='table' and #data.retrieval.facts==0 and (data.retrieval.known_fact_count>0 and 'retrieval_gap' or 'knowledge_missing') or 'verified_query' end
 data.request_id=inst._ybf_trace_id or data.request_id
 local s=state(inst);s.trace=s.trace or {};s.trace[#s.trace+1]=data
 if #s.trace>20 then table.remove(s.trace,1) end
 local function clean(v)return tostring(v or ''):gsub('sk%-[%w_%-]+','[redacted]'):gsub('[%c]',' '):sub(1,300) end
 print('[YBF KNOWLEDGE TRACE] id='..clean(data.request_id)..' raw='..clean(data.original)..' model='..clean(data.model_query)..' identity='..clean(data.prefab)..' reason='..clean(data.reason))
 local encoder=inst._ybf_diagnostic_encode or json and (json.encode_compliant or json.encode)
 if encoder then local ok,body=pcall(encoder,data);if ok then print('[YBF KNOWLEDGE DETAIL] '..body) end end
end
function M.SetDebug(inst,enabled)inst._ybf_knowledge_debug=enabled==true;if not enabled then state(inst).trace=nil end end
function M.Trace(inst)return state(inst).trace or {}end
function M.Resolve(inst,query,message,for_execution)
 local prefab,reason,candidates=resolve(inst,query,message,for_execution)
 if not prefab and reason~='reference_ambiguous' and reason~='variant_execution_unsupported' and reason~='name_ambiguous' then
  local phrase=Names.NounText(message or query)
  local hits=M.Expressions(inst,message)
  if #hits==1 and (hits[1].unresolved_prefix or hits[1].unresolved_suffix) then phrase=(hits[1].unresolved_prefix or '')..hits[1].text..(hits[1].unresolved_suffix or '') end
  local context={topics=inst._ybf_query_context and inst._ybf_query_context.topics or {},categories=require('ybf_knowledge_semantic').Categories()}
  local raw=message or '';for word,category in pairs({['生物']='creature',['动物']='creature',['首领']='creature',['建筑']='facility',['设施']='facility',['工具']='tool',['食物']='food'}) do if raw:find(word,1,true) then context.category=category;break end end
  local ranks=Names.Rank(phrase,M.Index(inst),context)
  local ids=M.Names(inst,query)
  if Names.Obvious(ranks) and (query==phrase or #ids==1 and ids[1]==ranks[1].prefab) then
   if for_execution then reason='name_typo_confirmation';candidates={ranks[1].prefab}
   elseif ranks[1].kind~='state' and ranks[1].kind~='skin' then prefab=ranks[1].prefab;reason='knowledge_inferred';candidates={prefab} end
  elseif #ranks>0 and #hits<=1 and (query==phrase or #ids==0) then reason='name_typo_confirmation';candidates=Names.Suggestions(phrase,M.Index(inst),context) end
 end
 if inst._ybf_knowledge_debug then
  local stored=prefab and Store.Entry(prefab)
  M.Diagnostic(inst,{original=message,model_query=query,for_execution=for_execution==true,
   candidates=candidates or M.Names(inst,query),expressions=M.Expressions(inst,message),prefab=prefab,reason=reason,
   identity_source=stored and stored.identity or {kind='runtime_registry',version=APP_VERSION or 'unreported_current_runtime'}})
 end
 return prefab,reason,candidates
end
function M.Coverage(inst)
 local out={runtime_registered=0,runtime_named=0,official_total=Store.Manifest().official_total,
  static_identity_records=0,static_names={zh=0,en=0},static_verified_facets={},runtime_is_not_official_universe=true,
  build=APP_VERSION,static_build=Store.Manifest().build,version_compatible=Store.Compatible()}
 for name in pairs(Prefabs or {}) do
  if id(name) then out.runtime_registered=out.runtime_registered+1
   if type((STRINGS and STRINGS.NAMES or {})[name:upper()])=='string' then out.runtime_named=out.runtime_named+1 end
  end
 end
 for prefab,row in pairs(Store.data.entries) do
  out.static_identity_records=out.static_identity_records+1
  for _,lang in ipairs({'zh','en'}) do if row.names and row.names[lang] then out.static_names[lang]=out.static_names[lang]+1 end end
  for _,facet in ipairs({'properties','uses','sources','recipes','mechanisms','behaviors','restrictions','variants','habitats'}) do
   local count=row.verified_facets and row.verified_facets[facet] or (not row.detail_module and #Store.Facts(prefab,facet)>0 and 1 or 0)
   out.static_verified_facets[facet]=(out.static_verified_facets[facet] or 0)+(Store.Compatible() and (count or 0)>0 and 1 or 0)
  end
 end
 return out
end
function M.Safe(e)
 return e and e:IsValid() and not e:IsInLimbo() and not tag(e,'irreplaceable') and not tag(e,'NOCLICK')
  and not tag(e,'fire') and not tag(e,'intense') and not (e.components.burnable and e.components.burnable:IsBurning())
end
local function ordinary(e)
 local c=e.components
 return M.Safe(e) and not tag(e,'monster') and not tag(e,'hostile') and not tag(e,'thorny')
  and not tag(e,'trap') and not tag(e,'structure') and not tag(e,'character')
  and not tag(e,'heavy') and not tag(e,'wall') and not tag(e,'sculpture') and not tag(e,'statue')
  and not c.combat and not c.health and not c.container and not c.trap and not c.explosive
  and not c.prototyper and not e.monster and not e.monster_start_task and not e.dostartmonster_task
  and not tag(e,'burnt') and not tag(e,'stump')
end
local function loot(c)
 local out={}
 if not c or c.lootsetupfn then return out,'dynamic_loot_unknown' end
 local function add(p)if id(p) then out[p]=true end end
 for _,p in ipairs(c.loot or {}) do add(p) end
 for _,v in ipairs(c.chanceloot or {}) do if (v.chance or 0)>0 then add(v.prefab) end end
 for _,v in ipairs(c.randomloot or {}) do if (v.weight or 0)>0 and (c.numrandomloot or 0)>0 and (c.chancerandomloot or 1)>0 then add(v.prefab) end end
 for _,v in ipairs((LootTables or {})[c.chanceloottable] or {}) do if (v[2] or 0)>0 then add(v[1]) end end
 return out
end
local function sourcefacts(inst,e)
 local out={};if not M.Safe(e) or e.prefab=='ybf_friendship_flower' then return out end
 local c=e.components
 local function add(product,action,supported,reason)
  if id(product) and product~='ybf_friendship_flower' then
   out[#out+1]={product=product,object=e.prefab,action=action,tool=action=='chop' and 'axe' or action=='mine' and 'pickaxe' or nil,
    supported=supported,reason=reason,evidence='component_fact',version=APP_VERSION or 'unreported_current_runtime',certainty='observed',available=false}
  end
 end
 if c.inventoryitem and not c.inventoryitem.owner and c.inventoryitem.canbepickedup then
  add(e.prefab,'pickup',ordinary(e) and not tag(e,'heavy') and not c.inventoryitem.isheavy,'special_object')
  if #out>0 then out[#out].available=out[#out].supported end
 end
 local p=c.pickable
 if p then
  local standard=id(p.product) and p.product~='ybf_friendship_flower' and not p.use_lootdropper_for_product and not p.getproductfn
  local supported=standard and ordinary(e) and not p.requirespecialtool and not p.requiredtool and not p.requiredtag and not p.restrictedtag
  if standard then
   add(p.product,'pick',supported,supported and nil or 'special_object')
   out[#out].available=supported and p.caninteractwith~=false and p:CanBePicked() and not (p.IsStuck and p:IsStuck()) or false
  elseif p.use_lootdropper_for_product then
   for product in pairs(loot(c.lootdropper)) do add(product,'pick',false,'dynamic_product_unknown') end
  end
 end
 local w=c.workable
 if w and w:CanBeWorked() then
  local action=w:GetWorkAction()
  if action==ACTIONS.CHOP or action==ACTIONS.MINE then
   local products=loot(c.lootdropper)
   -- Dynamic ordinary trees retain the verified log-only adapter; do not
   -- infer other dynamic drops by executing the drop callback.
   if action==ACTIONS.CHOP and trees[e.prefab] then products.log=true end
   products.ybf_friendship_flower=nil
   for product in pairs(products) do
    local step=action==ACTIONS.CHOP and 'chop' or 'mine'
    local supported=ordinary(e) and (step=='mine' and not tag(e,'tree') or step=='chop' and tag(e,'tree'))
    add(product,step,supported,supported and nil or 'special_object');out[#out].available=supported
   end
  end
 end
 return out
end
function M.Sources(inst,e)
 local ok,result=pcall(sourcefacts,inst,e)
 if ok then return result end
 print('[YBF KNOWLEDGE] category=source_unknown object='..tostring(e and e.prefab)..' reason=component_read_failed')
 return {}
end
function M.Perceived(inst,e)
 if not inst.Transform or not e.Transform then return false end
 local x,_,z=inst.Transform:GetWorldPosition();local ex,_,ez=e.Transform:GetWorldPosition()
 local work=inst.components.ybf_work;local radius=work and work.radius or 32
 return type(x)=='number' and type(z)=='number' and type(ex)=='number' and type(ez)=='number' and (x-ex)^2+(z-ez)^2<=radius^2
end
function M.Observe(inst,entities)
 local s=state(inst)
 for _,e in ipairs(entities) do
  if M.Safe(e) and M.Perceived(inst,e) then
   if id(e.prefab) then M.RecordName(inst,e);if not s.items[e.prefab] then s.items[e.prefab]=e;s.name_index=nil end end
   for _,v in ipairs(M.Sources(inst,e)) do
    if not s.observed[v.product] then
     if #s.order>=256 then local old=table.remove(s.order,1);s.observed[old]=nil end
     s.order[#s.order+1]=v.product;s.observed[v.product]={}
    end
    local list=s.observed[v.product];local key=v.object..':'..v.action
    local count=0;for _ in pairs(list) do count=count+1 end
    if count<4 or list[key] then list[key]={product=v.product,object=v.object,action=v.action,tool=v.tool,supported=v.supported,reason=v.reason,evidence=v.evidence,version=v.version,certainty=v.certainty} end
    -- Positions are never global knowledge: only this actual perception.
   end
  end
 end
end
function M.ObserveInventory(inst)
 local Inventory=require('ybf_work_inventory');local s=state(inst);s.items={};s.displays={};s.name_index=nil
 for _,e in ipairs(Inventory.Items(inst,true)) do s.items[e.prefab]=e;M.RecordName(inst,e) end
end
function M.CanAcquire(inst,prefab)
 if basic[prefab] then return true end
 for _,v in pairs(state(inst).observed[prefab] or {}) do if v.supported then return true end end
 return false
end
function M.Capability(inst,prefab)
 if not M.Known(inst,prefab) then return 'name_unknown' end
 if M.CanAcquire(inst,prefab) then return 'supported_acquisition' end
 if M.craft_allowed[prefab] then return 'supported_crafting_with_conditions' end
 local building=require('ybf_building');local r=building.Recipe(prefab);if r and building.Supported(r)then return 'supported_building_with_location_conditions' end
 for name,r in pairs(AllRecipes or {}) do if r.product==prefab or (r.product==nil and name==prefab) then return 'source_unsupported' end end
 if #Store.Facts(prefab,'sources')>0 then return 'source_unsupported' end
 local sources=state(inst).observed[prefab]
 return sources and next(sources) and 'source_unsupported' or 'source_unknown'
end
function M.Recipes(inst,prefab)
 local out={};local builder=inst.components.builder
 for name,r in pairs(AllRecipes or {}) do
  if r.product==prefab or (r.product==nil and name==prefab) then
   out[#out+1]={id=name,product=r.product,output=type(r.numtogive)=='number' and not r.override_numtogive_fn and r.numtogive or nil,
    output_unknown=r.override_numtogive_fn~=nil,ingredients={},technology={},supported=(M.craft_allowed[name]==true and not r.placer and not r.dropitem and not r.manufactured) or (r.placer~=nil and require('ybf_building').Supported(r)==true),
    version=APP_VERSION or 'unreported_current_runtime',certainty='runtime_recipe_fact',facility_unknown=r.manufactured~=nil and r.manufactured~=false,placement=r.placer~=nil,evidence='recipe_data',
    character_condition_unknown=true,special_conditions_unknown=r.canbuild~=nil or r.character_ingredients~=nil}
   local row=out[#out]
   for i,v in ipairs(r.ingredients or {}) do if i<=12 then row.ingredients[#row.ingredients+1]={item=v.type,amount=v.amount,friend_amount=type(v.amount)=='number' and builder and type(builder.ingredientmod)=='number' and RoundBiasedUp and math.max(1,RoundBiasedUp(v.amount*builder.ingredientmod)) or nil,evidence='recipe_data'} end end
   for key,v in pairs(r.level or {}) do if type(v)=='number' and v>0 then row.technology[key]=v end end
   if builder and builder.KnowsRecipe then local ok,result=pcall(builder.KnowsRecipe,builder,r);if ok then row.unlocked=result==true end end
   if builder and builder.CanLearn then local ok,result=pcall(builder.CanLearn,builder,name);if ok then row.can_learn=result==true;row.character_condition_unknown=false end end
   if #out>=4 then break end
  end
 end
 table.sort(out,function(a,b)return a.id<b.id end);return out
end
function M.Entry(inst,prefab,expression)
 local s=state(inst);local e=expression and (s.displays[prefab] or {})[expression] or s.items[prefab]
 local row={prefab=prefab,name=M.DisplayName(inst,prefab),aliases=aliases[prefab],category='unknown',facts={},derived={},unknown={},recipes=M.Recipes(inst,prefab),sources={},capability=M.Capability(inst,prefab)}
 for _,v in pairs(s.observed[prefab] or {}) do if #row.sources<4 then row.sources[#row.sources+1]=v end end
 for _,r in ipairs(row.recipes) do if #row.sources<4 then row.sources[#row.sources+1]={product=prefab,object=r.id,action='craft',supported=r.supported,evidence='recipe_data'} end end
 if e and e:IsValid() then
  local c=e.components
  if c.pickable and id(c.pickable.product) and not c.pickable.use_lootdropper_for_product then row.facts.pick_product=c.pickable.product;row.category='harvestable_object' end
  if c.edible then
   row.category='food';local edible=c.edible;local eater=inst.components.eater
   local base={hunger=edible.hungervalue,health=edible.healthvalue,sanity=edible.sanityvalue}
   if type(base.hunger)=='number' and type(base.health)=='number' and type(base.sanity)=='number' then
    row.facts.food_base=base;row.facts.food_basis='实际食物组件的基础值；不执行食物或角色自定义效果回调'
    if eater and not eater.custom_stats_mod_fn and type(eater.hungerabsorption)=='number' and type(eater.healthabsorption)=='number' and type(eater.sanityabsorption)=='number' then
     row.facts.food_effects={hunger=base.hunger*eater.hungerabsorption,health=base.health*eater.healthabsorption,sanity=base.sanity*eater.sanityabsorption}
    end
   end
   local perishable=c.perishable
   if perishable and type(perishable.perishremainingtime)=='number' and type(perishable.perishtime)=='number' and perishable.perishtime>0 then row.facts.freshness=math.max(0,math.min(1,perishable.perishremainingtime/perishable.perishtime)) end
  end
  if c.tool then
   row.category='tool';row.facts.tool_actions={}
   for _,name in ipairs({'CHOP','MINE','DIG','HAMMER'}) do
    local action=ACTIONS[name]
    if action then
     local value=c.tool.actions and c.tool.actions[action]
     if type(value)=='number' and value>0 then row.facts.tool_actions[#row.facts.tool_actions+1]={action=name,effectiveness=value,supported=name=='CHOP' or name=='MINE'} end
    end
   end
  end
  if c.equippable then row.facts.equipment_slot=c.equippable.equipslot end
  if c.finiteuses and type(c.finiteuses.current)=='number' then row.facts.remaining_uses=c.finiteuses.current end
 end
 if #row.recipes>0 then row.derived.has_recipe=true;if row.category=='unknown' then row.category='recipe_product' end end
 row.static={};local stored=Store.Entry(prefab)
 if stored then
  if Store.Compatible() and stored.category~='unclassified' and stored.category_evidence and stored.category_evidence.certainty=='verified' and (row.category=='unknown' or row.category=='recipe_product') then row.category=stored.category end
  row.static.category=stored.category;row.static.identity=stored.identity;row.static.names=stored.names;row.static.knowledge_complete=stored.knowledge_complete
  for _,facet in ipairs({'properties','uses','sources','mechanisms','behaviors','restrictions','variants','habitats'}) do
   row.static[facet]={};for i,fact in ipairs(Store.Facts(prefab,facet)) do if i<=3 then row.static[facet][#row.static[facet]+1]=fact end end
  end
 end
 if e and e:IsValid() then
  local c=e.components;local readable,display=pcall(e.GetDisplayName or function()return M.Label(prefab)end,e);row.facts.observed_display=readable and display or M.Label(prefab);row.facts.instance=e.GUID;row.facts.skin=e.skinname
  row.facts.has_container=c.container~=nil;row.facts.has_prototyper=c.prototyper~=nil
  if c.prototyper and type(c.prototyper.trees)=='table' then row.facts.facility_technology={};for key,v in pairs(c.prototyper.trees) do if type(v)=='number' and v>0 then row.facts.facility_technology[key]=v end end end
  local fields={weapon={'damage'},armor={'absorb_percent','condition'},health={'maxhealth'},combat={'attackperiod','range'},insulator={'insulation'},waterproofer={'effectiveness'},container={'numslots'}}
  for component,keys in pairs(fields) do if c[component] then
   for _,key in ipairs(keys) do local v=c[component][key];if type(v)=='number' or type(v)=='boolean' then row.facts[component..'_'..key]=v end end
  end end
  if c.health or c.combat then row.category='creature' elseif c.container or c.prototyper or tag(e,'structure') then row.category='facility' end
  for product in pairs(loot(c.lootdropper)) do if #row.sources<4 then row.sources[#row.sources+1]={product=product,object=prefab,action='drop',supported=false,evidence='actual_static_loot_component',availability_unknown=true} end end
 end
row.static_version_compatible=Store.Compatible();row.live_basis='actual_observed_instance';if e and e:IsValid() and (tag(e,'FX') or tag(e,'CLASSIFIED') or tag(e,'NOCLICK')) then row.category='auxiliary_or_effect' end
 if not (e and e:IsValid()) then row.unknown[#row.unknown+1]='未观察对象的实时属性' end
 if not (stored and stored.knowledge_complete and Store.Compatible()) then row.unknown[#row.unknown+1]='完整百科覆盖尚未核验' end
 row.provenance={};for field in pairs(row.facts) do row.provenance[field]={kind='actual_component_field',version=APP_VERSION or 'unreported_current_runtime',certainty='observed',prefab=prefab,instance=e and e.GUID or nil} end
 row.facts.evidence='observed_component_or_recipe';row.derived.evidence='bounded_rule'
 return row
end
function M.CandidateText(candidates)
 local labels={};local seen={}
 for _,p in ipairs(candidates or {}) do local n=require('ybf_knowledge_semantic').Label(p,M);if not seen[n] and n~='该对象' then seen[n]=true;labels[#labels+1]=n end;if #labels>=4 then break end end
 return #labels>0 and table.concat(labels,'、') or '请提供完整中文名称'
end
local reasons={reference_ambiguous='你指的是哪一个？请告诉我名字。',
 name_ambiguous='这个名字对应多个对象，请说明是哪一种',
 name_typo_confirmation='这个名称可能有错字，请确认具体对象',
 qualified_name_unresolved='这个名称带有我尚未核实的限定词或状态，我不能把它当作普通版本。请提供完整显示名称或说明状态。',
 name_expression_mismatch='我核对到的对象与原句不一致，请确认你说的完整名称。',
 variant_execution_unsupported='我识别到了显示名称或变体，但还不能保证对该状态或皮肤执行任务，请明确普通对象或先核实变体。',
 identity_version_unconfirmed='该身份来自其他版本资料，当前游戏没有确认，不能执行。',
 name_unknown='我还没有可靠识别出这个对象，请告诉我更明确的名字。'}
function M.FailureText(reason,candidates)
 local result=reasons[reason] or reasons.name_unknown
 if reason=='name_ambiguous' or reason=='name_typo_confirmation' or reason=='reference_ambiguous' then result=result..'（'..M.CandidateText(candidates or {})..'）。' end
 return result
end
local function bounded(answer,limit)
 if #answer<=limit then return answer end
 while limit>0 and answer:byte(limit+1)>=128 and answer:byte(limit+1)<192 do limit=limit-1 end
 return answer:sub(1,limit)..'…'
end
function M.Retrieve(inst,prefab,kind)
 local facets={identity={'uses','behaviors','mechanisms','properties'},properties={'properties','mechanisms'},uses={'uses','mechanisms','restrictions'},recipe={'recipes'},sources={'sources','habitats'},habitats={'habitats','sources'},mechanisms={'mechanisms','behaviors','restrictions'},difference={'properties','uses','recipes','variants','mechanisms','restrictions'}}
 local result={known_fact_count=0,prefab=prefab,build=Store.Manifest().build,version_compatible=Store.Compatible(),facts={},unknown={}}
 for _,f in ipairs({'properties','uses','sources','recipes','mechanisms','behaviors','restrictions','variants','habitats'}) do result.known_fact_count=result.known_fact_count+#Store.Facts(prefab,f) end
 for _,facet in ipairs(facets[kind] or facets.properties) do
  local facts,conflicts=Store.Facts(prefab,facet)
  for _,key in ipairs(conflicts or {}) do result.unknown[#result.unknown+1]='conflicting:'..key end
  if #facts==0 then result.unknown[#result.unknown+1]=facet end
  for i=1,math.min(3,#facts) do result.facts[#result.facts+1]=facts[i] end
 end
 return result
end
function M.QuestionKind(message)
 local groups={{'difference','有什么区别','的区别','有什么不同','有啥区别','哪个更耐用','哪个更耐久','比较','对比'},
  {'habitats','在哪里','在哪','通常出现','栖息'},
  {'recipe','怎么烹饪','如何烹饪','怎么制作','如何制作','怎么做','怎么做的','制作配方','需要什么材料','需要什么科技'},
  {'sources','怎么获得','如何获得','怎么获取','从哪获得'},
  {'uses','能用来制作什么','能拿来制作什么','能做成什么','有什么用','有啥用','啥用途','怎么用','能做什么','能干什么','怎么使用','如何使用'},
  {'mechanisms','有什么机制','什么机制','怎么交互','怎么攻击'},
  {'properties','有什么效果','的属性','多少伤害','多少防御'},
  {'identity','是什么','是怎样','什么样','长什么','知道','认识','介绍','讲讲','说说','是牛吗'}}
 for _,group in ipairs(groups) do for i=2,#group do if (message or ''):find(group[i],1,true) then return group[1] end end end
 return nil
end
function M.PendingChoice(inst,message,pending)
 if not pending then return nil end
 local candidates=pending.candidates or {}
 local ordinals={['第一个']=1,['第二个']=2,['第三个']=3,['第四个']=4,['1']=1,['2']=2,['3']=3,['4']=4}
 local clean=message:gsub('[%s%p]','');for _,punct in ipairs({'。','！','，','？'}) do clean=clean:gsub(punct,'') end
 if ordinals[clean] then return candidates[ordinals[clean]] end
 if Names.IsConfirmation(message) and #candidates==1 then return candidates[1] end
 local fragment=clean:gsub('那个',''):gsub('这个',''):gsub('就要',''):gsub('的','')
 if #fragment>=6 then
  local chosen
  for _,p in ipairs(candidates) do if M.Label(p):find(fragment,1,true) then if chosen then return nil end;chosen=p end end
  return chosen
 end
end
function M.ConceptAnswer(message)
 if not Store.Compatible() then return nil end
 local data=require('ybf_knowledge_concepts')
 for _,entry in ipairs(data.entries or {}) do
  if #message<=120 and message:find(entry.name,1,true) then return entry.answer,entry.source end
 end
end
function M.QuestionName(message)return Names.QuestionName(message)end
function M.GenericTreeRequest(inst,message)
 return #M.Expressions(inst,message)==0 and Names.GenericTree(message)
end
local function technology_text(values)
 local labels={SCIENCE='科学',MAGIC='魔法',ANCIENT='远古',SEAFARING='航海',CELESTIAL='天体',MOON_ALTAR='月亮祭坛',SHADOW='暗影'};local out={}
 for key,value in pairs(values or {}) do out[#out+1]=(labels[key] or key)..value..'级' end;table.sort(out);return table.concat(out,'、')
end
local Presentation=require('ybf_knowledge_presentation')
local function oneanswer(inst,prefab,kind,message,expression)
 local reply=Presentation.Answer(inst,prefab,kind,message,M)
 M.Diagnostic(inst,{original=message,prefab=prefab,kind=kind,retrieval=M.Retrieve(inst,prefab,kind),final_answer=reply})
 return reply
end
function M.OneAnswer(inst,prefab,kind,message)return oneanswer(inst,prefab,kind,message) end
function M.Answer(inst,query,kind,message)
 local prefab,reason,candidates=M.Resolve(inst,query,message)
 M.Diagnostic(inst,{original=message,model_query=query,candidates=candidates,expressions=M.Expressions(inst,message),prefab=prefab,reason=reason})
 if not prefab then return M.FailureText(reason,candidates) end
 return oneanswer(inst,prefab,kind,message,query)
end
function M.AnswerMany(inst,queries,kind,message)
 local targets={};local seen={};local identities={}
 for _,q in ipairs(queries) do
  local prefab,reason,candidates=M.Resolve(inst,q,message)
  M.Diagnostic(inst,{original=message,model_query=q,candidates=candidates,expressions=M.Expressions(inst,message),prefab=prefab,reason=reason})
  if not prefab then return M.FailureText(reason,candidates) end
  local key=prefab..':'..q
  if not seen[key] then seen[key]=true;targets[#targets+1]={prefab=prefab,expression=q} end
 end
 -- Preserve other explicitly named objects even if the model returned one.
 for _,hit in ipairs(M.Expressions(inst,message)) do
  local prefab,reason,candidates=M.Resolve(inst,hit.text,message)
  if not prefab then return M.FailureText(reason,candidates) end
  local found=false
  for _,target in ipairs(targets) do if target.prefab==prefab and (target.expression==hit.text or target.expression==prefab) then found=true end end
  if not found then targets[#targets+1]={prefab=prefab,expression=hit.text} end
 end
 if #targets>4 then return '你提到了多种对象，请分成每次不超过四种，我会逐一核对。' end
 if kind=='difference' then return Presentation.Compare(inst,targets,message,M) end
 local answers={}
 for _,target in ipairs(targets) do
  if #targets>1 then answers[#answers+1]=M.Label(target.prefab)..'：'..Presentation.Answer(inst,target.prefab,kind,message,M,math.floor(460/#targets))
  else answers[#answers+1]=oneanswer(inst,target.prefab,kind,message,target.expression) end
 end
 return table.concat(answers,'\n')
end
-- Small relevant packet: <=8 item entries, <=12 local sources, never entire catalog.
function M.Context(inst,message,entities)
 M.ObserveInventory(inst);M.Observe(inst,entities)
 local names=M.Mentions(inst,message or '');local selected={};local seen={}
 local kind=M.QuestionKind(message)
 if kind and Names.HasPronoun(message) and #names==0 then names=inst._ybf_query_context and inst._ybf_query_context.topics or {} end
 local function add(name)if id(name) and not seen[name] and #selected<8 then
  seen[name]=true;local entry=M.Entry(inst,name)
  if kind then
   entry.relevant=M.Retrieve(inst,name,kind)
   -- Retain identity but remove unrelated encyclopedia facets from requests.
   entry.static.properties=nil;entry.static.uses=nil;entry.static.sources=nil;entry.static.mechanisms=nil
   entry.static.behaviors=nil;entry.static.restrictions=nil;entry.static.variants=nil;entry.static.habitats=nil
   if kind~='recipe' then entry.recipes={} end
  end
  selected[#selected+1]=entry
 end end
 for _,name in ipairs(names) do add(name) end
 local j=inst.components.ybf_work and inst.components.ybf_work.core.job
 for _,target in ipairs(j and j.targets or {}) do add(target.item) end
 local sources={}
 for _,e in ipairs(entities) do
  for _,v in ipairs(M.Perceived(inst,e) and M.Sources(inst,e) or {}) do
   if #sources<12 and (#names==0 or seen[v.product] or seen[v.object]) then
    local x,_,z=e.Transform:GetWorldPosition();v.position={x=x,z=z};v.position_basis='当前朋友实际感知';sources[#sources+1]=v;add(v.product)
   end
  end
 end
 local ambiguous={}
 for i=1,math.min(8,#names) do ambiguous[#ambiguous+1]=names[i] end
 local all_expressions=M.Expressions(inst,message);local expressions={};local valid={};local issue_count=0
 for index,hit in ipairs(all_expressions) do
  local unique={};local n=0;for _,v in ipairs(hit.candidates) do if not unique[v.prefab] then unique[v.prefab]=true;n=n+1 end end
  if n>1 or hit.unresolved_prefix or hit.unresolved_suffix then
   issue_count=issue_count+1
   if #valid<8 then valid[#valid+1]={text=hit.text,unresolved_prefix=hit.unresolved_prefix and bounded(hit.unresolved_prefix,120),unresolved_suffix=hit.unresolved_suffix and bounded(hit.unresolved_suffix,120),candidate_count=n} end
  end
  if index<=8 then
   local candidates={};for i=1,math.min(8,#hit.candidates) do candidates[#candidates+1]=hit.candidates[i] end
   expressions[#expressions+1]={start=hit.start,finish=hit.finish,text=hit.text,candidates=candidates,candidate_count=n,candidates_truncated=#hit.candidates>8}
  end
 end
 return {semantic=require('ybf_knowledge_semantic').Context(inst,message,M),entries=selected,nearby_sources=sources,name_expressions=expressions,name_issues=valid,static_manifest={build=Store.Manifest().build,status=Store.Manifest().status,version_compatible=Store.Compatible()},name_context_truncated=#all_expressions>8,expression_count=#all_expressions,ambiguous_names=issue_count>0 and ambiguous or nil,ambiguous_count=issue_count>0 and issue_count or nil,limits={items=8,sources=12,recipes_per_item=4},unknown_policy='未知不是确定事实；位置不来自名称或配方表'}
end
return M
