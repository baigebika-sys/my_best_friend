-- A local, non-interactive six-second marker, never a building or placer test.
local assets={Asset('ANIM','anim/gridplacer.zip')}
local function fn()
 local inst=CreateEntity();inst.entity:AddTransform();inst.entity:AddAnimState()
 inst:AddTag('CLASSIFIED');inst:AddTag('NOCLICK');inst:AddTag('FX');inst:AddTag('NOBLOCK');inst.persists=false
 inst.AnimState:SetBank('gridplacer');inst.AnimState:SetBuild('gridplacer');inst.AnimState:PlayAnimation('anim',true)
 inst.AnimState:SetLightOverride(1);inst.AnimState:SetOrientation(ANIM_ORIENTATION.OnGround);inst.AnimState:SetLayer(LAYER_BACKGROUND)
 return inst
end
return Prefab('ybf_build_marker',fn,assets)
