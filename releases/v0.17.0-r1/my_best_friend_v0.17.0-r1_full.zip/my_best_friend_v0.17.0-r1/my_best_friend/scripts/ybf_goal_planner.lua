-- Bounded dependency resolver. It produces one next action from actual world
-- state, never a fixed script for a particular finished product.
local Inventory=require('ybf_work_inventory')
local Resources=require('ybf_work_resources')
local Crafting=require('ybf_work_crafting')
local Warehouse=require('ybf_warehouse')
local Building=require('ybf_building')
local M={MAX_DEPTH=12,MAX_NODES=256,MAX_ACTIONS=4000,MAX_RESUMES=12}
function M.New(inst,work)
 local self={}
 function self:Refresh(j)
  local total=0
  for _,target in ipairs(j.targets) do
   local b=j.builds and j.builds[target.item]
   total=total+(b and math.min(target.quantity,#b.placed) or ((target.destination or j.destination or (j.deliver and 'player' or 'friend'))~='friend' and math.min(target.quantity,j.given[target.item] or 0) or math.min(target.quantity,(target.mode or j.intentmode)=='craft' and (j.crafted[target.item] or 0) or Inventory.Count(inst,target.item,true))))
  end
  j.count=total
  if j.blocked then
   for _,node in ipairs(j.trace or {}) do node.have=Inventory.Count(inst,node.item,true);node.missing=math.max(0,node.required-node.have) end
  end
 end
 function self:Trace(j,item,required)
  local have=Inventory.Count(inst,item,true)
  local node={item=item,required=required,have=have,missing=math.max(0,required-have)}
  j.trace[#j.trace+1]=node
  return node
 end
 function self:Station(j,recipe)
  local builder=inst.components.builder
  j.phase='检查'..Inventory.Label(recipe.product)..'的解锁与科技条件'
  builder:EvaluateTechTrees()
  if builder:KnowsRecipe(recipe) or CanPrototypeRecipe(recipe.level,builder.accessible_tech_trees) then return true end
  if j.forbidden and j.forbidden.tech then return nil,'配方还没解锁，而你要求不去科技站。','restricted_action' end
  if not builder:CanLearn(recipe.name) then return nil,'角色条件不允许解锁'..Inventory.Label(recipe.product),'recipe_condition' end
  local x,y,z=inst.Transform:GetWorldPosition()
  local found=TheSim:FindEntities(x,y,z,work.radius,nil,{'INLIMBO'})
  table.sort(found,function(a,b)return inst:GetDistanceSqToInst(a)<inst:GetDistanceSqToInst(b) end)
  for _,entity in ipairs(found) do
   local proto=entity.components.prototyper
   if proto and (not proto.restrictedtag or inst:HasTag(proto.restrictedtag))
    and Resources.InRange(inst,entity,j.center,work.radius)
    and CanPrototypeRecipe(recipe.level,proto.trees) and (j.failed[entity] or 0)<2 then
    j.step='tech';j.techrecipe=recipe.name;j.recipe=recipe.name;j.collectitem=nil;j.invobject=nil
    j.phase='靠近可解锁'..Inventory.Label(recipe.product)..'的科技站'
    return entity
   end
  end
  return nil,'尚未解锁'..Inventory.Label(recipe.product)..'；'..work.radius..'单位范围内没有满足实际配方科技要求的可达科技站','missing_technology'
 end
 local ensure
 ensure=function(j,item,required,path,depth)
  j.visits=j.visits+1
  if depth>M.MAX_DEPTH or j.visits>M.MAX_NODES then return nil,'依赖拆解超过深度或节点上限','dependency_limit' end
  if j.source=='warehouse_only' and not (path.root==item and j.planningmode=='craft') then
   local allowed=math.min(Inventory.Count(inst,item,true),j.sourced[item] or 0)
   required=required+math.max(0,Inventory.Count(inst,item,true)-allowed)
  end
  local missing=required-Inventory.Count(inst,item,true)
  if j.source=='warehouse_first' then missing=math.max(missing,required-(j.sourced[item] or 0)) end
  if missing>0 and j.source~='inventory_only' and not (path.root==item and j.planningmode=='craft') then
   local chest=Warehouse.WithdrawTarget(inst,work,j,item,missing)
   if chest then j.phase='从友谊容器取出'..Inventory.Label(item);return chest end
  end
  if Inventory.Count(inst,item,true)>=required then return true end
  self:Trace(j,item,required)
  j.phase='补齐'..Inventory.Label(item)..'：缺'..math.max(0,required-Inventory.Count(inst,item,true))
  if j.source~='warehouse_only' and j.source~='inventory_only' and not (j.forbidden and j.forbidden.pickup) and not (j.planningmode=='craft' and path.root==item) and not j.existing_only and not (j.forbidden and j.forbidden.pickup) then
   local x,y,z=inst.Transform:GetWorldPosition()
   local loose=TheSim:FindEntities(x,y,z,work.radius,nil,{'INLIMBO'})
   table.sort(loose,function(a,b)return inst:GetDistanceSqToInst(a)<inst:GetDistanceSqToInst(b) end)
   for _,entity in ipairs(loose) do
    local invitem=entity.components.inventoryitem
    if entity.prefab==item and invitem and not invitem.owner and invitem.canbepickedup
      and Resources.InRange(inst,entity,j.center,work.radius) and (j.failed[entity] or 0)<2
      and inst.components.inventory:CanAcceptCount(entity)>=Inventory.Size(entity) then
     j.step='pickup';j.collectitem=item;j.invobject=nil;j.recipe=nil
     j.phase='优先拾取现成'..Inventory.Label(item)
     return entity
    end
   end
  end
  if path[item] then return nil,'检测到循环依赖：获取'..Inventory.Label(item)..'又需要其自身前置条件；需先有可拾取材料或可用工具','dependency_cycle' end
  local nextpath={};for key,value in pairs(path) do nextpath[key]=value end;nextpath[item]=true
  if Resources.CanAcquire(inst,item) and (not Crafting.allowed[item] or #Resources.Scan(inst,j.center,work.radius,item,'collect')>0) and not (j.source=='warehouse_only' or j.source=='inventory_only' or j.existing_only) then
   if j.existing_only or j.source=='warehouse_only' then return nil,'只能用约定范围内的材料；还缺'..(required-Inventory.Count(inst,item,true))..'个'..Inventory.Label(item),'missing_materials' end
   local state=j.resource_states[item]
   if not state then state={kind='collect',item=item,label=Inventory.Label(item),center=j.center,failed=j.failed};j.resource_states[item]=state end
   state.failed=j.failed;state.goal=required;state.forbidden=j.forbidden
   state.awaitloot_until=j.lootitem==item and j.awaitloot_until or nil
   local candidates=Resources.Scan(inst,j.center,work.radius,item,'collect')
   local first
   local permitted=false;for _,candidate in ipairs(candidates) do if not (j.forbidden and j.forbidden[candidate.step]) then permitted=true end end
   if #candidates>0 and not permitted then return nil,'附近有目标，但可用获取动作都被你这次的限制禁止了。','restricted_action' end
   local waiting=state.awaitloot_until and GetTime()<state.awaitloot_until
   for _,candidate in ipairs(candidates) do
    if not (j.forbidden and j.forbidden[candidate.step]) and (j.failed[candidate.target] or 0)<2 and (not waiting or candidate.step=='pickup') then
     local room=candidate.step=='pickup' and inst.components.inventory:CanAcceptCount(candidate.target)>=Inventory.Size(candidate.target)
       or candidate.step~='pickup' and Inventory.Room(inst,item,candidate.step=='pick' and (candidate.target.components.pickable.numtoharvest or 1) or 1)
     if room then first=candidate;break end
    end
   end
   if first and (first.step=='mine' or first.step=='chop') then
    local action=first.step=='mine' and ACTIONS.MINE or ACTIONS.CHOP
    local tool,why=work:Tool(action)
    if why then return nil,why,'tool_condition' end
    if not tool then
     local name=first.step=='mine' and 'pickaxe' or 'axe'
     if (j.toolbuilds or 0)>=math.min(64,8+#j.targets*4) then return nil,'本任务工具更换次数达到上限','tool_limit' end
     j.phase='准备'..Inventory.Label(name)..'以获取'..Inventory.Label(item)
     -- Existing unusable tools must not satisfy the missing usable-tool goal.
     local result,reason,code=ensure(j,name,Inventory.Count(inst,name,true)+1,nextpath,depth+1)
     if result~=true then
      if j.step=='craft' and j.recipe==name then j.autotool=true end
      return result,reason,code
     end
     return nil,'工具准备后仍不可使用，停止重复制作','tool_condition'
    end
   end
   local entity,reason,code=work:FindStep(state)
   if not entity then return nil,reason,code end
   for _,key in ipairs({'step','invobject','recipe','preferred','autotool'}) do j[key]=state[key] end
   j.collectitem=item;j.giveitem=nil
   j.phase='获取'..Inventory.Label(item)..'：已有'..Inventory.Count(inst,item,true)..'，目标'..required
   return entity
  end
  if j.source=='warehouse_only' or j.existing_only then
   if not Crafting.allowed[item] then return nil,'约定库存不足以取得'..Inventory.Label(item),'missing_materials' end
  end
  if j.forbidden and j.forbidden.craft then return nil,'你要求不制作，但我手里的成品还不够。','restricted_action' end
  local info,reason,code=Crafting.PlanRecipe(inst,item)
  if not info then return nil,reason,code end
  local batches=math.ceil((required-Inventory.Count(inst,item,true))/info.output)
  -- Re-read after every action. A sub-tool can consume a parent ingredient;
  -- restart this loop on the next tick and replenish the actual missing amount.
  for _,ingredient in ipairs(info.ingredients) do
   local reserve=ingredient.item~=j.currentitem and (j.protected[ingredient.item] or 0) or 0
   local needed=ingredient.amount*batches+reserve
   if Inventory.Count(inst,ingredient.item)<needed then
    j.phase='准备'..Inventory.Label(item)..'材料：'..Inventory.Label(ingredient.item)
    local result,why,blocked=ensure(j,ingredient.item,needed,nextpath,depth+1)
    if result~=true then return result,why,blocked end
   end
  end
  local station,why,blocked=self:Station(j,info.recipe)
  if station~=true then return station,why,blocked end
  local ready,failure=Crafting.Check(inst,item)
  if not ready then return nil,failure,'craft_condition' end
  j.step='craft';j.recipe=info.recipe.name;j.collectitem=nil;j.giveitem=nil;j.invobject=nil;j.autotool=false
  j.phase='按实际配方制作'..Inventory.Label(info.recipe.product)
  return inst
 end
 function self:Ensure(...)return ensure(...)end
 function self:Resolve(j)
  Resources.Observe(inst,j.center,work.radius)
  Building.Sync(work,j);self:Refresh(j);j.material_plan=require('ybf_material_plan').Build(inst,work,j);j.trace={};j.visits=0;j.collectitem=nil;j.giveitem=nil;j.autotool=false
  j.protected={};j.target_blocks=j.target_blocks or {}
  for _,t in ipairs(j.targets) do j.protected[t.item]=math.max(0,t.quantity-(j.given[t.item] or 0)) end
  if (j.actions or 0)>=M.MAX_ACTIONS then return nil,'任务动作预算已用完，保留物资','action_limit' end
  local blockers={};local ordered={};for i,t in ipairs(j.targets) do ordered[#ordered+1]={target=t,index=i} end
  local function tool(t)
   local e=work:GiftItem(t.item);if e and e.components.tool then return true end
   local store=require('ybf_knowledge_store');local row=store.Compatible() and store.Identity(t.item)
   return row and row.category=='tool' or false
  end
  table.sort(ordered,function(a,b)local at,bt=tool(a.target),tool(b.target);if at~=bt then return not at end;return a.index<b.index end)
  for _,entry in ipairs(ordered) do local target=entry.target
   j.currentitem=target.item
   if j.builds and j.builds[target.item] then
    local result,reason,code=Building.Next(work,j,target,self)
    if result and result~=true then return result end
    if not result then Building.Release(j,j.builds[target.item]);j.target_blocks[target.item]={reason=reason,code=code};blockers[#blockers+1]=Inventory.Label(target.item)..'：'..tostring(reason) else j.target_blocks[target.item]=nil end
   else
   local mode=target.mode or j.intentmode or 'obtain';j.planningmode=mode
   local done=j.given[target.item] or 0
   local remaining=math.max(0,target.quantity-done)
   if mode=='craft' then remaining=math.max(0,target.quantity-(j.crafted[target.item] or 0)) end
   local held=Inventory.Count(inst,target.item,true)
   if mode=='craft' and remaining==0 then remaining=math.max(0,target.quantity-(j.given[target.item] or 0)-held) end
   local required=mode=='craft' and (remaining>0 and held+remaining or 0) or remaining
   local result,reason,code=true,nil,nil
   if required>0 then result,reason,code=ensure(j,target.item,required,{root=target.item},1) end
   if result and result~=true then return result end
   if result==true then
    j.target_blocks[target.item]=nil
    local remain=target.quantity-(j.given[target.item] or 0)
    local destination=target.destination or j.destination or (j.deliver and 'player' or 'friend')
    if remain>0 and destination~='friend' then
     local gift=work:GiftItem(target.item)
     if gift then
      j.giveitem=target.item;j.givegoal=remain;j.invobject=gift;j.collectitem=nil
      if destination=='auto' or destination=='warehouse' then
       local chest=Warehouse.DepositTargets(inst,work,j,gift)
       if chest then j.step='deposit';j.phase='存入友谊容器';return chest end
       if destination=='warehouse' then result=nil;reason='友谊容器已满、不能接收或不可到达';code='destination_unavailable' end
      end
      if result and destination~='ground' then
       local ok=work:CanGive(j,gift)
       if ok and (j.failed[j.owner] or 0)<2 and work:OwnerValid(j.owner) then j.step='give';j.phase='交给玩家';return j.owner end
       if destination=='player' then result=nil;reason='玩家现在不能接收，已保留成品';code='recipient_unavailable' end
      end
      if result and (destination=='auto' or destination=='ground') then
       j.step='drop';j.phase='在附近安全位置放下';return inst
      end
     elseif remain>0 then result=nil;reason='成品库存发生变化';code='inventory_changed' end
    end
   end
   if not result then j.target_blocks[target.item]={reason=reason,code=code};blockers[#blockers+1]=Inventory.Label(target.item)..'：'..tostring(reason) end
   end
  end
  if #blockers>0 then local b=j.target_blocks[j.targets[1].item];return nil,table.concat(blockers,'；'),#j.targets==1 and b and b.code or 'partial_blocked' end
  return nil,'目标已完成','complete'
 end
 function self:Gift(j,item,count)
  j.given[item]=(j.given[item] or 0)+count;j.sourced[item]=math.max(0,(j.sourced[item] or 0)-count);self:Refresh(j)
 end
 function self:Feedback(j,reason)
  if j.builds and next(j.builds) then
   local blocks={};for _,t in ipairs(j.targets)do local b=j.target_blocks and j.target_blocks[t.item];if b then blocks[#blocks+1]=Inventory.Label(t.item)..'：'..b.reason end end
   local items={};for _,t in ipairs(j.targets)do if not j.builds[t.item] then local held=(t.destination or j.destination)=='friend';items[#items+1]=Inventory.Label(t.item)..(held and '由我保管' or '已交付')..(held and Inventory.Count(inst,t.item,true) or j.given[t.item] or 0)..'/'..t.quantity end end
   return tostring(reason)..'。'..Building.Feedback(j)..(#items>0 and '；'..table.concat(items,'；') or '')..(#blocks>0 and '。尚未完成：'..table.concat(blocks,'；') or '')
  end
  if j.destination=='auto' or j.destination=='warehouse' or j.destination=='ground' or j.stored or j.ground then
   local parts={};local blocked={}
   for _,t in ipairs(j.targets) do
    local stored=j.stored and j.stored[t.item] or 0;local dropped=j.ground and j.ground[t.item] or 0;local given=math.max(0,(j.given[t.item] or 0)-stored-dropped)
    local name=Inventory.Label(t.item)
    if stored>0 then parts[#parts+1]='已存入'..stored..'个'..name end
    if given>0 then parts[#parts+1]='已给你'..given..'个'..name end
    if dropped>0 then parts[#parts+1]='已在附近放下'..dropped..'个'..name end
    local b=j.target_blocks and j.target_blocks[t.item];if b then blocked[#blocked+1]=name..'：'..b.reason end
   end
   local text=reason=='目标已完成' or reason=='已达到目标数量' and '目标已完成' or tostring(reason)
   text=tostring(reason)..'。'..table.concat(parts,'；')..(#parts>0 and '。' or '')
   if j.last_drop then text=text..'放置位置在附近（'..math.floor(j.last_drop.x)..'，'..math.floor(j.last_drop.z)..'）。' end
   local held={};for _,t in ipairs(j.targets) do local n=Inventory.Count(inst,t.item,true);if n>0 then held[#held+1]=n..'个'..Inventory.Label(t.item) end end
   if #held>0 then text=text..'我还保留着'..table.concat(held,'、')..'。' end
   if #blocked>0 then text=text..'尚受阻：'..table.concat(blocked,'；')..'。' end
   return text
  end
  local delivered,held,missing={},{},{}
  for _,target in ipairs(j.targets) do
   local given=j.given[target.item] or 0
   local have=Inventory.Count(inst,target.item,true)
   if given>0 then delivered[#delivered+1]=given..'个'..Inventory.Label(target.item) end
   if have>0 then held[#held+1]=have..'个'..Inventory.Label(target.item) end
   local need=math.max(0,target.quantity-(j.intentmode=='craft' and (j.crafted[target.item] or 0) or given+have))
   if need>0 then missing[#missing+1]=need..'个'..Inventory.Label(target.item) end
  end
  if reason=='目标已完成' or reason=='已达到目标数量' then
   if j.intentmode=='craft' and not j.deliver then
    local made={};for _,target in ipairs(j.targets) do made[#made+1]=(j.crafted[target.item] or 0)..'个'..Inventory.Label(target.item) end
    return '做好了'..table.concat(made,'和')..'，我先保管着。'
   end
   return j.deliver and ('给你了'..table.concat(delivered,'和')..'。') or ('收集好了'..table.concat(held,'和')..'，我先保管着。')
  end
  local text=reason=='任务已停止' and '好，我停下了。' or tostring(reason)..'。'
  if #delivered>0 then text=text..'已给你'..table.concat(delivered,'和')..'。' end
  local stock={};local names={}
  for _,entity in ipairs(Inventory.Items(inst,true)) do stock[entity.prefab]=(stock[entity.prefab] or 0)+Inventory.Size(entity) end
  for name in pairs(stock) do names[#names+1]=name end;table.sort(names)
  local owned={};for index=1,math.min(8,#names) do local name=names[index];owned[#owned+1]=stock[name]..'个'..Inventory.Label(name) end
  if #owned>0 then text=text..'我还保留着'..table.concat(owned,'、')..'。' end
  if #missing>0 then text=text..(j.intentmode=='craft' and '还需要制作' or '还没备齐')..table.concat(missing,'和')..'。' end
  -- The leaf shortage is useful to the player; internal graph/phase stays in Status.
  local leaf=j.trace and j.trace[#j.trace]
  if j.blocked and leaf and leaf.missing>0 and not (j.targets[1] and leaf.item==j.targets[1].item) then
   text=text..'现在还缺'..leaf.missing..'个'..Inventory.Label(leaf.item)..'。'
  end
  return text
 end
 function self:Summary(j,reason)
  local owned={};local names={}
  for _,entity in ipairs(Inventory.Items(inst,true)) do owned[entity.prefab]=(owned[entity.prefab] or 0)+Inventory.Size(entity) end
  for name in pairs(owned) do names[#names+1]=name end;table.sort(names)
  local held={};for i=1,math.min(16,#names) do held[#held+1]=Inventory.Label(names[i])..'×'..owned[names[i]] end
  local targets={};local missing={};local delivered={}
  for _,target in ipairs(j.targets) do
   local given=j.given[target.item] or 0
   targets[#targets+1]=Inventory.Label(target.item)..'×'..target.quantity
   local need=math.max(0,target.quantity-given-Inventory.Count(inst,target.item,true))
   if need>0 then missing[#missing+1]=Inventory.Label(target.item)..'×'..need end
   if given>0 then delivered[#delivered+1]=Inventory.Label(target.item)..'×'..given end
  end
  local trace={};for _,node in ipairs(j.trace or {}) do if node.missing>0 then trace[#trace+1]=Inventory.Label(node.item)..'×'..node.missing end end
  return '目标：'..table.concat(targets,'、')..'；当前持有：'..(#held>0 and table.concat(held,'、') or '无')
   ..'；已交付：'..(#delivered>0 and table.concat(delivered,'、') or '无')
   ..'；成品/目标缺口：'..(#missing>0 and table.concat(missing,'、') or '已备齐')
   ..'；当前阶段：'..tostring(j.phase or '检查库存')..'；当前前置缺口：'..(#trace>0 and table.concat(trace,'→') or '无')..'；'..tostring(reason)
 end
 return self
end
return M
