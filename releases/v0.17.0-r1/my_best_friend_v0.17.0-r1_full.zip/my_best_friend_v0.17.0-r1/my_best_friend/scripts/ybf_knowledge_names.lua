-- Span-based identity matching. Longest wins only within an overlapping span.
local M={}
local function chars(s)
 local out={};for c in s:gmatch('[%z\1-\127\194-\244][\128-\191]*') do out[#out+1]=c end;return out
end
local fillers={'麻烦','劳驾','您','方便的话','可以的话','顺便','稍微','好','行','你','我','想','点儿','点','些','一下','呗','吧','呀','啊','呢','嘛','哦','啦','喔','what is','tell me about','give me','collect','and','please','拿起','装备','吃','把','明确','指定','用现有材料','只','要','你能','你会','能给我','请你帮我','能不能帮我','能帮我','帮我','请问','你知道','你认识','我想知道','我想要','我要','给我','帮忙','告诉我','说说','解释一下','介绍一下','查询一下','查询','了解','分别','还有','以及','和','与','是','能','可以','请','采集','采','收集','制作','准备','弄','捡','检','拿','找','给','做','砍','棵','颗','个','块','把','份','根','种','下子','下','朵','套','件','条','袋','组','株','一些','一点','一个','两个','一','二','两','三','四','五','六','七','八','九','十','这','那','它','的'}
table.sort(fillers,function(a,b)return #a>#b end)
local function prefix(s)
 s=s:lower():gsub('^%s+',''):gsub('%s+$','')
 local changed=true
 while changed and #s>0 do
  changed=false
  local n=s:match('^%d+');if n then s=s:sub(#n+1);changed=true end
  for _,word in ipairs(fillers) do if s:sub(1,#word)==word then s=s:sub(#word+1);changed=true;break end end
  s=s:gsub('^%s+','')
 end
 return s
end
local function boundary(message,a,b,name)
 if not name:match('^[%w_]+$') then return true end
 return not (a>1 and message:sub(a-1,a-1):match('[%w_]')) and not message:sub(b+1,b+1):match('[%w_]')
end
-- Grammar is analysed separately from identity. Remove a request frame up
-- to its last verb, then preserve the remaining noun modifier. A predicate
-- after a noun is sentence grammar; a bare attached adjective is not.
local function grammar_prefix(s)
 s=s:gsub('^%s+',''):gsub('%s+$','')
 local last=0
 for _,verb in ipairs({'请介绍','介绍','说说','讲讲','告诉','知道','认识','了解','比较','对比','帮','给','采集','收集','制作','准备','弄','拿','找','采','做','捡','砍','装备','吃','建造','搭建','建','造','搭'}) do
  local from=1
  while true do local a,b=s:find(verb,from,true);if not a then break end
   -- A verb is a frame only if everything before it is grammar, not a
   -- modifier: 神秘的斧头 remains a protected noun phrase.
   local lead=s:sub(1,a-1)
   local grammatical=prefix(lead):gsub('你',''):gsub('我',''):gsub('想',''):gsub('能',''):gsub('不','')==''
   for _,location in ipairs({'在我这','在我这里','在我这儿','在我脚下','在我的位置','在我站的位置','在附近','在指定位置','在我指定的位置','我脚下'})do if lead==location then grammatical=true end end
   for _,opening in ipairs({'请','你','您','我','麻烦','劳驾'}) do if lead:sub(1,#opening)==opening then grammatical=true end end
   for _,protected in ipairs({'黄金','烧灼','灼烧','损坏','暗影','升级'}) do if lead:find(protected,1,true) then grammatical=false end end
   if grammatical then last=math.max(last,b) end
   from=b+1
  end
 end
 if last>0 then s=s:sub(last+1) end
 s=prefix(s):gsub('^我',''):gsub('^点',''):gsub('^些',''):gsub('^点儿','')
 return s
end
local function grammar_suffix(s)
 s=s:gsub('^%s+',''):gsub('%s+$','')
 for _,modifier in ipairs({'黄金','烧灼','灼烧','损坏','升级版','暗影'}) do
  if s:sub(1,#('是'..modifier))=='是'..modifier or s:sub(1,#('要'..modifier))=='要'..modifier then return s end
 end
 -- Questions and predicates are not part of an object's name. Parenthesis
 -- and direct suffixes still require explicit variant/name evidence.
 for _,lead in ipairs({'不是','是不是','算不算','算是','都是什么','分别是什么','各是什么','怎么','如何','是什么','是','有什么','有啥','有哪些','有何','能否','能不能','能做','能干','用来','在哪','在哪里','从哪','与','和','以及','哪个','哪种','谁','是否','属于','看起来','长什么','什么样','的材料','的属性','的用途','的区别','的效果','给我','留在','交给','拿给','带给'}) do
  if s:sub(1,#lead)==lead then return '' end
 end
 s=prefix(s)
 for _,tone in ipairs({'呗','吧','呀','啊','呢','吗','嘛','哦','啦','喔'}) do s=s:gsub('^'..tone,'') end
 return s
end
function M.Scan(message,index)
 if type(message)~='string' then return {} end
 local hits={};local folded=message:lower()
 for name,bindings in pairs(index) do
  if #name>=2 then local from=1
   while from<=#message do
    local a,b=folded:find(name:lower(),from,true);if not a then break end
    if boundary(message,a,b,name) then hits[#hits+1]={start=a,finish=b,text=message:sub(a,b),candidates=bindings} end
    from=b+1
   end
  end
 end
 table.sort(hits,function(a,b)if a.start==b.start then return a.finish>b.finish end;return a.start<b.start end)
 local kept={}
 for _,hit in ipairs(hits) do
  local overlap=false
  for _,old in ipairs(kept) do if hit.start<=old.finish and hit.finish>=old.start then overlap=true;break end end
  if not overlap then kept[#kept+1]=hit end
 end
 local previous=0
 for i,hit in ipairs(kept) do
  local before=message:sub(previous+1,hit.start-1)
  for _,sep in ipairs({'，','。','？','！','、','；',',',';','?','!','\n','“','"','（','('}) do
   while true do local a,b=before:find(sep,1,true);if not a then break end;before=before:sub(b+1) end
  end
  local before_raw=before;local modifier=grammar_prefix(before)
  if modifier~='' then hit.unresolved_prefix=modifier end
  local after=message:sub(hit.finish+1,(kept[i+1] and kept[i+1].start-1) or #message)
  for _,sep in ipairs({'，','。','？','！','、','；',',',';','?','!','\n'}) do local at=after:find(sep,1,true);if at then after=after:sub(1,at-1) end end
  local rest=grammar_suffix(after)
  if rest~='' then hit.unresolved_suffix=rest end
  hit.grammar={before=before_raw,after=after};previous=hit.finish
 end
 return kept
end
function M.IsPronoun(s)
 return s=='它' or s=='这' or s=='这个' or s=='它们' or s=='这些' or s=='这两个' or s=='刚才那个' or s=='刚才说的那个'
end
function M.HasPronoun(s)
 return (s or ''):find('这个',1,true)~=nil or (s or ''):find('它',1,true)~=nil or (s or ''):find('这是什么',1,true)~=nil or (s or ''):find('这是怎样',1,true)~=nil
end
local qualifiers={'黄金','烧灼','灼烧','损坏','破损','暗影','远古','月光','普通','升级'}
local function normalize(s)
 s=(s or ''):lower():gsub('%s+','')
 for _,pair in ipairs({{'斧头','斧'},{'斧子','斧'},{'镐子','镐'},{'鹤嘴锄','镐'},{'铲子','铲'},{'锄头','锄'}}) do s=s:gsub(pair[1],pair[2]) end
 for _,head in ipairs({'斧','镐','铲','锄'}) do if s:sub(1,#('金'..head))=='金'..head then s='黄金'..s:sub(#'金'+1) end end
 return s
end
local function distance(a,b)
 local x,y=chars(a),chars(b);local rows={[0]={}}
 for j=0,#y do rows[0][j]=j end
 for i=1,#x do
  rows[i]={[0]=i}
  for j=1,#y do
   rows[i][j]=math.min(rows[i-1][j]+1,rows[i][j-1]+1,rows[i-1][j-1]+(x[i]==y[j] and 0 or 1))
   if i>1 and j>1 and x[i]==y[j-1] and x[i-1]==y[j] then rows[i][j]=math.min(rows[i][j],rows[i-2][j-2]+1) end
  end
 end
 return rows[#x][#y],#x,#y
end
function M.Morphology(display,category)
 if category~='tool' then return {} end
 local n=normalize(display);local out={}
 if n~=display then out[#out+1]=n end
 for _,head in ipairs({'斧','镐','铲','锄'}) do
  if n:sub(-#head)==head then
   out[#out+1]=n..'子'
   local special=false;for _,q in ipairs(qualifiers) do if n:find(q,1,true) then special=true end end
   if not special and #chars(n)<=3 then out[#out+1]='普通'..n;out[#out+1]='普通'..display end
  end
 end
 return out
end
function M.Rank(query,index,context)
 local q=normalize(query);local out={};if #chars(q)<2 then return out end
 local byprefab={}
 for raw,bindings in pairs(index) do
  local n=normalize(raw);local d,ql,nl=distance(q,n)
  local compatible=true
  for _,qual in ipairs(qualifiers) do
   if q:find(qual,1,true) and not n:find(qual,1,true) and not (qual=='灼烧' and n:find('烧灼',1,true)) then compatible=false end
  end
  -- Preserve meaningful tool heads. A gold adjective cannot make an axe a pick.
  for _,head in ipairs({'斧','镐','铲','锄'}) do if q:find(head,1,true) and not n:find(head,1,true) then compatible=false end end
  local abbr=ql>=2 and nl<=ql+3 and n:sub(-#q)==q
  if compatible and (d<=math.max(1,math.floor(ql/3)) or abbr) then
   local score=d==0 and 1 or abbr and .91 or 1-d/math.max(ql,nl)*.75
   for _,v in ipairs(bindings) do
    local bonus=0
    for _,p in ipairs(context and context.topics or {}) do if p==v.prefab then bonus=.025 end end
    local cat=context and context.categories and context.categories[v.prefab]
    if context and context.category and cat==context.category then bonus=bonus+.04 end
    local candidate={prefab=v.prefab,score=score+bonus,name=raw,match=d==0 and 'normalized_name' or abbr and 'short_name' or 'edit_distance',distance=d,kind=v.kind}
    if not byprefab[v.prefab] or byprefab[v.prefab].score<candidate.score then byprefab[v.prefab]=candidate end
   end
  end
 end
 for _,v in pairs(byprefab) do out[#out+1]=v end
 table.sort(out,function(a,b)if a.score==b.score then return a.prefab<b.prefab end;return a.score>b.score end)
 return out
end
function M.Suggestions(query,index,context)
 local ranked=M.Rank(query,index,context);local out={};local top=ranked[1]
 for _,r in ipairs(ranked) do if top and r.score>=top.score-.09 and #out<4 then out[#out+1]=r.prefab end end
 return out
end
function M.Obvious(ranked)
 return ranked[1] and ranked[1].score>=.88 and (not ranked[2] or ranked[1].score-ranked[2].score>=.10)
end
function M.IsConfirmation(message)
 local s=(message or ''):gsub('[%s%p]','');for _,punct in ipairs({'，','。','！','？'}) do s=s:gsub(punct,'') end
 return s=='是的' or s=='对' or s=='没错' or s=='就这个' or s=='是的就是这个' or s=='对就是它' or s=='就是这个' or s=='就是它'
end
function M.IsCancelQuery(message)
 return (message or ''):find('不问了',1,true) or (message or ''):find('不用介绍',1,true) or (message or ''):find('取消查询',1,true)
end
function M.QuestionName(message)
 for _,ending in ipairs({'能用来制作什么','能拿来制作什么','能做成什么','怎么烹饪','如何烹饪','有什么区别','有什么不同','在哪里','在哪','通常出现','栖息','怎么制作','如何制作','怎么做','制作配方','怎么获得','如何获得','怎么获取','从哪获得','有什么用途','有什么用','能做什么','能干什么','怎么使用','如何使用','有什么机制','什么机制','怎么交互','怎么攻击','有什么效果','的属性','多少伤害','多少防御','是什么'}) do
  local at=(message or ''):find(ending,1,true)
  if at then return grammar_prefix(message:sub(1,at-1)) end
 end
 local intro=(message or ''):match('^.-知道(.*)$') or (message or ''):match('^.-认识(.*)$')
 if intro then
  local changed=true
  while changed do changed=false;for _,suffix in ipairs({'吗','呢','？','?','。','呀','啊'}) do if intro:sub(-#suffix)==suffix then intro=intro:sub(1,#intro-#suffix);changed=true end end end
 end
 return intro and grammar_prefix(intro) or nil
end
function M.NounText(message)
 local q=M.QuestionName(message)
 if q and #q>0 then return q end
 return grammar_suffix(grammar_prefix(message or ''))
end
function M.GenericTree(message)
 local hits=M.Scan((message or ''):gsub('普通树','树'),{['树']={{prefab='ordinary_tree',kind='generic'}}})
 if #hits==0 then return false end
 for _,hit in ipairs(hits) do if hit.unresolved_prefix or hit.unresolved_suffix then return false end end
 return true
end
return M
