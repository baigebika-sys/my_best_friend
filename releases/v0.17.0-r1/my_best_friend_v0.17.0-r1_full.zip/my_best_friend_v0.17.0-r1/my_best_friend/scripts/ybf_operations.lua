-- Independent game-side schema check, even when backend validation succeeded.
local M={};local types={cook=true,goal=true,propose=true,accept=true,reject=true,modify_proposal=true,cancel=true,pause=true,resume=true,modify=true,status=true,unsupported=true}
local fields={type=true,recipe=true,category=true,quantity=true,destination=true,destination_guid=true,proposal_id=true,target=true,kind=true,scope=true,item=true,operation=true,goal=true,depends_on=true,append=true,reason=true,source=true}
function M.Validate(ops)
 if type(ops)~='table'or #ops<1 or #ops>6 then return false end
 for index,o in ipairs(ops)do
  if type(o)~='table'or not types[o.type]then return false end
  for k in pairs(o)do if not fields[k]then return false end end
  if o.quantity~=nil and (type(o.quantity)~='number'or o.quantity%1~=0 or o.quantity<1 or o.quantity>20)then return false end
  if (o.type=='cook'or o.type=='propose')and not o.quantity then return false end
  if o.type=='goal'and(type(o.goal)~='table'or type(o.goal.targets)~='table')then return false end
  if o.type=='modify'and o.operation~='remove'and not o.quantity then return false end
  if o.depends_on and(type(o.depends_on)~='number'or o.depends_on%1~=0 or o.depends_on<1 or o.depends_on>=index)then return false end
  if o.source and o.source~='default'and o.source~='warehouse_only'and o.source~='inventory_only'then return false end
  if o.category and o.category~='any'and o.category~='meat'and o.category~='vegetarian'then return false end
  if o.destination and o.destination~='auto'and o.destination~='player'and o.destination~='warehouse'and o.destination~='ground'and o.destination~='friend'then return false end
  if o.append~=nil and type(o.append)~='boolean'then return false end
  if o.destination_guid and(type(o.destination_guid)~='number'or o.destination_guid%1~=0 or o.destination_guid<1)then return false end
  if o.operation and o.operation~='set'and o.operation~='add'and o.operation~='remove'and o.operation~='append'then return false end
  if o.kind and o.kind~='cook'and o.kind~='work'then return false end
  if o.scope and o.scope~='single'and o.scope~='all'then return false end
  for _,k in ipairs({'recipe','target','proposal_id','item','reason'})do if o[k]~=nil and(type(o[k])~='string'or #o[k]<1 or #o[k]>360)then return false end end
 end
 return true
end
return M
