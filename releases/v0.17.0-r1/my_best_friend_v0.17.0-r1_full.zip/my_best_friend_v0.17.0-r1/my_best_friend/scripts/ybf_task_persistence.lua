-- No coroutine, callback, entity GUID or short-lived proposal countdown is saved.
local M={}
local function plain(v,depth)
 depth=depth or 0;if depth>10 then return end
 if type(v)=='string'or type(v)=='number'or type(v)=='boolean'then return v end
 if type(v)~='table'then return end
 local out={};for k,x in pairs(v)do if type(k)=='string'or type(k)=='number'then local p=plain(x,depth+1);if p~=nil then out[k]=p end end end;return out
end
function M.Save(h)
 h:Adopt();local out={sequence=h.sequence,held_outputs=h.held_outputs,tasks={}}
 for _,t in ipairs(h.tasks)do
  local row={};for _,k in ipairs({'id','kind','spec','ownerkey','state','created','center','world','done','stored','paused','reason','product','carry','started','pot_id','batch','depends','acquired','pot_prepared','loaded_slots','deposits','given_count','ground_count','kept_count','ground','target_stored','aux_stored'})do row[k]=plain(t[k])end
  if t.pot and t.pot.components.ybf_cook_marker and not row.pot_id then row.pot_id=t.pot.components.ybf_cook_marker.id end
  if t.job then
   local j=t.job;row.progress={};for _,k in ipairs({'crafted','given','sourced','stored','ground','count','protected','intentmode','location_origin'})do row.progress[k]=plain(j[k])end
   row.progress.builds={};for p,b in pairs(j.builds or {})do
    local build={};for _,k in ipairs({'id','item','recipe','product','status','world','origin','rotation','mode','index','placement_initialized','position','player_origin','snap_kind','snap_position','prepaid'})do build[k]=plain(b[k])end
    build.placed={};for _,placed in ipairs(b.placed or {})do build.placed[#build.placed+1]={x=placed.x,z=placed.z,rotation=placed.rotation,world=placed.world,verified=placed.verified}end
    row.progress.builds[p]=build
   end
  end
  out.tasks[#out.tasks+1]=row
 end
 return out
end
function M.Load(h,data)
 if not data then return end;h.sequence=data.sequence or 0;h.proposals={};h.held_outputs=data.held_outputs
 for _,row in ipairs(data.tasks or {})do if #h.tasks<32 then
  row.created=GetTime();row.owner=nil;row.friend=h.work.inst;row.external_reservation=row.kind=='cook';row.failed={};row.attempt=0;row._restore=true
  if row.state~='completed'and row.state~='cancelled'then row.state=row.paused and 'paused'or row.started and 'waiting'or 'queued'end
  h.tasks[#h.tasks+1]=row
 end end
end
function M.ApplyLegacy(work,t)
 local j=work.core.job;local p=t.progress
 if not p then return end
 for _,k in ipairs({'crafted','given','sourced','stored','ground','count','protected','intentmode','location_origin'})do if p[k]~=nil then j[k]=p[k]end end
 -- Completed placement receipts persist as progress, not a new placement request.
 -- Recheck the entities at the stored points; missing receipts block, never rebuild.
 if p.builds then j.builds=p.builds;for _,b in pairs(j.builds)do
  for _,placed in ipairs(b.placed or {})do
   local found;for _,e in ipairs(TheSim:FindEntities(placed.x,0,placed.z,.15,nil,{'INLIMBO'}))do if e.prefab==b.product then found=e;break end end
   if not found then j.blocked={code='restore_unverified',reason='已完成建筑的位置无法恢复，不重复建造'};j.uncertain=true;t.state='blocked';t.reason=j.blocked.reason else placed.entity=found;placed.guid=found.GUID end
  end
 end end
 t.progress=nil;t._restore=nil
end
return M
