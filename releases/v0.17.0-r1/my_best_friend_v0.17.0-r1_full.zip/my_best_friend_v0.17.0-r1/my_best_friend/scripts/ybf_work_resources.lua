-- Perception is local to the friend and additionally bounded by the job origin.
local M = {}
local Knowledge=require('ybf_knowledge')
function M.Safe(target)return Knowledge.Safe(target)end
function M.InRange(inst,target,center,radius)
 if not M.Safe(target) then return false end
 local x,_,z=target.Transform:GetWorldPosition()
 return (x-center.x)^2+(z-center.z)^2<=radius^2 and inst:GetDistanceSqToInst(target)<=radius^2
end
function M.Classify(target,prefab,kind,inst)
 if not M.Safe(target) then return nil end
 for _,source in ipairs(Knowledge.Sources(inst,target)) do
  if source.product==prefab and source.supported and source.available and (kind~='pickup' or source.action=='pickup') then return source.action end
 end
end
function M.Observe(inst,center,radius)
 local x,y,z=inst.Transform:GetWorldPosition();local visible={}
 for _,target in ipairs(TheSim:FindEntities(x,y,z,radius,nil,{'INLIMBO'})) do
  if M.InRange(inst,target,center,radius) then visible[#visible+1]=target end
 end
 table.sort(visible,function(a,b)
  local da,db=inst:GetDistanceSqToInst(a),inst:GetDistanceSqToInst(b)
  if da==db then return (a.GUID or 0)<(b.GUID or 0) end
  return da<db
 end)
 Knowledge.ObserveInventory(inst);Knowledge.Observe(inst,visible)
 return visible
end
function M.CanAcquire(inst,prefab)return Knowledge.CanAcquire(inst,prefab)end
function M.Scan(inst, center, radius, prefab, kind)
    local x, y, z = inst.Transform:GetWorldPosition()
    local out = {}
    for _, target in ipairs(TheSim:FindEntities(x, y, z, radius, nil, {'INLIMBO'})) do
        if M.InRange(inst, target, center, radius) then
            local step = M.Classify(target, prefab, kind,inst)
            if step then out[#out+1] = {target=target, step=step} end
        end
    end
    table.sort(out, function(a,b)
        if (a.step == 'pickup') ~= (b.step == 'pickup') then return a.step == 'pickup' end
        return inst:GetDistanceSqToInst(a.target) < inst:GetDistanceSqToInst(b.target)
    end)
    return out
end
return M
