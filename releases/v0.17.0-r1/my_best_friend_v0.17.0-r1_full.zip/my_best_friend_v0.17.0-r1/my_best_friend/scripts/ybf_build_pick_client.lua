-- Temporary playercontroller interception; never invokes player crafting.
local M={};local function hint(text)
 if ThePlayer and ThePlayer.components.talker then ThePlayer.components.talker:Say(text)end
end
function M.Clear()
 M.pending=nil;M.cancel_pending=nil
 local ghost=M.ghost;M.ghost=nil
 if ghost then pcall(function()if ghost:IsValid()then ghost:Remove()end end)end
end
function M.Preview(d)
 local r=GetValidRecipe(d.recipe)
 if not r or type(r.placer)~='string' then return false end
 local ghost=SpawnPrefab(r.placer)
 if not ghost or not ghost.components.placer then if ghost then ghost:Remove()end;return false end
 M.ghost=ghost
 local placer=ghost.components.placer
 -- Independent native placer: never attach to playercontroller.placer or craft.
 placer:SetBuilder(ThePlayer,r)
 placer.testfn=function(pt,rot)return TheWorld.Map:CanDeployRecipeAtPoint(pt,r,rot,Ents[d.friend] or ThePlayer)end
 local update=placer.OnUpdate
 placer.OnUpdate=function(self,dt)
  if M.pending~=d then return end
  self.fixedcameraoffset=TheCamera:GetHeading()+d.rotation;self.rotationoffset=0;self.fixedcameraoffset_nearestangle=nil
  return update(self,dt)
 end
 ghost:DoTaskInTime(90,function()if M.pending==d then M.Clear();hint('点选已过期，请重新指定位置。')end end)
 return true
end
function M.Marker(d)
 if not SpawnPrefab or not d.x then return end
 local marker=SpawnPrefab('ybf_build_marker')
 if marker then marker.Transform:SetPosition(d.x,0,d.z);marker.Transform:SetRotation(d.rotation or 0);marker:DoTaskInTime(6,function()if marker:IsValid()then marker:Remove()end end)end
 hint(d.text or '位置已记录')
end
function M.Begin(d)
 M.Clear();M.pending=d;d.expires=GetTime()+90;d.rotation=d.rotation or 0
 local screen=TheFrontEnd and TheFrontEnd:GetActiveScreen()
 if screen and screen.name=='YBFChatScreen' then TheFrontEnd:PopScreen()end
 local ok,result=pcall(M.Preview,d)
 if not ok or not result then M.Clear();hint('建筑预览无法加载，已退出点选；请重新指定位置。');SendModRPCToServer(GetModRPC('my_best_friend','build_point'),json.encode_compliant({friend=d.friend,task=d.task,target=d.target,nonce=d.nonce,x=0,z=0,rotation=d.rotation,cancel=true}));return end
 hint(d.text)
end
function M.Ack(d)
 local p=M.pending or M.cancel_pending
 if not p or p.friend~=d.friend or p.task~=d.task or p.target~=d.target or p.nonce~=d.nonce then return end
 if p==M.cancel_pending then M.cancel_pending=nil;hint(d.text or '已退出点选；如需停止整个任务，请说取消任务');return end
 print('[YBF POINT CLIENT] task='..tostring(d.task)..' phase='..(d.accepted and 'accepted' or 'rejected'))
 if d.accepted then M.Clear() else p.sending=nil;if M.ghost then M.ghost.components.placer.selected_pos=nil end end
 hint(d.text or '服务器未接受点选，请重试或取消任务')
end
function M.Submit(cancel)
 local d=M.pending;if not d then return end
 if d.sending and not cancel then hint('正在等待服务器确认位置；未收到确认前不会退出点选。');return end
 if not cancel and M.ghost then M.ghost.components.placer:OnUpdate(0) end
 local p=not cancel and (M.ghost and M.ghost:GetPosition() or TheInput:GetWorldPosition())or {x=0,z=0}
 local raw=json.encode_compliant({friend=d.friend,task=d.task,target=d.target,nonce=d.nonce,x=p.x,z=p.z,rotation=d.rotation,cancel=cancel==true})
 if cancel then M.Clear();M.cancel_pending=d;hint('已退出点选，正在请求取消；若已提交位置，可说取消任务停止施工。')end
 d.sending=true;if M.ghost and not cancel then M.ghost.components.placer.selected_pos=p end
 print('[YBF POINT CLIENT] task='..tostring(d.task)..' target='..tostring(d.target)..' phase=sending')
 local ok,err=pcall(SendModRPCToServer,GetModRPC('my_best_friend','build_point'),raw)
 if not ok then d.sending=nil;hint(cancel and '已退出点选，但取消请求发送失败；请用取消任务停止工作' or '位置发送失败，请重新点击或取消任务');print('[YBF POINT CLIENT] send_exception '..tostring(err))end
 if ThePlayer.DoTaskInTime then ThePlayer:DoTaskInTime(5,function()
  if M.pending==d and d.sending then d.sending=nil;if M.ghost then M.ghost.components.placer.selected_pos=nil end;hint('尚未收到服务器的位置确认；可再点击重试或取消任务。');print('[YBF POINT CLIENT] task='..tostring(d.task)..' phase=ack_timeout')end
 end)end
end
function M.Hook(controller)
 local left,right,control=controller.OnLeftClick,controller.OnRightClick,controller.OnControl
 local swallow={}
 local function active()if M.pending and GetTime()>M.pending.expires then M.Clear();hint('点选已过期，请重新请求指定位置。')end;return controller.inst==ThePlayer and M.pending~=nil end
 controller.OnLeftClick=function(self,down)
  if down and swallow.left then return true end
  if not down and swallow.left then swallow.left=nil;return true end
  if active()then if down then swallow.left=true
   if TheFrontEnd and TheFrontEnd:GetActiveScreen()~=ThePlayer.HUD or TheInput:GetHUDEntityUnderMouse()then return true end
   M.Submit(false)
  end;return true end
  return left(self,down)
 end
 controller.OnRightClick=function(self,down)
  if down and swallow.right then return true end
  if not down and swallow.right then swallow.right=nil;return true end
  if active()then if down then swallow.right=true;M.Submit(true)end;return true end
  return right(self,down)
 end
 controller.OnControl=function(self,c,down)
  if active()then
   if c==CONTROL_CANCEL then if down then M.Submit(true)end;return true end
   if c==CONTROL_ROTATE_LEFT or c==CONTROL_ROTATE_RIGHT then if down then M.pending.rotation=(M.pending.rotation+(c==CONTROL_ROTATE_LEFT and -45 or 45))%360;hint('施工朝向：'..M.pending.rotation..'°')end;return true end
   if c==CONTROL_PRIMARY then return self:OnLeftClick(down)end
   if c==CONTROL_SECONDARY then return self:OnRightClick(down)end
  end
  return control(self,c,down)
 end
end

function M.Cancel(d)
 if M.pending and M.pending.friend==d.friend and M.pending.task==d.task and (not d.target or M.pending.target==d.target) then M.Clear() end
end
function M.HookHUD(hud)
 local original=hud.OnControl;local swallow={}
 hud.OnControl=function(self,c,down)
  if not down and swallow[c]then swallow[c]=nil;return true end
  if M.pending and self.owner==ThePlayer and (c==CONTROL_PAUSE or c==CONTROL_CANCEL)then
   if down then swallow[c]=true;M.Submit(true)end;return true
  end
  return original(self,c,down)
 end
end

return M
