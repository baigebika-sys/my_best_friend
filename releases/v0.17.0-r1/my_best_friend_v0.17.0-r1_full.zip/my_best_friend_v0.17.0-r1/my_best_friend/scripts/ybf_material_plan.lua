-- Merged demand view; executor rechecks actual stock after every action.
local Craft=require('ybf_work_crafting');local Inv=require('ybf_work_inventory');local Warehouse=require('ybf_warehouse')
local M={}
function M.Build(inst,work,j)
 local demand,allocated,paths,gaps={}, {},{},{};local nodes=0
 local function visit(p,n,path,depth,force)
  nodes=nodes+1;if nodes>256 or depth>12 then gaps[#gaps+1]='依赖预算';return end
  local held=Inv.Count(inst,p,true)
  if j.source=='warehouse_only' then held=math.min(held,j.sourced[p] or 0) end
  local stored=j.source~='inventory_only' and Warehouse.Stock(inst,j,work.radius,p) or 0
  local available=force and 0 or math.max(0,held+stored-(allocated[p] or 0))
  local reused=math.min(n,available);allocated[p]=(allocated[p] or 0)+reused
  local missing=math.max(0,n-reused);demand[p]=(demand[p] or 0)+n
  if missing==0 then return end
  if path[p] then gaps[#gaps+1]=Inv.Label(p)..'依赖循环';return end
  local info=Craft.PlanRecipe(inst,p,require('ybf_building').Recipe(p)~=nil)
  if not info then return end
  local nextpath={};for k,v in pairs(path) do nextpath[k]=v end;nextpath[p]=true
  local batches=math.ceil(missing/info.output)
  paths[#paths+1]={item=p,batches=batches,output=info.output}
  for _,i in ipairs(info.ingredients) do visit(i.item,i.amount*batches,nextpath,depth+1,false) end
 end
 for _,t in ipairs(j.targets) do
  local mode=t.mode or j.intentmode;local building=j.builds and j.builds[t.item];local done=building and #building.placed or mode=='craft' and (j.crafted[t.item] or 0) or (j.given[t.item] or 0)
  visit(t.item,math.max(0,t.quantity-done),{},1,mode=='craft')
 end
 return {requirements=demand,allocated=allocated,dependencies=paths,gaps=gaps,scope='merged planning snapshot; not proof of acquisition or qualification'}
end
return M
