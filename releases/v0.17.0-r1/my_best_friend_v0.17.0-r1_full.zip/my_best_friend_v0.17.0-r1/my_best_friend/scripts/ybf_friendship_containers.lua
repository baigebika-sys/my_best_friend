local M={supported={treasurechest=true,dragonflychest=true,icebox=true,saltbox=true}}
function M.Authorized(e)
 return e and e:IsValid() and M.supported[e.prefab] and e.components.container
  and e.components.ybf_friendship_container and e.components.ybf_friendship_container.enabled
  and not e:HasTag('burnt') and not e.components.container.readonlycontainer
end
function M.Install(inst)
 inst._ybf_friendship_net=net_bool(inst.GUID,'ybf.friendshipcontainer','ybf_friendship_dirty')
 local display=inst.GetDisplayName
 inst.GetDisplayName=function(e,...)
  local name=display(e,...)
  return e._ybf_friendship_net:value() and '友谊'..name or name
 end
 local function dirty()
  if inst._ybf_friendship_net:value() then inst:AddTag('ybf_friendship_container') else inst:RemoveTag('ybf_friendship_container') end
 end
 inst:ListenForEvent('ybf_friendship_dirty',dirty)
 if TheWorld.ismastersim then inst:AddComponent('ybf_friendship_container') end
end
return M
