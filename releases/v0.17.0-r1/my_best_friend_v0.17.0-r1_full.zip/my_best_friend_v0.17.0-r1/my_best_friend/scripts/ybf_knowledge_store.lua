-- Versioned static facts are independent of disclosure/personality and executors.
-- Only data modules produced by the offline importer are accepted here.
local data=require('ybf_official_knowledge')
local M={data=data}
function M.Identity(prefab)return data.entries[prefab]end
function M.Entry(prefab)
 local row=data.entries[prefab]
 if row and row.detail_module and row.detail_module:match('^ybf_official_detail_%x%x$') then
  local details=require(row.detail_module);return details[prefab]
 end
 return row
end
function M.Manifest()return data.manifest end
function M.Compatible()
 local target=data.manifest.build;local running=APP_VERSION
 return target~=nil and running~=nil and tostring(target)==tostring(running)
end
local function equal(a,b,depth)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 if depth>12 then return false end
 for k,v in pairs(a) do if not equal(v,b[k],depth+1) then return false end end
 for k in pairs(b) do if a[k]==nil then return false end end
 return true
end
function M.Facts(prefab,facet)
 local row=M.Entry(prefab);local out={};local groups={};local conflicts={}
 for _,fact in ipairs(row and row[facet] or {}) do
  -- Imported candidates and mismatched versions are searchable evidence,
  -- never promoted to current confirmed game facts.
  if fact.certainty=='verified' and fact.version==data.manifest.build and M.Compatible() then
   if not fact.semantic_key then out[#out+1]=fact
   else local key=fact.semantic_key;groups[key]=groups[key] or {};groups[key][#groups[key]+1]=fact end
  end
 end
 for key,facts in pairs(groups) do
  local implementation={};for _,fact in ipairs(facts) do if fact.kind=='official_script' then implementation[#implementation+1]=fact end end
  local preferred=#implementation>0 and implementation or facts;local consistent=true
  for i=2,#preferred do if not equal(preferred[1].value,preferred[i].value,0) then consistent=false end end
  if consistent then out[#out+1]=preferred[1] else conflicts[#conflicts+1]=key end
 end
 table.sort(out,function(a,b)return tostring(a.semantic_key or a.field or a.path)<tostring(b.semantic_key or b.field or b.path) end)
 table.sort(conflicts);return out,conflicts
end
return M
