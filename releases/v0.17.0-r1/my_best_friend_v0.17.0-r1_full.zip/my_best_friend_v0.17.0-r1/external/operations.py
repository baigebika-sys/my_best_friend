"""Bounded cooking/control operations; no model-created material or coordinate steps."""
TYPES={'cook','goal','propose','accept','reject','modify_proposal','cancel','pause','resume','modify','status','unsupported'}
def validate(ops,fail,parse_goal):
 if not isinstance(ops,list) or not 1<=len(ops)<=6:fail('invalid_operations','操作列表须含1至6项')
 fields={'type','recipe','category','quantity','destination','destination_guid','proposal_id','target','kind','scope','item','operation','goal','depends_on','append','reason','source'}
 for i,o in enumerate(ops):
  path='$.item[%d]'%i
  if not isinstance(o,dict) or set(o)-fields or o.get('type')not in TYPES:fail('invalid_operation','操作条目或字段无效',path)
  typ=o['type']
  if o.get('depends_on')is not None:
   if isinstance(o['depends_on'],bool)or not isinstance(o['depends_on'],int)or not 1<=o['depends_on']<=i:fail('invalid_dependency','依赖只可指向之前的操作序号',path)
  if 'quantity'in o and not(o['quantity']is None and typ=='modify'and o.get('operation')=='remove') and (isinstance(o['quantity'],bool)or not isinstance(o['quantity'],int)or not 1<=o['quantity']<=20):fail('invalid_cooking_quantity','烹饪数量须为1至20整数',path)
  if o.get('source','default')not in ('default','warehouse_only','inventory_only'):fail('invalid_source','材料来源范围无效',path)
  if o.get('category','any')not in ('any','meat','vegetarian'):fail('invalid_cooking_category','料理分类无效',path)
  if o.get('destination','auto')not in ('auto','player','warehouse','ground','friend'):fail('invalid_destination','去向无效',path)
  if o.get('scope','single')not in ('single','all')or o.get('kind')not in (None,'cook','work'):fail('invalid_task_scope','任务范围无效',path)
  for k in ('recipe','target','proposal_id','item','reason'):
   if k in o and (not isinstance(o[k],str)or not 1<=len(o[k])<=120):fail('invalid_operation_name','名称或任务标识无效',path)
  if 'append'in o and not isinstance(o['append'],bool):fail('invalid_append','追加标记须为布尔',path)
  if 'destination_guid'in o and (isinstance(o['destination_guid'],bool)or not isinstance(o['destination_guid'],int)or o['destination_guid']<1):fail('invalid_destination_guid','容器标识无效',path)
  if o.get('operation','set')not in ('set','add','remove','append'):fail('invalid_modify_operation','目标修改方式无效',path)
  if typ=='goal':
   if not isinstance(o.get('goal'),dict):fail('invalid_goal','缺少目标内容',path)
   o['goal']=parse_goal(o['goal'])
  if typ in ('cook','propose'):o.setdefault('quantity',1);o.setdefault('destination','auto');o.setdefault('category','any')
  if typ=='modify'and o.get('operation')!='remove'and 'quantity'not in o:fail('invalid_modify','修改须带数量',path)
 return ops
