"""Strict intent decoding. Diagnostics contain structure, never raw model text."""
import json
import re
import logging

RESOURCES={'twigs','cutgrass','log','rocks','flint','goldnugget'}
RECIPES={'axe','pickaxe','cutstone','boards','rope','torch'}
ACTIONS={'command_operations':'operations','command_wait':'wait','command_follow':'follow','command_pickup':'pickup','command_stop':'stop',
         'command_eat':'eat','command_collect':'collect','command_craft':'craft','command_give':'give',
         'command_plan':'plan','command_goal':'goal','command_resume':'resume','command_equip':'equip',
         'command_pause':'pause','command_cancel':'cancel','command_modify':'modify',
         'query_knowledge':'knowledge','query_progress':'status','query_inventory':'inventory','clarify':'clarify','unsupported':'unsupported',
         'question':'none','chat':'none','unclear':'none'}
FIELDS={'intent','action','dialogue','item','quantity','deliver','mode','recipient','constraints','reference','destination','destination_guid','ground_position','placement','operation'}
STEP_FIELDS={'kind','item','quantity','prepare','ensure'}

class DecisionError(ValueError):
    def __init__(self,code,reason,path='$',category='decision_schema',structure=None):
        super().__init__(reason)
        self.code=code;self.reason=reason;self.path=path;self.category=category
        self.structure=structure or {}
    def diagnostic(self):
        return dict(category=self.category,code=self.code,path=self.path,reason=self.reason,structure=self.structure)

def shape(value):
    def typ(v):
        return 'null' if v is None else 'boolean' if isinstance(v,bool) else 'object' if isinstance(v,dict) else 'array' if isinstance(v,list) else 'string' if isinstance(v,str) else 'number' if isinstance(v,(int,float)) else 'other'
    result={'type':typ(value)}
    if isinstance(value,dict):
        keys=set(value);result['fields']={k:typ(value[k]) for k in sorted(keys & FIELDS)}
        result['unexpected_field_count']=len(keys-FIELDS)
        if isinstance(value.get('item'),list):
            result['entry_count']=len(value['item'])
            result['entries']=[{'type':typ(e),'fields':{k:typ(v) for k,v in e.items() if k in STEP_FIELDS},'unexpected_field_count':len(set(e)-STEP_FIELDS)} if isinstance(e,dict) else {'type':typ(e)} for e in value['item'][:3]]
    return result

def parse_decision(text):
    if not isinstance(text,str) or not text.strip():
        raise DecisionError('empty_content','模型没有返回非空文本',category='provider_envelope')
    try:d=json.loads(text)
    except json.JSONDecodeError as e:
        raise DecisionError('invalid_json','JSON语法错误：第%d行、第%d列'%(e.lineno,e.colno),category='decision_json',structure={'bytes':len(text.encode('utf-8')),'line':e.lineno,'column':e.colno}) from None
    structure=shape(d)
    def fail(code,reason,path='$'):raise DecisionError(code,reason,path,structure=structure)
    if not isinstance(d,dict):fail('object_required','顶层必须是JSON对象')
    intent=d.get('intent');action=d.get('action')
    if not isinstance(intent,str) or intent not in ACTIONS:fail('invalid_intent','intent必须是已定义的意图字符串','$.intent')
    if not isinstance(action,str) or action not in set(ACTIONS.values()):fail('invalid_action','action必须是已定义的动作字符串','$.action')
    expected={'intent','action','dialogue','item','quantity'}|({'deliver'} if intent=='command_goal' else set())
    # Non-action replies may carry a harmless unused goal flag. This is a
    # defined schema variant, not a second model request or action repair.
    if ACTIONS[intent]=='none' and 'deliver' in d:
        if d['deliver'] is not None and d['deliver'] is not False:fail('unexpected_deliver','闲聊或问题不能要求交付','$.deliver')
        expected.add('deliver')
    optional={'mode','recipient','constraints','reference','destination','destination_guid','ground_position','placement'} if intent=='command_goal' else ({'reference','operation'} if intent=='command_modify' else {'reference'} if intent in ('command_resume','command_pause','command_cancel') else set())
    expected|=set(d)&optional
    if set(d)!=expected:
        structure['missing_fields']=sorted(expected-set(d));structure['unexpected_field_count']=len(set(d)-expected)
        fail('invalid_fields','顶层字段缺失或多余；请按所选意图的规定字段返回')
    if not isinstance(d['dialogue'],str) or not d['dialogue'].strip():fail('invalid_dialogue','dialogue必须是非空字符串','$.dialogue')
    action=ACTIONS[intent]
    if action!='none' and d['action']!=action:fail('inconsistent_action','intent与action不匹配','$.action')
    def quantity(n,path,optional=False,limit=100):
        if optional and n is None:return
        if isinstance(n,bool) or not isinstance(n,int) or not 1<=n<=limit:fail('invalid_quantity','数量必须是1至%d的整数，不能是字符串、小数、布尔或null'%limit,path)
    def item(value,path):
        if not isinstance(value,str) or not re.fullmatch(r'[a-z0-9_]{1,80}',value):fail('invalid_item','物品必须是游戏prefab标识字符串',path)
        if value=='ybf_friendship_flower':fail('protected_item','不能交付或获取友谊小花',path)
    reference=d.get('reference','current')
    if 'reference' in d and reference not in ('current','clarification'):fail('invalid_reference','reference只能指向当前任务或待确认问题','$.reference')
    if action=='operations':
        if d['quantity']is not None:fail('unexpected_arguments','操作列表顶层数量须为null')
        from operations import validate
        def goal(spec):
            if set(spec)-{'targets','deliver','mode','constraints','destination','destination_guid','placement'}:fail('invalid_goal_fields','目标内容含未授权字段')
            raw=dict(intent='command_goal',action='goal',dialogue='核实目标',item=spec.get('targets'),quantity=None,deliver=spec.get('deliver',False),mode=spec.get('mode','obtain'))
            for k in ('constraints','destination','destination_guid','placement'): 
                if k in spec:raw[k]=spec[k]
            return parse_decision(json.dumps(raw))[3]
        return action,d['dialogue'],intent,validate(d['item'],fail,goal),None
    if action=='knowledge':
        value=d['item']
        if not isinstance(value,dict) or set(value)-{'answer_style'} not in ({'name','kind'},{'names','kind'}):fail('invalid_knowledge_query','查询须含name或names，以及kind','$.item')
        names=value.get('names') if 'names' in value else [value['name']]
        if not isinstance(names,list) or not 1<=len(names)<=4:fail('invalid_query_names','每次查询1至4个对象','$.item.names')
        for name in names:
            if not isinstance(name,str) or not 1<=len(name.encode('utf-8'))<=120 or any(ord(c)<32 for c in name):fail('invalid_query_name','查询名称须为非空短文本','$.item')
        if 'answer_style' in value and value['answer_style'] not in ('direct','overview'):fail('invalid_answer_style','知识表达样式须为direct或overview','$.item.answer_style')
        if value['kind'] not in ('identity','properties','uses','recipe','sources','mechanisms','difference','habitats','category','family','condition'):fail('invalid_query_kind','查询类型不支持','$.item.kind')
        if d['quantity'] is not None:fail('unexpected_arguments','知识查询不能带任务数量','$.quantity')
        return action,d['dialogue'],intent,value,None
    if action=='modify':
        if d['item'] is not None:item(d['item'],'$.item')
        operation=d.get('operation','set')
        if operation not in ('set','add','remove','append'):fail('invalid_operation','目标修改方式无效')
        if operation=='remove':
            if d['quantity'] is not None:fail('invalid_remove_quantity','删除目标不带数量')
        else:quantity(d['quantity'],'$.quantity')
        result={'item':d['item'],'reference':reference}
        if 'operation' in d:result['operation']=operation
        return action,d['dialogue'],intent,result,d['quantity']
    if action=='pause':
        if d['item'] not in (None,'chop','mine'):fail('invalid_pause_filter','暂停限定只支持chop或mine','$.item')
        if d['quantity'] is not None:fail('unexpected_arguments','暂停不能带数量','$.quantity')
        return action,d['dialogue'],intent,{'filter':d['item'],'reference':reference},None
    if action in ('resume','cancel'):
        if d['item'] is not None or d['quantity'] is not None:fail('unexpected_arguments','任务控制不接受新物品或数量')
        return action,d['dialogue'],intent,{'reference':reference},None
    if action=='goal':
        def placement(v,path):
            if not isinstance(v,dict) or set(v)-{'mode','tile','rotation'} or v.get('mode') not in ('free','fixed','tile','player'):fail('invalid_placement','建筑定位方式无效',path)
            if v.get('tile','auto') not in ('auto','cell','edge','corner'):fail('invalid_tile_alignment','地皮对齐方式无效',path)
            if v['mode']=='player':v.update(mode='tile',tile='auto')
            r=v.get('rotation',0)
            if isinstance(r,bool) or not isinstance(r,(int,float)) or not 0<=r<360:fail('invalid_rotation','建筑朝向须为0至359度',path)
        if 'placement' in d:placement(d['placement'],'$.placement')
        if not isinstance(d['deliver'],bool):fail('invalid_deliver','deliver必须是布尔值','$.deliver')
        if isinstance(d['item'],list):
            if d['quantity'] is not None or not 1<=len(d['item'])<=8:fail('invalid_targets','多目标须为1至3个条目且顶层quantity为null','$.item')
            targets=d['item'];seen=set()
            for index,e in enumerate(targets):
                path='$.item[%d]'%index
                if not isinstance(e,dict) or set(e)-{'item','quantity','mode','destination','placement'} or not {'item','quantity'}<=set(e):fail('invalid_target_fields','目标条目只能包含item与quantity',path)
                if 'placement' in e:placement(e['placement'],path+'.placement')
                item(e['item'],path+'.item');quantity(e['quantity'],path+'.quantity')
                if e['item'] in seen:fail('duplicate_target','同一物品目标不能重复',path+'.item')
                seen.add(e['item'])
                if e.get('mode','obtain') not in ('obtain','craft'):fail('invalid_target_mode','单目标模式无效',path)
                if e.get('destination','auto') not in ('auto','player','friend','warehouse','ground'):fail('invalid_target_destination','单目标去向无效',path)
        else:
            item(d['item'],'$.item');quantity(d['quantity'],'$.quantity')
            targets=[{'item':d['item'],'quantity':d['quantity']}]
        mode=d.get('mode','obtain')
        if mode not in ('obtain','materials','craft'):fail('invalid_mode','目标模式须为obtain、materials或craft','$.mode')
        recipient=d.get('recipient','player' if d['deliver'] else 'friend')
        if recipient not in ('player','friend'):fail('invalid_recipient','接收者必须是player或friend','$.recipient')
        # deliver is the sole canonical legacy handoff flag; recipient duplicates it.
        if (recipient=='player')!=d['deliver']:logging.info('MODEL_NORMALIZE category=redundant_recipient canonical=deliver; destination unchanged')
        recipient='player' if d['deliver'] else 'friend'
        constraints=d.get('constraints',{})
        if not isinstance(constraints,dict) or set(constraints)-{'existing_only','forbidden','source'}:fail('invalid_constraints','限制仅支持existing_only和forbidden','$.constraints')
        if 'existing_only' in constraints and not isinstance(constraints['existing_only'],bool):fail('invalid_constraint_type','existing_only必须是布尔值','$.constraints.existing_only')
        forbidden=constraints.get('forbidden',[])
        if not isinstance(forbidden,list) or len(forbidden)>6 or any(not isinstance(v,str) or v not in ('pickup','pick','chop','mine','craft','tech') for v in forbidden):fail('invalid_forbidden','禁止动作列表不合法','$.constraints.forbidden')
        if constraints.get('source','default') not in ('default','warehouse_first','warehouse_only','inventory_only'):fail('invalid_source','材料范围无效')
        if d.get('destination','auto') not in ('auto','player','friend','warehouse','ground'):fail('invalid_destination','物品去向无效')
        if 'destination_guid' in d and (not isinstance(d['destination_guid'],int) or isinstance(d['destination_guid'],bool) or d['destination_guid']<1):fail('invalid_container','容器身份无效')
        if 'ground_position' in d:
            pos=d['ground_position']
            if not isinstance(pos,dict) or set(pos)!={'x','z'} or any(isinstance(v,bool) or not isinstance(v,(float,int)) or not -100000<=v<=100000 for v in pos.values()):fail('invalid_ground_position','地面位置格式无效')
        result={'targets':targets,'deliver':d['deliver']}
        for f in ('destination','destination_guid','ground_position','placement'):
            if f in d:result[f]=d[f]
        if set(d)&{'mode','recipient','constraints','reference','destination','destination_guid','ground_position','placement'}:result.update(mode=mode,recipient=recipient,constraints=constraints,reference=d.get('reference'))
        return action,d['dialogue'],intent,result,None
    if action=='pickup':
        def pickup(value,n,path):
            if not isinstance(value,str) or value not in RESOURCES:fail('unsupported_resource','暂不支持此基础资源标识',path+'.item')
            quantity(n,path+'.quantity',optional=True)
        if isinstance(d['item'],list):
            if d['quantity'] is not None or not 1<=len(d['item'])<=8:fail('invalid_pickup_plan','拾取数组须有1至3项且顶层quantity为null','$.item')
            seen=set()
            for i,e in enumerate(d['item']):
                path='$.item[%d]'%i
                if not isinstance(e,dict) or set(e)-{'item','quantity','mode','destination'} or not {'item','quantity'}<=set(e):fail('invalid_pickup_entry','拾取条目字段应为item、quantity',path)
                pickup(e['item'],e['quantity'],path)
                if e['item'] in seen:fail('duplicate_target','拾取物品不能重复',path)
                seen.add(e['item'])
                if e.get('mode','obtain') not in ('obtain','craft'):fail('invalid_target_mode','单目标模式无效',path)
                if e.get('destination','auto') not in ('auto','player','friend','warehouse','ground'):fail('invalid_target_destination','单目标去向无效',path)
        else:pickup(d['item'],d['quantity'],'$')
    elif action=='plan':
        entries=d['item']
        if d['quantity'] is not None or not isinstance(entries,list) or not 1<=len(entries)<=12:fail('invalid_plan','旧计划须有1至12步，顶层quantity应为null','$.item')
        for i,e in enumerate(entries):
            path='$.item[%d]'%i
            if not isinstance(e,dict) or not {'kind','item','quantity'}<=set(e) or set(e)-STEP_FIELDS:fail('invalid_step_fields','步骤缺少必需字段或存在多余字段',path)
            kind=e['kind']
            if not isinstance(kind,str) or kind not in ('collect','craft','give','tree','equip'):fail('invalid_step_kind','步骤kind不支持',path+'.kind')
            item(e['item'],path+'.item');quantity(e['quantity'],path+'.quantity')
            if kind=='collect' and e['item'] not in RESOURCES:fail('unsupported_resource','采集资源不支持',path+'.item')
            if kind=='equip' and e['quantity']!=1:fail('invalid_equip_count','一次只能装备一个物品',path+'.quantity')
            if kind=='tree' and e['item']!='log':fail('invalid_tree_item','树目标标识必须为log',path+'.item')
            if kind=='craft' and e['item'] not in RECIPES:fail('unsupported_recipe','当前基础配方范围不支持此配方',path+'.item')
            if 'prepare' in e and not isinstance(e['prepare'],bool):fail('invalid_prepare','prepare必须是布尔值',path+'.prepare')
            if 'ensure' in e and (kind!='craft' or not isinstance(e['ensure'],bool)):fail('invalid_ensure','ensure只用于craft且必须是布尔值',path+'.ensure')
    elif action in ('collect','craft','give','equip'):
        item(d['item'],'$.item');quantity(d['quantity'],'$.quantity')
        if action=='collect' and d['item'] not in RESOURCES:fail('unsupported_resource','采集资源不支持','$.item')
        if action=='craft' and d['item'] not in RECIPES:fail('unsupported_recipe','当前基础配方范围不支持此配方','$.item')
        if action=='equip' and d['quantity']!=1:fail('invalid_equip_count','一次只能装备一个物品','$.quantity')
    elif action=='eat':
        item(d['item'],'$.item');quantity(d['quantity'],'$.quantity',limit=20)
    elif d['item'] is not None or d['quantity'] is not None:fail('unexpected_arguments','非工作意图的item与quantity必须为null')
    return action,d['dialogue'],intent,d['item'],d['quantity']
