@echo off
cd /d "%~dp0"
py -3 repack_dst_scripts.py --source scripts.zip --output dst_script_parts
pause
