-- Semantic goal validation/expansion. No game actions or model step plans.
local Crafting=require('ybf_work_crafting')
local Inventory=require('ybf_work_inventory')
local Resources=require('ybf_work_resources')
local Knowledge=require('ybf_knowledge')
local M={}
function M.Copy(value)
 if type(value)~='table' then return value end
 local out={};for key,item in pairs(value) do out[key]=M.Copy(item) end;return out
end
-- Canonical goal equality ignores target order and clarification references.
function M.Same(a,b)
 if type(a)~='table' or type(b)~='table' or type(a.targets)~='table' or type(b.targets)~='table' or #a.targets~=#b.targets then return false end
 if a.deliver~=b.deliver or (a.mode or 'obtain')~=(b.mode or 'obtain') then return false end
 if (a.recipient or (a.deliver and 'player' or 'friend'))~=(b.recipient or (b.deliver and 'player' or 'friend')) then return false end
 local left,right=a.constraints or {},b.constraints or {}
 if type(left)~='table' or type(right)~='table' or (left.existing_only==true)~=(right.existing_only==true) then return false end
 if left.forbidden~=nil and type(left.forbidden)~='table' or right.forbidden~=nil and type(right.forbidden)~='table' then return false end
 local prohibited,other={},{}
 for _,action in ipairs(left.forbidden or {}) do prohibited[action]=true end
 for _,action in ipairs(right.forbidden or {}) do other[action]=true end
 for action in pairs(prohibited) do if not other[action] then return false end end
 for action in pairs(other) do if not prohibited[action] then return false end end
 local amounts={};for _,target in ipairs(a.targets) do if type(target)~='table' or type(target.item)~='string' then return false end;amounts[target.item]=target.quantity end
 for _,target in ipairs(b.targets) do if type(target)~='table' or amounts[target.item]~=target.quantity then return false end end
 return true
end
function M.Expand(inst,input,delivered)
 if type(input)~='table' or type(input.targets)~='table' or #input.targets<1 or #input.targets>3 or type(input.deliver)~='boolean' then return nil,'我没有弄清楚你需要哪些物品和数量。','unclear' end
 local spec={targets=input.targets,deliver=input.deliver,mode=input.mode or 'obtain',recipient=input.recipient or (input.deliver and 'player' or 'friend')}
 if input.reference~=nil then spec.reference=input.reference end
 if spec.mode~='obtain' and spec.mode~='materials' and spec.mode~='craft' then return nil,'我还不支持这种完成方式。','unsupported' end
 if (spec.recipient~='player' and spec.recipient~='friend') or (spec.recipient=='player')~=spec.deliver then return nil,'这些东西是交给你，还是留在我这里？','unclear' end
 local constraints=input.constraints or {}
 if type(constraints)~='table' or constraints.existing_only~=nil and type(constraints.existing_only)~='boolean' then return nil,'我没有弄清楚你对材料的限制。','unclear' end
 local forbidden={};local allowed={pickup=true,pick=true,chop=true,mine=true,craft=true,tech=true}
 if constraints.forbidden~=nil and (type(constraints.forbidden)~='table' or #constraints.forbidden>6) then return nil,'我没有弄清楚禁止哪些动作。','unclear' end
 for _,action in ipairs(constraints.forbidden or {}) do if not allowed[action] then return nil,'我还不能保证这项限制。','unsupported' end;forbidden[action]=true end
 for key in pairs(constraints) do if key~='existing_only' and key~='forbidden' then return nil,'我还不能保证这项限制。','unsupported' end end
 spec.constraints={existing_only=constraints.existing_only==true,forbidden={}}
 for action in pairs(forbidden) do spec.constraints.forbidden[#spec.constraints.forbidden+1]=action end;table.sort(spec.constraints.forbidden)
 Resources.Observe(inst,inst.components.ybf_work:Position(),inst.components.ybf_work.radius)
 local seen,costs,clean={},{},{}
 for _,target in ipairs(spec.targets) do
  if type(target)~="table" then return nil,"我没有弄清楚目标物品。","unclear" end
  local item,n=target.item,target.quantity
  if type(item)~='string' or not item:match('^[a-z0-9_]+$') or #item>80 or item=='ybf_friendship_flower' or seen[item]
   or type(n)~='number' or n%1~=0 or n<1 or n>100 then return nil,'请说明物品以及1到100之间的数量。','unclear' end
  if not Knowledge.Known(inst,item) then return nil,'我还没有可靠识别出这个物品，请说明具体名字。','name_unknown' end
  seen[item]=true;clean[#clean+1]={item=item,quantity=n}
  if spec.mode=='materials' then
   local info,why=Crafting.PlanRecipe(inst,item)
   if not info then return nil,why,'unsupported' end
   for _,ingredient in ipairs(info.ingredients) do costs[ingredient.item]=(costs[ingredient.item] or 0)+ingredient.amount*math.ceil(n/info.output) end
  elseif spec.mode=='craft' and not Crafting.allowed[item] then return nil,'我理解你想制作'..Inventory.Label(item)..'，但目前还不会做它。','unsupported'
  elseif spec.mode=='obtain' and not Resources.CanAcquire(inst,item) and not Crafting.allowed[item] and Inventory.Count(inst,item,true)+(delivered and delivered[item] or 0)<n then
   local code=Knowledge.Capability(inst,item)
   return nil,'我认识'..Inventory.Label(item)..(code=='source_unsupported' and '，也知道来源，但已知的获取或加工方式还不在我能安全采集或制作的能力范围。' or '，但还没有确认我能使用的获取来源。')..'我现在持有'..Inventory.Count(inst,item,true)..'个。',code
  end
 end
 spec.targets=clean
 local targets=M.Copy(spec.targets)
 if spec.mode=='materials' then
  targets={};local names={};for name in pairs(costs) do names[#names+1]=name end;table.sort(names)
  for _,name in ipairs(names) do if costs[name]>100 then return nil,'这次所需材料超过我当前单项目100个的上限，请减少数量。','unsupported' end;targets[#targets+1]={item=name,quantity=costs[name]} end
 end
 if #targets==0 or #targets>6 then return nil,'这次材料种类超过当前处理范围。','unsupported' end
 return {spec=spec,targets=targets,forbidden=forbidden,existing_only=constraints.existing_only==true}
end
return M
