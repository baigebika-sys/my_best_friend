from pathlib import Path
root=Path(__file__).resolve().parents[1]
old=(root/'developer_tools/run_knowledge_r3_checks.py').read_text();a=old.index('D={}');b=old.index('server=bridge.BridgeServer',a)
D={}
def goal(t,item):D[t]=dict(intent='command_goal',action='goal',dialogue='我核对材料和位置。',item=item,quantity=1 if isinstance(item,str)else None,deliver=False,mode='craft')
goal('在附近建一个木牌','homesign')
goal('请建一个木牌','homesign')
goal('挑个合适的空地搭一座木牌','homesign');D['挑个合适的空地搭一座木牌']['placement']={'mode':'free'}
goal('在我指定的位置建一个木牌','homesign')
goal('按脚下地皮中心建一个避雷针','lightning_rod')
goal('按这格中心建一个木牌','homesign')
goal('按这两格中间建一个木牌','homesign')
goal('按这四格交点建一个木牌','homesign')
goal('附近建一个晾肉架和一把鹤嘴锄',[dict(item='meatrack',quantity=1),dict(item='pickaxe',quantity=1)])
goal('造1个木牌','homesign');D['造1个木牌']['placement']={'mode':'free'}
goal('建造木牌','homesign');D['建造木牌']['placement']={'mode':'free'}
goal('在我这建一个木牌','homesign');D['在我这建一个木牌']['placement']={'mode':'free'}
goal('在我脚下造一个木牌','homesign');D['在我脚下造一个木牌']['placement']={'mode':'free'}
D['木牌怎么制作']=dict(intent='query_knowledge',action='knowledge',dialogue='我核对一下。',item=dict(name='homesign',kind='recipe'),quantity=None)
source=old[:a]+'D='+repr(D)+'\n'+old[b:]
source=source.replace("(root/'tests/test_knowledge_r3.lua').read_text()", "(root/'tests/test_v0160_language.lua').read_text()")
source=source.replace("source=setup+'\\nlocal LANGUAGE_FIXTURES='", "source=setup+'\\n'+(root/'tests/test_v0150_warehouse.lua').read_text()+'\\n'+(root/'tests/test_v0160_building.lua').read_text()+'\\nlocal LANGUAGE_FIXTURES='")
source=source.replace("harness=harness.replace('function h:last()", "harness=harness.replace('local request=pending[#pending];assert(request.packet.message==text)', 'local request=pending[#pending];if not request or request.packet.message~=text then return end')\nharness=harness.replace('function h:last()")
source=source.replace('state=lib.luaL_newstate();lib.luaL_openlibs(state)', '''source=source.replace('local request=pending[#pending];if text==\"开启知识诊断\" or text==\"关闭知识诊断\" then return end;assert(request.packet.message==text)', 'local request=pending[#pending];if not request or request.packet.message~=text then return end')
state=lib.luaL_newstate();lib.luaL_openlibs(state)''')
exec(compile(source,str(root/'developer_tools/run_knowledge_r3_checks.py'),'exec'),{'__file__':str(root/'developer_tools/run_knowledge_r3_checks.py'),'__name__':'__main__'})
