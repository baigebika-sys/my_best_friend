-- Temporary playercontroller interception; never invokes player crafting.
local M={};local function hint(text)
 if ThePlayer and ThePlayer.components.talker then ThePlayer.components.talker:Say(text)end
end
function M.Clear()
 M.pending=nil
 local ghost=M.ghost;M.ghost=nil
 if ghost then pcall(function()if ghost:IsValid()then ghost:Remove()end end)end
end
function M.Preview(d)
 local r=GetValidRecipe(d.recipe)
 if not r or type(r.placer)~='string' then return false end
 local ghost=SpawnPrefab(r.placer)
 if not ghost or not ghost.components.placer then if ghost then ghost:Remove()end;return false end
 M.ghost=ghost
 local placer=ghost.components.placer
 -- Independent native placer: never attach to playercontroller.placer or craft.
 placer:SetBuilder(ThePlayer,r)
 placer.testfn=function(pt,rot)return TheWorld.Map:CanDeployRecipeAtPoint(pt,r,rot,Ents[d.friend] or ThePlayer)end
 local update=placer.OnUpdate
 placer.OnUpdate=function(self,dt)
  if M.pending~=d then return end
  self.fixedcameraoffset=TheCamera:GetHeading()+d.rotation;self.rotationoffset=0;self.fixedcameraoffset_nearestangle=nil
  return update(self,dt)
 end
 ghost:DoTaskInTime(90,function()if M.pending==d then M.Clear();hint('点选已过期，请重新指定位置。')end end)
 return true
end
function M.Marker(d)
 if not SpawnPrefab or not d.x then return end
 local marker=SpawnPrefab('ybf_build_marker')
 if marker then marker.Transform:SetPosition(d.x,0,d.z);marker.Transform:SetRotation(d.rotation or 0);marker:DoTaskInTime(6,function()if marker:IsValid()then marker:Remove()end end)end
 hint(d.text or '位置已记录')
end
function M.Begin(d)
 M.Clear();M.pending=d;d.expires=GetTime()+90;d.rotation=d.rotation or 0
 local screen=TheFrontEnd and TheFrontEnd:GetActiveScreen()
 if screen and screen.name=='YBFChatScreen' then TheFrontEnd:PopScreen()end
 local ok,result=pcall(M.Preview,d)
 if not ok or not result then M.Clear();hint('建筑预览无法加载，已退出点选；请重新指定位置。');SendModRPCToServer(GetModRPC('my_best_friend','build_point'),d.friend,d.task,d.target,d.nonce,0,0,d.rotation,true);return end
 hint(d.text)
end
function M.Submit(cancel)
 local d=M.pending;if not d then return end
 if not cancel and M.ghost then M.ghost.components.placer:OnUpdate(0) end
 local p=not cancel and (M.ghost and M.ghost:GetPosition() or TheInput:GetWorldPosition())or {x=0,z=0}
 M.Clear()
 SendModRPCToServer(GetModRPC('my_best_friend','build_point'),d.friend,d.task,d.target,d.nonce,p.x,p.z,d.rotation,cancel==true)
end
function M.Hook(controller)
 local left,right,control=controller.OnLeftClick,controller.OnRightClick,controller.OnControl
 local swallow={}
 local function active()if M.pending and GetTime()>M.pending.expires then M.Clear();hint('点选已过期，请重新请求指定位置。')end;return controller.inst==ThePlayer and M.pending~=nil end
 controller.OnLeftClick=function(self,down)
  if not down and swallow.left then swallow.left=nil;return true end
  if active()then if down then swallow.left=true
   if TheFrontEnd and TheFrontEnd:GetActiveScreen()~=ThePlayer.HUD or TheInput:GetHUDEntityUnderMouse()then return true end
   M.Submit(false)
  end;return true end
  return left(self,down)
 end
 controller.OnRightClick=function(self,down)
  if not down and swallow.right then swallow.right=nil;return true end
  if active()then if down then swallow.right=true;M.Submit(true)end;return true end
  return right(self,down)
 end
 controller.OnControl=function(self,c,down)
  if active()then
   if c==CONTROL_CANCEL then if down then M.Submit(true)end;return true end
   if c==CONTROL_ROTATE_LEFT or c==CONTROL_ROTATE_RIGHT then if down then M.pending.rotation=(M.pending.rotation+(c==CONTROL_ROTATE_LEFT and -45 or 45))%360;hint('施工朝向：'..M.pending.rotation..'°')end;return true end
   if c==CONTROL_PRIMARY then return self:OnLeftClick(down)end
   if c==CONTROL_SECONDARY then return self:OnRightClick(down)end
  end
  return control(self,c,down)
 end
end

function M.Cancel(d)
 if M.pending and M.pending.friend==d.friend and M.pending.task==d.task then M.Clear() end
end
function M.HookHUD(hud)
 local original=hud.OnControl;local swallow={}
 hud.OnControl=function(self,c,down)
  if not down and swallow[c]then swallow[c]=nil;return true end
  if M.pending and self.owner==ThePlayer and (c==CONTROL_PAUSE or c==CONTROL_CANCEL)then
   if down then swallow[c]=true;M.Submit(true)end;return true
  end
  return original(self,c,down)
 end
end

return M
