APP_VERSION='756039';Prefabs={homesign={},meatrack={},lightning_rod={},pickaxe={}}
for _,r in pairs(AllRecipes)do if r.placer then STRINGS.NAMES[r.product:upper()]=r.product=='homesign' and '木牌' or r.product=='meatrack' and '晾肉架' or r.product=='lightning_rod' and '避雷针' or nil end end
local h=harness();supply('homesign');h:send('在附近建一个木牌');assert(w.core.job,h:last());assert(w.core.job.builds.homesign.mode=='free');run();assert(#built==1)
h=harness();supply('homesign');h:send('挑个合适的空地搭一座木牌');assert(w.core.job,h:last());assert(w.core.job.builds.homesign.mode=='free');run();assert(#built==1)
h=harness();supply('homesign');h:send('请建一个木牌');assert(w.core.job,h:last());run();assert(w.core.job.builds.homesign.mode=='choose' and buffers==0);h:send('附近找个地方建');run();assert(#built==1)
h=harness();supply('homesign');h:send('在我指定的位置建一个木牌');assert(w.core.job,h:last());tick();local j=w.core.job;local b=j.builds.homesign;assert(b.mode=='fixed' and b.pick);assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,8,8,90,false));owner.x=22;run();assert(b.placed[1].x==8 and b.placed[1].z==8)
for _,case in ipairs({{'按脚下地皮中心建一个避雷针','lightning_rod',3,1,'cell'},{'按这格中心建一个木牌','homesign',3,0,'cell'},{'按这两格中间建一个木牌','homesign',3.8,2,'edge'},{'按这四格交点建一个木牌','homesign',3.8,3.8,'corner'}})do
 h=harness();supply(case[2]);owner.x=case[3];owner.z=case[4];local req=h:send(case[1],true);owner.x=18;owner.z=18;h:finish(req);assert(w.core.job,h:last());local b=w.core.job.builds[case[2]];assert(b.position and b.position.kind==case[5]);run();assert(#b.placed==1)
end
h=harness();supply('meatrack');put(friend,'twigs',2);put(friend,'flint',2);h:send('附近建一个晾肉架和一把鹤嘴锄');assert(w.core.job,h:last());assert(#w.core.job.targets==2);run();assert(#built==1 and Inventory.Count(friend,'pickaxe',true)==1)
h=harness();h:send('木牌怎么制作');assert(not w.core.job and h:last():find('木板',1,true))
print('PASS 10 natural building messages: free/fixed/no-mode/tile single/edge/corner/mixed/read-only through real HTTP decoder and production chat entry, captured origin before model delay; model/world simulated')
