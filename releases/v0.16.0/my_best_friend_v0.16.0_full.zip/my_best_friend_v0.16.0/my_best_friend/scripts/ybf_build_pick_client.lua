-- Temporary playercontroller interception; never invokes player crafting.
local M={};local function hint(text)
 if ThePlayer and ThePlayer.components.talker then ThePlayer.components.talker:Say(text)end
end
function M.Marker(d)
 if not SpawnPrefab or not d.x then return end
 local marker=SpawnPrefab('ybf_build_marker')
 if marker then marker.Transform:SetPosition(d.x,0,d.z);marker.Transform:SetRotation(d.rotation or 0);marker:DoTaskInTime(6,function()if marker:IsValid()then marker:Remove()end end)end
 hint(d.text or '位置已记录')
end
function M.Begin(d)
 M.pending=d;d.expires=GetTime()+90;d.rotation=d.rotation or 0
 local screen=TheFrontEnd and TheFrontEnd:GetActiveScreen()
 if screen and screen.name=='YBFChatScreen' then TheFrontEnd:PopScreen()end
 hint(d.text)
end
function M.Submit(cancel)
 local d=M.pending;if not d then return end
 M.pending=nil
 local p=not cancel and TheInput:GetWorldPosition()or {x=0,z=0}
 SendModRPCToServer(GetModRPC('my_best_friend','build_point'),d.friend,d.task,d.target,d.nonce,p.x,p.z,d.rotation,cancel==true)
end
function M.Hook(controller)
 local left,right,control=controller.OnLeftClick,controller.OnRightClick,controller.OnControl
 local swallow={}
 local function active()if M.pending and GetTime()>M.pending.expires then M.pending=nil;hint('点选已过期，请重新请求指定位置。')end;return controller.inst==ThePlayer and M.pending~=nil end
 controller.OnLeftClick=function(self,down)
  if not down and swallow.left then swallow.left=nil;return true end
  if active()then if down then swallow.left=true
   if TheFrontEnd and TheFrontEnd:GetActiveScreen()~=ThePlayer.HUD or TheInput:GetHUDEntityUnderMouse()then return true end
   M.Submit(false)
  end;return true end
  return left(self,down)
 end
 controller.OnRightClick=function(self,down)
  if not down and swallow.right then swallow.right=nil;return true end
  if active()then if down then swallow.right=true;M.Submit(true)end;return true end
  return right(self,down)
 end
 controller.OnControl=function(self,c,down)
  if active()then
   if c==CONTROL_CANCEL then if down then M.Submit(true)end;return true end
   if c==CONTROL_ROTATE_LEFT or c==CONTROL_ROTATE_RIGHT then if down then M.pending.rotation=(M.pending.rotation+(c==CONTROL_ROTATE_LEFT and -45 or 45))%360;hint('施工朝向：'..M.pending.rotation..'°')end;return true end
   if c==CONTROL_PRIMARY then return self:OnLeftClick(down)end
   if c==CONTROL_SECONDARY then return self:OnRightClick(down)end
  end
  return control(self,c,down)
 end
end

function M.Cancel(d)
 if M.pending and M.pending.friend==d.friend and M.pending.task==d.task then M.pending=nil end
end
function M.HookHUD(hud)
 local original=hud.OnControl;local swallow={}
 hud.OnControl=function(self,c,down)
  if not down and swallow[c]then swallow[c]=nil;return true end
  if M.pending and self.owner==ThePlayer and (c==CONTROL_PAUSE or c==CONTROL_CANCEL)then
   if down then swallow[c]=true;M.Submit(true)end;return true
  end
  return original(self,c,down)
 end
end

return M
