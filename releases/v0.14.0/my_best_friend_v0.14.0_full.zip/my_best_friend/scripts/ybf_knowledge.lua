-- Runtime facts and conservative capability rules. Never instantiate prefabs,
-- run prefab factories, GenerateLoot/lootsetupfn, or recipe callbacks for discovery.
local M={}
M.craft_allowed={axe=true,pickaxe=true,cutstone=true,boards=true,rope=true,torch=true}
local aliases={twigs={'树枝','枝条'},cutgrass={'草','割下的草'},log={'木头','原木'},rocks={'石头','岩石'},flint={'燧石'},goldnugget={'金子','金块'},axe={'斧头','斧子'},pickaxe={'鹤嘴锄','镐子'},cutstone={'石砖'},boards={'木板'},rope={'绳子'},torch={'火把'},bonestew={'炖肉汤','肉汤'},petals={'花瓣'}}
-- Explicit fallbacks retain the tested basic capabilities before first sighting.
local basic={twigs=true,cutgrass=true,log=true,rocks=true,flint=true,goldnugget=true}
local trees={evergreen=true,evergreen_sparse=true,deciduoustree=true,twiggytree=true}
local function id(s)return type(s)=='string' and #s<=80 and s:match('^[a-z0-9_]+$')~=nil end
local function text(s,fallback)return type(s)=='string' and #s<=120 and s or fallback end
local function tag(e,t)return e:HasTag(t)end
function M.Aliases(prefab)return aliases[prefab]end
function M.Label(prefab)
 local names=STRINGS and STRINGS.NAMES or {}
 return text(names[string.upper(prefab)],aliases[prefab] and aliases[prefab][1] or prefab)
end
local function state(inst)
 if not inst._ybf_knowledge then inst._ybf_knowledge={observed={},order={},items={}} end
 return inst._ybf_knowledge
end
function M.DisplayName(inst,prefab)
 local e=state(inst).items[prefab]
 if e and e:IsValid() and e.GetDisplayName then
  local ok,name=pcall(e.GetDisplayName,e)
  if ok and type(name)=='string' and #name>0 and #name<=120 and name~=prefab then return name end
 end
 return M.Label(prefab)
end
function M.Known(inst,prefab)
 if not id(prefab) then return false end
 local s=state(inst)
 if basic[prefab] or M.craft_allowed[prefab] or s.items[prefab] or s.observed[prefab] then return true end
 if Prefabs and Prefabs[prefab] then return true end
 for name,r in pairs(AllRecipes or {}) do
  if name==prefab or r.product==prefab then return true end
  for _,v in ipairs(r.ingredients or {}) do if v.type==prefab then return true end end
 end
 return false
end
function M.Catalog(inst)
 local out={}
 for name in pairs(Prefabs or {}) do if id(name) then out[name]=true end end
 for name,r in pairs(AllRecipes or {}) do
  if id(name) then out[name]=true end
  if id(r.product) then out[r.product]=true end
  for _,v in ipairs(r.ingredients or {}) do if id(v.type) then out[v.type]=true end end
 end
 for name in pairs(basic) do out[name]=true end
 for name in pairs(M.craft_allowed) do out[name]=true end
 for name in pairs(state(inst).items) do out[name]=true end
 for name in pairs(state(inst).observed) do out[name]=true end
 return out
end
function M.Names(inst,query)
 local matches={};if type(query)~='string' then return matches end
 for prefab in pairs(M.Catalog(inst)) do
  local yes=query==prefab or query==M.Label(prefab) or query==M.DisplayName(inst,prefab)
  for _,alias in ipairs(aliases[prefab] or {}) do yes=yes or query==alias end
  if yes then matches[#matches+1]=prefab end
 end
 table.sort(matches);return matches
end
-- Literal current-language/alias mentions only; typo/colloquial interpretation is
-- left to the model. Equal displayed names remain an ambiguity, not an ID.
function M.Mentions(inst,message)
 local names={};local longest=0
 for prefab in pairs(M.Catalog(inst)) do
  local options={M.Label(prefab),M.DisplayName(inst,prefab),prefab}
  for _,alias in ipairs(aliases[prefab] or {}) do options[#options+1]=alias end
  for _,name in ipairs(options) do
   if #name>=2 and message:find(name,1,true) then
    if #name>longest then names={};longest=#name end
    if #name==longest then names[prefab]=true end
   end
  end
 end
 local out={};for name in pairs(names) do out[#out+1]=name end;table.sort(out);return out
end
function M.Resolve(inst,query,message)
 local candidates=M.Names(inst,query)
 if #candidates==0 then return nil,'name_unknown',{} end
 if #candidates>1 then return nil,'name_ambiguous',candidates end
 local mentions=message and M.Mentions(inst,message) or {}
 for _,name in ipairs({M.Label(candidates[1]),M.DisplayName(inst,candidates[1])}) do
  if message and not message:find(candidates[1],1,true) and message:find(name,1,true) and #M.Names(inst,name)>1 then
   return nil,'name_ambiguous',M.Names(inst,name)
  end
 end
 if #mentions>1 then
  -- Several explicit prefabs are unambiguous; duplicate language names are not.
  for _,other in ipairs(mentions) do
   if other~=candidates[1] and M.Label(other)==M.Label(candidates[1]) and not message:find(candidates[1],1,true) then
    return nil,'name_ambiguous',mentions
   end
  end
 end
 return candidates[1]
end
function M.Safe(e)
 return e and e:IsValid() and not e:IsInLimbo() and not tag(e,'irreplaceable') and not tag(e,'NOCLICK')
  and not tag(e,'fire') and not tag(e,'intense') and not (e.components.burnable and e.components.burnable:IsBurning())
end
local function ordinary(e)
 local c=e.components
 return M.Safe(e) and not tag(e,'monster') and not tag(e,'hostile') and not tag(e,'thorny')
  and not tag(e,'trap') and not tag(e,'structure') and not tag(e,'character')
  and not tag(e,'heavy') and not tag(e,'wall') and not tag(e,'sculpture') and not tag(e,'statue')
  and not c.combat and not c.health and not c.container and not c.trap and not c.explosive
  and not c.prototyper and not e.monster and not e.monster_start_task and not e.dostartmonster_task
  and not tag(e,'burnt') and not tag(e,'stump')
end
local function loot(c)
 local out={}
 if not c or c.lootsetupfn then return out,'dynamic_loot_unknown' end
 local function add(p)if id(p) then out[p]=true end end
 for _,p in ipairs(c.loot or {}) do add(p) end
 for _,v in ipairs(c.chanceloot or {}) do if (v.chance or 0)>0 then add(v.prefab) end end
 for _,v in ipairs(c.randomloot or {}) do if (v.weight or 0)>0 and (c.numrandomloot or 0)>0 and (c.chancerandomloot or 1)>0 then add(v.prefab) end end
 for _,v in ipairs((LootTables or {})[c.chanceloottable] or {}) do if (v[2] or 0)>0 then add(v[1]) end end
 return out
end
local function sourcefacts(inst,e)
 local out={};if not M.Safe(e) or e.prefab=='ybf_friendship_flower' then return out end
 local c=e.components
 local function add(product,action,supported,reason)
  if id(product) and product~='ybf_friendship_flower' then
   out[#out+1]={product=product,object=e.prefab,action=action,tool=action=='chop' and 'axe' or action=='mine' and 'pickaxe' or nil,
    supported=supported,reason=reason,evidence='component_fact',available=false}
  end
 end
 if c.inventoryitem and not c.inventoryitem.owner and c.inventoryitem.canbepickedup then
  add(e.prefab,'pickup',ordinary(e) and not tag(e,'heavy') and not c.inventoryitem.isheavy,'special_object')
  if #out>0 then out[#out].available=out[#out].supported end
 end
 local p=c.pickable
 if p then
  local standard=id(p.product) and p.product~='ybf_friendship_flower' and not p.use_lootdropper_for_product and not p.getproductfn
  local supported=standard and ordinary(e) and not p.requirespecialtool and not p.requiredtool and not p.requiredtag and not p.restrictedtag
  if standard then
   add(p.product,'pick',supported,supported and nil or 'special_object')
   out[#out].available=supported and p.caninteractwith~=false and p:CanBePicked() and not (p.IsStuck and p:IsStuck()) or false
  elseif p.use_lootdropper_for_product then
   for product in pairs(loot(c.lootdropper)) do add(product,'pick',false,'dynamic_product_unknown') end
  end
 end
 local w=c.workable
 if w and w:CanBeWorked() then
  local action=w:GetWorkAction()
  if action==ACTIONS.CHOP or action==ACTIONS.MINE then
   local products=loot(c.lootdropper)
   -- Dynamic ordinary trees retain the verified log-only adapter; do not
   -- infer other dynamic drops by executing the drop callback.
   if action==ACTIONS.CHOP and trees[e.prefab] then products.log=true end
   products.ybf_friendship_flower=nil
   for product in pairs(products) do
    local step=action==ACTIONS.CHOP and 'chop' or 'mine'
    local supported=ordinary(e) and (step=='mine' and not tag(e,'tree') or step=='chop' and tag(e,'tree'))
    add(product,step,supported,supported and nil or 'special_object');out[#out].available=supported
   end
  end
 end
 return out
end
function M.Sources(inst,e)
 local ok,result=pcall(sourcefacts,inst,e)
 if ok then return result end
 print('[YBF KNOWLEDGE] category=source_unknown object='..tostring(e and e.prefab)..' reason=component_read_failed')
 return {}
end
function M.Observe(inst,entities)
 local s=state(inst)
 for _,e in ipairs(entities) do
  if M.Safe(e) then
   if id(e.prefab) and not s.items[e.prefab] then s.items[e.prefab]=e end
   for _,v in ipairs(M.Sources(inst,e)) do
    if not s.observed[v.product] then
     if #s.order>=256 then local old=table.remove(s.order,1);s.observed[old]=nil end
     s.order[#s.order+1]=v.product;s.observed[v.product]={}
    end
    local list=s.observed[v.product];local key=v.object..':'..v.action
    local count=0;for _ in pairs(list) do count=count+1 end
    if count<4 or list[key] then list[key]={product=v.product,object=v.object,action=v.action,tool=v.tool,supported=v.supported,reason=v.reason,evidence=v.evidence} end
    -- Positions are never global knowledge: only this actual perception.
   end
  end
 end
end
function M.ObserveInventory(inst)
 local Inventory=require('ybf_work_inventory');local s=state(inst);s.items={}
 for _,e in ipairs(Inventory.Items(inst,true)) do s.items[e.prefab]=e end
end
function M.CanAcquire(inst,prefab)
 if basic[prefab] then return true end
 for _,v in pairs(state(inst).observed[prefab] or {}) do if v.supported then return true end end
 return false
end
function M.Capability(inst,prefab)
 if not M.Known(inst,prefab) then return 'name_unknown' end
 if M.CanAcquire(inst,prefab) then return 'supported_acquisition' end
 if M.craft_allowed[prefab] then return 'supported_crafting_with_conditions' end
 for name,r in pairs(AllRecipes or {}) do if name==prefab or r.product==prefab then return 'source_unsupported' end end
 local sources=state(inst).observed[prefab]
 return sources and next(sources) and 'source_unsupported' or 'source_unknown'
end
function M.Recipes(inst,prefab)
 local out={};local builder=inst.components.builder
 for name,r in pairs(AllRecipes or {}) do
  if name==prefab or r.product==prefab then
   out[#out+1]={id=name,product=r.product,output=type(r.numtogive)=='number' and not r.override_numtogive_fn and r.numtogive or nil,
    output_unknown=r.override_numtogive_fn~=nil,ingredients={},technology={},supported=M.craft_allowed[name]==true and not r.placer and not r.dropitem and not r.manufactured,
    facility_unknown=r.manufactured~=nil and r.manufactured~=false,placement=r.placer~=nil,evidence='recipe_data',
    character_condition_unknown=true,special_conditions_unknown=r.canbuild~=nil or r.character_ingredients~=nil}
   local row=out[#out]
   for i,v in ipairs(r.ingredients or {}) do if i<=12 then row.ingredients[#row.ingredients+1]={item=v.type,amount=v.amount,friend_amount=type(v.amount)=='number' and builder and type(builder.ingredientmod)=='number' and RoundBiasedUp and math.max(1,RoundBiasedUp(v.amount*builder.ingredientmod)) or nil,evidence='recipe_data'} end end
   for key,v in pairs(r.level or {}) do if type(v)=='number' and v>0 then row.technology[key]=v end end
   if builder and builder.KnowsRecipe then local ok,result=pcall(builder.KnowsRecipe,builder,r);if ok then row.unlocked=result==true end end
   if builder and builder.CanLearn then local ok,result=pcall(builder.CanLearn,builder,name);if ok then row.can_learn=result==true;row.character_condition_unknown=false end end
   if #out>=4 then break end
  end
 end
 table.sort(out,function(a,b)return a.id<b.id end);return out
end
function M.Entry(inst,prefab)
 local s=state(inst);local e=s.items[prefab]
 local row={prefab=prefab,name=M.DisplayName(inst,prefab),aliases=aliases[prefab],category='unknown',facts={},derived={},unknown={'完整用途','未观察对象的组件属性'},recipes=M.Recipes(inst,prefab),sources={},capability=M.Capability(inst,prefab)}
 for _,v in pairs(s.observed[prefab] or {}) do if #row.sources<4 then row.sources[#row.sources+1]=v end end
 for _,r in ipairs(row.recipes) do if #row.sources<4 then row.sources[#row.sources+1]={product=prefab,object=r.id,action='craft',supported=r.supported,evidence='recipe_data'} end end
 if e and e:IsValid() then
  local c=e.components
  if c.pickable and id(c.pickable.product) and not c.pickable.use_lootdropper_for_product then row.facts.pick_product=c.pickable.product;row.category='harvestable_object' end
  if c.edible then
   row.category='food';local Info=require('ybf_supply_info');local ok,d=pcall(Info.Describe,inst,e)
   if ok and d.known then row.facts.food_effects=d.effects;row.facts.can_eat=d.can_eat;row.facts.freshness=d.freshness;row.facts.food_basis='当前朋友实际食物组件估算，使用后核对状态' end
  end
  if c.tool then
   row.category='tool';row.facts.tool_actions={}
   for _,name in ipairs({'CHOP','MINE','DIG','HAMMER'}) do
    local action=ACTIONS[name]
    if action then
     local ok,value=pcall(c.tool.GetEffectiveness,c.tool,action)
     local usable=true
     if c.tool.CanDoAction then local read,can=pcall(c.tool.CanDoAction,c.tool,action);usable=read and can==true end
     if ok and type(value)=='number' and value>0 and usable then row.facts.tool_actions[#row.facts.tool_actions+1]={action=name,effectiveness=value,supported=name=='CHOP' or name=='MINE'} end
    end
   end
  end
  if c.equippable then row.facts.equipment_slot=c.equippable.equipslot end
  if c.finiteuses and c.finiteuses.GetUses then local ok,uses=pcall(c.finiteuses.GetUses,c.finiteuses);if ok and type(uses)=='number' then row.facts.remaining_uses=uses end end
 end
 if #row.recipes>0 then row.derived.has_recipe=true;if row.category=='unknown' then row.category='recipe_product' end end
 row.facts.evidence='observed_component_or_recipe';row.derived.evidence='bounded_rule'
 return row
end
function M.CandidateText(candidates)
 local out={};for i=1,math.min(4,#candidates) do out[#out+1]=candidates[i] end
 return table.concat(out,'、')..(#candidates>4 and '等多个对象' or '')
end
function M.Answer(inst,query,kind,message)
 local prefab,reason,candidates=M.Resolve(inst,query,message)
 if not prefab then
  print('[YBF KNOWLEDGE] category='..reason)
  if reason=='name_ambiguous' then return '这个名字对应不止一种东西，请说明具体是哪一种（'..M.CandidateText(candidates)..'）。' end
  return '我还没有可靠识别出这个物品，请告诉我更明确的名字。'
 end
 local row=M.Entry(inst,prefab);local parts={row.name..'：'}
 print('[YBF KNOWLEDGE] query='..kind..' item='..prefab..' capability='..row.capability..' recipes='..#row.recipes)
 if kind~='recipe' then
  local f=row.facts
  if f.pick_product then parts[#parts+1]='我实际观察到它的普通采摘产物是'..M.Label(f.pick_product)..'；是否允许采摘还要检查对象状态。' end
  if f.food_effects then parts[#parts+1]=string.format('按我实际观察到的这份食物和我的当前吸收效果，每份估计饥饿%g、生命%g、精神%g；实际效果吃后核对。',f.food_effects.hunger,f.food_effects.health,f.food_effects.sanity) end
  for _,a in ipairs(f.tool_actions or {}) do parts[#parts+1]='工具可以用于'..({CHOP='砍伐',MINE='开采',DIG='挖掘',HAMMER='敲拆'})[a.action]..(a.supported and '。' or '，但我还不执行这类工作。') end
  if f.equipment_slot then parts[#parts+1]='它是可以装备的物品。' end
 end
 for _,r in ipairs(row.recipes) do
  local costs={};for _,v in ipairs(r.ingredients) do costs[#costs+1]=tostring(v.amount)..'个'..M.Label(v.item) end
  parts[#parts+1]='游戏配方记录：'..table.concat(costs,'、')..(r.output and '，每次产出'..r.output..'个。' or '；实际产出有动态规则，目前不能确定。')
  local tech={};local names={SCIENCE='科学',MAGIC='魔法',ANCIENT='远古',SEAFARING='航海',CELESTIAL='天体',MOON_ALTAR='月亮祭坛',SHADOW='暗影'}
  for key,value in pairs(r.technology) do tech[#tech+1]=(names[key] or '特殊科技')..value..'级' end
  if #tech>0 then parts[#parts+1]='科技要求为'..table.concat(tech,'、')..'。' end
  if r.can_learn~=nil then parts[#parts+1]=r.can_learn and '我的角色允许学习；材料和当前位置科技仍需执行前检查。' or '我的角色目前不允许学习这个配方。' end
  if r.special_conditions_unknown then parts[#parts+1]='这个配方还有特殊条件，我没有完整读取，不能仅凭普通材料保证可做。' end
  if not r.supported then parts[#parts+1]='我知道这个配方，但目前的制作执行器还不支持它。' end
 end
 if #parts==1 then parts[#parts+1]='我认识这个名字，但还没有观察到可可靠读取的属性或配方，不能确定它的用途。' end
 if kind=='sources' then
  for _,v in ipairs(row.sources) do
   if v.evidence=='recipe_data' then parts[#parts+1]='配方表记录了制作'..M.Label(v.product)..'的加工方式'..(v.supported and '；执行前仍需检查材料和科技。' or '；目前的执行器还不支持它。')
   else parts[#parts+1]='我实际见过的来源是'..M.Label(v.object)..(v.supported and '，可用普通采集流程；现在是否可用还要在附近重新检查。' or '，但该对象还不在我的获取能力内。') end
  end
  if #row.sources==0 then parts[#parts+1]='我还没确认过它的获取来源。' end
 end
 local answer=table.concat(parts)
 if #answer>570 then
  local limit=540
  while limit>0 and answer:byte(limit+1)>=128 and answer:byte(limit+1)<192 do limit=limit-1 end
  answer=answer:sub(1,limit)..'。其他细节可再问我。'
 end
 return answer
end
-- Small relevant packet: <=8 item entries, <=12 local sources, never entire catalog.
function M.Context(inst,message,entities)
 M.ObserveInventory(inst);M.Observe(inst,entities)
 local names=M.Mentions(inst,message or '');local selected={};local seen={}
 local function add(name)if id(name) and not seen[name] and #selected<8 then seen[name]=true;selected[#selected+1]=M.Entry(inst,name) end end
 for _,name in ipairs(names) do add(name) end
 local j=inst.components.ybf_work and inst.components.ybf_work.core.job
 for _,target in ipairs(j and j.targets or {}) do add(target.item) end
 local sources={}
 for _,e in ipairs(entities) do
  for _,v in ipairs(M.Sources(inst,e)) do
   if #sources<12 and (#names==0 or seen[v.product] or seen[v.object]) then
    local x,_,z=e.Transform:GetWorldPosition();v.position={x=x,z=z};v.position_basis='当前朋友实际感知';sources[#sources+1]=v;add(v.product)
   end
  end
 end
 local ambiguous={}
 for i=1,math.min(8,#names) do ambiguous[#ambiguous+1]=names[i] end
 return {entries=selected,nearby_sources=sources,ambiguous_names=#names>1 and ambiguous or nil,ambiguous_count=#names>1 and #names or nil,limits={items=8,sources=12,recipes_per_item=4},unknown_policy='未知不是确定事实；位置不来自名称或配方表'}
end
return M
