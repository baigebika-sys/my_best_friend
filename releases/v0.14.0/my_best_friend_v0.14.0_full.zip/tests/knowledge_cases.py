"""Preset provider responses: these do not validate real language understanding."""
from language_cases import goal,reply
CASES={
 '帮我采集2个花瓣给我':goal('petals',2),
 '帮我采集2个浆果给我':goal('berries',2),
 '帮我采1个自定义果实给我':goal('modfruit',1),
 '花瓣有什么用途':reply('query_knowledge','knowledge',{'name':'花瓣','kind':'properties'}),
 '浆果有什么效果':reply('query_knowledge','knowledge',{'name':'浆果','kind':'properties'}),
 '斧头能做什么':reply('query_knowledge','knowledge',{'name':'斧头','kind':'properties'}),
 '石砖怎么制作':reply('query_knowledge','knowledge',{'name':'石砖','kind':'recipe'}),
 '帮我收集1个特殊果实给我':goal('specialfruit',1),
 '帮我弄1个不存在物品':goal('made_up_thing',1),
 '帮我采集1个同名果实':goal('fruit_a',1),
 '取消这个任务':reply('command_cancel','cancel',reference='current'),
 '帮我收集1个树枝给我':goal('twigs',1),
}
