-- No unverifiable mirror or model-memory encyclopedia is shipped as official data.
-- Replace through developer_tools/import_dst_knowledge.py using your game files.
return {manifest={schema=1,build=nil,status='awaiting_current_game_data',official_total=nil,
 source='none',coverage_complete=false,missing={'version.txt','data/scripts.zip','Chinese localization'}},entries={}}
