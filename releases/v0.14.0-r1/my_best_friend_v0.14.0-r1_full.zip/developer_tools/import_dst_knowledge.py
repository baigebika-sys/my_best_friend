"""Offline, non-executing DST data importer. Standard library only.
Never evaluates Lua, imports mods, spawns entities, or runs callbacks.
Incomplete/dynamic analysis is reported, never counted as complete knowledge.
"""
import argparse, hashlib, json, re, zipfile
from pathlib import Path

FACETS=('properties','uses','sources','recipes','mechanisms','behaviors','restrictions','variants')
ID=re.compile(r'^[a-z0-9_]{1,80}$')
TOKEN=re.compile(r'--\[(=*)\[.*?\]\1\]|--[^\n]*|\[(=*)\[.*?\]\2\]|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_][A-Za-z_0-9]*|\d+(?:\.\d+)?|\.\.|[^\s]',re.S)

def tokens(text):
    out=[];line=1;previous=0
    for m in TOKEN.finditer(text):
        line+=text.count('\n',previous,m.start());previous=m.start()
        if not m.group().startswith('--'):out.append((m.group(),m.start(),line))
    return out

def literal(s):
    if not isinstance(s,str):return None
    if s[:1] in ('"',"'") and s[-1:]==s[:1]:
        body=s[1:-1];out=[];i=0
        escapes={'a':'\a','b':'\b','f':'\f','n':'\n','r':'\r','t':'\t','v':'\v','\\':'\\','"':'"',"'":"'",'\n':'\n'}
        while i<len(body):
            if body[i]!='\\':out.append(body[i]);i+=1;continue
            i+=1
            if i>=len(body):return None
            if body[i] in escapes:out.append(escapes[body[i]]);i+=1
            elif body[i].isdigit():
                m=re.match(r'\d{1,3}',body[i:]);v=int(m[0])
                if v>255:return None
                out.append(chr(v));i+=len(m[0])
            elif body[i]=='z':
                i+=1
                while i<len(body) and body[i].isspace():i+=1
            else:return None
        return ''.join(out)
    m=re.fullmatch(r'\[(=*)\[(.*?)\]\1\]',s,re.S)
    if m:return m[2]
    if s=='true':return True
    if s=='false':return False
    if re.fullmatch(r'\d+(?:\.\d+)?',s):return float(s) if '.' in s else int(s)
    return None

def split_args(ts,at):
    if at>=len(ts) or ts[at][0]!='(':return [],at
    depth=0;parts=[];start=at+1
    for i in range(at,len(ts)):
        v=ts[i][0]
        if v in ('(','{','['):depth+=1
        elif v in (')','}',']'):
            depth-=1
            if depth==0:parts.append(ts[start:i]);return parts,i
        elif v==',' and depth==1:parts.append(ts[start:i]);start=i+1
    return [],at

def value(ts):return literal(ts[0][0]) if len(ts)==1 else None

def table(ts):
    """Partial literal table. Expressions are explicitly absent, not evaluated."""
    if not ts or ts[0][0]!='{' or ts[-1][0]!='}':return None
    out={};i=1
    while i<len(ts)-1:
        key=ts[i][0]
        if i+1<len(ts) and ts[i+1][0]=='=':
            j=i+2;depth=0;k=j
            while k<len(ts)-1:
                t=ts[k][0]
                if t in ('{','(','['):depth+=1
                if t in ('}',')',']'):depth-=1
                if t==',' and depth==0:break
                k+=1
            seq=ts[j:k];v=table(seq) if seq and seq[0][0]=='{' else value(seq)
            if v is not None:out[key]=v
            i=k+1
        else:i+=1
    return out

def read_sources(source):
    if source.is_dir():
        files={p.relative_to(source).as_posix():p.read_bytes() for p in source.rglob('*') if p.is_file() and (p.suffix=='.lua' or p.name in ('chinese_s.po','chinese.po'))}
    else:
        with zipfile.ZipFile(source) as z:
            files={n:z.read(n) for n in z.namelist() if (n.endswith('.lua') or Path(n).name in ('chinese_s.po','chinese.po')) and not n.startswith('/') and '..' not in Path(n).parts}
    if not any('/prefabs/' in '/'+n for n in files):raise ValueError('Source has no prefabs directory; provide the complete official data/scripts.zip')
    return files

def po_names(text):
    rows={};context=None;field=None;record={}
    def flush():
        c=record.get('msgctxt','');name=record.get('msgstr','')
        m=re.fullmatch(r'STRINGS\.NAMES\.([A-Z0-9_]+)',c)
        if m and name and not record.get('fuzzy'):rows[m[1].lower()]=name
    for line in text.splitlines()+['']:
        if not line.strip():flush();record={};field=None;continue
        if line.startswith('#,') and 'fuzzy' in line:record['fuzzy']=True
        m=re.match(r'(msgctxt|msgid|msgstr)\s+(".*")$',line)
        if m:
            field=m[1]
            try:record[field]=json.loads(m[2])
            except json.JSONDecodeError:field=None
        elif line.startswith('"') and field:
            try:record[field]+=json.loads(line)
            except json.JSONDecodeError:pass
    return rows

def lua(v):
    if v is None:return 'nil'
    if v is True:return 'true'
    if v is False:return 'false'
    if isinstance(v,(float,int)):return repr(v)
    if isinstance(v,str):
        encoded=json.dumps(v,ensure_ascii=False).replace('\\/', '/')
        return re.sub(r'\\u00([0-9a-fA-F]{2})',lambda m:'\\'+str(int(m[1],16)).zfill(3),encoded)
    if isinstance(v,list):return '{'+','.join(lua(x) for x in v)+'}'
    return '{'+','.join('['+lua(str(k))+']='+lua(x) for k,x in sorted(v.items()))+'}'

def import_data(source,version_file,localization,adapters=None):
    raw_version=version_file.read_text(encoding='utf-8-sig').strip()
    if not re.fullmatch(r'\d{4,12}',raw_version):raise ValueError('version.txt must contain the actual numeric DST build, not a mod version')
    build=raw_version;files=read_sources(source);entries={};unresolved=[];sha={};texts={};english={};chinese={}
    def citation(path,line,certainty='candidate'):
        return {'kind':'official_script','path':path,'line':line,'sha256':sha[path],'version':build,'certainty':certainty}
    for path,raw in sorted(files.items()):
        sha[path]=hashlib.sha256(raw).hexdigest();text=raw.decode('utf-8-sig',errors='replace');texts[path]=text
        if Path(path).name in ('chinese_s.po','chinese.po'):chinese.update(po_names(text))
        if path.endswith('strings.lua'):
            ts=tokens(text)
            # Both STRINGS.NAMES.FOO assignments and a NAMES={...} table.
            for i,t in enumerate(ts):
                if t[0]=='NAMES' and i+2<len(ts) and ts[i+1][0]=='=' and ts[i+2][0]=='{':
                    depth=0
                    for j in range(i+2,len(ts)):
                        if ts[j][0]=='{':depth+=1
                        if ts[j][0]=='}':depth-=1
                        if depth==0:
                            english.update({k.lower():v for k,v in (table(ts[i+2:j+1]) or {}).items() if isinstance(v,str)});break
            for m in re.finditer(r'\bSTRINGS\.NAMES\.([A-Z0-9_]+)\s*=\s*("(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')',text):
                name=literal(m[2])
                if isinstance(name,str):english[m[1].lower()]=name
    if localization:
        raw=localization.read_bytes();path='provided/'+localization.name;sha[path]=hashlib.sha256(raw).hexdigest();chinese.update(po_names(raw.decode('utf-8-sig')))
    for path,text in texts.items():
        if not path.endswith('.lua'):continue
        ts=tokens(text);objects=[]
        for i,t in enumerate(ts):
            if t[0]!='Prefab' or i+1>=len(ts) or ts[i+1][0]!='(' or (i>0 and ts[i-1][0]=='function'):continue
            args,end=split_args(ts,i+1);name=value(args[0]) if args else None
            if not isinstance(name,str) or not ID.fullmatch(name):
                unresolved.append({'path':path,'line':t[2],'type':'dynamic_prefab_declaration','expression':' '.join(x[0] for x in (args[0] if args else []))[:200]});continue
            if name in entries:
                unresolved.append({'path':path,'line':t[2],'type':'duplicate_prefab_declaration','prefab':name});continue
            row={'prefab':name,'names':{},'aliases':[],'category':'unclassified','identity':citation(path,t[2],'verified'),'name_evidence':{},'knowledge_complete':False,**{f:[] for f in FACETS}}
            if name in english:row['names']['en']=english[name];row['name_evidence']['en']={'version':build,'certainty':'verified','kind':'official_strings','source_hashes':{p:h for p,h in sha.items() if p.endswith('strings.lua')}}
            if name in chinese:row['names']['zh']=chinese[name];row['name_evidence']['zh']={'version':build,'certainty':'verified','kind':'official_localization','source_hashes':{p:h for p,h in sha.items() if p.endswith('.po')}}
            entries[name]=row;objects.append(row)
        # File-scoped analysis is deliberately candidate-only: shared factories,
        # conditional branches and inherited state cannot be inferred reliably.
        components=sorted(set(re.findall(r'\bAddComponent\s*\(\s*["\']([a-z0-9_]+)["\']',text)))
        tags=sorted(set(re.findall(r'\bAddTag\s*\(\s*["\']([^"\']+)["\']',text)))
        hint='unclassified'
        if 'FX' in tags or 'CLASSIFIED' in tags:hint='auxiliary_or_effect'
        elif 'health' in components and 'combat' in components:hint='creature'
        elif 'prototyper' in components or 'structure' in tags or 'container' in components:hint='facility'
        elif 'inventoryitem' in components:hint='item'
        elif any(c in components for c in ('pickable','workable','growable')):hint='natural_or_interactive'
        for row in objects:
            row['category_hint']=hint;row['component_candidates']=components
            if components:row['properties'].append({'field':'components_in_source_file','value':components,**citation(path,1)})
            # Keep behavior/transformation evidence searchable, never prose facts.
            for facet,patterns in {
                'properties':[r'components\.[a-z]+\.[a-z_]+\s*=\s*[^\n;]+',r'components\.[a-z]+:Set[A-Za-z]+\([^\n]+'],
                'sources':[r'pickable:SetUp\([^\n]+',r'lootdropper:[A-Za-z]+\([^\n]+',r'trader:[A-Za-z]+\([^\n]+'],
                'mechanisms':[r'ListenForEvent\([^\n]+',r'components\.(?:workable|activatable|useableitem|transformer|upgrader|trader|burnable)[^\n]+',r'SetStateGraph\([^\n]+'],
                'behaviors':[r'SetBrain\([^\n]+',r'components\.combat[^\n]+'],
            }.items():
                for pattern in patterns:
                    for m in re.finditer(pattern,text):
                        if len(row[facet])>=32:break
                        row[facet].append({'field':'script_excerpt','value':m[0][:500],**citation(path,text.count('\n',0,m.start())+1)})
    # Recipe tables contain real IDs/conditions. Dynamic values are gaps; the
    # game runtime remains authoritative for ingredients and availability.
    for path,text in texts.items():
        if not path.endswith('.lua') or 'recipe' not in path.lower():continue
        ts=tokens(text)
        for i,t in enumerate(ts):
            if t[0] not in ('AddRecipe2','AddRecipe','Recipe','Recipe2') or i+1>=len(ts) or ts[i+1][0]!='(':continue
            args,end=split_args(ts,i+1)
            rid=value(args[0]) if args else None
            config=table(args[3]) if len(args)>3 else None
            product=(config or {}).get('product',rid)
            if not isinstance(product,str) or product not in entries:
                unresolved.append({'path':path,'line':t[2],'type':'recipe_product_unresolved','recipe':rid});continue
            row=entries[product]
            row['recipes'].append({'field':'recipe_definition','value':{'id':rid,'config_literals':config or {},'argument_excerpts':[' '.join(x[0] for x in a)[:1000] for a in args[1:4]],'ingredients_require_runtime':True},**citation(path,t[2])})
    # Reviewed adapters are centralized data, not executable extensions.
    if adapters:
        data=json.loads(adapters.read_text(encoding='utf-8'))
        if data.get('build')!=build:raise ValueError('Adapter build differs from source build')
        adapter_hash=hashlib.sha256(adapters.read_bytes()).hexdigest()
        def validate_source(fact):
            if fact.get('certainty') not in ('verified','candidate','unknown') or fact.get('version')!=build:raise ValueError('Fact requires exact version and certainty')
            if fact.get('kind')=='official_script':
                p=fact.get('path');line=fact.get('line')
                if p not in sha or fact.get('sha256')!=sha[p] or not isinstance(line,int) or not 1<=line<=len(texts.get(p,'').splitlines()):raise ValueError('Invalid script citation')
            elif fact.get('kind') in ('official_documentation','reviewed_wiki'):
                if not fact.get('url','').startswith('https://') or not fact.get('reviewed_at') or not isinstance(fact.get('implementation_check'),dict):raise ValueError('External fact needs URL, review date and implementation cross-check')
                check=fact['implementation_check']
                if check.get('kind')!='official_script' or check.get('certainty')!='verified':raise ValueError('External fact needs verified current script cross-check')
                validate_source(check)
            else:raise ValueError('Unknown adapter source type')
        # Explicit, reviewed expansion closes a dynamic declaration without
        # evaluating the loop/callback that creates its names.
        for expansion in data.get('identity_expansions',[]):
            prefab=expansion.get('prefab');proof=expansion.get('source',{})
            if not isinstance(prefab,str) or not ID.fullmatch(prefab) or prefab in entries:raise ValueError('Invalid expanded identity')
            validate_source(proof)
            if proof.get('kind')!='official_script' or proof.get('certainty')!='verified' or not expansion.get('reviewed_reason'):raise ValueError('Dynamic identity expansion needs verified script and review reason')
            row={'prefab':prefab,'names':{},'aliases':[],'category':'unclassified','identity':proof,'name_evidence':{},'knowledge_complete':False,'identity_expansion_reason':expansion['reviewed_reason'],**{f:[] for f in FACETS}}
            for lang,names in (('en',english),('zh',chinese)):
                if prefab in names:row['names'][lang]=names[prefab];row['name_evidence'][lang]={'kind':'official_localization' if lang=='zh' else 'official_strings','version':build,'certainty':'verified'}
            entries[prefab]=row
        for prefab,adapter in data.get('entries',{}).items():
            if prefab not in entries:raise ValueError('Adapter identity not declared or expanded by supplied official scripts: '+prefab)
            row=entries[prefab]
            if adapter.get('category'):
                validate_source(adapter.get('category_source',{}))
                if adapter['category_source']['certainty']!='verified':raise ValueError('Category classification must be verified')
                row['category']=adapter['category'];row['category_evidence']=adapter['category_source']
            for facet in FACETS:
                for fact in adapter.get(facet,[]):
                    validate_source(fact)
                    if fact.get('value') is None or fact.get('value')=='' or fact.get('value')==[] or fact.get('value')=={}:raise ValueError('Empty facts cannot establish coverage')
                    row[facet].append(fact)
            if adapter.get('aliases'):
                if any(not isinstance(x,str) or not 1<=len(x.encode())<=120 for x in adapter['aliases']):raise ValueError('Invalid alias')
                row['aliases']=adapter['aliases'];row['alias_evidence']={'kind':'reviewed_adapter','version':build,'sha256':adapter_hash}
            applicable=adapter.get('applicable_facets',[]);na=adapter.get('not_applicable',{})
            if any(f not in FACETS for f in applicable):raise ValueError('Unknown facet in applicability review')
            row['applicable_facets']=applicable;row['not_applicable']=na
            for facet,reason in na.items():
                if facet not in FACETS or not isinstance(reason,dict) or not reason.get('reason'):raise ValueError('Not-applicable needs a reason and verified source')
                validate_source(reason.get('source',{}))
                if reason['source']['certainty']!='verified':raise ValueError('Not-applicable source must be verified')
            # Field presence never means complete. Require manual topic-level
            # review, coverage of all applicable facets and no known gaps.
            review=adapter.get('completeness_review',{});topics=review.get('checked_topics',{})
            complete=set(applicable)|set(na)==set(FACETS)
            complete=complete and bool(review.get('reviewer')) and bool(review.get('reviewed_at')) and review.get('version')==build and review.get('remaining_gaps')==[]
            for facet in applicable:
                verified={f.get('semantic_key') for f in row[facet] if f.get('certainty')=='verified' and f.get('semantic_key')}
                complete=complete and bool(topics.get(facet)) and set(topics.get(facet,[]))<=verified
            row['knowledge_complete']=bool(complete);row['completeness_review']=review
        sha['reviewed_adapters.json']=adapter_hash
    catalog_review=data.get('catalog_review',{}) if adapters else {}
    scope_complete=bool(catalog_review.get('reviewer')) and bool(catalog_review.get('reviewed_at')) and catalog_review.get('version')==build and catalog_review.get('universe_verified') is True
    prefab_paths={p for p in texts if '/prefabs/' in '/'+p and p.endswith('.lua')} | {r['identity']['path'] for r in entries.values()} | {u['path'] for u in unresolved}
    scope_complete=scope_complete and prefab_paths<=set(catalog_review.get('reviewed_prefab_files',[]))
    resolutions={(x.get('path'),x.get('line'),x.get('type')) for x in catalog_review.get('resolved_declarations',[]) if x.get('review_reason') and all(v in entries for v in x.get('prefabs',[]))}
    scope_complete=scope_complete and all((x['path'],x['line'],x['type']) in resolutions for x in unresolved)
    scope_complete=scope_complete and set(catalog_review.get('prefab_ids',[]))==set(entries)
    manifest={'schema':1,'build':build,'status':'imported_partial_review_required','official_total':len(entries) if scope_complete else None,'universe_verified_by_review':bool(scope_complete),'catalog_review':catalog_review,'indexed_prefab_count':len(entries),'coverage_complete':False,'source':'user_supplied_official_game_files','source_sha256':sha,'version_sha256':hashlib.sha256(version_file.read_bytes()).hexdigest(),'unresolved':unresolved,'localization_supplied':bool(chinese)}
    return {'manifest':manifest,'entries':entries}

def effective_facts(row,facet):
    independent=[];groups={};conflicts=[]
    for fact in row[facet]:
        if fact.get('certainty')!='verified':continue
        key=fact.get('semantic_key')
        if not key:independent.append(fact)
        else:groups.setdefault(key,[]).append(fact)
    for key,facts in groups.items():
        preferred=[f for f in facts if f.get('kind')=='official_script'] or facts
        values={json.dumps(f.get('value'),sort_keys=True,ensure_ascii=False) for f in preferred}
        if len(values)>1:conflicts.append(key)
        else:independent.append(preferred[0])
    return independent,conflicts

def audit(data):
    rows=list(data['entries'].values());report={'build':data['manifest']['build'],'official_total':data['manifest']['official_total'],'identity_records':len(rows),'names':{lang:sum(bool(r['names'].get(lang)) for r in rows) for lang in ('en','zh')},'classified_verified':sum(r['category']!='unclassified' for r in rows),'auxiliary_verified':sum(r['category']=='auxiliary_or_effect' for r in rows),'complete_knowledge_records':sum(r['knowledge_complete'] for r in rows),'total_scope_status':'manually_reviewed_universe' if data['manifest'].get('universe_verified_by_review') else 'unverified_universe_even_if_all_literal_declarations_found','facets':{},'conflicts':[],'metrics_definition':'verified_objects means at least one verified fact, NOT complete knowledge of that facet; complete_knowledge_records requires manual topic review','unknown_universe_declarations':data['manifest']['unresolved'],'all_official_content_complete':False,'missing':[]}
    for f in FACETS:
        report['facets'][f]={'verified_objects':sum(bool(effective_facts(r,f)[0]) for r in rows),'candidate_only_objects':sum(bool(r[f]) and not bool(effective_facts(r,f)[0]) for r in rows),'missing_objects':sum(not r[f] and f not in r.get('not_applicable',{}) for r in rows),'not_applicable_reviewed':sum(f in r.get('not_applicable',{}) for r in rows)}
    for r in rows:
        for facet in FACETS:
            for key in effective_facts(r,facet)[1]:report['conflicts'].append({'prefab':r['prefab'],'facet':facet,'semantic_key':key})
        if any(effective_facts(r,f)[1] for f in FACETS):r['knowledge_complete']=False
        gaps=[f for f in FACETS if f not in r.get('not_applicable',{}) and not bool(effective_facts(r,f)[0])]
        if not r['names'].get('zh'):gaps.append('zh_name')
        if r['category']=='unclassified':gaps.append('category')
        if gaps:report['missing'].append({'prefab':r['prefab'],'gaps':gaps})
    report['complete_knowledge_records']=sum(r['knowledge_complete'] for r in rows)
    report['all_official_content_complete']=bool(rows) and data['manifest'].get('universe_verified_by_review',False) and all(r['knowledge_complete'] and r['names'].get('zh') and r['names'].get('en') and r['category']!='unclassified' for r in rows)
    return report

def write_bundle(data,output):
    """Identity index loads once; detail buckets load only for requested objects.
    Avoids one enormous Lua 5.1 function/constant pool for the full game.
    """
    output.mkdir(parents=True,exist_ok=True);index={};buckets={}
    for prefab,row in sorted(data['entries'].items()):
        bucket=int(hashlib.sha256(prefab.encode()).hexdigest()[:2],16)%64
        module='ybf_official_detail_%02x'%bucket
        buckets.setdefault(module,{})[prefab]=row
        lightweight={k:row[k] for k in ('prefab','names','aliases','category','identity','knowledge_complete')}
        for key in ('name_evidence','alias_evidence','category_evidence'):
            if key in row:lightweight[key]=row[key]
        lightweight['variant_index']=effective_facts(row,'variants')[0]
        lightweight['verified_facets']={f:len(effective_facts(row,f)[0]) for f in FACETS}
        lightweight['detail_module']=module;index[prefab]=lightweight
    for module,rows in buckets.items():(output/(module+'.lua')).write_text('-- Generated data only.\nreturn '+lua(rows)+'\n',encoding='utf-8')
    (output/'ybf_official_knowledge.lua').write_text('-- Generated identity index. Details loaded on demand.\nreturn '+lua({'manifest':data['manifest'],'entries':index})+'\n',encoding='utf-8')
    return index

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--version-file',type=Path,required=True);p.add_argument('--localization',type=Path);p.add_argument('--adapters',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    data=import_data(a.source,a.version_file,a.localization,a.adapters);report=audit(data)
    data['manifest']['coverage_complete']=report['all_official_content_complete']
    if report['all_official_content_complete']:data['manifest']['status']='manually_reviewed_complete'
    a.output.mkdir(parents=True,exist_ok=True)
    (a.output/'official_knowledge.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    (a.output/'coverage.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    write_bundle(data,a.output)
    print(json.dumps({k:v for k,v in report.items() if k not in ('missing','unknown_universe_declarations')},ensure_ascii=False))
if __name__=='__main__':main()
