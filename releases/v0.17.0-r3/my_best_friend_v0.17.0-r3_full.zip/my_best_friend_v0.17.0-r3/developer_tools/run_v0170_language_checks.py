"""Natural messages through actual provider decoder and game entry; provider canned."""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
old=(root/'developer_tools/run_knowledge_r3_checks.py').read_text();a=old.index('D={}');b=old.index('server=bridge.BridgeServer',a)
D={}
def ops(text,items):D[text]=dict(intent='command_operations',action='operations',dialogue='我核实一下。',item=items,quantity=None)
def chat(text):D[text]=dict(intent='chat',action='none',dialogue='我在呢。',item=None,quantity=None)
for text in ['我饿了','要','做吧','不要','天气不错','好呀'] :chat(text)
ops('做一份芦笋汤给我',[dict(type='cook',recipe='asparagussoup',quantity=1,destination='player')])
ops('给我做一份蛙腿三明治',[dict(type='cook',recipe='frogglebunwich',quantity=1,destination='player')])
ops('来份素菜就好，弄好拿给我',[dict(type='cook',category='vegetarian',destination='player')])
ops('做点肉食给我',[dict(type='cook',category='meat',destination='player')])
ops('那就来两份素的，先别开始',[dict(type='modify_proposal',quantity=2,category='vegetarian')])
ops('当前都有哪些任务',[dict(type='status')])
ops('不用做饭了，给我一根树枝',[dict(type='cancel',kind='cook'),dict(type='goal',goal=dict(targets=[dict(item='twigs',quantity=1)],deliver=True))])
ops('先不做饭，帮我找一根树枝，然后继续之前的建筑',[dict(type='cancel',kind='cook'),dict(type='goal',goal=dict(targets=[dict(item='twigs',quantity=1)],deliver=True)),dict(type='resume',target='build-task')])
ops('别做饭了，种地也不用，你先给我一根树枝',[dict(type='cancel',kind='cook'),dict(type='unsupported',reason='耕种执行尚未支持'),dict(type='goal',goal=dict(targets=[dict(item='twigs',quantity=1)],deliver=True))])
ops('先把那锅取消，再找一根树枝',[dict(type='cancel',kind='cook'),dict(type='goal',depends_on=1,goal=dict(targets=[dict(item='twigs',quantity=1)],deliver=True))])
ops('要，做好放到友谊容器',[dict(type='modify_proposal',destination='warehouse'),dict(type='accept')])
D['在附近搭一座鸟笼']=dict(intent='command_goal',action='goal',dialogue='核实条件',item='birdcage',quantity=1,deliver=False,mode='craft',placement={'mode':'free'})
D['先暂停建筑']=dict(intent='command_operations',action='operations',dialogue='停一下',item=[dict(type='pause',target='build-task')],quantity=None)
ops('先给我一根树枝，再继续之前的建筑',[dict(type='goal',goal=dict(targets=[dict(item='twigs',quantity=1)],deliver=True)),dict(type='resume',target='build-task',depends_on=1)])
D['蛙腿三明治怎么做']=dict(intent='query_knowledge',action='knowledge',dialogue='核实料理',item=dict(name='frogglebunwich',kind='recipe'),quantity=None)
ops('煮一份肉汤拿给我',[dict(type='cook',recipe='bonestew',destination='player')])
D['鸟笼怎么做']=dict(intent='query_knowledge',action='knowledge',dialogue='核实配方',item=dict(name='birdcage',kind='recipe'),quantity=None)
source=old[:a]+'D='+repr(D)+'\n'+old[b:]
source=source.replace("(root/'tests/test_knowledge_r3.lua').read_text()", "(root/'tests/test_v0170_language.lua').read_text()")
source=source.replace("harness=harness.replace('function h:last()", "harness=harness.replace(' reset()', ' setup()')\nharness=harness.replace('local request=pending[#pending];assert(request.packet.message==text)', 'local request=pending[#pending];if not request or request.packet.message~=text then return end')\nharness=harness.replace('function h:last()")
source=source.replace("source=setup+'\\nlocal LANGUAGE_FIXTURES='", 'source=\'OFFICIAL_TUNING=\'+lua(json.loads((root/\'tests/official_cooking_756039/tuning_values.json\').read_text()))+\'\\nOFFICIAL_NAMES=\'+lua({p.upper():v.get(\'names\',{}).get(\'zh\',p) for p,v in json.loads((root/\'knowledge/official_knowledge.json\').read_text())[\'entries\'].items()})+\'\\n\'+setup+\'\\n\'+(root/\'tests/test_v0150_warehouse.lua\').read_text().split(\'setup()\\nfor _,p\',1)[0]+\'\\n\'+(root/\'tests/test_v0160_building.lua\').read_text().split(\'-- Coordinates from actual map center interfaces;\',1)[0]+\'\\n\'+(root/\'tests/test_v0170_cooking.lua\').read_text()+\'\\nrequire("ybf_chat_server").Emit=original_emit\\nlocal LANGUAGE_FIXTURES=\'')
# Restore fixture grammar assertions after the base harness special-diagnostic replacement.
source=source.replace('raw=source.encode();', "(Path('/tmp')/'v0170-language-source.lua').write_text(source);raw=source.encode();")
source=source.replace("state=lib.luaL_newstate();", "source=source.replace('local request=pending[#pending];if text==\\\"开启知识诊断\\\" or text==\\\"关闭知识诊断\\\" then return end;assert(request.packet.message==text)', 'local request=pending[#pending];if not request or request.packet.message~=text then return end')\nstate=lib.luaL_newstate();")
exec(compile(source,str(root/'developer_tools/run_knowledge_r3_checks.py'),'exec'),{'__file__':str(root/'developer_tools/run_knowledge_r3_checks.py'),'__name__':'__main__'})
