local R=require('ybf_cooking_rules');local I=require('ybf_work_inventory');local W=require('ybf_warehouse');local P=require('ybf_build_positions');local M={};local pots=setmetatable({},{__mode='k'})
local function live(t)return t and t.state~='cancelled'and t.state~='completed'and t.state~='blocked'and not t.paused and t.friend and t.friend:IsValid()and t.friend.components.ybf_friend.active end
function M.Release(t)if t.watch and t.pot and t.pot:IsValid()then t.pot:RemoveEventCallback('ybf_cook_change',t.watch);t.pot:RemoveEventCallback('onremove',t.watch)end;t.watch=nil;W.Release(t);for p,claim in pairs(pots)do if claim==t then pots[p]=nil end end end
local labels={withdraw='取材',load='放料',remove='调整锅内材料',start='开锅',harvest='收取',deposit='存放',give='交付',drop='地面存放'}
function M.Log(t,phase,detail)
 local now=GetTime();local signature=phase..':'..tostring(detail or '')
 t.cook_logs=t.cook_logs or {};local row=t.cook_logs[phase]
 if (phase=='flight_monitor'or phase=='busy_monitor')and row and now-row.time<2 then return end
 if not row or row.signature~=signature or now-row.time>=10 then
  t.cook_logs[phase]={signature=signature,time=now};print('[YBF COOK FLOW] task='..tostring(t.id)..' phase='..phase..' time='..string.format('%.3f',now)..' state='..tostring(t.state)..' '..tostring(detail or ''))
 end
end
local action_ids=setmetatable({},{__mode='k'});local action_sequence=0
local function identity(a)
 if a and not action_ids[a]then action_sequence=action_sequence+1;action_ids[a]=action_sequence end
 local d=a and a.ybf_cook
 return a and(tostring(a.action and a.action.id)..'/instance='..tostring(action_ids[a])..'/task='..tostring(d and d.task and d.task.id)..'/attempt='..tostring(d and d.attempt)..'/step='..tostring(d and d.step))or 'nil'
end
function M.Trace(h,t,phase,reason,a)
 local inst=h.work.inst;local loco=inst.components.locomotor;local sg=inst.sg;local f=h.inflight
 M.Log(t,phase,'reason='..tostring(reason)..' action='..identity(a)..' submitted='..tostring(a and a.ybf_cook and a.ybf_cook.submitted)..' deadline='..tostring(a and a.ybf_cook and a.ybf_cook.deadline)..' inflight='..identity(f and f.act)..' entity_buffer='..identity(inst.bufferedaction)..' effective_buffer='..identity(inst:GetBufferedAction())..' loco_buffer='..identity(loco and loco.bufferedaction)..' loco_dest='..tostring(loco and loco.dest)..' loco_target='..tostring(loco and loco.dest and loco.dest.inst and loco.dest.inst.GUID)..' target='..tostring(a and a.target and a.target.GUID)..' distance_sq='..tostring(a and a.target and a.target:IsValid()and inst:GetDistanceSqToInst(a.target))..' sg_action='..identity(sg and sg.statemem and sg.statemem.action)..' sg_cook_marker='..identity(sg and sg.statemem and sg.statemem.ybf_cook_action)..' moving='..tostring(loco and loco.wantstomoveforward)..' updating='..tostring(loco and loco.updating)..' stategraph='..tostring(sg and sg.currentstate and sg.currentstate.name)..' doing='..tostring(sg and sg:HasStateTag('doing'))..' busy='..tostring(sg and sg:HasStateTag('busy'))..' giving='..tostring(sg and sg:HasStateTag('giving')))
end
function M.ClearFlight(h,reason)
 local f=h.inflight;if not f then return end
 M.Trace(h,f.task,'inflight_clear',reason,f.act);h.inflight=nil
end
function M.CleanAction(h,a,reason)
 local d=a and a.ybf_cook;if not d or d.hub~=h then return end
 local inst=h.work.inst;local loco=inst.components.locomotor;local sg=inst.sg
 local entity=inst:GetBufferedAction();local locomotor=loco and loco.bufferedaction;local stateaction=sg and sg.statemem and(sg.statemem.action or sg.statemem.ybf_cook_action)
 local owned=entity==a or locomotor==a or stateaction==a
 M.Trace(h,d.task,'owned_action_cleanup_before',reason,a)
 if owned and d.cleanup_done then M.Trace(h,d.task,'retired_action_reappeared','previous_cleanup='..tostring(d.cleanup_done),a)end
 local pending=inst.components.ybf_needs and inst.components.ybf_needs.pending
 if sg and sg.statemem and not sg:HasStateTag('nointerrupt')then if sg.statemem.action==a then sg.statemem.action=nil end;if sg.statemem.ybf_cook_action==a then sg.statemem.ybf_cook_action=nil end end
 if entity==a then inst:ClearBufferedAction()end
 if locomotor==a then if loco.SetBufferedAction then loco:SetBufferedAction(nil)else loco.bufferedaction=nil;a:Fail()end end
 -- Stop/Fail callbacks can synchronously install another valid action: re-read ownership.
 local current=inst:GetBufferedAction();local currentloco=loco and loco.bufferedaction
 if owned and not pending and(not current or current==a)and(not currentloco or currentloco==a)then
  if loco then loco:Stop();if loco.Clear then loco:Clear()end end
  if stateaction==a and not sg:HasStateTag('nointerrupt')then sg:GoToState('idle')end
 end
 d.cleanup_done=GetTime()
 M.Trace(h,d.task,'owned_action_cleanup_after',reason,a)
end
function M.Invalidate(h,t,reason)
 t.attempt=(t.attempt or 0)+1
 if h then
  local inst=h.work.inst;local loco=inst.components.locomotor;local sg=inst.sg;local flight=h.inflight
  local actions={last=t.cook_action,entity=inst:GetBufferedAction(),locomotor=loco and loco.bufferedaction,stategraph=sg and sg.statemem and sg.statemem.action,stategraph_marker=sg and sg.statemem and sg.statemem.ybf_cook_action,flight=flight and flight.task==t and flight.act or nil}
  if flight and flight.task==t then M.ClearFlight(h,reason or 'invalidate')end
  local seen={};for _,a in pairs(actions)do local d=a.ybf_cook;if d and d.hub==h and d.task==t and not seen[a]then seen[a]=true;M.CleanAction(h,a,reason or 'invalidate')end end
 end
 M.Release(t)
end
function M.Reconcile(h)
 local inst=h.work.inst;local loco=inst.components.locomotor;local seen={}
 for _,a in pairs({entity=inst:GetBufferedAction(),locomotor=loco and loco.bufferedaction,stategraph=inst.sg and inst.sg.statemem and inst.sg.statemem.action,stategraph_marker=inst.sg and inst.sg.statemem and inst.sg.statemem.ybf_cook_action})do
  local d=a.ybf_cook
  if d and d.hub==h and not seen[a]then
   seen[a]=true;local f=h.inflight
   if not f or f.act~=a or d.attempt~=d.task.attempt or d.task.state=='blocked'or d.task.state=='cancelled'or d.task.paused then M.CleanAction(h,a,'orphan_or_invalid_attempt')end
  end
 end
end
function M.Flight(h)
 local f=h.inflight;if not f then return false end
 local now=GetTime();local inst=h.work.inst;local sg=inst.sg
 if sg and sg.statemem and inst:GetBufferedAction()==f.act and(sg:HasStateTag('giving')or sg:HasStateTag('doing'))then sg.statemem.ybf_cook_action=f.act end
 M.Trace(h,f.task,'flight_monitor',f.finished and 'await_native_exit'or 'await_perform',f.act)
 if now>=f.deadline then M.Trace(h,f.task,'action_timeout','deadline_reached',f.act);M.Block(h,f.task,'动作超过20秒未完成原版执行/退出，请检查动作链日志');return true end
 if f.finished and now>=(f.finished_at or now)+.25 and not(sg and(sg:HasStateTag('doing')or sg:HasStateTag('busy')or sg:HasStateTag('working')or sg:HasStateTag('giving')))then
  -- Callback is not an animation-exit event. Keep the executor lease until this boundary.
  M.ClearFlight(h,'native_action_settled');M.CleanAction(h,f.act,'settled_buffer_release');return false
 end
 return true
end
function M.Block(h,t,reason)
 local stage=t.cook_stage or '准备'
 t.state='blocked';t.reason=reason;t.search=nil;t.plan=nil
 -- Clear ownership and generation BEFORE StopAction: its failure callback can run synchronously.
 M.Invalidate(h,t,'blocked:'..reason)
 M.Log(t,'blocked','stage='..stage..' reason='..reason)
 if t.last_block_reason~=reason then t.last_block_reason=reason
  local work=t.friend and t.friend.components.ybf_work or h and h.work
  if work then work:Announce('料理任务在'..stage..'阶段受阻：'..reason..'；已收取'..(t.done or 0)..'份、存放/交付'..(t.stored or 0)..'份。已取材料和锅内进度保留，其他独立任务会继续。')end
 end
end
local function block(t,reason)M.Block(t.friend and t.friend.components.ybf_work.hub,t,reason)end
function M.Progress(t) t.prep_progress=GetTime();t.prep_busy_since=nil;t.replans=0 end
function M.Busy(h,t)
 if t.started then return end
 local inst=h.work.inst;local sg=inst.sg;local a=inst:GetBufferedAction();local needs=inst.components.ybf_needs
 local tags={};for _,tag in ipairs({'busy','working','giving','prechop','premine','nointerrupt'})do if sg and sg:HasStateTag(tag)then tags[#tags+1]=tag end end
 t.prep_busy_since=t.prep_busy_since or GetTime();t.cook_stage='等待执行机会';M.Trace(h,t,'busy_monitor','since='..t.prep_busy_since..' deadline='..(t.prep_busy_since+20),a)
 M.Log(t,'action_busy','action='..tostring(a and a.action and a.action.id)..' stategraph='..tostring(sg and sg.currentstate and sg.currentstate.name)..' tags='..table.concat(tags,',')..' supply_pending='..tostring(needs and needs.pending~=nil)..' core_inflight='..tostring(h.work.core.job and h.work.core.job.inflight))
 if GetTime()-t.prep_busy_since>=20 then M.Block(h,t,'执行机会持续被占用，具体缓冲动作、状态图和补给状态已写入日志；没有强制中断其他任务或补给')end
end
function M.Replan(h,t,reason)
 t.plan=nil;t.search=nil;W.Release(t);t.replans=(t.replans or 0)+1;M.Log(t,'replan',reason..' attempts='..t.replans)
 if t.replans>=3 then M.Block(h,t,reason..'，连续重新规划未取得进展，请核实后恢复')end
end
local function receipt(t,n)
 t.stored=(t.stored or 0)+n
 if t.auxiliary then t.aux_stored=(t.aux_stored or 0)+n else t.target_stored=(t.target_stored or 0)+n end
end
local function usable(p)return p and p:IsValid()and R.POTS[p.prefab]and p.components.stewer and p.components.container and p.components.ybf_cook_marker and not p:HasTag('burnt')end
local function inrange(h,t,e)
 if not e or not e:IsValid()or t.world~=P.World()then return false end
 local x,_,z=e.Transform:GetWorldPosition();return (x-t.center.x)^2+(z-t.center.z)^2<=h.work.radius^2
end
local function opened(h,p)return p.components.container.IsOpenedByOthers and p.components.container:IsOpenedByOthers(h.work.inst)end
local function locate(h,t)
 local x,_,z=h.work.inst.Transform:GetWorldPosition();local rows={}
 for _,p in ipairs(TheSim:FindEntities(x,0,z,h.work.radius,{'stewer'},{'INLIMBO','burnt'}))do if usable(p)and inrange(h,t,p)then rows[#rows+1]=p end end
 table.sort(rows,function(a,b)return h.work.inst:GetDistanceSqToInst(a)<h.work.inst:GetDistanceSqToInst(b)end)
 for index,p in ipairs(rows)do if index>16 then break end;if t.pot_id then if p.components.ybf_cook_marker.id==t.pot_id then return p end
 elseif (not t.spec.recipe or require('cooking').GetRecipe(p.prefab,t.spec.recipe))and not p.components.stewer:IsCooking()and not opened(h,p)and(not live(pots[p])or pots[p]==t)then return p end end
end
local function slots(p)local out={};for slot,it in pairs(p.components.container.slots)do out[#out+1]={slot=slot,item=it,prefab=it.prefab}end;table.sort(out,function(a,b)return a.slot<b.slot end);return out end
local function fingerprint(p)local out={};for _,v in ipairs(slots(p))do out[#out+1]=v.slot..':'..v.item.GUID..':'..v.prefab..':'..I.Size(v.item)end;return table.concat(out,'|')end
local function count(c,p)local n=0;for _,i in pairs(c.slots)do if i.prefab==p then n=n+I.Size(i)end end;return n end
function M.Stock(h,t,pot)
 t.friend=h.work.inst;t.external_reservation=true;local rows={};local own=h.work.inst
 local function add(item,where)
  if not R.Ingredient(item.prefab)or not pot.components.container:CanTakeItemInSlot(item)or item.components.inventoryitem and item.components.inventoryitem.islockedinslot then return end
  local n=W.Available(item,t);if where==own then n=math.max(0,n-math.min(h.held_outputs and h.held_outputs[item.prefab]or 0,I.Count(own,item.prefab,true)))end;if n<=0 then return end
  local per=item.components.perishable;local cost=(per and per:GetPercent()or 2)+(not per and 2 or 0)
  local _,values=R.Tags({item.prefab});if (values.magic or 0)>0 or (values.decoration or 0)>0 or item:HasTag('irreplaceable')then cost=cost+20 end
  for _,value in pairs(values)do if value>1 then cost=cost+(value-1)*3 end end
  cost=cost+1/math.max(1,n)
  if where==pot then cost=cost-4 end
  local row=rows[item.prefab]or {count=0,cost=cost,items={}};rows[item.prefab]=row;row.count=row.count+n;row.cost=math.min(row.cost,cost);row.items[#row.items+1]={item=item,where=where,count=n}
 end
 for _,i in ipairs(I.Items(own))do if t.spec.source~='warehouse_only'then add(i,own)elseif (t.acquired and t.acquired[i.prefab]or 0)>0 then add(i,own);local row=rows[i.prefab];if row then row.count=math.min(row.count,t.acquired[i.prefab])end end end
 if t.spec.source~='inventory_only'then for _,c in ipairs(W.Discover(own,t,h.work.radius))do for _,i in pairs(c.components.container.slots)do add(i,c)end end end
 if t.spec.source~='warehouse_only'or t.pot_prepared then for _,v in ipairs(slots(pot))do add(v.item,pot)end end
 -- Keep raw final-food goals in suspended/running legacy tasks out of cooking.
 for _,task in ipairs(h.tasks)do if task~=t and task.kind=='work'and task.state~='cancelled'and task.state~='completed'then for _,target in ipairs(task.spec.targets or {})do local row=rows[target.item];if row then row.count=math.max(0,row.count-target.quantity)end end end end
 return rows
end
local function reserve(h,t)
 local need={};for _,p in ipairs(t.plan.ingredients)do need[p]=(need[p]or 0)+1 end
 local stock=M.Stock(h,t,t.pot);t.reserved={}
 for p,n in pairs(need)do
  local row=stock[p];if not row or row.count<n then W.Release(t);return false end
  table.sort(row.items,function(a,b)return a.where==t.pot and b.where~=t.pot end)
  for _,source in ipairs(row.items)do if n>0 then local amount=math.min(n,source.count);if source.where~=t.pot then if not W.Reserve(h.work.inst,h.work,t,source.item,amount)then W.Release(t);return false end;t.reserved[#t.reserved+1]={item=source.item,where=source.where,count=amount} end;n=n-amount end end
 end
 return true
end
local function transfer(h,t,target,item,take,slot)
 local inv=h.work.inst.components.inventory;local c=target.components.container;local p=item and item.prefab
 if not item or not item:IsValid()then return false end
 local from=take and c or inv;local to=take and inv or c
 do local present=false;for _,v in pairs(take and c.slots or inv.itemslots)do if v==item then present=true end end;if not present then return false end end
 if to:CanAcceptCount(item,1)<1 or not take and not c:CanTakeItemInSlot(item,slot)then return false end
 local before=I.Count(h.work.inst,p,true);local old=count(c,p);local part=from:RemoveItem(item,false);if not part then return false end
 local given=to:GiveItem(part,take and nil or slot,h.work.inst:GetPosition(),false)
 if not given and part:IsValid()and not part.components.inventoryitem.owner then from:GiveItem(part)end
 local delta=I.Count(h.work.inst,p,true)-before;return delta==(take and 1 or -1)and count(c,p)-old==-delta
end
local function push(h,t,target,step,item,slot)
 if h.inflight then M.Trace(h,t,'inflight_replace_rejected','existing_executor_lease',h.inflight.act);return true end
 local inst=h.work.inst;t.cook_stage=labels[step]or step;M.Log(t,'submit','step='..step..' target='..tostring(target and target.GUID)..' item='..tostring(item and item.prefab));t.state='running';t.attempt=t.attempt+1;local serial=t.attempt
 local action=step=='give'and ACTIONS.YBF_GIVE or ACTIONS.YBF_COOK_TASK;local a=BufferedAction(inst,target,action,item);local submitted=GetTime();a.ybf_cook={hub=h,task=t,attempt=serial,step=step,slot=slot,submitted=submitted,deadline=submitted+20};t.cook_action=a;h.inflight={task=t,act=a,submitted=submitted,deadline=submitted+20};a.validfn=function()return h.inflight and h.inflight.act==a and t.attempt==serial and not t.paused and t.state~='blocked'and t.state~='cancelled'and h.work:OwnerValid(t.owner)and target and target:IsValid()end;M.Trace(h,t,'inflight_set','submit',a)
 local function finish(ok)
  if not h.inflight or h.inflight.act~=a or t.attempt~=serial then M.Trace(h,t,'callback_ignored','no_matching_inflight_or_generation',a);return end
  h.inflight.finished=true;h.inflight.finished_at=GetTime();M.Trace(h,t,'callback','verified='..tostring(a.ybf_cook_verified==true),a)
  M.Log(t,a.ybf_cook_verified and 'action_success' or 'action_failed','step='..step..' callback='..tostring(ok)..' reason='..tostring(a.ybf_cook_failure or(a.ybf_cook_verified and 'verified' or 'perform_not_reached_or_no_inventory_change')))
  if a.ybf_cook_verified then M.Progress(t)end
  if t.state=='cancelled'or t.paused then return end
  if not a.ybf_cook_verified then t.failures=(t.failures or 0)+1;t.state='queued';t.plan=nil;t.search=nil;W.Release(t);if t.failures>=3 then block(t,'连续动作未取得实际结果；请检查路径、锅状态或背包（详细失败原因已写入日志）')end
  elseif t.state=='running'then t.state='queued' end
 end
 a:AddSuccessAction(finish);a:AddFailAction(finish)
 inst.components.ybf_friend.mode='work';inst.components.ybf_friend:ApplyMovementPolicy();h.work.returning=nil;inst.components.locomotor:PushAction(a,true);M.Trace(h,t,'push_return','locomotor_push_complete',a);return true
end
local function perform(act)
 local d=act.ybf_cook;if not d then return false end;local h,t=d.hub,d.task;local inst=h.work.inst
 if not h.inflight or h.inflight.act~=act or t.attempt~=d.attempt or t.paused or t.state=='cancelled'then act.ybf_cook_failure='stale_generation';return false end
 if not h.work:OwnerValid(t.owner)or inst.components.health:IsDead()then act.ybf_cook_failure='owner_or_friend_invalid';return false end
 local target=act.target;if not inrange(h,t,target)or inst:GetDistanceSqToInst(target)>16 then act.ybf_cook_failure='target_out_of_range_or_removed';return false end
 local step=d.step
 if step=='withdraw'then
  if not require('ybf_friendship_containers').Authorized(target)then act.ybf_cook_failure='container_unauthorized';return false end
  if not act.invobject or not act.invobject:IsValid()or W.Available(act.invobject,t)<1 then act.ybf_cook_failure='ingredient_removed_or_reserved';return false end
  act.ybf_cook_verified=transfer(h,t,target,act.invobject,true);if act.ybf_cook_verified then t.acquired=t.acquired or {};t.acquired[act.invobject.prefab]=(t.acquired[act.invobject.prefab]or 0)+1 end;return act.ybf_cook_verified
 elseif step=='deposit'then
  if not require('ybf_friendship_containers').Authorized(target)then act.ybf_cook_failure='container_unauthorized';return false end
  local p=t.product;local before=I.Count(inst,p,true);t.giveitem=p;t.givegoal=1
  local ok,n=W.Transfer(inst,t,target,false)
  if ok and n==before-I.Count(inst,p,true)then t.carry=t.carry-n;receipt(t,n);t.deposits=t.deposits or {};local key=tostring(target.GUID);local receipt=t.deposits[key]or {name=target:GetDisplayName(),count=0};receipt.count=receipt.count+n;t.deposits[key]=receipt;act.ybf_cook_verified=true end;return act.ybf_cook_verified or false
 elseif step=='give'then
  local item=act.invobject;local ok=h.work:CanGive({owner=t.owner},item);if not ok then return false end
  local before=I.Count(inst,item.prefab,true);local received=I.Count(t.owner,item.prefab,true)
  local accepted=t.owner.components.trader:AcceptGift(inst,item,1)
  if accepted and before-I.Count(inst,item.prefab,true)==1 and I.Count(t.owner,item.prefab,true)-received==1 then t.carry=t.carry-1;receipt(t,1);t.given_count=(t.given_count or 0)+1;act.ybf_cook_verified=true end;return act.ybf_cook_verified or false
 elseif step=='drop'then
  local point=inst:GetPosition();local map=TheWorld.Map
  if not map:IsPassableAtPoint(point.x,0,point.z)or map.IsPointNearHole and map:IsPointNearHole(point)then return false end
  for _,e in ipairs(TheSim:FindEntities(point.x,0,point.z,4,nil,{'INLIMBO'}))do if e:HasTag('hostile')or e:HasTag('fire')or e:HasTag('burning')then return false end end
  local item=act.invobject;local before=I.Count(inst,item.prefab,true);local part=inst.components.inventory:RemoveItem(item,false);if not part then return false end
  part.Transform:SetPosition(point.x,0,point.z);part.components.inventoryitem:OnDropped(true)
  if part:IsValid()and not part.components.inventoryitem.owner and before-I.Count(inst,item.prefab,true)==1 then t.carry=t.carry-1;receipt(t,1);t.ground_count=(t.ground_count or 0)+1;t.ground={x=point.x,z=point.z};act.ybf_cook_verified=true end;return act.ybf_cook_verified or false
 end
 local pot=t.pot;if target~=pot or not usable(pot)or pots[pot]~=t or opened(h,pot)then act.ybf_cook_failure='pot_invalid_claim_lost_or_player_operating';return false end
 local s,c=pot.components.stewer,pot.components.container
 if step=='harvest'then
  if not s:IsDone()or s.product~=t.product then return false end
  if t.started and pot.components.ybf_cook_marker.batch~=t.batch then block(t,'锅的批次已变化，不能把别人的产物计入任务');return false end
  local r=require('cooking').GetRecipe(pot.prefab,s.product);local n=r and r.stacksize or 1
  if not I.Room(inst,t.product,n)then return false end
  local before=I.Count(inst,t.product,true);local ok=ACTIONS.HARVEST.fn(act);local delta=I.Count(inst,t.product,true)-before
  if ok and not s:IsDone()and delta==n then
   t.carry=delta;if t.started then t.done=t.done+delta end;t.started=nil;t.plan=nil;t.search=nil;t.pot_id=nil;t.batch=nil;M.Release(t);t.auxiliary=not t.was_requested;t.was_requested=nil;act.ybf_cook_verified=true
  else block(t,'收取结果与实际入包数量不一致，不自动重做')end;return act.ybf_cook_verified or false
 end
 if s:IsCooking()or s:IsDone()then return false end
 if t.expected and fingerprint(pot)~=t.expected then act.ybf_cook_failure='pot_contents_changed';t.plan=nil;t.search=nil;W.Release(t);return false end
 if step=='remove'then local approved_slot;for _,v in ipairs(slots(pot))do if v.item==act.invobject and t.loaded_slots and t.loaded_slots[v.slot]==v.prefab then approved_slot=v.slot end end;act.ybf_cook_verified=transfer(h,t,pot,act.invobject,true);if act.ybf_cook_verified and approved_slot then t.acquired=t.acquired or {};t.acquired[act.invobject.prefab]=(t.acquired[act.invobject.prefab]or 0)+1;t.loaded_slots[approved_slot]=nil end
 elseif step=='load'then
  if t.spec.source=='warehouse_only'and (not t.acquired or (t.acquired[act.invobject.prefab]or 0)<1)then return false end
  act.ybf_cook_verified=transfer(h,t,pot,act.invobject,false,d.slot);if act.ybf_cook_verified then t.loaded_slots=t.loaded_slots or {};t.loaded_slots[d.slot]=act.invobject.prefab end;if act.ybf_cook_verified and t.acquired then t.acquired[act.invobject.prefab]=math.max(0,(t.acquired[act.invobject.prefab]or 0)-1)end
 elseif step=='start'then
  local list={};for _,v in ipairs(slots(pot))do list[#list+1]=v.prefab end
  local candidates=R.Candidates(pot.prefab,list)
  if #candidates~=1 or candidates[1].name~=t.plan.recipe or not s:CanCook()then t.plan=nil;return false end
  local ok=ACTIONS.COOK.fn(act)
  if ok and s:IsCooking()and s.product==t.plan.recipe then
   t.started=true;t.product=s.product;t.batch=pot.components.ybf_cook_marker.batch;t.pot_id=pot.components.ybf_cook_marker.id;t.was_requested=true;t.pot_prepared=nil;t.loaded_slots=nil;t.plan=nil;t.state='waiting';t.expected=nil;t.wait_check=GetTime()+2;W.Release(t);act.ybf_cook_verified=true
   print('[YBF COOK] task='..t.id..' phase=started pot='..pot.GUID..' batch='..t.batch..' product='..t.product)
  end
 end
 if act.ybf_cook_verified and step~='start'then t.expected=fingerprint(pot)end
 return act.ybf_cook_verified or false
end
function M.Perform(act)
 local d=act.ybf_cook;if not d then return false end
 local h,t=d.hub,d.task;local p=act.invobject and act.invobject.prefab or t.product
 local before=p and I.Count(h.work.inst,p,true)or 0;local source=act.target and act.target:IsValid()and act.target.components.container;local source_before=source and p and count(source,p)
 M.Log(t,'perform','step='..d.step..' target='..tostring(act.target and act.target.GUID)..' distance_sq='..tostring(act.target and act.target:IsValid()and h.work.inst:GetDistanceSqToInst(act.target)))
 local ok=perform(act)
 local pot=t.pot;local stewer=pot and pot:IsValid()and pot.components.stewer
 M.Log(t,'actual_result','step='..d.step..' verified='..tostring(act.ybf_cook_verified==true)..' inventory='..tostring(p)..':'..before..'->'..tostring(p and I.Count(h.work.inst,p,true)or 0)..' target_count='..tostring(source_before)..'->'..tostring(source and p and count(source,p))..' failure='..tostring(act.ybf_cook_failure)..' pot_slots='..tostring(pot and pot:IsValid()and fingerprint(pot))..' cooking='..tostring(stewer and stewer:IsCooking())..' done='..tostring(stewer and stewer:IsDone())..' product='..tostring(stewer and stewer.product))
 return ok
end
function M.Poll(h)
 local now=GetTime();for _,t in ipairs(h.tasks)do if t.kind=='cook'and t.started and t.state~='cancelled'and t.state~='completed'and (not t.wait_check or now>=t.wait_check)then
  t.wait_check=now+2;local p=t.pot;M.Log(t,'pot_check','pot='..tostring(p and p.GUID)..' cooking='..tostring(usable(p)and p.components.stewer:IsCooking())..' done='..tostring(usable(p)and p.components.stewer:IsDone())..' product='..tostring(usable(p)and p.components.stewer.product));if not usable(p)then p=locate(h,t);t.pot=p end
  if not usable(p)then block(t,'原烹饪锅已移除或当前范围无法恢复；不重新消耗材料')
  elseif p.components.ybf_cook_marker.batch~=t.batch or p.components.stewer.product~=t.product then block(t,'原批次产物被取走、腐败或锅被重新操作；不自动重做')
  elseif p.components.stewer:IsDone()and not t.paused and(not live(pots[p])or pots[p]==t)then t.state='queued';pots[p]=t
  elseif not p.components.stewer:IsCooking()and not p.components.stewer:IsDone()then block(t,'原烹饪状态已消失；不自动重做')end
 end end
end
function M.Step(h,t)
 t.friend=h.work.inst;t.prep_progress=t.prep_progress or GetTime();t.prep_busy_since=nil;M.Log(t,'scheduled','started='..tostring(t.started==true));if not t.started and GetTime()-t.prep_progress>=30 then M.Block(h,t,'准备阶段持续没有真实进展，请查看配方搜索、预留与动作日志');return false end;t.external_reservation=true;t.destination_guid=t.spec.destination_guid;t.prefer_ice=true
 if t.world~=P.World()then block(t,'任务属于其他世界分片，不搜索设施');return false end
 if t.carry and t.carry>0 then
  if t.spec.destination=='friend'then h.held_outputs=h.held_outputs or {};h.held_outputs[t.product]=(h.held_outputs[t.product]or 0)+t.carry;receipt(t,t.carry);t.kept_count=(t.kept_count or 0)+t.carry;t.carry=0;return true end
  local item=I.Find(h.work.inst,t.product);if not item then block(t,'已收取产物不在库存，停止自动交付且不重做');return false end
  if t.spec.destination~='player'and t.spec.destination~='ground'then
   local target=W.DepositTargets(h.work.inst,h.work,t,item);if target then return push(h,t,target,'deposit',item)end
  end
  local can=h.work:CanGive({owner=t.owner},item);if can and t.spec.destination~='ground'then return push(h,t,t.owner,'give',item)end
  return push(h,t,h.work.inst,'drop',item)
 end
 if t.done>=t.spec.quantity then t.state='completed';M.Release(t);local locations={};for _,v in pairs(t.deposits or {})do locations[#locations+1]='存入'..v.name..v.count..'份'end;if t.given_count then locations[#locations+1]='交给你'..t.given_count..'份'end;if t.kept_count then locations[#locations+1]='留在我库存'..t.kept_count..'份'end;if t.ground then locations[#locations+1]=string.format('放在附近地面%d份（%.1f，%.1f）',t.ground_count or 0,t.ground.x,t.ground.z)end;h.work:Announce('料理任务完成：本次收取新料理'..t.done..'份、存放/交付'..(t.target_stored or 0)..'份。'..(t.aux_stored and '原锅已有产物另处理'..t.aux_stored..'份。'or '')..table.concat(locations,'；')..'。');return false end
 if t.started then if live(pots[t.pot])and pots[t.pot]~=t then return false end;if t.pot and t.pot.components.stewer:IsDone()then return push(h,t,t.pot,'harvest')end;t.state='waiting';return false end
 if not usable(t.pot)then t.pot=locate(h,t)end
 local pot=t.pot;if not pot then block(t,'附近没有可用的已部署普通锅/便携锅，或锅正在被占用');return false end
 if live(pots[pot])and pots[pot]~=t then t.pot=nil;return false end
 pots[pot]=t
 if not t.watch then t.watch=function()t.wait_check=GetTime()end;pot:ListenForEvent('ybf_cook_change',t.watch);pot:ListenForEvent('onremove',t.watch)end
 if pot.components.stewer:IsCooking()then t.pot=nil;M.Release(t);return false end
 if pot.components.stewer:IsDone()then t.product=pot.components.stewer.product;t.was_requested=false;return push(h,t,pot,'harvest')end
 if opened(h,pot)then block(t,'锅正在被玩家操作，保留现有材料');return false end
 if t.spec.source=='warehouse_only'and not t.pot_prepared then local entries=slots(pot);if #entries>0 then local item=entries[1].item;if not I.Room(h.work.inst,item.prefab,1)then block(t,'背包无法保存锅中原有材料，不能违反只用仓库材料的约束');return false end;t.expected=nil;return push(h,t,pot,'remove',item)end;t.pot_prepared=true end
 if not t.plan then
  if not t.search then local request={};for k,v in pairs(t.spec)do request[k]=v end;request.remaining=t.spec.quantity-t.done;local stock=M.Stock(h,t,pot);local summary={};for name,row in pairs(stock)do summary[#summary+1]=name..':'..row.count end;table.sort(summary);M.Log(t,'search_start','stock='..table.concat(summary,',',1,math.min(#summary,40))..(#summary>40 and ',remaining_types='..(#summary-40)or '')..' pot='..pot.GUID);t.cook_stage='配方搜索';t.search=R.Search(pot.prefab,stock,request,t.spec.destination=='friend'and h.work.inst or t.owner);t.expected=fingerprint(pot)end
  local ok,plan,why=coroutine.resume(t.search);if not ok then print('[YBF COOK] task='..t.id..' phase=search_error detail='..tostring(plan));block(t,'官方配方求解失败，开发日志已记录，请重新核实');return false end
  if coroutine.status(t.search)~='dead'then M.Log(t,'search_yield','bounded_solver');return true end
  M.Log(t,'search_end','recipe='..tostring(plan and plan.recipe)..' reason='..tostring(not plan and why or 'verified_plan'))
  t.search=nil;if not plan then block(t,why..'；'..R.Gap(pot.prefab,M.Stock(h,t,pot),t.spec)..'不会自行找食材或擅自换菜。');return false end
  t.plan=plan;t.product=plan.recipe;if not reserve(h,t)then t.plan=nil;t.failures=(t.failures or 0)+1;M.Log(t,'reservation_failed','attempts='..t.failures);if t.failures>=3 then block(t,'食材被其他任务或玩家取走，请核实后恢复')end;return true end
 end
 if t.plan and t.reserved then for _,source in ipairs(t.reserved)do if source.item:IsValid()and source.item.components.inventoryitem.owner==source.where then W.Reserve(h.work.inst,h.work,t,source.item,source.count)end end end
 if fingerprint(pot)~=t.expected then t.pot_prepared=nil;M.Replan(h,t,'锅内材料发生变化');return true end
 local need={};for _,p in ipairs(t.plan.ingredients)do need[p]=(need[p]or 0)+1 end
 local occupied={};for _,v in ipairs(slots(pot))do if (need[v.prefab]or 0)>0 then need[v.prefab]=need[v.prefab]-1;occupied[v.slot]=true else if not I.Room(h.work.inst,v.prefab,1)then block(t,'背包无法接收需调整的锅内材料，不清空或销毁');return false end;return push(h,t,pot,'remove',v.item)end end
 for p,n in pairs(need)do if n>0 then
  local item=I.Find(h.work.inst,p);if t.spec.source=='warehouse_only'and(not t.acquired or (t.acquired[p]or 0)<1)then item=nil end;if item then
   local slot;for k=1,pot.components.container.numslots do if not pot.components.container.slots[k]then slot=k;break end end
   if not slot or not pot.components.container:CanTakeItemInSlot(item,slot)then block(t,'锅具当前不接受该材料');return false end
   return push(h,t,pot,'load',item,slot)
  end
  for _,c in ipairs(t.spec.source~='inventory_only'and W.Discover(h.work.inst,t,h.work.radius)or {})do for _,i in pairs(c.components.container.slots)do if i.prefab==p and W.Available(i,t)>0 then return push(h,t,c,'withdraw',i)end end end
  M.Replan(h,t,'计划食材已不在可用库存');return true
 end end
 return push(h,t,pot,'start')
end
return M
