-- Bounded per-friend accepted task ledger; the existing work engine remains executor.
local I=require('ybf_work_inventory');local P=require('ybf_build_positions');local Cooking=require('ybf_cooking_rules');local M={}
local function key(p)return p and (p.userid or tostring(p.GUID))end
local function terminal(t)return t.state=='completed' or t.state=='cancelled'end
function M.New(work)
 local h={work=work,tasks={},proposals={},sequence=0,revision=0};work.hub=h
 function h:ID()self.sequence=self.sequence+1;return tostring(work.inst.GUID)..'-'..self.sequence end
 function h:Owner(t)
  if t.owner and t.owner:IsValid()then return t.owner end
  for _,player in ipairs(AllPlayers or {})do if key(player)==t.ownerkey then t.owner=player;return player end end
 end
 function h:Proposal(player,spec)
  local k=key(player);local old=self.proposals[k];if old then old.state='cancelled'end
  local p={id=self:ID(),owner=k,friend=tostring(work.inst.GUID),spec=spec,created=GetTime(),expires=GetTime()+(TUNING.YBF_PROPOSAL_TTL or 60),state='pending',missing={}}
  self.proposals[k]=p;self.revision=self.revision+1
  return '要不要用现有食材给你做'..(spec.quantity or 1)..'份'..(spec.recipe and I.Label(spec.recipe)or '吃的')..'？'
 end
 function h:Pending(player)local p=self.proposals[key(player)];if p and p.state=='pending' and GetTime()>=p.expires then p.state='expired'end;return p and p.state=='pending' and p end
 function h:Accept(player,id)
  local p=self:Pending(player);if not p or id and p.id~=id then return '当前没有有效的待确认提议，请重新说明要做什么。',false end
  p.state='accepted';local t,why=self:Add('cook',p.spec,player,true);if not t then p.state='blocked';return why,false end
  p.task_id=t.id;return '好，已安排'..t.spec.quantity..'份，我先核实食材和锅具。',true
 end
 function h:Add(kind,spec,player,keep)
  local active=0;for _,t in ipairs(self.tasks)do if not terminal(t)then active=active+1 end end
  if active>=8 then return nil,'已有八项未结束任务，请先完成或取消一些。'end
  if not keep then local p=self:Pending(player);if p then p.state='cancelled'end end
  local t={id=self:ID(),kind=kind,spec=spec,owner=player,ownerkey=key(player),state='queued',created=GetTime(),center=work:Position(),world=P.World(),done=0,stored=0,failed={},attempt=0}
  while #self.tasks>=32 do local removed=false;for i,old in ipairs(self.tasks)do if terminal(old)then table.remove(self.tasks,i);removed=true;break end end;if not removed then break end end
  self.tasks[#self.tasks+1]=t;self.revision=self.revision+1;return t
 end
 function h:Adopt()
  local j=work.core.job;if not j then return end
  for _,t in ipairs(self.tasks)do if t.job==j then t.spec=j.spec or t.spec;t.done=j.count;if not t.paused then t.state=j.blocked and 'blocked'or 'running';t.reason=j.blocked and j.blocked.reason end;return t end end
  local t=self:Add('work',j.spec or {targets=j.targets,deliver=j.deliver,mode=j.intentmode},j.owner,true)
  if t then t.job=j;t.state=j.blocked and 'blocked' or 'running'end;return t
 end
 function h:Select(player,target,kind,all,prefer_running)
  local out={};for _,t in ipairs(self.tasks)do local match=t.id==target;if target and not match then if t.spec.recipe then match=target==t.spec.recipe or target==I.Label(t.spec.recipe)else for _,v in ipairs(t.spec.targets or {})do if target==v.item or target==I.Label(v.item)then match=true end end end end;if t.ownerkey==key(player)and not terminal(t)and (all or match or not target and (not kind or t.kind==kind))then out[#out+1]=t end end
  if prefer_running and not target and not kind and not all and #out>1 then local running={};for _,t in ipairs(out)do if t.state=='running'or t.state=='waiting'and t.started or self.inflight and self.inflight.task==t then running[#running+1]=t end end;if #running==1 then out=running end end
  if not all and #out~=1 then local candidates={};for _,t in ipairs(out)do local names={};for _,v in ipairs(t.spec.targets or {})do names[#names+1]=I.Label(v.item)end;candidates[#candidates+1]=(t.kind=='cook'and(t.spec.recipe and I.Label(t.spec.recipe)or '料理')or table.concat(names,'、'))..'（'..({queued='待执行',running='执行中',waiting='等待烹饪',blocked='受阻',paused='暂停'})[t.state]..'，'..t.id..'）'end;return nil,#out==0 and '没有对应的未结束任务。' or '要停止哪项：'..table.concat(candidates,'、')..'？'end;return out
 end
 function h:ControlEvidence(player,op,text)
  if not op.target or not text then return true end
  if text:find(op.target,1,true)then return true end
  local selected;for _,t in ipairs(self.tasks)do if t.id==op.target and t.ownerkey==key(player)and not terminal(t)then selected=t end end
  if not selected then return true end
  local function family(t)
   if t.kind=='cook'then return 'cook'end
   for _,v in ipairs(t.spec.targets or {})do if AllRecipes and AllRecipes[v.item]and AllRecipes[v.item].placer then return 'building'end end
   return t.kind
  end
  local matched_name
  if selected.spec.recipe and text:find(I.Label(selected.spec.recipe),1,true)then matched_name=selected.spec.recipe end
  for _,v in ipairs(selected.spec.targets or {})do if text:find(I.Label(v.item),1,true)then matched_name=v.item end end
  local count=0;for _,t in ipairs(self.tasks)do if t.ownerkey==key(player)and not terminal(t)then
   local match=family(t)==family(selected)
   if matched_name then match=t.spec.recipe==matched_name;for _,v in ipairs(t.spec.targets or {})do if v.item==matched_name then match=true end end end
   if op.type=='resume'and selected.paused and not(t.paused or t.state=='blocked')then match=false end
   if match then count=count+1 end
  end end
  if count~=1 then return false,'有多个同类任务，请明确任务编号；本项没有执行。'end
  return true
 end
 function h:Control(player,op)
  self:Adopt();local removed=false
  if op.type=='cancel'and(op.kind=='cook'or op.scope=='all')then local p=self:Pending(player);if p then p.state='cancelled';removed=true end end
  local rows,why=self:Select(player,op.target,op.kind,op.scope=='all',op.type=='cancel');if not rows then return removed and '未确认的料理提议已取消。'or why,removed end
  if op.type=='modify'and #rows==1 and rows[1].job and rows[1].job~=work.core.job and(work:ActionBusy()or self.inflight)then local queued,why=self:Add('control',op,player,true);return queued and '已安排在当前动作结束后修改。'or why,queued~=nil end
  for _,t in ipairs(rows)do
   if op.type=='cancel'then
    if t.job and t.job==work.core.job then work:Cancel(true)elseif t.job then require('ybf_warehouse').Release(t.job);require('ybf_building').Release(t.job)end
    require('ybf_cooking_executor').Invalidate(self,t,'control:'..op.type)
    require('ybf_cooking_executor').Release(t);t.state='cancelled';t.reason=t.started and '停止后续收取；原版锅继续加工，材料已消耗' or '已取消，已有物品保留'
   elseif op.type=='pause'then
    if t.job and t.job==work.core.job then work:PauseTask()end
    require('ybf_cooking_executor').Invalidate(self,t,'control:'..op.type)
    t.paused=true;t.state='paused';require('ybf_cooking_executor').Release(t)
   elseif op.type=='resume'then t.paused=nil;t.reason=nil;t.last_block_reason=nil;t.prep_progress=GetTime();t.prep_busy_since=nil;t.replans=0;t.failures=0;if t.job then if work.core.job and work.core.job~=t.job then local old=self:Adopt();local oldjob=work.core.job;oldjob.attempt=(oldjob.attempt or 0)+1;oldjob.inflight=false;work.core.sequence=work.core.sequence+1;oldjob.serial=work.core.sequence;work:StopAction();require('ybf_warehouse').Release(oldjob);require('ybf_building').Release(oldjob);if old then old.state='queued';old.suspended_at=GetTime()end end;work.core.job=t.job;work:ResumeTask();t.state='running'else t.state=t.started and 'waiting' or 'queued'end
   elseif op.type=='modify'then
    if t.kind=='cook'then if op.operation=='remove'then return '删除料理任务请使用单项取消。',false end;local quantity=op.operation=='add'and t.spec.quantity+op.quantity or op.quantity;if quantity>20 or quantity<t.done then return '数量须为已收取数量到20之间。',false end;t.spec.quantity=quantity;if op.destination then t.spec.destination=op.destination end
    elseif t.job then local saved=work.core.job;work.core.job=t.job;local ok,msg=work:ModifyTask(op.item,op.quantity,op.operation or 'set');if saved~=t.job then work.core.job=saved end;if not ok then return msg,false end;t.spec=t.job.spec or t.spec
    elseif t.kind=='work'then
     local spec=require('ybf_task_intent').Copy(t.spec);local found=false;local targets={}
     if not op.item and #spec.targets~=1 then return '请说明要修改哪种物品。',false end
     for _,v in ipairs(spec.targets)do if not op.item or v.item==op.item then found=true;if op.operation~='remove'then v.quantity=op.operation=='add'and v.quantity+op.quantity or op.quantity;targets[#targets+1]=v end else targets[#targets+1]=v end end
     if not found then if op.operation=='append'and op.item then targets[#targets+1]={item=op.item,quantity=op.quantity}else return '任务中没有这项目标。',false end end
     spec.targets=targets;t.spec=spec;if #targets==0 then t.state='cancelled';t.reason='最后一项目标已移除'end
    else return '该项不能这样修改。',false end
   end
  end
  self.revision=self.revision+1;return '已处理'..#rows..'项任务。'..(op.type=='cancel' and rows[1]and rows[1].reason or ''),true
 end
 function h:List(player)
  self:Adopt();local words={queued='待执行',running='执行中',waiting='等待烹饪',blocked='受阻',paused='已暂停',completed='已完成',cancelled='已取消'};local destinations={auto='合适友谊容器优先',player='给玩家',warehouse='友谊容器',ground='附近地面',friend='朋友库存'};local out={};local bytes=0;local omitted=0
  local function add(line)if bytes+#line<=1100 then out[#out+1]=line;bytes=bytes+#line else omitted=omitted+1 end end
  local p=self:Pending(player);if p then add('提议 '..p.id..'：待确认')end
  local ordered={};for _,t in ipairs(self.tasks)do if t.ownerkey==key(player)and not terminal(t)then ordered[#ordered+1]=t end end;local closed=0;for index=#self.tasks,1,-1 do local t=self.tasks[index];if t.ownerkey==key(player)and terminal(t)and closed<4 then ordered[#ordered+1]=t;closed=closed+1 end end
  for _,t in ipairs(ordered)do if t.ownerkey==key(player)then
   local names={};local total=t.spec.quantity or 0
   if t.kind=='control'then names[1]='任务控制';total=1 elseif t.kind=='cook'then names[1]=t.spec.recipe and I.Label(t.spec.recipe)or '料理'else for _,v in ipairs(t.spec.targets or {})do names[#names+1]=I.Label(v.item);total=total+v.quantity end end
   local name=#names>0 and table.concat(names,'、')or '原工作';local reason=t.state=='blocked'and t.reason and '；'..t.reason or ''
   add(t.id..' '..name..'：'..(words[t.state]or t.state)..'，'..(t.done or 0)..'/'..total..'，'..(destinations[t.spec.destination]or(t.spec.deliver and '给玩家'or '原任务去向'))..reason)
  end end
  if omitted>0 then out[#out+1]='另有'..omitted..'项，请按编号询问。'end
  return #out>0 and table.concat(out,'。')or '当前没有任务或提议。'
 end
 function h:Protected(p)
  local n=math.min(self.held_outputs and self.held_outputs[p]or 0,I.Count(work.inst,p,true));for _,t in ipairs(self.tasks)do if not terminal(t)and t.kind=='cook'then if t.product==p then n=n+(t.carry or 0)end;if t.plan then for _,v in ipairs(t.plan.ingredients)do if v==p then n=n+1 end end end end end;return n
 end
 function h:Snapshot(player)
  local p=self:Pending(player);local rows={};for _,t in ipairs(self.tasks)do if t.ownerkey==key(player)and not terminal(t)then rows[#rows+1]={id=t.id,kind=t.kind,state=t.state,quantity=t.spec.quantity,targets=t.spec.targets,recipe=t.spec.recipe,done=t.done,destination=t.spec.destination,reason=t.reason}end end
  local recent={};for index=#self.tasks,1,-1 do local t=self.tasks[index];if t.ownerkey==key(player)and terminal(t)and #recent<4 then recent[#recent+1]={id=t.id,kind=t.kind,state=t.state,recipe=t.spec.recipe,done=t.done,stored=t.stored}end end
  return {tasks=rows,recent=recent,proposal=p and {id=p.id,spec=p.spec,missing=p.missing,seconds=math.max(0,p.expires-GetTime())},classification='荤含肉/鱼/蛋/乳标签；素不含这四类；植物肉按原版肉标签',revision=self.revision}
 end
 function h:Operations(player,ops,origin,text)
  if not require('ybf_operations').Validate(ops)then return '操作列表无效。',false end
  local out={};local accepted=false;local previous;local results={}
  local R=require('ybf_cooking_rules')
  for index,op in ipairs(ops)do
   previous=op.depends_on and results[op.depends_on]or nil
   local invalid
   if op.target and(op.type=='cancel'or op.type=='pause'or op.type=='resume'or op.type=='modify')then local verified,why=self:ControlEvidence(player,op,text);if not verified then invalid=why end end
   if op.type=='modify'and op.item then local p,code,candidates=require('ybf_knowledge').Resolve(work.inst,op.item,text or '',true);if p then op.item=p else invalid=require('ybf_knowledge').FailureText(code,candidates)end end
   if op.recipe then local name,why=R.Resolve(op.recipe,text or '',work.inst);if not name then invalid=why else op.recipe=name end end
   if op.type=='goal'then for _,target in ipairs(op.goal.targets)do
    local K=require('ybf_knowledge');K.ObserveInventory(work.inst)
    local resolved,code,candidates=K.Resolve(work.inst,target.item,text or '',true)
    if not resolved and code=='qualified_name_unresolved'then
     local clauses=(text or ''):gsub('，','\n'):gsub('。','\n'):gsub('；','\n'):gsub('[,;]','\n')
     for clause in clauses:gmatch('[^\n]+')do
      for _,connector in ipairs({'然后','接着','先','再'})do if clause:sub(1,#connector)==connector then local rest=clause:sub(#connector+1);if rest:sub(1,6)=='给我'or rest:sub(1,6)=='帮我'or rest:sub(1,3)=='找'or rest:sub(1,3)=='拿'or rest:sub(1,3)=='做'or rest:sub(1,3)=='造'then clause=rest;break end end end
      local positive=clause:find('给我',1,true)or clause:find('找',1,true)or clause:find('拿',1,true)or clause:find('做',1,true)or clause:find('造',1,true)or clause:find('采',1,true)
      local negative=clause:find('不要',1,true)or clause:find('不用',1,true)or clause:find('别',1,true)or clause:find('取消',1,true)or clause:find('不是',1,true)or clause:find('停止',1,true)
      if positive and not negative then local p,why,choices=K.Resolve(work.inst,target.item,clause,true);if p then resolved=p;code=why;candidates=choices;break end end
     end
    end
    if not resolved then invalid=require('ybf_knowledge').FailureText(code,candidates)else target.item=resolved end
   end end
   if invalid then out[#out+1]=invalid;results[index]=nil
   elseif op.depends_on and not previous then out[#out+1]='依赖的前项尚未安排，本项未开始。'
   elseif previous and previous.task and previous.task.state~='completed'and(op.type=='cancel'or op.type=='pause'or op.type=='resume'or op.type=='modify')then
    local t,why=self:Add('control',op,player,true);if t then t.depends=previous.task.id;previous={task=t};out[#out+1]='已安排完成前项后执行控制 '..t.id else previous=nil;out[#out+1]=why end
   elseif op.type=='propose'then out[#out+1]=self:Proposal(player,op);previous={}
   elseif op.type=='accept'then local s,ok=self:Accept(player,op.proposal_id);out[#out+1]=s;accepted=accepted or ok;previous=ok and {task=self.tasks[#self.tasks]}or nil
   elseif op.type=='reject'then local p=self:Pending(player);if p then p.state='cancelled';out[#out+1]='好，未确认的做饭提议取消了。'else out[#out+1]='没有有效的待确认提议。'end
   elseif op.type=='modify_proposal'then local p=self:Pending(player);if p then self.revision=self.revision+1; if op.quantity then p.spec.quantity=op.quantity end;if op.destination then p.spec.destination=op.destination end;if op.category then p.spec.category=op.category end;if op.recipe then p.spec.recipe=op.recipe end;if op.source then p.spec.source=op.source end;p.expires=GetTime()+(TUNING.YBF_PROPOSAL_TTL or 60);out[#out+1]='提议已调整，还没有开始；要执行请确认。'else out[#out+1]='提议已过期，请重新说明。'end
   elseif op.type=='status'then out[#out+1]=self:List(player);previous={}
   elseif op.type=='cook'or op.type=='goal'then
    local kind=op.type=='cook'and 'cook'or 'work';local spec=op.type=='cook'and op or op.goal
    if kind=='work'then spec._server_origin=origin end
    local t,why=self:Add(kind,spec,player,accepted or op.append);if t then t.depends=op.depends_on and previous and previous.task and previous.task.id;t.state='queued';previous={task=t};out[#out+1]='已安排'..(kind=='cook'and '料理' or '获取/制作')..'任务 '..t.id else out[#out+1]=why;previous=nil end
   elseif op.type=='unsupported'then out[#out+1]=op.reason or '这项能力尚未支持。';previous=nil
   else local message,ok=self:Control(player,op);out[#out+1]=message;previous=ok and {}or nil end
   results[index]=previous
  end
  return table.concat(out,'。'),true
 end
 function h:ShortReply(player,text,proposal_id,revision)
  local p=self:Pending(player)
  if (text=='要'or text=='好'or text=='好呀'or text=='好啊'or text=='行'or text=='可以'or text=='做吧'or text=='要的'or text=='可以，做吧')and(p or text=='要'or text=='做吧')then return self:Accept(player,proposal_id)end
  if p and (text=='不要'or text=='不用'or text=='算了')then p.state='cancelled';self.revision=self.revision+1;return '好，提议取消，还没有取材或开锅。',true end
  if p and (text:find('怎么做',1,true)or text:find('什么方案',1,true))then p.expires=GetTime()+(TUNING.YBF_PROPOSAL_TTL or 60);return '接受后我会核实自己的食材和附近友谊容器，选可保证产物的四槽组合，用空闲锅做一份；缺材料不会自行采集。',false end
  if (text=='我饿了'or text=='肚子好饿'or text=='有点饿了')and(not revision or revision==self.revision)then return self:Proposal(player,{type='cook',quantity=1,destination='player',category='any'}),false end
 end
 function h:LegacyFinished(j,result)
  if self.held_outputs then for p,n in pairs(j.given or {})do self.held_outputs[p]=math.max(0,(self.held_outputs[p]or 0)-n)end end
  for _,t in ipairs(self.tasks)do if t.job==j and t.state~='cancelled'then t.state=result.reached_goal and 'completed'or 'blocked';t.reason=result.summary;t.done=j.count end end
 end
 function h:Tick()
  self:Adopt();local now=GetTime();for _,p in pairs(self.proposals)do if p.state=='pending'and now>=p.expires then p.state='expired'end end
  local E=require('ybf_cooking_executor');E.Reconcile(self);E.Poll(self);for _,t in ipairs(self.tasks)do if t.kind=='cook'and not terminal(t)and not t.paused and t.state~='blocked'then E.Log(t,'scheduler','inflight='..tostring(self.inflight and self.inflight.task==t)..' started='..tostring(t.started==true))end end
  if E.Flight(self)then return true end
  if work:ActionBusy()or work.core.job and work.core.job.inflight then for _,t in ipairs(self.tasks)do if t.kind=='cook'and not terminal(t)and not t.paused and not t.started and t.state~='blocked'and(not work.core.job or work.core.job.blocked and not work.core.job.inflight)and not t.depends then t.friend=work.inst;E.Busy(self,t)end end;return false end
  -- Suspended/blocked work releases the execution slot, never its progress.
  local current=self:Adopt();local other=false;for _,task in ipairs(self.tasks)do if task~=current and not terminal(task)and not task.paused and(task.state=='queued'or task.state=='running')then other=true end end
  if current and other and (current.paused or work.core.job.blocked)then current.suspended_at=current.suspended_at or now;work.core.job=nil end
  for _,t in ipairs(self.tasks)do if not terminal(t)and not t.paused and t.state~='blocked'and t.state~='waiting'then
   local dependency;for _,d in ipairs(self.tasks)do if d.id==t.depends then dependency=d end end
   if t.depends and(not dependency or dependency.state=='cancelled')then t.state='blocked';t.reason='前项已取消或记录无法恢复，后续依赖未执行';work:Announce(t.reason)end
   if not t.depends or dependency and dependency.state=='completed'then
    if t.kind=='control'then
     local player=self:Owner(t);if player then local message,ok=self:Control(player,t.spec);t.state=ok and 'completed'or 'blocked';t.done=ok and 1 or 0;t.reason=message;work:Announce(message)end;return false
    elseif t.kind=='cook'then
     if work.core.job then t.prep_progress=nil;t.prep_busy_since=nil;return false end
     local player=self:Owner(t);if not player or not work:OwnerValid(player)then E.Block(self,t,'持有人离开或授权变化');return false end
     local ok,result=pcall(E.Step,self,t);if not ok then E.Log(t,'executor_error',tostring(result));E.Block(self,t,'料理执行器发生异常，详细堆栈线索已写入日志');return false end;return result
    elseif not work.core.job then
     if t.job then work.core.job=t.job;t.state='running';if t.suspended_at then local delta=now-t.suspended_at;t.job.started=t.job.started+delta;t.job.deadline=t.job.deadline+delta;t.suspended_at=nil end;t.job.lastprogress=now;t.job.started=t.job.started or now;return false end
     local player=self:Owner(t);if not player then t.reason='等待原持有人重新上线';return false end
     local ok,why=work:RequestIntent(t.spec,player);if ok then t.job=work.core.job;t.state='running';require('ybf_task_persistence').ApplyLegacy(work,t)else t.state='blocked';t.reason=why end;return false
    end
   end
  end end
  return false
 end
 return h
end
return M
