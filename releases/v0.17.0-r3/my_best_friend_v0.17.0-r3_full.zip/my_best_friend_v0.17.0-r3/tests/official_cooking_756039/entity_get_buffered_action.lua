-- Exact build 756039 native getter: fallback is central to the timeout defect.
local EntityScript={}
function EntityScript:GetBufferedAction()
    return self.bufferedaction or (self.components.locomotor ~= nil and self.components.locomotor.bufferedaction) or nil
end
return EntityScript.GetBufferedAction
