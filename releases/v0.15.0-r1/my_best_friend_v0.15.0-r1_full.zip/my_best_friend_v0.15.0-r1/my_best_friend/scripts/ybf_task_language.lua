-- Clause roles for permissions/destination; model still resolves item identities.
local M={}
local function any(text,words)for _,w in ipairs(words) do if text:find(w,1,true) then return true end end end
function M.Apply(text,spec,owner)
 spec.constraints=spec.constraints or {}
 local storage=any(text,{'箱','仓库','容器'})
 local use=any(text,{'材料','用','取','拿','不够','不足'})
 local only=any(text,{'只用','仅用','只能用','不要出去','不许采','别去找','不再找'})
 if storage and any(text,{'普通箱','普通容器','未授权','没有友谊'}) and (use or any(text,{'放','存'})) then spec.permission_error='普通容器没有自动存取授权；请先用友谊小花赋予友谊，或指定友谊容器。' end
 if storage and use then spec.constraints.source=only and 'warehouse_only' or 'warehouse_first' end
 if any(text,{'自身库存','自己包里','你包里'}) and only and not storage then spec.constraints.source='inventory_only';spec.constraints.existing_only=true end
 if storage and any(text,{'存进','存入','放箱','放到箱','放进箱','装箱','放仓库','放到容器','放在箱'}) then spec.destination='warehouse' end
 if any(text,{'给我','交给我','交给玩家','拿给我'}) then spec.destination='player' end
 if any(text,{'放地上','放到地上','放在地上','放脚边','放在我旁边','放到我旁边'}) then
  spec.destination='ground'
  if owner and any(text,{'脚边','我旁边'}) then local x,_,z=owner.Transform:GetWorldPosition();spec.ground_position={x=x,y=0,z=z} end
 end
 if not spec.destination and not spec.recipient then spec.destination='auto' end
 return spec
end
function M.StorageMention(expression,text)
 return (text:find('材料',1,true) or text:find('用',1,true) or text:find('取',1,true) or text:find('拿',1,true) or text:find('放',1,true) or text:find('存',1,true)) and (expression.text:find('箱',1,true) or expression.text=='冰箱' or expression.text=='盐盒')
end
function M.QuantifiedName(hit)
 local before=hit.grammar and hit.grammar.before or ''
 -- A quantity/unit ends before the verified name, delimiting the noun phrase.
 -- Qualifiers between the number and name never satisfy this boundary.
 for _,q in ipairs({'黄金','烧灼','灼烧','损坏','破损','暗影','远古','月光','升级','皮肤'}) do if before:find(q,1,true) then return false end end
 for _,unit in ipairs({'个','把','根','块','件','份','张','顶','条','副','双'}) do if before:sub(-#unit)==unit then before=before:sub(1,#before-#unit);break end end
 local numbered=before:match('%d+$')~=nil
 for _,n in ipairs({'一','二','两','三','四','五','六','七','八','九','十'}) do if before:sub(-#n)==n then numbered=true end end
 if not numbered then
  local after=hit.grammar and hit.grammar.after or ''
  for _,verb in ipairs({'不要','删除','去掉','删掉','取消'}) do if before==verb and (after=='' or after=='了' or after=='吧') then return true end end
  return false
 end
 local after=hit.grammar and hit.grammar.after or ''
 if after=='' then return true end
 -- Remaining clause can introduce a conjunction/quantity or purpose/storage,
 -- but a postfix state/skin qualifier must still be checked.
 for _,q in ipairs({'黄金','烧灼','灼烧','损坏','破损','暗影','远古','月光','升级','皮肤'}) do if after:find(q,1,true) then return false end end
 return after:sub(1,#'和')=='和' or after:sub(1,#'及')=='及' or after:sub(1,#'与')=='与' or after:sub(1,#'呗')=='呗' or after:sub(1,#'吧')=='吧'
end
return M
