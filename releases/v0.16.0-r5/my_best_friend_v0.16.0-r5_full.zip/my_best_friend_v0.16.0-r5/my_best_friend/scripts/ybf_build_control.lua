local B=require('ybf_building');local P=require('ybf_build_positions');local Chat=require('ybf_chat_server');local M={}
local function emit(work,kind,b,extra)
 local j=work.core.job;local d=extra or {};d.kind=kind;d.friend=work.inst.GUID;d.task=j.id;d.target=b.id;d.text=d.text or ''
 local ok,err=pcall(Chat.Emit,_G,j.owner,d)
 if not ok then print("[YBF BUILD] notification_failed kind="..kind.." task="..tostring(j.id)..": "..tostring(err)) end
end
function M.Begin(work,b)
 local j=work.core.job
 for _,other in pairs(j.builds or {})do if other~=b and other.pick and other.pick.expires>GetTime()then return end end
 if b.pick and b.pick.expires>GetTime()then return end
 b.pick_sequence=(b.pick_sequence or 0)+1;b.pick={nonce=tostring(j.serial)..':'..b.id..':'..b.pick_sequence,expires=GetTime()+90}
 emit(work,'build_pick',b,{nonce=b.pick.nonce,recipe=b.recipe,rotation=b.rotation,text='左键点选施工位置，右键或Esc取消；Q/E调整朝向。'})
end
function M.CancelPicks(work,except)
 local j=work.core.job;if not j then return end
 for _,b in pairs(j.builds or {})do if b~=except then b.pick=nil;emit(work,'build_pick_cancel',b)end end
end
function M.Invalidate(work,selected)
 local j=work.core.job;work.point_receipt=nil;M.CancelPicks(work,selected);work:StopAction();B.Release(j);j.attempt=(j.attempt or 0)+1;j.inflight=false
 work.core.sequence=work.core.sequence+1;j.serial=work.core.sequence;j.control_revision=(j.control_revision or 0)+1;j.failed={};j.target_blocks={};j.lastprogress=GetTime()
 if not j.manual_pause then
  j.blocked=nil;j.fatal=nil;j.settle_until=nil;work.returning=nil
  work.inst.components.ybf_friend.mode='work';work.inst.components.ybf_friend:ApplyMovementPolicy()
 end
end
function M.Submit(work,player,task,target,nonce,x,z,rotation,cancel)
 local j=work.core.job
 if not j or j.id~=task or j.owner~=player or not work:OwnerValid(player)then return false,'点选所属任务或持有人已变化' end
 if j.nonresumable or j.uncertain then return false,'先前结果尚未核实，不能修改后重复施工；请检查现场并取消任务' end
 local b;for _,v in pairs(j.builds or {})do if v.id==target then b=v end end
 if not b or not b.pick or b.pick.nonce~=nonce or b.pick.expires<GetTime()then return false,'点选已失效，请重新请求指定位置' end
 if cancel then b.pick=nil;b.blocked='已取消点选，材料与预制状态保留';B.Release(j,b);return true,'点选已取消，不会施工；要重新选请说“改为指定位置”。' end
 if not P.Finite(x) or not P.Finite(z) or not P.Finite(rotation) or rotation<0 or rotation>=360 then return false,'坐标或朝向无效' end
 if b.world~=P.World()or (x-j.center.x)^2+(z-j.center.z)^2>work.radius^2 then return false,'点选超出本任务分片或附近工作范围' end
 M.Invalidate(work,b);b.pick=nil;b.position={x=x,y=0,z=z};b.rotation=rotation;b.blocked=nil;b.failures=0;b.location_notified=nil
 emit(work,'build_marker',b,{x=x,z=z,rotation=rotation,text=string.format('位置已确认（%.1f，%.1f），朝向%.0f°；接下来准备材料并施工。',x,z,rotation)})
 b.location_notified=true
 return true,'位置已确认，我会准备材料并施工，不需要再确认。'
end
function M.PositionReady(work,b)
 if not b.location_notified then
  b.location_notified=true
  emit(work,'build_marker',b,{x=b.position.x,z=b.position.z,rotation=b.rotation,text='位置已确认，接下来准备材料并施工，无需再次确认。'})
 end
end
function M.Text(work,text,player)
 local j=work.core.job;if not j or j.owner~=player or not j.builds or not next(j.builds)then return end
 if require('ybf_knowledge').QuestionKind(text)then return end
 if j.nonresumable or j.uncertain then return '先前施工结果尚未核实，请先检查现场并取消任务。' end
 local placement=P.Parse(text)
 local angle=text:match('朝向%s*(%d+)')or text:match('旋转%s*(%d+)')
 if not placement and not angle then return end
 if text:find('再建',1,true) or text:find('新增',1,true) or text:find('再做',1,true) then return end
 local candidates={};local expressions=require('ybf_knowledge').Expressions(work.inst,text);local explicit={}
 for _,e in ipairs(expressions)do for _,v in ipairs(e.candidates or {})do explicit[v.prefab]=true end end
 for _,t in ipairs(j.targets)do local b=j.builds[t.item];if b and #b.placed<t.quantity and (next(explicit)==nil or explicit[t.item])then candidates[#candidates+1]=b end end
 if #candidates==0 then return end
 for _,unit in ipairs({'个','座','栋','间'})do if text:match('%d+'..unit)then return end;for _,n in ipairs({'一','二','两','三','四','五','六','七','八','九','十'})do if text:find(n..unit,1,true)then return end end end
 if #candidates~=1 then return '请说明要修改哪一项建筑的定位，不能把同一句位置选择套用到所有建筑。' end
 local b=candidates[1]
 if b.mode~='choose' and not b.pick and not (placement and placement.mode=='player') and not angle and not text:find('改',1,true) and not text:find('位置',1,true) and not text:find('点选',1,true) and not text:find('按',1,true) then return end
 if angle and (tonumber(angle)>=360)then return '朝向请用0到359度。' end
 M.Invalidate(work);b.blocked=nil;b.failures=0;b.pick=nil;b.location_notified=nil
 if angle then b.rotation=tonumber(angle)end
 if placement then
  b.mode=placement.mode;b.position=nil;b.position_reason=nil
  if b.mode=='player' then local pos=player:GetPosition();b.position={x=pos.x,y=0,z=pos.z};b.world=P.World()
  elseif b.mode=='tile' then
   local pos=player:GetPosition();local point,reason=P.Tile(TheWorld.Map,{x=pos.x,z=pos.z},placement.tile,TUNING.YBF_TILE_SNAP)
   b.position=point;b.position_reason=reason
   if not point then b.blocked=reason;return reason end
  elseif b.mode=='fixed'then M.Begin(work,b)end
 end
 if b.position then emit(work,'build_marker',b,{x=b.position.x,z=b.position.z,rotation=b.rotation,text='对齐位置已记录，玩家移动不会改变坐标。'})end
 return b.mode=='player' and '位置已确认，接下来准备材料并施工。' or b.mode=='fixed' and '进入地面点选；左键选择，右键或Esc取消，Q/E调整朝向。' or b.mode=='free' and '改为附近有限范围自由选址，保留既有进度。' or '地皮定位与朝向已记录；位置非法时不会偏移。'
end
return M
