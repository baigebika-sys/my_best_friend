-- Standard buffered placer recipes; original Builder is the only creator.
local P=require('ybf_build_positions');local I=require('ybf_work_inventory');local C=require('ybf_work_crafting')
local M={};local claims={}
function M.Recipe(name)
 local r=GetValidRecipe and GetValidRecipe(name) or AllRecipes and AllRecipes[name]
 if r then return r.placer and r or nil end
 local found
 for _,v in pairs(AllRecipes or {})do if v.product==name and v.placer then if found then return nil end;found=v end end
 return found
end
function M.Release(j,b)
 for key,c in pairs(claims)do if c.job==j and (not b or c.build==b)then claims[key]=nil end end
end
function M.Claim(work,j,b,recipe)
 local point=b.position;local radius=math.max(.25,recipe.min_spacing or 3.2);local now=GetTime()
 for key,c in pairs(claims)do
  if c.expires<now or not c.inst:IsValid() or c.work.core.job~=c.job or c.job.blocked or c.job.manual_pause then claims[key]=nil
  elseif c.build~=b and c.world==b.world and (point.x-c.point.x)^2+(point.z-c.point.z)^2<math.max(c.radius,radius)^2 then return false,'与另一位朋友的待建位置冲突' end
 end
 claims[b]={build=b,job=j,inst=work.inst,work=work,world=b.world,point=point,radius=radius,expires=now+40};return true
end
function M.Supported(r)
 if not r or type(r.placer)~='string' then return false,'没有唯一有效的建筑配方' end
 if r.sg_state then return false,'要求特殊施工状态图的建筑尚未适配' end
 if r.manufactured or r.dropitem or r.unlocks_from_skin or r.character_ingredients and next(r.character_ingredients) then return false,'特殊加工、特殊消耗或皮肤解锁建筑尚未适配' end
 if BUILDMODE and r.build_mode==BUILDMODE.WATER or r.overridecandeployrecipeatpointfn then return false,'水上或自定义占地规则尚未适配' end
 if r.placer:find('boat',1,true) or r.placer:find('dock',1,true) or r.placer:find('turf',1,true) then return false,'船只、码头或铺地配方尚未适配' end
 if (r.numtogive or 1)~=1 or r.override_numtogive_fn then return false,'多产物或动态产物建筑尚未适配' end
 return true
end
-- Retire only obsolete player-wait state; preserve manual pauses and other blockers.
function M.ClearPlayerWait(work,j)
 local function old(code)return code=='waiting_player' or code=='player_wait_timeout'end
 j.pending_build_wait=nil
 for _,b in pairs(j.builds or {})do b.wait_started=nil;if b.status=='waiting_player'then b.status=b.prepaid and 'buffered' or 'await_location';b.blocked=nil end end
 for key,block in pairs(j.target_blocks or {})do if old(block.code)then j.target_blocks[key]=nil end end
 if j.blocked and old(j.blocked.code) and not j.manual_pause then
  j.blocked=nil;j.fatal=nil;j.lastprogress=GetTime();work.returning=nil
  work.inst.components.ybf_friend.mode='work';work.inst.components.ybf_friend:ApplyMovementPolicy()
 end
end
function M.Sync(work,j)
 M.ClearPlayerWait(work,j)
 j.builds=j.builds or {};local retained={}
 for index,t in ipairs(j.targets)do
  local r=M.Recipe(t.item)
  if r then
   local b=j.builds[t.item]
   if not b then
    j.build_sequence=(j.build_sequence or 0)+1
    b={id=tostring(j.id)..'-building-'..j.build_sequence,item=t.item,recipe=r.name,product=r.product,placed={},status='await_location',world=j.location_origin and j.location_origin.world or P.World(),origin={x=j.center.x,z=j.center.z},rotation=0,mode='fixed',index=index}
    j.builds[t.item]=b
   end
   if work.inst.components.builder and work.inst.components.builder:IsBuildBuffered(r.name)then b.status='buffered';b.prepaid=true end
   t.id=b.id;retained[t.item]=true
   local placement=t.placement or j.spec and j.spec.placement
   if placement and not b.placement_initialized then
    b.placement_initialized=true
    b.mode=placement.mode or 'fixed';b.rotation=placement.rotation or 0
    if b.mode=='player' and j.location_origin then b.position={x=j.location_origin.x,y=0,z=j.location_origin.z};b.world=j.location_origin.world or P.World() end
    if b.mode=='tile' and j.location_origin then
     local point,reason=P.Tile(TheWorld.Map,j.location_origin,placement.tile,TUNING.YBF_TILE_SNAP)
     b.position=point;b.world=P.World();b.position_reason=reason
    end
   end
  end
 end
 for key,b in pairs(j.builds)do if not retained[key]then M.Release(j,b);j.builds[key]=nil end end
end
local function legal(inst,b,r)
 if b.world~=P.World()then return false,'指定位置属于其他世界分片' end
 if not P.Valid(b.position)then return false,b.position_reason or '尚未指定施工位置' end
 local p=P.Point(b.position)
 if TheWorld.Map.GetPlatformAtPoint and TheWorld.Map:GetPlatformAtPoint(p.x,p.z) then return false,'移动平台上的建筑尚未适配' end
 return TheWorld.Map:CanDeployRecipeAtPoint(p,r,b.rotation,inst), '地形、占地或配方放置条件不合法'
end
M.Legal=legal
-- Same collision predicate as build756039 Map.IsNearOther; only used diagnostically.
local function near(e,pt,sq,spacing)
 if sq<=0 and e:HasTag('structure')then if e.deploy_extra_spacing then sq=e.deploy_extra_spacing^2 end
 elseif e.deploy_smart_radius then spacing=e.deploy_smart_radius+spacing/2;sq=spacing^2
 elseif e.deploy_extra_spacing then sq=math.max(e.deploy_extra_spacing^2,sq)
 elseif e.replica and e.replica.inventoryitem then spacing=e:GetPhysicsRadius(.5)+spacing/2;sq=math.min(spacing^2,sq)end
 return e:GetDistanceSqToPoint(pt)<sq
end
function M.Obstruction(work,j,b,r)
 if not P.Valid(b.position) or r.overridecandeployrecipeatpointfn or not TheWorld.Map.IsDeployPointClear then return nil end
 local pt=P.Point(b.position);local blockers={}
 -- Original map iteration preserves ignored tags, visibility, parent and arena rules.
 TheWorld.Map:IsDeployPointClear(pt,nil,r.min_spacing or 3.2,nil,function(e,p,sq,spacing)
  if near(e,p,sq,spacing)then blockers[#blockers+1]=e end;return false
 end)
 if #blockers==0 then return nil end
 for _,e in ipairs(blockers)do
  local inv=e.components.inventoryitem
  if not inv or inv.owner or not inv.canbepickedup or e:HasTag('heavy') then return nil,'施工点受到建筑、植物或不可携带实体遮挡；不会自动清除' end
 end
 local e=blockers[1]
 if work.inst.components.inventory:CanAcceptCount(e)<I.Size(e) then return nil,'施工点物品需要拾取，但背包空间不足；请存放物品或清理现场' end
 if (j.failed[e] or 0)>=2 then return nil,'施工点物品无法可靠拾取' end
 j.step='pickup';j.collectitem=e.prefab;j.invobject=nil;j.giveitem=nil;j.recipe=nil;j.phase='仅拾取原版判定的施工遮挡物'
 return e
end
function M.SelectFree(work,j,b,r)
 local limit=math.min(12,work.radius);local step=math.max(2,r.min_spacing or 3.2);local candidates={{x=b.origin.x,z=b.origin.z}}
 for ring=1,math.floor(limit/step)do
  local n=math.max(8,ring*8)
  for i=1,n do local angle=2*math.pi*i/n;candidates[#candidates+1]={x=b.origin.x+ring*step*math.cos(angle),z=b.origin.z+ring*step*math.sin(angle)}end
 end
 b.search_count=0
 for _,p in ipairs(candidates)do
  b.search_count=b.search_count+1;if b.search_count>81 then break end
  local key=string.format('%.2f:%.2f',p.x,p.z)
  local used=false;for _,e in ipairs(b.placed)do if (e.x-p.x)^2+(e.z-p.z)^2<.01 then used=true end end
  if not used and not (b.failed_points and b.failed_points[key])then
   b.position=p
   local reachable=true;local pf=TheWorld.Pathfinder
   if pf and pf.IsClear then local from=work.inst:GetPosition();reachable=pf:IsClear(from.x,0,from.z,p.x,0,p.z,work.inst.components.locomotor.pathcaps) end
   if reachable and legal(work.inst,b,r) and M.Claim(work,j,b,r) then return true end
  end
 end
 b.position=nil;return false,'12单位有限选址范围内没有合法、未被预留的施工位置'
end
function M.Next(work,j,t,planner)
 M.Sync(work,j);local b=j.builds[t.item];local r=M.Recipe(t.item);j.build_current=b
 local ok,why=M.Supported(r);if not ok then return nil,why,'unsupported_building' end
 if #b.placed>=t.quantity then return true end
 if b.blocked then return nil,b.blocked,'building_blocked' end
 if b.mode=='choose' then return nil,'请选定位方式：附近自由建造、指定位置点选，或按脚下地皮中心建','location_choice' end
 if (b.mode=='tile' or b.mode=='player') and t.quantity>1 then return nil,'玩家坐标或地皮中心单点只对应一座建筑；请分别点选或改为附近自由选址','multiple_positions' end
 if b.mode=='fixed' and not b.position then work:BeginBuildPick(b);return nil,'请点击地面指定这一座建筑的位置；右键或Esc取消点选','await_location' end
 if b.mode=='tile' and not b.position then return nil,b.position_reason or '请用站位明确要对齐的地皮组','location_unresolved' end
 if b.mode=='free' and not b.position then local good,reason=M.SelectFree(work,j,b,r);if not good then return nil,reason,'no_build_site' end end
 if P.Valid(b.position) and (b.position.x-j.center.x)^2+(b.position.z-j.center.z)^2>work.radius^2 then return nil,'已记录位置超出本任务施工范围，保留坐标但不远行','site_out_of_range' end
 if b.mode=='player' then require('ybf_build_control').PositionReady(work,b)end
 local valid,reason=legal(work.inst,b,r)
 if not valid then
  if b.mode=='free' then b.position=nil;local good,why=M.SelectFree(work,j,b,r);if not good then return nil,why,'no_build_site' end
  else local e,why=M.Obstruction(work,j,b,r);if e then return e end;return nil,why or reason,'invalid_site' end
 end
 local claimed,reason=M.Claim(work,j,b,r);if not claimed then return nil,reason,'site_conflict' end
 local builder=work.inst.components.builder
 if not builder or builder.freebuildmode then return nil,'制作组件不可用或处于免费模式','builder_condition' end
 if builder:IsBuildBuffered(r.name) then b.status='buffered'
 else
  local info,why,code=C.PlanRecipe(work.inst,t.item,true);if not info then return nil,why,code end
  for _,i in ipairs(info.ingredients)do
   local reserved=j.protected[i.item] or 0
   local result,why,code=planner:Ensure(j,i.item,i.amount+reserved,{root=t.item},1)
   if result~=true then return result,why,code end
  end
  local station,why,code=planner:Station(j,r);if station~=true then return station,why,code end
  local info,reason=C.Check(work.inst,t.item,b);if not info then return nil,reason,'building_condition' end
  b.status='materials_ready';j.step='build_prepare';j.recipe=r.name;j.collectitem=nil;j.giveitem=nil;j.invobject=nil;j.phase='原版预制建筑，核实材料消耗';return work.inst
 end
 j.step='build_place';j.recipe=r.name;j.collectitem=nil;j.giveitem=nil;j.invobject=nil;j.phase='走到已记录位置并施工';return work.inst
end
function M.Perform(work,act)
 if not work:Guard(act)then return false end
 local j=work.core.job;local b=j.build_current;if not b or act.ybf_build_id~=b.id then return false end
 local r=M.Recipe(b.item);local builder=work.inst.components.builder
 if not builder or builder.freebuildmode then return false end
 if j.step=='build_prepare' then
  if builder:IsBuildBuffered(r.name)then b.status='buffered';act.ybf_build_verified=true;return true end
  local info,reason=C.Check(work.inst,b.item,b);if not info then b.blocked=reason;M.Release(j,b);return false end
  local before={};for p in pairs(info.costs)do before[p]=I.Count(work.inst,p)end
  builder:BufferBuild(r.name)
  local verified=builder:IsBuildBuffered(r.name) and true or false
  local changed=false
  for p,n in pairs(info.costs)do local used=before[p]-I.Count(work.inst,p);if used~=n then verified=false end;if used~=0 then changed=true end;j.sourced[p]=math.max(0,(j.sourced[p] or 0)-math.max(0,used))end
  if not verified then b.blocked='原版预制未成功或材料消耗无法核实';if changed then j.uncertain=true;j.fatal=b.blocked end;M.Release(j,b);return false end
  b.status='buffered';b.prepaid=true;print('[YBF BUILD] target='..b.id..' phase=buffered recipe='..r.name..' world='..b.world);act.ybf_build_verified=true;return true
 end
 local valid,reason=legal(work.inst,b,r)
 if not valid then b.blocked=reason;M.Release(j,b);return false end
 if not M.Claim(work,j,b,r) then b.blocked='其他朋友占用了施工位置';return false end
 if not (r.always_allow_buffered_placer or builder:KnowsRecipe(r))then b.blocked='预制保留，但当前解锁、角色、技能或站点条件不能放置';return false end
 if not builder:IsBuildBuffered(r.name)then b.blocked='预制状态已发生变化，停止以免重复消耗';return false end
 local pt=P.Point(b.position)
 local distance=r.build_distance or ACTIONS.BUILD.distance or 1
 if work.inst:GetDistanceSqToPoint(pt)>(distance+.25)^2 then b.blocked='未到达施工距离内';return false end
 local built;local function observed(_,data)if data and data.recipe and data.recipe.name==r.name then built=data.item end end
 work.inst:ListenForEvent('buildstructure',observed)
 local before={};for _,i in ipairs(r.ingredients)do before[i.type]=I.Count(work.inst,i.type)end
 local result=ACTIONS.BUILD.fn(act)
 work.inst:RemoveEventCallback('buildstructure',observed)
 local verified=result and built and built:IsValid() and built.prefab==r.product and built:GetDistanceSqToPoint(pt)<.01 and not builder:IsBuildBuffered(r.name)
 if built and built.Transform.GetRotation then local diff=(built.Transform:GetRotation()-b.rotation+180)%360-180;if math.abs(diff)>.1 then verified=false end end
 for p,n in pairs(before)do if I.Count(work.inst,p)~=n then verified=false end end
 if not verified then
  b.blocked='建筑放置结果未核实，保留进度，不能重复施工';b.status=builder:IsBuildBuffered(r.name) and 'buffered' or 'unverified'
  if result or not builder:IsBuildBuffered(r.name) then j.uncertain=true;j.fatal=b.blocked end
  M.Release(j,b);return false
 end
 b.placed[#b.placed+1]={guid=built.GUID,entity=built,x=pt.x,z=pt.z,rotation=b.rotation,world=b.world,verified=true}
 b.status='verified';b.prepaid=false;print('[YBF BUILD] target='..b.id..' phase=verified entity='..built.GUID..' world='..b.world..' x='..pt.x..' z='..pt.z..' rotation='..b.rotation);b.position=nil;b.blocked=nil;M.Release(j,b)
 if b.mode=='tile' then b.position={x=pt.x,z=pt.z}end
 work.planner:Refresh(j);act.ybf_build_verified=true;return true
end
function M.Status(j)
 local out={};for _,t in ipairs(j.targets or {})do local b=j.builds and j.builds[t.item];if b then
  local entities={};for i=math.max(1,#b.placed-5),#b.placed do local e=b.placed[i];entities[#entities+1]={guid=e.guid,x=e.x,z=e.z,rotation=e.rotation,world=e.world,verified=e.verified}end
  out[#out+1]={target_id=b.id,item=b.item,recipe=b.recipe,product=b.product,mode=b.mode,world=b.world,origin=b.origin,position=b.position,rotation=b.rotation,status=b.status,placed_count=#b.placed,entities=entities,blocked=b.blocked or b.position_reason}
 end end;return out
end
function M.Feedback(j)
 local out={}
 for _,t in ipairs(j.targets or {})do local b=j.builds and j.builds[t.item];if b then
  local text=I.Label(t.item)..'：已核实新建'..#b.placed..'/'..t.quantity..'座'
  for index,e in ipairs(b.placed)do if index>6 then text=text..'（更多位置见任务诊断）';break end;text=text..string.format('（%.1f，%.1f，朝向%.0f°）',e.x,e.z,e.rotation)end
  if b.status=='buffered' or b.prepaid then text=text..'；预制已消耗材料且尚未放置，保留在原版制作器中' end
  if b.blocked then text=text..'；'..b.blocked end
  out[#out+1]=text
 end end
 return table.concat(out,'；')
end
return M
