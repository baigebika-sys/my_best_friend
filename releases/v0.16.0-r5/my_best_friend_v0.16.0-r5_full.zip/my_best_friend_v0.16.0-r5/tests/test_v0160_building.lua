Vector3=function(x,y,z)return {x=x,y=y,z=z,Get=function(self)return self.x,self.y,self.z end}end
local Building=require('ybf_building');local Positions=require('ybf_build_positions');local Control=require('ybf_build_control')
local Native=dofile('tests/v0160_native_build_functions.lua')
dofile('tests/v0160_recipe_cases.lua')
BUILDMODE={WATER=2};TUNING.BOAT={NO_BUILD_BORDER_RADIUS=.1};TUNING.WAGPUNK_ARENA_COLLISION_NOBUILD_THICKNESS=1
ProfileStatsAdd=function()end;NotifyPlayerProgress=function()end
local original_emit=require('ybf_chat_server').Emit
local messages={};require('ybf_chat_server').Emit=function(_,_,d)messages[#messages+1]=d end
for _,n in ipairs({'homesign','meatrack','lightning_rod','birdcage','tent'})do Prefabs=Prefabs or {};Prefabs[n]={}end
ACTIONS.YBF_PREPARE_BUILD={id='YBF_PREPARE_BUILD',distance=2,fn=function(a)return a.doer.components.ybf_work:PerformBuilding(a)end}
ACTIONS.YBF_PLACE_BUILD={id='YBF_PLACE_BUILD',distance=2,fn=ACTIONS.YBF_PREPARE_BUILD.fn}
local buffers;local built;local mapblocked=false
local base_reset=reset
reset=function()
 base_reset();buffers=0;built={};messages={};mapblocked=false
 local listeners={}
 function friend:ListenForEvent(event,fn)listeners[event]=listeners[event]or {};listeners[event][fn]=true end
 function friend:RemoveEventCallback(event,fn)if listeners[event]then listeners[event][fn]=nil end end
 function friend:PushEvent(event,data)for fn in pairs(listeners[event]or {})do fn(self,data)end end
 function friend:GetDistanceSqToPoint(pt)return (self.x-pt.x)^2+(self.z-pt.z)^2 end
 function owner:GetPosition()return {x=self.x,y=0,z=self.z}end
 TheWorld.GUID=700
 TheWorld.Map={
  IsPassableAtPoint=function()return not mapblocked end,
  IsPassableAtPointWithPlatformRadiusBias=function()return not mapblocked end,
  IsXZWithThicknessInWagPunkArenaAndBarrierIsUp=function()return false end,
  IsPointNearHole=function()return false end,
  GetTileCoordsAtPoint=function(_,x,y,z)return math.floor((x+100)/4),math.floor((z+200)/4)end,
  GetTileCenterPoint=function(_,x,z)return -100+4*x+2,0,-200+4*z+2 end,
  IsDeployPointClear=Native.Map.IsDeployPointClear,
  CanDeployRecipeAtPoint=Native.Map.CanDeployRecipeAtPoint,
 }
 -- Real map iteration needs actual ignore semantics; simulated entities retain tags.
 local find=TheSim.FindEntities
 TheSim.FindEntities=function(self,x,y,z,r,must,exclude,oneof)
  local out={};for _,e in ipairs(find(self,x,y,z,r))do
   local omit=false;for _,tag in ipairs(exclude or {})do if e:HasTag(tag) or tag=='INLIMBO' and e.components.inventoryitem and e.components.inventoryitem.owner then omit=true end end
   if not omit then e.entity=e.entity or {IsVisible=function()return true end,GetParent=function()return nil end};e.GetPhysicsRadius=e.GetPhysicsRadius or function()return .5 end
    e.GetDistanceSqToPoint=function(v,p)return (v.x-p.x)^2+(v.z-p.z)^2 end;out[#out+1]=e end
  end;return out
 end
 local b=friend.components.builder;b.inst=friend;b.buffered_builds={};b.current_prototyper=nil
 b.known.homesign=true;b.known.meatrack=true;b.known.lightning_rod=true;b.known.birdcage=true;b.known.tent=true
 function b:IsBuildBuffered(n)return self.buffered_builds[n]end
 function b:CheckIngredientsForMimic()return false end
 function b:CheckDiscountEquipsForMimic()return false end
 function b:RemoveIngredients(costs)for p,entries in pairs(costs)do for _,n in pairs(entries)do take(friend,p,n)end end end
 b.SetBuildBuffered=Native.Builder.SetBuildBuffered
 b.BufferBuild=function(self,n)buffers=buffers+1;return Native.Builder.BufferBuild(self,n)end
 local oldbuild=b.DoBuild
 b.DoBuild=function(self,n,pt,rot,skin)if AllRecipes[n].placer then return Native.Builder.DoBuild(self,n,pt,rot,skin)else return oldbuild(self,n)end end
 friend.replica.builder={SetIsBuildBuffered=function()end}
 SpawnPrefab=function(n)
  local e=entity(n);e.Transform.SetPosition=function(_,x,y,z)e.x=x;e.z=z end;e.rotation=0;e.Transform.SetRotation=function(_,r)e.rotation=r end;e.Transform.GetRotation=function()return e.rotation end
  e.GetDistanceSqToPoint=function(self,p)return (self.x-p.x)^2+(self.z-p.z)^2 end;e.OnBuilt=function()end;e.tags.structure=true;e.tags.player=nil
  built[#built+1]=e;world[#world+1]=e;return e
 end
 ACTIONS.BUILD.fn=function(a)return a.doer.components.builder:DoBuild(a.recipe,a:GetActionPoint(),a.rotation)end
end
local perform_old=perform
perform=function()
 if action and action.target==nil then local a=action;local pt=a:GetActionPoint();friend.x=pt.x;friend.z=pt.z;local ok=a:Do();action=nil;return ok,a end
 return perform_old()
end
local function request(p,q,placement)
 return w:RequestIntent({targets={{item=p,quantity=q or 1}},mode='craft',deliver=false,placement=placement,_server_origin={x=owner.x,z=owner.z,world=Positions.World()}},owner)
end
local function supply(p)for _,i in ipairs(AllRecipes[p].ingredients)do put(friend,i.type,i.amount)end end
-- Coordinates from actual map center interfaces; map dimensions/origin are test values only.
reset()
local function snapped(x,z,kind,ex,ez,k)
 local p,why=Positions.Tile(TheWorld.Map,{x=x,z=z},kind,.15);assert(p,why);assert(p.x==ex and p.z==ez and p.kind==k)
end
snapped(2,2,'auto',2,2,'cell');snapped(3.8,2,'auto',4,2,'edge');snapped(2,3.8,'auto',2,4,'edge');snapped(3.8,3.8,'auto',4,4,'corner')
snapped(-93.8,-189.8,'cell',-94,-190,'cell');snapped(-92.2,-189.8,'edge',-92,-190,'edge');snapped(-92.2,-188.2,'corner',-92,-188,'corner')
snapped(3.39,2,'auto',2,2,'cell');snapped(3.41,2,'auto',4,2,'edge');snapped(3.8,3.8,'cell',2,2,'cell')
assert(not Positions.Tile(TheWorld.Map,{x=2,z=2},'edge',.15));assert(not Positions.Tile(TheWorld.Map,{x=3.8,z=3.8},'edge',.15));assert(not Positions.Tile(TheWorld.Map,{x=3.8,z=2},'corner',.15))
print('PASS cell/horizontal/vertical edge/corner, translated regions, snap threshold, explicit override and ambiguous requested groups')
for _,p in ipairs({'homesign','meatrack','lightning_rod','birdcage','tent'})do
 reset();supply(p);assert(request(p,1,{mode='free'}));local j=w.core.job;run(60);assert(#built==1 and built[1].prefab==p and buffers==1 and not friend.components.builder:IsBuildBuffered(p));assert(#j.builds[p].placed==1)
 print('PASS source-backed ordinary building '..p..' with exact native BufferBuild and DoBuild bodies; engine dependencies mocked')
end
reset();supply('homesign');mapblocked=true;assert(request('homesign',1,{mode='free'}));run();assert(buffers==0 and #built==0 and w.core.job.blocked)
print('PASS bounded free search failure does not consume materials')
reset();supply('homesign');assert(request('homesign',1,{mode='fixed'}));tick();assert(not action and #messages==1 and messages[1].kind=='build_pick');local j=w.core.job;local b=j.builds.homesign;local pick=messages[1]
assert(Control.Submit(w,owner,j.id,b.id,pick.nonce,8,10,90,false));owner.x=21;owner.z=20
run();assert(b.placed[1].x==8 and b.placed[1].z==10 and b.placed[1].rotation==90)
print('PASS revision-bound fixed point, orientation and moving player cannot change selected coordinate')
reset();supply('homesign');assert(request('homesign',1,{mode='fixed'}));tick();local j=w.core.job;local b=j.builds.homesign
assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,0,0,0,true));assert(buffers==0 and #built==0);assert(not Control.Submit(w,owner,j.id,b.id,'expired',8,10,0,false))
print('PASS pick cancellation and stale nonce never consume or place')
reset();supply('homesign');assert(request('homesign',1,{mode='tile',tile='cell'}));local b=w.core.job.builds.homesign;local x,z=b.position.x,b.position.z;owner.x=20;run();assert(b.placed[1].x==x and b.placed[1].z==z)
reset();supply('homesign');assert(request('homesign',2,{mode='tile',tile='cell'}));run();assert(buffers==0 and #built==0)
print('PASS captured tile origin is stable, single tile coordinate cannot host multiple buildings')
-- Prepay then invalidate site. Must preserve one buffered build, never deduct twice.
reset();supply('homesign');assert(request('homesign',1,{mode='fixed'}));tick();local j=w.core.job;local b=j.builds.homesign
assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,8,0,0,false));tick();assert(action.action==ACTIONS.YBF_PREPARE_BUILD);assert(perform());assert(buffers==1 and Inventory.Count(friend,'boards')==0)
mapblocked=true;tick();assert(w.core.job.blocked and friend.components.builder:IsBuildBuffered('homesign'));assert(w:PauseTask());mapblocked=false;assert(w:ResumeTask());run();assert(buffers==1 and #b.placed==1)
print('PASS prepaid placement failure, pause/resume and recheck preserve buffer with no repeated consumption')
reset();supply('homesign');assert(request('homesign',1,{mode='free'}));tick();assert(perform());w:Cancel();assert(friend.components.builder:IsBuildBuffered('homesign'));assert(not w.core.job and notices[#notices]:find('预制',1,true))
print('PASS cancellation keeps native prepaid state and explicitly reports it')
reset();supply('homesign');assert(request('homesign',1,{mode='free'}));tick();assert(perform());local j=w.core.job;local b=j.builds.homesign;assert(Control.Text(w,'改为指定位置',owner));assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,10,12,180,false));run();assert(buffers==1 and b.placed[1].x==10)
print('PASS modify location invalidates old action while keeping prepaid state')
-- Only native map-detected blockers may be picked up; structural blockers aren't cleared.
reset();supply('homesign');local loose=drop('twigs',1,8);loose.z=0;assert(request('homesign',1,{mode='fixed'}));tick();local j=w.core.job;local b=j.builds.homesign;assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,8,0,0,false));run();assert(#b.placed==1 and Inventory.Count(friend,'twigs')==1)
reset();supply('homesign');local obstruction=entity('old_structure',8);obstruction.tags.structure=true;world[#world+1]=obstruction;assert(request('homesign',1,{mode='fixed'}));tick();local j=w.core.job;local b=j.builds.homesign;assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,8,0,0,false));run();assert(buffers==0 and #built==0 and obstruction:IsValid())
print('PASS actual map obstruction pickup, existing structure never demolished')
reset();put(friend,'boards',1);put(friend,'twigs',2);put(friend,'flint',2);assert(w:RequestIntent({targets={{item='homesign',quantity=1},{item='pickaxe',quantity=1}},mode='craft',deliver=false,placement={mode='free'},destination='friend'},owner));run();assert(#built==1 and Inventory.Count(friend,'pickaxe',true)==1)
reset();put(friend,'twigs',2);put(friend,'flint',2);mapblocked=true;assert(w:RequestIntent({targets={{item='homesign',quantity=1},{item='pickaxe',quantity=1}},mode='craft',deliver=false,placement={mode='free'},destination='friend'},owner));run();assert(#built==0 and Inventory.Count(friend,'pickaxe',true)==1 and w.core.job.blocked)
print('PASS building/item mixed targets, blocked building does not prevent viable item')
-- Coordination uses real task identities; does not lock the world against players.
reset();local job={};local b={position={x=8,z=8},world=Positions.World()};local first={inst=friend,core={job=job}}
assert(Building.Claim(first,job,b,AllRecipes.homesign));local secondjob={};local second={inst=owner,core={job=secondjob}};local bb={position={x=8,z=8},world=Positions.World()}
assert(not Building.Claim(second,secondjob,bb,AllRecipes.homesign));Building.Release(job);assert(Building.Claim(second,secondjob,bb,AllRecipes.homesign));Building.Release(secondjob)
print('PASS shared site conflict and release; reservations do not modify map or player permissions')
reset();friend.components.inventory.RemoveItem=remove;owner.components.inventory.RemoveItem=remove;local warehouse=chest('treasurechest',true,4,'log')
assert(w:RequestIntent({targets={{item='homesign',quantity=1}},mode='craft',deliver=false,placement={mode='free'},constraints={source='warehouse_only'}},owner));run(100);assert(buffers==1 and #built==1 and stock(warehouse,'log')==0 and Inventory.Count(friend,'boards')==0)
print('PASS building shares existing warehouse-only withdrawal and recursive boards material production')
reset();supply('homesign');assert(request('homesign',1,{mode='fixed'}));tick();local j=w.core.job;local b=j.builds.homesign;assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,8,0,0,false));tick();assert(perform());tick();assert(action and action.action==ACTIONS.YBF_PLACE_BUILD);mapblocked=true;assert(not perform());tick();assert(friend.components.builder:IsBuildBuffered('homesign') and buffers==1 and #built==0 and w.core.job.blocked)
print('PASS server rechecks site changed after queued BUILD and preserves native buffer')
reset();supply('homesign');assert(request('homesign',1,{mode='fixed'}));tick();local j=w.core.job;local b=j.builds.homesign;assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,8,0,0,false));b.world='another-shard';run();assert(buffers==0 and #built==0)
print('PASS cross-shard site rejected before consuming materials')
reset();supply('homesign');assert(request('homesign'));run();assert(buffers==0 and w.core.job.blocked and w.core.job.builds.homesign.mode=='fixed');assert(Control.Text(w,'附近找个地方建',owner));run();assert(buffers==1 and #built==1)
print('PASS missing location asks once, explicit free choice resumes existing task')

require('ybf_chat_server').Emit=original_emit
reset();supply('homesign');TheWorld.Pathfinder={IsClear=function()return false end};assert(request('homesign',1,{mode='free'}));run();assert(buffers==0 and #built==0 and w.core.job.blocked);TheWorld.Pathfinder=nil
print('PASS free sites reject failed native straight-line path precheck without consumption')
reset();supply('homesign');assert(request('homesign',1,{mode='free'}));tick();assert(perform());local j=w.core.job;local b=j.builds.homesign;tick();local stale=action;assert(Control.Text(w,'改为指定位置',owner));assert(not stale:Do());assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,12,12,0,false));run();assert(buffers==1 and #b.placed==1 and b.placed[1].x==12)
print('PASS old queued point callback invalidated by position modification, no duplicate prepay')
reset();supply('homesign');assert(request('homesign',1,{mode='fixed'}));tick();local j=w.core.job;local b=j.builds.homesign;assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,8,0,0,false));tick();assert(perform());assert(w:PauseTask());local otherjob={};local otherwork={inst=owner,core={job=otherjob}};assert(Building.Claim(otherwork,otherjob,{position={x=8,z=0},world=Positions.World()},AllRecipes.homesign));Building.Release(otherjob) -- paused claims are released
assert(w:ResumeTask());run();assert(#b.placed==1)
print('PASS paused construction releases reservation and resumes recorded coordinates')
reset();supply('homesign');assert(request('homesign',1,{mode='free'}));tick();assert(perform());local oldbuild=friend.components.builder.DoBuild;friend.components.builder.DoBuild=function()return true end;tick();assert(not perform());tick();assert(w.core.job.nonresumable and buffers==1 and #built==0);friend.components.builder.DoBuild=oldbuild;assert(not Control.Submit(w,owner,w.core.job.id,w.core.job.builds.homesign.id,'any',0,0,0,false))
print('PASS BUILD success signal without actual structure never counts completion or permits retry via location change')
require('ybf_chat_server').Emit=original_emit
reset();supply('homesign');owner.x=2;owner.z=2;assert(request('homesign',1,{mode='tile',tile='edge'}));run();assert(w.core.job.blocked and not w.core.job.uncertain and buffers==0);assert(Control.Text(w,'按这格中心建',owner));run();assert(buffers==1 and #built==1)
print('PASS ambiguous explicit tile group asks for clarification without execution error, corrected cell resumes')
reset();for _,i in ipairs(AllRecipes.homesign.ingredients)do put(friend,i.type,i.amount*2)end;assert(request('homesign',2,{mode='free'}));local j=w.core.job;run(100);assert(buffers==2 and #j.builds.homesign.placed==2 and j.builds.homesign.placed[1].x~=j.builds.homesign.placed[2].x)
print('PASS multiple free structures use distinct legal coordinates, never count nearby old buildings')
reset();put(friend,'boards',2);assert(request('homesign',2,{mode='fixed'}));tick();local j=w.core.job;local b=j.builds.homesign;assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,8,0,0,false));run();assert(#b.placed==1 and buffers==1 and b.pick and w.core.job.blocked);assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,12,8,45,false));run();assert(#b.placed==2 and buffers==2)
print('PASS fixed quantity two requires second explicit click, no automatic layout')
reset();supply('homesign');friend.components.builder.known.homesign=nil;assert(request('homesign',1,{mode='free'}));run();assert(buffers==0 and #built==0 and w.core.job.blocked)
reset();supply('homesign');assert(request('homesign',1,{mode='free'}));tick();assert(perform());friend.components.builder.known.homesign=nil;tick();assert(not perform());tick();assert(buffers==1 and #built==0 and friend.components.builder:IsBuildBuffered('homesign'))
print('PASS absent initial technology and qualification lost after prepay both block without bypass')
require('ybf_chat_server').Emit=original_emit

-- Reproduce DST's strict global lookup at the exact server notification entry.
do
 local Control=require('ybf_build_control');local Chat=require('ybf_chat_server')
 local oldemit=Chat.Emit;local oldglobal=rawget(_G,'GLOBAL');local mt=getmetatable(_G);local oldindex=mt and mt.__index
 local guard=mt or {};guard.__index=function(tbl,key)if key=='GLOBAL'then error("variable 'GLOBAL' is not declared")end;if type(oldindex)=='function'then return oldindex(tbl,key)elseif type(oldindex)=='table'then return oldindex[key]end end
 rawset(_G,'GLOBAL',nil);setmetatable(_G,guard)
 local j={id=99,serial=99,owner={userid='strict-player'},builds={}};local b={id='strict-building',recipe='homesign',rotation=0};j.builds.homesign=b
 local w={inst={GUID=99},core={job=j}};local called=false
 Chat.Emit=function(G,owner,d)assert(G==_G and owner==j.owner and d.recipe=='homesign');called=true end
 Control.Begin(w,b);assert(called and b.pick)
 Chat.Emit=function()error('simulated unavailable notification')end
 Control.CancelPicks(w);assert(not b.pick)
 guard.__index=oldindex;setmetatable(_G,mt);rawset(_G,'GLOBAL',oldglobal);Chat.Emit=oldemit
end
print('PASS strict GLOBAL notification regression and notification failure does not prevent pick cancellation')

-- Selection must restore movement/return state without ResumeTask or second confirmation.
reset();supply('homesign');assert(request('homesign',1,{mode='fixed'}));tick()
local j=w.core.job;local b=j.builds.homesign;assert(j.blocked and b.pick)
w.returning={anchor={x=-8,z=-8},deadline=GetTime()+20};friend.components.ybf_friend.mode='wait'
assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,9,9,0,false))
assert(not j.blocked and not w.returning and friend.components.ybf_friend.mode=='work')
run();assert(#built==1 and built[1].x==9 and built[1].z==9)
print('PASS single click restores task movement and cancels stale return; no resume/confirmation')
-- Keep a real player-tagged entity at the origin throughout native-map placement.
for _,mode in ipairs({'player','fixed'})do
 reset();owner:AddTag('player');owner.x=1.3;owner.z=2.7;world[#world+1]=owner;supply('homesign')
 assert(request('homesign',1,{mode=mode}));local j=w.core.job;local b=j.builds.homesign
 if mode=='fixed'then tick();assert(Control.Submit(w,owner,j.id,b.id,b.pick.nonce,1.3,2.7,0,false))end
 run();assert(buffers==1 and #built==1 and built[1].x==1.3 and built[1].z==2.7 and owner.x==1.3 and owner.z==2.7)
end
-- Stationary player also permits warehouse retrieval and recursive boards crafting.
reset();owner:AddTag('player');owner.x=1.3;owner.z=2.7;world[#world+1]=owner
friend.components.inventory.RemoveItem=remove;owner.components.inventory.RemoveItem=remove
local warehouse=chest('treasurechest',true,4,'log')
assert(w:RequestIntent({targets={{item='homesign',quantity=1}},mode='craft',deliver=false,placement={mode='player'},constraints={source='warehouse_only'},_server_origin={x=owner.x,z=owner.z,world=Positions.World()}},owner))
run(100);assert(buffers==1 and #built==1 and stock(warehouse,'log')==0 and owner.x==1.3 and owner.z==2.7)
print('PASS stationary player: friendship warehouse and recursive material preparation')
-- Obsolete wait state must retire, but manual pause must not be resumed.
reset();owner:AddTag('player');supply('homesign');assert(request('homesign',1,{mode='player'}))
local j=w.core.job;j.blocked={code='player_wait_timeout'};j.builds.homesign.status='waiting_player';j.builds.homesign.wait_started=0
run();assert(#built==1)
reset();supply('homesign');assert(request('homesign',1,{mode='player'}));j=w.core.job;j.manual_pause=true;j.blocked={code='user_pause'}
Building.ClearPlayerWait(w,j);assert(j.blocked and j.manual_pause)
print('PASS player remains at fixed/player origin: native map, materials, prepay and verified entity; legacy wait retired, manual pause retained')
assert(Positions.Parse('在我这附近建一个木牌').mode=='free')
assert(Positions.Parse('在我脚下建一个木牌').mode=='player')
assert(Positions.Parse('按脚下地皮中心建一个木牌').mode=='tile')
print('PASS nearby wording wins over player-prefix overlap; tile wording stays distinct')
