-- Read-only coordinate selection from the current server map, no world constants.
local M={}
function M.World()return tostring(TheShard and TheShard.GetShardId and TheShard:GetShardId() or TheWorld.GUID)end
function M.Point(p)return Vector3(p.x,0,p.z)end
function M.Finite(n)return type(n)=='number' and n==n and n~=math.huge and n~=-math.huge and math.abs(n)<1000000 end
function M.Valid(p)return type(p)=='table' and M.Finite(p.x) and M.Finite(p.z)end
function M.Tile(map,p,kind,threshold)
 if not M.Valid(p) or not map.GetTileCoordsAtPoint or not map.GetTileCenterPoint then return nil,'当前地图没有可靠地皮坐标接口' end
 local tx,tz=map:GetTileCoordsAtPoint(p.x,0,p.z)
 if type(tx)~='number' or type(tz)~='number' then return nil,'无法确定脚下地皮' end
 local x,_,z=map:GetTileCenterPoint(tx,tz)
 local ax,_,az=map:GetTileCenterPoint(tx+1,tz);local bx,_,bz=map:GetTileCenterPoint(tx,tz+1)
 if not M.Finite(x) or not M.Finite(z) or not M.Finite(ax) or not M.Finite(az) or not M.Finite(bx) or not M.Finite(bz) then return nil,'相邻地皮中心不可读取' end
 local ux,uz,vx,vz=ax-x,az-z,bx-x,bz-z;local a=math.sqrt(ux*ux+uz*uz);local b=math.sqrt(vx*vx+vz*vz)
 if a<=0 or b<=0 or math.abs(ux*vx+uz*vz)>0.001*a*b then return nil,'地图网格不支持可靠对齐' end
 local u=((p.x-x)*ux+(p.z-z)*uz)/a;local v=((p.x-x)*vx+(p.z-z)*vz)/b
 threshold=math.max(.05,math.min(.24,threshold or .15))
 local eu=math.abs(a/2-math.abs(u))<=a*threshold;local ev=math.abs(b/2-math.abs(v))<=b*threshold
 kind=kind or 'auto'
 if kind=='auto' then kind=eu and ev and 'corner' or (eu or ev) and 'edge' or 'cell' end
 local su=u>=0 and 1 or -1;local sv=v>=0 and 1 or -1
 if kind=='corner' then
  if not (eu and ev) then return nil,'请站近要指定的四格公共交点，当前站位不能确定是哪四格' end
  x=x+(su*ux+sv*vx)/2;z=z+(su*uz+sv*vz)/2
 elseif kind=='edge' then
  if eu==ev then return nil,'请靠近要指定的两格公共边，避开交点；当前不能唯一确定是哪两格' end
  x=x+(eu and su*ux or sv*vx)/2;z=z+(eu and su*uz or sv*vz)/2
 elseif kind~='cell' then return nil,'地皮对齐方式无效' end
 return {x=x,y=0,z=z,kind=kind,tile={tx=tx,tz=tz},origin={x=p.x,z=p.z},world=M.World()}
end
function M.Parse(text)
 local function has(s)return text:find(s,1,true)~=nil end
 if has('地皮') or has('这格中心') or has('这两格') or has('这四格') or has('四格交点') then
  local kind=(has('四格') or has('4格')) and 'corner' or (has('两格') or has('二格') or has('2格')) and 'edge' or (has('这格') or has('单格')) and 'cell' or 'auto'
  return {mode='tile',tile=kind}
 end
 if has('指定的位置') or has('指定位置') or has('点选') or has('在这里') or has('建在这里') then return {mode='fixed'} end
 if has('附近') or has('找个地方') or has('自由选址') or has('合适的空地') or has('找个空地') then return {mode='free'} end
 if has('在我这') or has('在我脚下') or has('我脚下') or has('我的位置') or has('我站的位置') then return {mode='player'} end
end
return M
