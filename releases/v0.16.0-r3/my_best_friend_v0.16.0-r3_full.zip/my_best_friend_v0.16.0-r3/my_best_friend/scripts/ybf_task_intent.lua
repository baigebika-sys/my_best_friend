-- Semantic goal validation/expansion. No game actions or model step plans.
local Crafting=require('ybf_work_crafting')
local Inventory=require('ybf_work_inventory')
local Resources=require('ybf_work_resources')
local Knowledge=require('ybf_knowledge')
local M={}
function M.Copy(value)
 if type(value)~='table' then return value end
 local out={};for key,item in pairs(value) do out[key]=M.Copy(item) end;return out
end
-- Canonical goal equality ignores target order and clarification references.
function M.Same(a,b)
 if type(a)~='table' or type(b)~='table' or type(a.targets)~='table' or type(b.targets)~='table' or #a.targets~=#b.targets then return false end
 if (a.destination or a.recipient or 'auto')~=(b.destination or b.recipient or 'auto') or a.destination_guid~=b.destination_guid or ((a.constraints or {}).source or 'default')~=((b.constraints or {}).source or 'default') then return false end
 local ap,bp=a.placement or {},b.placement or {}
 if ap.mode~=bp.mode or ap.tile~=bp.tile or ap.rotation~=bp.rotation then return false end
 if a.deliver~=b.deliver or (a.mode or 'obtain')~=(b.mode or 'obtain') then return false end
 if (a.recipient or (a.deliver and 'player' or 'friend'))~=(b.recipient or (b.deliver and 'player' or 'friend')) then return false end
 local left,right=a.constraints or {},b.constraints or {}
 if type(left)~='table' or type(right)~='table' or (left.existing_only==true)~=(right.existing_only==true) then return false end
 if left.forbidden~=nil and type(left.forbidden)~='table' or right.forbidden~=nil and type(right.forbidden)~='table' then return false end
 local prohibited,other={},{}
 for _,action in ipairs(left.forbidden or {}) do prohibited[action]=true end
 for _,action in ipairs(right.forbidden or {}) do other[action]=true end
 for action in pairs(prohibited) do if not other[action] then return false end end
 for action in pairs(other) do if not prohibited[action] then return false end end
 local metadata={};for _,t in ipairs(a.targets) do metadata[t.item]={mode=t.mode or a.mode or 'obtain',destination=t.destination or a.destination or a.recipient or 'auto'} end
 for _,t in ipairs(b.targets) do local m=metadata[t.item];if not m or m.mode~=(t.mode or b.mode or 'obtain') or m.destination~=(t.destination or b.destination or b.recipient or 'auto') then return false end end
 local amounts={};for _,target in ipairs(a.targets) do if type(target)~='table' or type(target.item)~='string' then return false end;amounts[target.item]=target.quantity end
 for _,target in ipairs(b.targets) do if type(target)~='table' or amounts[target.item]~=target.quantity then return false end end
 return true
end
local function placement(value)
 if value==nil then return nil end
 if type(value)~='table' then return false end
 for k in pairs(value)do if k~='mode' and k~='tile' and k~='rotation'then return false end end
 if value.mode~='free' and value.mode~='fixed' and value.mode~='tile' and value.mode~='player'then return false end
 if value.tile and value.tile~='auto' and value.tile~='cell' and value.tile~='edge' and value.tile~='corner'then return false end
 local r=value.rotation or 0;if type(r)~='number' or r~=r or r<0 or r>=360 then return false end
 return {mode=value.mode,tile=value.tile,rotation=r}
end
function M.Expand(inst,input,delivered)
 if type(input)~='table' or type(input.targets)~='table' or #input.targets<1 or #input.targets>8 or type(input.deliver)~='boolean' then return nil,'我没有弄清楚你需要哪些物品和数量。','unclear' end
 local spec={targets=input.targets,deliver=input.deliver,mode=input.mode or 'obtain',recipient=input.recipient or (input.deliver and 'player' or 'friend')}
 if input.reference~=nil then spec.reference=input.reference end
 if spec.mode~='obtain' and spec.mode~='materials' and spec.mode~='craft' then return nil,'我还不支持这种完成方式。','unsupported' end
 if (spec.recipient~='player' and spec.recipient~='friend') or (spec.recipient=='player')~=spec.deliver then return nil,'这些东西是交给你，还是留在我这里？','unclear' end
 spec.destination=input.destination or (input.recipient and input.recipient or 'auto')
 if spec.destination~='auto' and spec.destination~='player' and spec.destination~='friend' and spec.destination~='warehouse' and spec.destination~='ground' then return nil,'请明确物品去向','unclear' end
 if input.destination_guid~=nil and (type(input.destination_guid)~='number' or input.destination_guid%1~=0 or input.destination_guid<1) then return nil,'指定容器身份无效','unclear' end
 spec.destination_guid=input.destination_guid
 spec.ground_position=input.ground_position
 spec.placement=placement(input.placement);if spec.placement==false then return nil,'建筑定位参数无效','unclear' end;spec._server_origin=input._server_origin
 local constraints=input.constraints or {}
 if type(constraints)~='table' or constraints.existing_only~=nil and type(constraints.existing_only)~='boolean' then return nil,'我没有弄清楚你对材料的限制。','unclear' end
 local forbidden={};local allowed={pickup=true,pick=true,chop=true,mine=true,craft=true,tech=true}
 if constraints.forbidden~=nil and (type(constraints.forbidden)~='table' or #constraints.forbidden>6) then return nil,'我没有弄清楚禁止哪些动作。','unclear' end
 for _,action in ipairs(constraints.forbidden or {}) do if not allowed[action] then return nil,'我还不能保证这项限制。','unsupported' end;forbidden[action]=true end
 for key in pairs(constraints) do if key~='existing_only' and key~='forbidden' and key~='source' then return nil,'我还不能保证这项限制。','unsupported' end end
 local source=constraints.source or 'default'
 if source~='default' and source~='warehouse_first' and source~='warehouse_only' and source~='inventory_only' then return nil,'材料来源范围不明确','unclear' end
 spec.constraints={existing_only=constraints.existing_only==true,source=source,forbidden={}}
 for action in pairs(forbidden) do spec.constraints.forbidden[#spec.constraints.forbidden+1]=action end;table.sort(spec.constraints.forbidden)
 Resources.Observe(inst,inst.components.ybf_work:Position(),inst.components.ybf_work.radius)
 local seen,costs,clean={},{},{}
 for _,target in ipairs(spec.targets) do
  if type(target)~="table" then return nil,"我没有弄清楚目标物品。","unclear" end
  local item,n=target.item,target.quantity
  if type(item)~='string' or not item:match('^[a-z0-9_]+$') or #item>80 or item=='ybf_friendship_flower' or seen[item]
   or type(n)~='number' or n%1~=0 or n<1 or n>100 then return nil,'请说明物品以及1到100之间的数量。','unclear' end
  if not Knowledge.Known(inst,item) then return nil,'我还没有可靠识别出这个物品，请说明具体名字。','name_unknown' end
  if placement(target.placement)==false then return nil,'单项建筑定位参数无效','unclear' end
  seen[item]=true;clean[#clean+1]={item=item,quantity=n,mode=target.mode,destination=target.destination,placement=target.placement}
  if target.mode and target.mode~='craft' and target.mode~='obtain' then return nil,'目标数量模式不明确','unclear' end
  if target.destination and target.destination~='auto' and target.destination~='warehouse' and target.destination~='player' and target.destination~='friend' and target.destination~='ground' then return nil,'单项目去向不明确','unclear' end
  if spec.mode=='materials' then
   local info,why=Crafting.PlanRecipe(inst,item)
   if not info then return nil,why,'unsupported' end
   for _,ingredient in ipairs(info.ingredients) do costs[ingredient.item]=(costs[ingredient.item] or 0)+ingredient.amount*math.ceil(n/info.output) end
  end
 end
 spec.targets=clean
 local targets=M.Copy(spec.targets)
 if spec.mode=='materials' then
  targets={};local names={};for name in pairs(costs) do names[#names+1]=name end;table.sort(names)
  for _,name in ipairs(names) do if costs[name]>100 then return nil,'这次所需材料超过我当前单项目100个的上限，请减少数量。','unsupported' end;targets[#targets+1]={item=name,quantity=costs[name]} end
 end
 if #targets==0 or #targets>16 then return nil,'这次材料种类超过当前处理范围。','unsupported' end
 return {spec=spec,targets=targets,forbidden=forbidden,existing_only=constraints.existing_only==true}
end
return M
