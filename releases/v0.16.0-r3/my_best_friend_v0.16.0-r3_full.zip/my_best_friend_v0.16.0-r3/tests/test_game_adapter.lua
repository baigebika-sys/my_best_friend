-- Tests real modmain registration/UI routing and bridge with mock game objects.
-- No engine, network replication, or animation is simulated.
package.path = "my_best_friend/scripts/?.lua;" .. package.path
local function noop() end
local rpc_handler, ui_hook, query_callback, client_handler, player_hook
local classhooks={}
local handlers={};local encoded={};local wireseq=0;local events={}
local now, notices, requests, talks = 0, {}, {}, {}
local wire_response
local function entity(guid, tags)
    local e={GUID=guid,components={},valid=true,tags=tags or {},listeners={}}
    function e:IsValid() return self.valid end
    function e:AddTag(tag)self.tags[tag]=true end
    function e:HasTag(tag) return self.tags[tag] or false end
    function e:GetDisplayName() return "玩家" end
    function e:ListenForEvent(event,fn,source)
        source=source or self
        source.listeners[event]=source.listeners[event] or {}
        source.listeners[event][fn]=true
    end
    function e:RemoveEventCallback(event,fn,source)
        source=source or self
        if source.listeners[event] then source.listeners[event][fn]=nil end
    end
    function e:PushEvent(event)
        local copy={}
        for fn in pairs(self.listeners[event] or {}) do copy[#copy+1]=fn end
        for _,fn in ipairs(copy) do fn(self) end
    end
    function e:DoPeriodicTask(_,fn) self.tick=fn;return {Cancel=noop} end
    return e
end
local player=entity(1,{player=true});player.userid="test-player"
local friend=entity(2,{ybf_friend=true})
local flower=entity(3,{ybf_friendship_flower=true})
local world=entity(4);world.ismastersim=true;world.state={cycles=5,phase="day",season="autumn"}
friend.components.health={currenthealth=80,maxhealth=100,IsDead=function() return friend.dead or false end}
friend.components.ybf_friend={active=true,name="小白",flower=flower}
friend.components.talker={Say=function(_,text) talks[#talks+1]=text end}
flower._ybf_friend=friend
flower.components.inventoryitem={GetGrandOwner=function() return flower.owner end}
flower.owner=player
GetModConfigData=function()return nil end
GLOBAL={TUNING={},STRINGS={NAMES={},RECIPE_DESC={},CHARACTERS={GENERIC={DESCRIBE={}}}},
    Ingredient=noop,TECH={NONE={}},ActionHandler=noop,TheWorld=world,
    Ents={player,friend,flower},ThePlayer=player,math=math,
    GetTimeReal=function() return now*1000 end,
    TheNet={IsDedicated=function()return false end,Announce=function(_,line) notices[#notices+1]=line end},
    TheSim={QueryServer=function(_,url,cb,method,body)
        if url=="http://127.0.0.1:8765/tasks" and method=="POST" then
            requests[#requests+1]=body;query_callback=cb
        elseif method=="GET" then assert(url:find("?instance=",1,true));query_callback=cb
        elseif url:find('/result?instance=',1,true) then assert(encoded[body].reply);cb('',true,200)
        else assert(url:find("/cancel?instance=",1,true));cb("",true,200) end
    end},json={encode_compliant=function(d)wireseq=wireseq+1;local k='json-'..wireseq;encoded[k]=d;return k end,decode=function(d)return encoded[d] or wire_response end},
    SendModRPCToClient=function(_,userid,raw)assert(userid==player.userid);events[#events+1]=encoded[raw];client_handler(raw)end,
    GetClientModRPC=function()return {}end}
GLOBAL.require=function(name)
    if name=="writeables" then return {GetLayout=function() return {} end,AddLayout=noop} end
    return require(name)
end
AddRecipe2=noop
local registered_actions,registered_components,registered_prefabs={},{},{}
local registered_component_calls={}
AddAction=function(name,label,fn)local a={fn=fn,label=label,id=name,priority=0};registered_actions[name]=a;return a end
AddStategraphActionHandler=noop
AddPrefabPostInit=function(name,fn)registered_prefabs[name]=fn end
AddComponentAction=function(kind,component,fn)registered_components[kind..':'..component]=fn;registered_component_calls[#registered_component_calls+1]={kind,component,fn} end
AddPlayerPostInit=function(fn)player_hook=fn end
AddStategraphPostInit=noop
AddModRPCHandler=function(ns,name,fn)handlers[name]=fn;if name=="message" then rpc_handler=fn end end
AddClientModRPCHandler=function(ns,name,fn)client_handler=fn end
AddClassPostConstruct=function(path,fn)classhooks[path]=fn;if path=="screens/chatinputscreen" then ui_hook=fn end end
GetModRPC=function(ns,name) return {namespace=ns,name=name} end
SendModRPCToServer=function(id,...)handlers[id.name](player,...) end
ThePlayer=player;json=GLOBAL.json
modimport=function()error('configuration must not be imported during mod startup')end
dofile("my_best_friend/modmain.lua")
local vanilla=0
local text="普通玩家聊天"
local screen={chat_edit={GetString=function() return text end},Run=function() vanilla=vanilla+1 end}
ui_hook(screen)
screen:Run();assert(vanilla==1 and #requests==0)
text="/friendship 你好";screen:Run();assert(vanilla==2)
text="/dance";screen:Run();assert(vanilla==3)
text="/friend 你好";screen:Run();assert(vanilla==3 and #requests==1)
local req=encoded[requests[1]];assert(req.message=="你好" and req.friend_name=="小白")
now=0.1
wire_response={protocol=req.protocol,request_id=req.request_id,friend_id=req.friend_id,task_id=req.request_id,instance_id=string.rep("a",32),state="done",action="none",reply="我收到你的消息了"}
query_callback("body",true,200)
assert(talks[1]=="我收到你的消息了")
assert(notices[2]=="[小白] 我收到你的消息了")
assert(#notices==2)
local Client=require('ybf_chat_client')
assert(#Client.store.rows==2 and Client.store.rows[1].kind=='player' and Client.store.rows[2].kind=='reply')
assert(not Client.store:Status():find('正在'))
assert(notices[1]=='[玩家 → 小白] 你好' and notices[2]=='[小白] 我收到你的消息了')
local before=#Client.store.rows;Client.Receive('json-'..wireseq);assert(#Client.store.rows==before)
local outgoing=#requests;handlers.send(player,'你好','','ui-1');assert(#requests==outgoing)
print("PASS both entry points, public clean messages, client echo, no duplicate replay and completed waiting status")
now=1;text="/friend 长任务";screen:Run();req=encoded[requests[#requests]]
wire_response={protocol=req.protocol,request_id=req.request_id,friend_id=req.friend_id,task_id=req.request_id,instance_id=string.rep("a",32),state="pending"}
query_callback("body",true,202)
now=3;world.tick();wire_response.state="done";wire_response.action="none";wire_response.reply="我收到你的消息了";query_callback("body",true,200)
assert(#talks==2)
print("PASS real adapter submits pending task, polls using GET and displays completion")
now=4;text="/friend 小白|你好";screen:Run();local late=query_callback
flower:PushEvent("onremove");flower.valid=false
assert(world._ybf_communication.count==0)
req=encoded[requests[#requests]]
local n=#notices
wire_response={protocol=req.protocol,request_id=req.request_id,friend_id=req.friend_id,task_id=req.request_id,instance_id=string.rep("a",32),state="done",action="none",reply="我收到你的消息了"}
late("body",true,200)
assert(#notices==n and #talks==2)
print("PASS flower removal cancels request and suppresses late reply")
flower.valid=true;now=5;text="/friend 你好";screen:Run()
friend.dead=true;friend:PushEvent("death")
assert(world._ybf_communication.count==0)
assert(#talks==2)
print("PASS death event cancels request")
friend.dead=false;now=6;flower.owner=entity(5,{player=true})
local previous=#requests;screen:Run();assert(#requests==previous)
print("PASS rejects flowers owned by another player")
world:PushEvent("onremove");assert(world._ybf_communication.closed)
print("PASS world shutdown cleanup")

assert(encoded[requests[1]].game_state.health.current==80)
assert(encoded[requests[1]].game_state.time.day==6)
assert(encoded[requests[1]].game_state.sanity.available==false)
print("PASS snapshot health day missing sanity")
-- Meaningful local feedback goes to its owner's window once, in addition to public chat.
flower.owner=player;friend.components.named={};player_hook(friend)
local rows=#Client.store.rows;local count=#notices
friend:YBFAnnounce('[小白] 捡到了6个树枝，还差4个。')
assert(#notices==count+1 and #Client.store.rows==rows+1 and Client.store.rows[#Client.store.rows].kind=='feedback')
-- Failure remains private; retry reuses the same interface and new request identity.
world.valid=true;world._ybf_communication=nil;flower.owner=player;friend.dead=false;now=20
local startnotices=#notices;assert(Client.Send('你好',''));query_callback('',false,0)
assert(#notices==startnotices+1 and Client.store.rows[#Client.store.rows].kind=='error')
assert(not Client.store:Status():find('正在'))
now=21;assert(Client.Retry());req=encoded[requests[#requests]]
wire_response={protocol=req.protocol,request_id=req.request_id,friend_id=req.friend_id,task_id=req.request_id,instance_id=string.rep('a',32),state='done',action='none',reply='恢复了'}
query_callback('body',true,200);assert(Client.store.rows[#Client.store.rows].text=='恢复了')
print('PASS meaningful feedback in window, connection failure private, retry recovers without duplicate public errors')

-- Vanilla lifecycle: HUD constructor finishes with controls=nil; SetMainCharacter
-- later constructs Controls. Hook the latter instead of indexing a future field.
assert(type(classhooks['screens/playerhud'])=='function') -- position cancel hook touches only OnControl, never delayed controls
local earlyhud={controls=nil};assert(earlyhud.controls==nil)
local mockbutton={}
for _,method in ipairs({'ForceImageSize','SetFont','SetTextSize','SetText','SetHAnchor','SetVAnchor','SetPosition'})do mockbutton[method]=function()end end
function mockbutton:SetOnClick(fn)self.click=fn end
local oldrequire=GLOBAL.require
GLOBAL.require=function(name)
 if name=='widgets/imagebutton' then return function()return mockbutton end end
 return oldrequire(name)
end
local controls={count=0}
function controls:AddChild(child)self.count=self.count+1;return child end
classhooks['widgets/controls'](controls);earlyhud.controls=controls
assert(controls.count==1 and controls._ybf_chat_button==mockbutton and mockbutton.click)
classhooks['widgets/controls'](controls);assert(controls.count==1)
local second={count=0,AddChild=controls.AddChild};classhooks['widgets/controls'](second);assert(second.count==1)
GLOBAL.require=oldrequire
print('PASS native delayed HUD controls lifecycle, button constructed after Controls, no duplicate installation')

local other=entity(22,{ybf_friend=true});other.components.health={IsDead=function()return false end};other.components.ybf_friend={name="小白"}
local otherflower=entity(23,{ybf_friendship_flower=true});otherflower._ybf_friend=other;otherflower.components.inventoryitem={GetGrandOwner=function()return player end}
GLOBAL.Ents={friend,flower,other,otherflower};flower.owner=player;flower.valid=true;friend.valid=true;friend.dead=false
GLOBAL.GetTime=function()return now end
local Comm=require('ybf_communication')
assert(not Comm.Context(GLOBAL,player,nil))
assert(Comm.Context(GLOBAL,player,"小白",22).friend==other)
assert(not Comm.Context(GLOBAL,player,nil,999))
handlers.roster(player);assert(events[#events].kind=='roster' and #events[#events].friends==2)
other.valid=false;now=now+2;handlers.roster(player);assert(#events[#events].friends==1)
print('PASS server-owned roster updates, duplicate names resolved by entity ID, stale IDs rejected')

-- Actual registered server actions and client collector callbacks, mocked netvar.
function Class(ctor)local c={};c.__index=c;return setmetatable(c,{__call=function(_,...)local o=setmetatable({},c);ctor(o,...);return o end})end
TheWorld=world
net_bool=function()local value=false;return {set=function(_,v)value=v end,value=function()return value end}end
local box=entity(200);box.prefab='treasurechest';box.replica={container={}};box.components.container={slots={one='untouched'},numslots=9};box.skinname='original-skin'
box.RemoveTag=function(e,k)e.tags[k]=nil end
box.AddComponent=function(e,n)e.components[n]=require('components/'..n)(e)end
box.GetDisplayName=function()return '原箱子' end
player.GetDistanceSqToInst=function()return 4 end
flower.valid=true
registered_prefabs.treasurechest(box)
local c=box.components.container;local hover={};registered_components['USEITEM:inventoryitem'](flower,player,box,hover,true)
assert(#hover==1 and hover[1]==registered_actions.YBF_CONTAINER_GRANT)
assert(hover[1].fn({doer=player,target=box,invobject=flower}));assert(box:GetDisplayName()=='友谊原箱子' and box.skinname=='original-skin' and box.components.container==c and c.slots.one=='untouched')
assert(hover[1].fn({doer=player,target=box,invobject=flower}));assert(box:GetDisplayName()=='友谊原箱子' and flower:IsValid())
local remove={};registered_components['SCENE:container'](box,player,remove,true);assert(#remove==1 and remove[1].label=='解除友谊');assert(remove[1].fn({doer=player,target=box}));assert(box:GetDisplayName()=='原箱子' and c.slots.one=='untouched')
player.GetDistanceSqToInst=function()return 100 end;assert(not hover[1].fn({doer=player,target=box,invobject=flower}));player.GetDistanceSqToInst=function()return 4 end
local outsider=entity(201);outsider.GetDistanceSqToInst=function()return 4 end;assert(not hover[1].fn({doer=outsider,target=box,invobject=flower}))
world.ismastersim=false
local replica=entity(202);replica.prefab='icebox';replica.RemoveTag=box.RemoveTag;replica.GetDisplayName=function()return '冰箱' end
registered_prefabs.icebox(replica);assert(not replica.components.ybf_friendship_container);replica._ybf_friendship_net:set(true);replica:PushEvent('ybf_friendship_dirty');assert(replica:GetDisplayName()=='友谊冰箱' and replica:HasTag('ybf_friendship_container'));world.ismastersim=true
print('PASS registered grant/revoke server validation, hover collection, idempotent no-consumption, original container/skin preservation and client netvar display contract; NOT actual engine replication')

-- Replay the actual official registration, collection and priority picker functions.
local stock={STORE={id='STORE',priority=0},RUMMAGE={id='RUMMAGE',priority=0}}
local engine=dofile('tests/v0150_r1_action_engine.lua')({ACTIONS=stock,BufferedAction=function(d,t,a,i)return {doer=d,target=t,action=a,invobject=i}end})
for _,call in ipairs(registered_component_calls)do engine.AddComponentAction(call[1],call[2],call[3],'my_best_friend')end
local function native(e,component)
 e.actioncomponents={};e.modactioncomponents=nil
 e.RegisterComponentActions=engine.EntityScript.RegisterComponentActions;e.CollectActions=engine.EntityScript.CollectActions
 e:RegisterComponentActions(component)
 e.is_a=function(_,cls)return cls==engine.EntityScript end
 e.HasAnyTag=function(self,...)for _,tag in ipairs({...})do if self:HasTag(tag)then return true end end;return false end
 return e
end
player.replica={inventory={}}
flower.replica={inventoryitem={CanOnlyGoInPocket=function()return false end,IsLockedInSlot=function()return false end,CanOnlyGoInPocketOrPocketContainers=function()return false end,IsGrandOwner=function(_,d)return d==player end}}
box.replica.container={CanBeOpened=function()return true end,IsReadOnlyContainer=function()return false end}
native(flower,'inventoryitem');native(box,'container')
local picker=setmetatable({inst=player},{__index=engine.Picker})
local left=picker:GetUseItemActions(box,flower,false)
assert(left[1] and left[1].action==registered_actions.YBF_CONTAINER_GRANT,'left hover must select friendship grant instead of STORE')
local right=picker:GetUseItemActions(box,flower,true)
assert(right[1] and right[1].action==registered_actions.YBF_CONTAINER_GRANT,'right hover must prioritize grant over STORE')
local registrations=0;for _,call in ipairs(registered_component_calls)do if call[1]=='USEITEM' and call[2]=='inventoryitem'then registrations=registrations+1 end end
assert(registrations==1,'one collector must preserve friend-feed filtering and friendship grant')
assert(left[1].action.fn(left[1]));assert(box:GetDisplayName()=='友谊原箱子')
assert(picker:GetUseItemActions(box,flower,false)[1].action==stock.STORE,'already granted flower may still be normally stored')
assert(picker:GetSceneActions(box,false)[1].action==stock.RUMMAGE,'normal player container access preserved')
local revoke=picker:GetSceneActions(box,true);assert(revoke[1].action==registered_actions.YBF_CONTAINER_REVOKE);assert(revoke[1].action.fn(revoke[1]))
assert(box:GetDisplayName()=='原箱子' and c.slots.one=='untouched' and flower:IsValid())
for _,name in ipairs({'treasurechest','dragonflychest','icebox','saltbox'})do box.prefab=name;assert(picker:GetUseItemActions(box,flower,false)[1].action==registered_actions.YBF_CONTAINER_GRANT)end
box.prefab='mod_other_container';assert(picker:GetUseItemActions(box,flower,false)[1].action==stock.STORE);box.prefab='treasurechest'
local cb=registered_components['USEITEM:inventoryitem']
-- Action identity sentinels for the original feeding/dead-target safeguards.
GLOBAL.ACTIONS=GLOBAL.ACTIONS or {};GLOBAL.ACTIONS.FEEDPLAYER={};GLOBAL.ACTIONS.GIVETOPLAYER={};GLOBAL.ACTIONS.GIVEALLTOPLAYER={}
local feed={GLOBAL.ACTIONS.FEEDPLAYER,GLOBAL.ACTIONS.GIVETOPLAYER};cb(flower,player,friend,feed,true);assert(#feed==1 and feed[1]==GLOBAL.ACTIONS.GIVETOPLAYER)
friend:AddTag('ybf_dead');feed={GLOBAL.ACTIONS.GIVETOPLAYER,GLOBAL.ACTIONS.GIVEALLTOPLAYER};cb(flower,player,friend,feed,true);assert(#feed==0)
cb(flower,player,nil,{},false)
-- Remote client target has only replica data, never the server authorization component.
world.ismastersim=false
replica.replica={container=box.replica.container};replica._ybf_friendship_net:set(false);replica:PushEvent('ybf_friendship_dirty')
native(replica,'container');assert(not replica.components.ybf_friendship_container)
assert(picker:GetUseItemActions(replica,flower,false)[1].action==registered_actions.YBF_CONTAINER_GRANT)
replica._ybf_friendship_net:set(true);replica:PushEvent('ybf_friendship_dirty')
assert(picker:GetSceneActions(replica,true)[1].action==registered_actions.YBF_CONTAINER_REVOKE)
world.ismastersim=true
print('PASS official action registration/collection/priority picker: left/right grant, normal STORE/RUMMAGE, right revoke, all four types, original feed/dead-target filters, nil target; engine/network mocked')
-- Test temporary mouse interception through actual installed playercontroller hook.
local Pick=require('ybf_build_pick_client');local oldsend=SendModRPCToServer;local oldfront=TheFrontEnd;local oldinput=TheInput
local oldspawn,oldrecipe,oldcamera=SpawnPrefab,GetValidRecipe,TheCamera
local ghosts={}
GetValidRecipe=function(name)if name=='researchlab'then return {name=name,placer='researchlab_placer'}end end
TheCamera={GetHeading=function()return 0 end}
SpawnPrefab=function(name)
 assert(name=='researchlab_placer')
 local g={components={},valid=true};g.IsValid=function(self)return self.valid end;g.Remove=function(self)self.valid=false end;g.DoTaskInTime=function()end
 g.GetPosition=function()return TheInput:GetWorldPosition()end
 g.components.placer={SetBuilder=function(self,b,r)assert(b==player and r.name=='researchlab');self.builder=b end,OnUpdate=function()end}
 ghosts[#ghosts+1]=g;return g
end
local pointcalls={};SendModRPCToServer=function(_,raw)local d=json.decode(raw);pointcalls[#pointcalls+1]={d.friend,d.task,d.target,d.nonce,d.x,d.z,d.rotation,d.cancel};if not d.cancel then assert(Pick.pending and Pick.ghost,'preview must survive until server ack')end;Pick.Ack({friend=d.friend,task=d.task,target=d.target,nonce=d.nonce,accepted=true,text='ack'})end
GetTime=function()return now end;CONTROL_CANCEL=1;CONTROL_ROTATE_LEFT=2;CONTROL_ROTATE_RIGHT=3;CONTROL_PRIMARY=4;CONTROL_SECONDARY=5
player.HUD={};TheFrontEnd={GetActiveScreen=function()return player.HUD end};local mouse={x=7,z=9};TheInput={GetWorldPosition=function()return mouse end,GetHUDEntityUnderMouse=function()return nil end}
local nativeclicks=0;local controller={inst=player,OnLeftClick=function()nativeclicks=nativeclicks+1 end,OnRightClick=function()nativeclicks=nativeclicks+1 end,OnControl=function()nativeclicks=nativeclicks+1 end}
classhooks['components/playercontroller'](controller)
Pick.Begin({friend=2,task=1,target='stable-target',recipe='researchlab',nonce='once',rotation=0,text='choose'})
controller:OnControl(CONTROL_ROTATE_RIGHT,true);controller:OnLeftClick(true);controller:OnLeftClick(false)
assert(#pointcalls==1 and pointcalls[1][5]==7 and pointcalls[1][6]==9 and pointcalls[1][7]==45 and nativeclicks==0)
mouse={x=18,z=18};assert(pointcalls[1][5]==7);controller:OnLeftClick(true);assert(nativeclicks==1)
Pick.Begin({friend=2,task=1,target='stable-target',recipe='researchlab',nonce='cancel',rotation=0,text='choose'});controller:OnRightClick(true);controller:OnRightClick(false);assert(pointcalls[2][8]==true and nativeclicks==1)
Pick.Begin({friend=2,task=1,target='stable-target',recipe='researchlab',nonce='esc',rotation=0,text='choose'});controller:OnControl(CONTROL_CANCEL,true);assert(pointcalls[3][8]==true)
SendModRPCToServer=oldsend;TheFrontEnd=oldfront;TheInput=oldinput
print('PASS production point UI hooks: click records fixed coordinates, Q/E rotation, right/Esc cancel, release swallowed, normal click restored; actual input engine not run')

CONTROL_PAUSE=6;local paused=0;local hud={owner=player,OnControl=function(_,c,down)if not down and c==CONTROL_PAUSE then paused=paused+1 end end}
classhooks['screens/playerhud'](hud)
SendModRPCToServer=function(_,raw)local d=json.decode(raw);Pick.Ack({friend=d.friend,task=d.task,target=d.target,nonce=d.nonce,accepted=true})end
Pick.Begin({friend=2,task=1,target='stable-target',recipe='researchlab',nonce='pause-key',rotation=0,text='choose'});hud:OnControl(CONTROL_PAUSE,true);hud:OnControl(CONTROL_PAUSE,false);assert(not Pick.pending and paused==0)
hud:OnControl(CONTROL_PAUSE,false);assert(paused==1)
Pick.Begin({friend=2,task=1,target='stable-target',recipe='researchlab',nonce='old-task',rotation=0,text='choose'});Pick.Cancel({friend=2,task=1});assert(not Pick.pending)
SendModRPCToServer=oldsend
print('PASS real HUD pause-control release path cancels pick instead of opening pause menu; cancel-task event restores input')

assert(#ghosts>=5);for _,g in ipairs(ghosts)do assert(not g:IsValid(),'cancel/submit must remove native ghost')end
do
 local savedinput,savedfront,savedsend,savedtimer=TheInput,TheFrontEnd,SendModRPCToServer,player.DoTaskInTime
 local timeout
 TheFrontEnd={GetActiveScreen=function()return player.HUD end};TheInput={GetWorldPosition=function()return {x=4,z=5}end,GetHUDEntityUnderMouse=function()return nil end}
 player.DoTaskInTime=function(_,seconds,fn)if seconds==5 then timeout=fn end end
 SendModRPCToServer=function()end
 Pick.Begin({friend=2,task=1,target='reliable',recipe='researchlab',nonce='reliable',rotation=0})
 Pick.Cancel({friend=2,task=1,target='other-target'});assert(Pick.pending)
 Pick.Submit(false);assert(Pick.pending and Pick.pending.sending and Pick.ghost:IsValid())
 local beforeclicks=nativeclicks;controller:OnLeftClick(true);controller:OnLeftClick(false);assert(nativeclicks==beforeclicks,'in-flight double input must not reach normal gameplay')
 timeout();assert(Pick.pending and not Pick.pending.sending and Pick.ghost:IsValid())
 Pick.Ack({friend=2,task=1,target='reliable',nonce='wrong',accepted=true});assert(Pick.pending)
 Pick.Ack({friend=2,task=1,target='reliable',nonce='reliable',accepted=false,text='permission rejected'});assert(Pick.pending and Pick.ghost:IsValid())
 SendModRPCToServer=function()error('transport unavailable')end;Pick.Submit(false);assert(Pick.pending and not Pick.pending.sending)
 Pick.Submit(true);assert(not Pick.pending and not Pick.ghost,'Esc/right cancellation must restore UI even with broken transport')
 TheInput=savedinput;TheFrontEnd=savedfront;SendModRPCToServer=savedsend;player.DoTaskInTime=savedtimer
end
print('PASS preview retained on dropped/failed send, ACK timeout and rejection; stale ACK ignored; accepted ACK alone closes pick')
SpawnPrefab=oldspawn;GetValidRecipe=oldrecipe;TheCamera=oldcamera
print('PASS native recipe placer creation and cleanup on submit, server cancel, right click and Esc; mock client')

-- Registered server RPC (not direct Submit): rejects are observable and retries are idempotent.
do
 local oldContext=require('ybf_communication').Context;local C=require('ybf_build_control');local oldSubmit=C.Submit;local oldEmit=require('ybf_chat_server').Emit
 local replies={};local w={};local n=0
 require('ybf_communication').Context=function()return {friend={components={ybf_work=w}},name='朋友'}end
 C.Submit=function()n=n+1;return true,'position accepted' end
 require('ybf_chat_server').Emit=function(_,_,d)replies[#replies+1]=d end
 local d={friend=2,task=1,target='one',nonce='n',x=8,z=9,rotation=0,cancel=false}
 handlers.build_point(player,json.encode_compliant(d));handlers.build_point(player,json.encode_compliant(d));assert(n==1 and #replies==2 and replies[2].accepted)
 d.nonce='bad';d.task='wrong';handlers.build_point(player,json.encode_compliant(d));assert(not replies[#replies].accepted and n==1)
 d.task=1;d.nonce='context';require('ybf_communication').Context=function()return nil,'flower missing' end
 handlers.build_point(player,json.encode_compliant(d));assert(not replies[#replies].accepted and replies[#replies].text=='flower missing')
 local P=require('ybf_build_positions')
 local b={id='actual-point',world=P.World(),pick={nonce='actual',expires=now+90},rotation=0}
 local j={id=88,serial=88,owner=player,center={x=0,z=0},builds={researchlab=b},blocked={code='await_location'}}
 local real={inst=friend,core={sequence=88,job=j},radius=32,returning={anchor={x=-10,z=-10}},StopAction=function()end,OwnerValid=function()return true end}
 local oldpolicy=friend.components.ybf_friend.ApplyMovementPolicy;friend.components.ybf_friend.ApplyMovementPolicy=function()end
 require('ybf_communication').Context=function()return {friend={components={ybf_work=real}},name='朋友'}end;C.Submit=oldSubmit
 local packet={friend=2,task=88,target=b.id,nonce='actual',x=8,z=9,rotation=45,cancel=false}
 handlers.build_point(player,json.encode_compliant(packet))
 assert(b.position.x==8 and b.position.z==9 and b.rotation==45 and not j.blocked and not real.returning)
 assert(replies[#replies].kind=='build_point_ack' and replies[#replies].accepted)
 local serial=j.serial;handlers.build_point(player,json.encode_compliant(packet));assert(j.serial==serial)
 friend.components.ybf_friend.ApplyMovementPolicy=oldpolicy
 require('ybf_communication').Context=oldContext;C.Submit=oldSubmit;require('ybf_chat_server').Emit=oldEmit
end
print('PASS registered JSON point RPC, server acknowledgements, duplicate nonce no resubmission, invalid arguments and permission rejection')
