import json,unittest
from decision import parse_decision,DecisionError
class BuildingSchema(unittest.TestCase):
 def goal(self,**kw):
  d=dict(intent='command_goal',action='goal',dialogue='先核实条件',item='homesign',quantity=1,deliver=False,mode='craft');d.update(kw);return parse_decision(json.dumps(d))
 def test_location_modes(self):
  for v in [{'mode':'player'},{'mode':'free'},{'mode':'fixed','rotation':90},{'mode':'tile','tile':'edge'},{'mode':'tile','tile':'corner'}]:self.assertEqual(self.goal(placement=v)[3]['placement'],v)
 def test_different_targets_have_separate_placement(self):
  r=self.goal(item=[dict(item='homesign',quantity=1,placement={'mode':'free'}),dict(item='birdcage',quantity=1,placement={'mode':'fixed'})],quantity=None)
  self.assertEqual(r[3]['targets'][1]['placement']['mode'],'fixed')
 def test_coordinate_and_blueprint_injection_rejected(self):
  for v in [{'mode':'fixed','x':1,'z':2},{'mode':'blueprint'},{'mode':'tile','tile':'random'},{'mode':'fixed','rotation':360},{'mode':'fixed','rotation':True},{'mode':'fixed','rotation':float('nan')}]:
   with self.subTest(v=v),self.assertRaises(DecisionError):self.goal(placement=v)
 def test_query_cannot_contain_placement(self):
  with self.assertRaises(DecisionError):parse_decision(json.dumps(dict(intent='query_knowledge',action='knowledge',dialogue='这是查询',item={'name':'homesign','kind':'recipe'},quantity=None,placement={'mode':'free'})))

 def test_redundant_recipient_uses_deliver_without_changing_targets(self):
  for deliver,recipient,canonical in [(False,'player','friend'),(True,'friend','player')]:
   result=self.goal(deliver=deliver,recipient=recipient,placement={'mode':'fixed'})[3]
   self.assertEqual(result['deliver'],deliver);self.assertEqual(result['recipient'],canonical)
   self.assertEqual(result['targets'],[{'item':'homesign','quantity':1}])
