-- Span-based identity matching. Longest wins only within an overlapping span.
local M={}
local function chars(s)
 local out={};for c in s:gmatch('[%z\1-\127\194-\244][\128-\191]*') do out[#out+1]=c end;return out
end
local fillers={'what is','tell me about','give me','collect','and','please','拿起','装备','吃','把','明确','指定','用现有材料','只','要','你能','你会','能给我','请你帮我','能不能帮我','能帮我','帮我','请问','你知道','你认识','我想知道','我想要','我要','给我','帮忙','告诉我','说说','解释一下','介绍一下','查询一下','查询','了解','分别','还有','以及','和','与','是','能','可以','请','采集','采','收集','制作','准备','弄','捡','检','拿','找','给','做','砍','棵','颗','个','块','把','份','根','种','一些','一点','一个','两个','一','二','两','三','四','五','六','七','八','九','十','这','那','它','的'}
table.sort(fillers,function(a,b)return #a>#b end)
local function prefix(s)
 s=s:lower():gsub('^%s+',''):gsub('%s+$','')
 local changed=true
 while changed and #s>0 do
  changed=false
  local n=s:match('^%d+');if n then s=s:sub(#n+1);changed=true end
  for _,word in ipairs(fillers) do if s:sub(1,#word)==word then s=s:sub(#word+1);changed=true;break end end
  s=s:gsub('^%s+','')
 end
 return s
end
local function boundary(message,a,b,name)
 if not name:match('^[%w_]+$') then return true end
 return not (a>1 and message:sub(a-1,a-1):match('[%w_]')) and not message:sub(b+1,b+1):match('[%w_]')
end
function M.Scan(message,index)
 if type(message)~='string' then return {} end
 local hits={};local folded=message:lower()
 for name,bindings in pairs(index) do
  if #name>=2 then
   local from=1
   while from<=#message do
    local a,b=folded:find(name:lower(),from,true);if not a then break end
    if boundary(message,a,b,name) then hits[#hits+1]={start=a,finish=b,text=message:sub(a,b),candidates=bindings} end
    from=b+1
   end
  end
 end
 table.sort(hits,function(a,b)if a.start==b.start then return a.finish>b.finish end;return a.start<b.start end)
 local kept={}
 for _,hit in ipairs(hits) do
  local overlap=false
  for _,old in ipairs(kept) do if hit.start<=old.finish and hit.finish>=old.start then overlap=true;break end end
  if not overlap then kept[#kept+1]=hit end
 end
 local previous=0
 for hitindex,hit in ipairs(kept) do
  local before=message:sub(previous+1,hit.start-1)
  -- Last clause boundary; UTF-8 punctuation is matched as complete strings.
  for _,sep in ipairs({'，','。','？','！','、','；',',',';','?','!','\n','“','"','（','('}) do
   local from=1;while true do local a,b=before:find(sep,from,true);if not a then break end;before=before:sub(b+1);from=1 end
  end
  local qualifier=prefix(before)
  hit.unresolved_prefix=qualifier~='' and qualifier or nil
  local after=message:sub(hit.finish+1,(kept[hitindex+1] and kept[hitindex+1].start-1) or #message)
  for _,sep in ipairs({'，','。','？','！','、','；',',',';','?','!','\n'}) do local at=after:find(sep,1,true);if at then after=after:sub(1,at-1) end end
  local endings={'used for','do','有什么区别','有什么用途','有什么效果','有什么用','是什么东西','怎么制作','如何制作','怎么获得','如何获得','怎么获取','能做什么','是什么','有什么机制','的材料','的区别','的用途','的效果','给我','留在你那里','各是什么','分别是什么','是什么类型','吗','呢','能干什么','怎么样','如何使用','怎么使用','的属性'}
  table.sort(endings,function(a,b)return #a>#b end)
  local rest=after:gsub('^%s+',''):gsub('%s+$','')
  local changed=true;while changed and #rest>0 do changed=false
   for _,ending in ipairs(endings) do if rest:sub(1,#ending)==ending then rest=rest:sub(#ending+1);changed=true;break end end
   rest=rest:gsub('^%s+','')
  end
  rest=prefix(rest)
  if rest~='' then hit.unresolved_suffix=rest end
  previous=hit.finish
 end
 return kept
end
function M.Suggestions(query,index)
 local q=chars(query);local out={};if #q<2 then return out end
 for name,bindings in pairs(index) do
  local n=chars(name)
  if #q==#n then
   local changes=0;for i=1,#q do if q[i]~=n[i] then changes=changes+1 end end
   local transposed=false
   if changes==2 then
    for i=1,#q-1 do
     if q[i]~=n[i] and q[i]==n[i+1] and q[i+1]==n[i] then transposed=true;break end
    end
   end
   if changes==1 or transposed then for _,v in ipairs(bindings) do out[v.prefab]=true end end
  end
 end
 local list={};for k in pairs(out) do list[#list+1]=k end;table.sort(list);return list
end
function M.QuestionName(message)
 for _,ending in ipairs({'有什么区别','有什么不同','怎么制作','如何制作','怎么做','制作配方','怎么获得','如何获得','怎么获取','从哪获得','有什么用途','有什么用','能做什么','能干什么','怎么使用','如何使用','有什么机制','什么机制','怎么交互','怎么攻击','有什么效果','的属性','多少伤害','多少防御','是什么'}) do
  local at=(message or ''):find(ending,1,true)
  if at then return prefix(message:sub(1,at-1)) end
 end
 return nil
end
function M.GenericTree(message)
 local hits=M.Scan((message or ''):gsub('普通树','树'),{['树']={{prefab='ordinary_tree',kind='generic'}}})
 if #hits==0 then return false end
 for _,hit in ipairs(hits) do if hit.unresolved_prefix or hit.unresolved_suffix then return false end end
 return true
end
return M
