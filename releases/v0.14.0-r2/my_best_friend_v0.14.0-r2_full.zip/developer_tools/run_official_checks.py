"""Actual imported 756039 data + production query code; simulated world, no DST/model."""
import ctypes as c,os,json
from pathlib import Path
root=Path(__file__).resolve().parents[1];os.chdir(root)
lib=c.CDLL('liblua5.4.so.0');lib.luaL_newstate.restype=c.c_void_p;lib.luaL_openlibs.argtypes=[c.c_void_p];lib.luaL_loadbufferx.argtypes=[c.c_void_p,c.c_char_p,c.c_size_t,c.c_char_p,c.c_char_p];lib.lua_pcallk.argtypes=[c.c_void_p,c.c_int,c.c_int,c.c_int,c.c_longlong,c.c_void_p];lib.lua_tolstring.argtypes=[c.c_void_p,c.c_int,c.POINTER(c.c_size_t)];lib.lua_tolstring.restype=c.c_char_p;lib.lua_close.argtypes=[c.c_void_p]
setup=(root/'tests/test_foundation.lua').read_text().split("reset();put(friend,'twigs',3);plant",1)[0]
checks='''
reset()
APP_VERSION='756039'
local K=require('ybf_knowledge');local S=require('ybf_knowledge_store');local Names=require('ybf_knowledge_names')
assert(S.Compatible());assert(S.Manifest().indexed_prefab_count>3000)
assert(K.Resolve(friend,'fumarole_farm_hoe','烧灼园艺锄有什么用')=='fumarole_farm_hoe')
assert(K.Resolve(friend,'farm_hoe','烧灼园艺锄有什么用')==nil)
local p,reason,choices=K.Resolve(friend,'farm_hoe','灼烧园艺锄有什么用')
assert(p==nil and reason=='name_typo_confirmation');assert(choices[1]=='fumarole_farm_hoe')
local hits=K.Expressions(friend,'园艺锄和烧灼园艺锄有什么区别');assert(#hits==2)
assert(K.Resolve(friend,'farm_hoe','园艺锄升级版有什么用')==nil)
local job=w.core.job;local queued=action
local a=K.Answer(friend,'浆果','properties','浆果的属性');assert(a:find('9.375') and a:find('基准') and not a:find('配方'))
local b=K.Answer(friend,'箱子','uses','箱子有什么用');assert(b:find('箱子') and not b:find('脚本配方'))
local d=K.Answer(friend,'皮弗娄牛','properties','皮弗娄牛的属性');assert(d:find('1000'))
local e=K.Answer(friend,'烧灼园艺锄','difference','烧灼园艺锄有什么区别');assert(e:find('独立 prefab') and e:find('状态变化'))
local f=K.Answer(friend,'花瓣','sources','花瓣怎么获得');assert(f:find('普通花朵') and f:find('petals'))
assert(w.core.job==job and action==queued)
local cf=S.Entry('fumarole_farm_hoe');local found=false
for _,fact in ipairs(cf.recipes) do if fact.certainty=='verified' then assert(fact.value.ingredients[1].prefab=='twigs');found=true end end
assert(found)
local no_recipe='';for _,r in ipairs(S.Facts('beefalo','recipes')) do no_recipe=no_recipe..tostring(r.value) end;assert(no_recipe=='')
local index=K.Index(friend);assert(#Names.Suggestions('灼烧园艺锄',index)>=1)
local total=0;for prefab,row in pairs(S.data.entries) do
 total=total+1;local full=S.Entry(prefab);assert(full.prefab==prefab)
 for _,facet in ipairs({'properties','uses','sources','recipes','mechanisms','variants'}) do
  for _,fact in ipairs(S.Facts(prefab,facet)) do assert(fact.version=='756039' and fact.path and fact.sha256 and fact.certainty=='verified') end
 end
end
assert(total==S.Manifest().indexed_prefab_count)
reset();APP_VERSION='756039';Prefabs={twigs={},petals={},berries={}}
plant('sapling','twigs',2);assert(w:RequestIntent({targets={{item='twigs',quantity=1}},deliver=true},owner));run();assert(Inventory.Count(owner,'twigs')==1)
reset();APP_VERSION='756039';plant('sapling','twigs',2);assert(w:RequestIntent({targets={{item='twigs',quantity=2}},deliver=true},owner));tick();local stale=action;assert(stale);w:Cancel();assert(not w.core.job and not stale:Do())
print('PASS existing gathering and cancellation with real static catalog enabled, mocked world and inventory')
APP_VERSION='other';assert(not S.Compatible() and #S.Facts('fumarole_farm_hoe','mechanisms')==0)
print('PASS imported official identities, actual properties/recipes/citations, ordinary/special/multiple/typo identity, read-only item/building/creature queries and version gate; '..total..' detail records loaded')
'''
state=lib.luaL_newstate();lib.luaL_openlibs(state);raw=(setup+checks).encode()
try:
 code=lib.luaL_loadbufferx(state,raw,len(raw),b'official current data checks',None)
 if not code:code=lib.lua_pcallk(state,0,-1,0,0,None)
 if code:raise AssertionError(lib.lua_tolstring(state,-1,None).decode())
finally:lib.lua_close(state)
print('Local Lua 5.4 / simulated world. No real provider or DST gameplay validation.')
