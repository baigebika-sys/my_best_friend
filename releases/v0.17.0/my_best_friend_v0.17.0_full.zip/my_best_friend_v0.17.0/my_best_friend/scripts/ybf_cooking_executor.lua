local R=require('ybf_cooking_rules');local I=require('ybf_work_inventory');local W=require('ybf_warehouse');local P=require('ybf_build_positions');local M={};local pots=setmetatable({},{__mode='k'})
local function live(t)return t and t.state~='cancelled'and t.state~='completed'and t.state~='blocked'and not t.paused and t.friend and t.friend:IsValid()and t.friend.components.ybf_friend.active end
function M.Release(t)if t.watch and t.pot and t.pot:IsValid()then t.pot:RemoveEventCallback('ybf_cook_change',t.watch);t.pot:RemoveEventCallback('onremove',t.watch)end;t.watch=nil;W.Release(t);for p,claim in pairs(pots)do if claim==t then pots[p]=nil end end end
local function block(t,reason)
 t.state='blocked';t.reason=reason;M.Release(t)
 if t.last_block_reason~=reason then t.last_block_reason=reason;print('[YBF COOK] task='..t.id..' phase=blocked reason='..reason)
  local work=t.friend and t.friend.components.ybf_work;if work then work:Announce('料理任务受阻：'..reason..'；已收取'..(t.done or 0)..'份、存放/交付'..(t.stored or 0)..'份，其他独立任务会继续。')end
 end
end
local function receipt(t,n)
 t.stored=(t.stored or 0)+n
 if t.auxiliary then t.aux_stored=(t.aux_stored or 0)+n else t.target_stored=(t.target_stored or 0)+n end
end
local function usable(p)return p and p:IsValid()and R.POTS[p.prefab]and p.components.stewer and p.components.container and p.components.ybf_cook_marker and not p:HasTag('burnt')end
local function inrange(h,t,e)
 if not e or not e:IsValid()or t.world~=P.World()then return false end
 local x,_,z=e.Transform:GetWorldPosition();return (x-t.center.x)^2+(z-t.center.z)^2<=h.work.radius^2
end
local function opened(h,p)return p.components.container.IsOpenedByOthers and p.components.container:IsOpenedByOthers(h.work.inst)end
local function locate(h,t)
 local x,_,z=h.work.inst.Transform:GetWorldPosition();local rows={}
 for _,p in ipairs(TheSim:FindEntities(x,0,z,h.work.radius,{'stewer'},{'INLIMBO','burnt'}))do if usable(p)and inrange(h,t,p)then rows[#rows+1]=p end end
 table.sort(rows,function(a,b)return h.work.inst:GetDistanceSqToInst(a)<h.work.inst:GetDistanceSqToInst(b)end)
 for index,p in ipairs(rows)do if index>16 then break end;if t.pot_id then if p.components.ybf_cook_marker.id==t.pot_id then return p end
 elseif (not t.spec.recipe or require('cooking').GetRecipe(p.prefab,t.spec.recipe))and not p.components.stewer:IsCooking()and not opened(h,p)and(not live(pots[p])or pots[p]==t)then return p end end
end
local function slots(p)local out={};for slot,it in pairs(p.components.container.slots)do out[#out+1]={slot=slot,item=it,prefab=it.prefab}end;table.sort(out,function(a,b)return a.slot<b.slot end);return out end
local function fingerprint(p)local out={};for _,v in ipairs(slots(p))do out[#out+1]=v.slot..':'..v.item.GUID..':'..v.prefab..':'..I.Size(v.item)end;return table.concat(out,'|')end
local function count(c,p)local n=0;for _,i in pairs(c.slots)do if i.prefab==p then n=n+I.Size(i)end end;return n end
function M.Stock(h,t,pot)
 t.friend=h.work.inst;t.external_reservation=true;local rows={};local own=h.work.inst
 local function add(item,where)
  if not R.Ingredient(item.prefab)or not pot.components.container:CanTakeItemInSlot(item)or item.components.inventoryitem and item.components.inventoryitem.islockedinslot then return end
  local n=W.Available(item,t);if where==own then n=math.max(0,n-math.min(h.held_outputs and h.held_outputs[item.prefab]or 0,I.Count(own,item.prefab,true)))end;if n<=0 then return end
  local per=item.components.perishable;local cost=(per and per:GetPercent()or 2)+(not per and 2 or 0)
  local _,values=R.Tags({item.prefab});if (values.magic or 0)>0 or (values.decoration or 0)>0 or item:HasTag('irreplaceable')then cost=cost+20 end
  for _,value in pairs(values)do if value>1 then cost=cost+(value-1)*3 end end
  cost=cost+1/math.max(1,n)
  if where==pot then cost=cost-4 end
  local row=rows[item.prefab]or {count=0,cost=cost,items={}};rows[item.prefab]=row;row.count=row.count+n;row.cost=math.min(row.cost,cost);row.items[#row.items+1]={item=item,where=where,count=n}
 end
 for _,i in ipairs(I.Items(own))do if t.spec.source~='warehouse_only'then add(i,own)elseif (t.acquired and t.acquired[i.prefab]or 0)>0 then add(i,own);local row=rows[i.prefab];if row then row.count=math.min(row.count,t.acquired[i.prefab])end end end
 if t.spec.source~='inventory_only'then for _,c in ipairs(W.Discover(own,t,h.work.radius))do for _,i in pairs(c.components.container.slots)do add(i,c)end end end
 if t.spec.source~='warehouse_only'or t.pot_prepared then for _,v in ipairs(slots(pot))do add(v.item,pot)end end
 -- Keep raw final-food goals in suspended/running legacy tasks out of cooking.
 for _,task in ipairs(h.tasks)do if task~=t and task.kind=='work'and task.state~='cancelled'and task.state~='completed'then for _,target in ipairs(task.spec.targets or {})do local row=rows[target.item];if row then row.count=math.max(0,row.count-target.quantity)end end end end
 return rows
end
local function reserve(h,t)
 local need={};for _,p in ipairs(t.plan.ingredients)do need[p]=(need[p]or 0)+1 end
 local stock=M.Stock(h,t,t.pot);t.reserved={}
 for p,n in pairs(need)do
  local row=stock[p];if not row or row.count<n then W.Release(t);return false end
  table.sort(row.items,function(a,b)return a.where==t.pot and b.where~=t.pot end)
  for _,source in ipairs(row.items)do if n>0 then local amount=math.min(n,source.count);if source.where~=t.pot then if not W.Reserve(h.work.inst,h.work,t,source.item,amount)then W.Release(t);return false end;t.reserved[#t.reserved+1]={item=source.item,where=source.where,count=amount} end;n=n-amount end end
 end
 return true
end
local function transfer(h,t,target,item,take,slot)
 local inv=h.work.inst.components.inventory;local c=target.components.container;local p=item and item.prefab
 if not item or not item:IsValid()then return false end
 local from=take and c or inv;local to=take and inv or c
 if take then local present=false;for _,v in pairs(c.slots)do if v==item then present=true end end;if not present then return false end end
 if to:CanAcceptCount(item,1)<1 or not take and not c:CanTakeItemInSlot(item,slot)then return false end
 local before=I.Count(h.work.inst,p,true);local old=count(c,p);local part=from:RemoveItem(item,false);if not part then return false end
 local given=to:GiveItem(part,take and nil or slot,h.work.inst:GetPosition(),false)
 if not given and part:IsValid()and not part.components.inventoryitem.owner then from:GiveItem(part)end
 local delta=I.Count(h.work.inst,p,true)-before;return delta==(take and 1 or -1)and count(c,p)-old==-delta
end
local function push(h,t,target,step,item,slot)
 local inst=h.work.inst;t.state='running';t.attempt=t.attempt+1;local serial=t.attempt
 local a=BufferedAction(inst,target,ACTIONS.YBF_COOK_TASK,item);a.ybf_cook={hub=h,task=t,attempt=serial,step=step,slot=slot};h.inflight={task=t,act=a,deadline=GetTime()+20}
 local function finish(ok)
  if not h.inflight or h.inflight.act~=a or t.attempt~=serial then return end
  h.inflight=nil
  if t.state=='cancelled'or t.paused then return end
  if not a.ybf_cook_verified then t.failures=(t.failures or 0)+1;t.state='queued';t.plan=nil;t.search=nil;W.Release(t);if t.failures>=3 then block(t,'连续动作未取得实际结果；请检查路径、锅状态或背包')end
  elseif t.state=='running'then t.state='queued' end
 end
 a:AddSuccessAction(finish);a:AddFailAction(finish)
 inst.components.ybf_friend.mode='work';inst.components.ybf_friend:ApplyMovementPolicy();h.work.returning=nil;inst.components.locomotor:PushAction(a,true);return true
end
function M.Perform(act)
 local d=act.ybf_cook;if not d then return false end;local h,t=d.hub,d.task;local inst=h.work.inst
 if not h.inflight or h.inflight.act~=act or t.attempt~=d.attempt or t.paused or t.state=='cancelled'or not h.work:OwnerValid(t.owner)or inst.components.health:IsDead()then return false end
 local target=act.target;if not inrange(h,t,target)or inst:GetDistanceSqToInst(target)>16 then return false end
 local step=d.step
 if step=='withdraw'then
  if not require('ybf_friendship_containers').Authorized(target)then return false end
  if W.Available(act.invobject,t)<1 then return false end
  act.ybf_cook_verified=transfer(h,t,target,act.invobject,true);if act.ybf_cook_verified then t.acquired=t.acquired or {};t.acquired[act.invobject.prefab]=(t.acquired[act.invobject.prefab]or 0)+1 end;return act.ybf_cook_verified
 elseif step=='deposit'then
  if not require('ybf_friendship_containers').Authorized(target)then return false end
  local p=t.product;local before=I.Count(inst,p,true);t.giveitem=p;t.givegoal=1
  local ok,n=W.Transfer(inst,t,target,false)
  if ok and n==before-I.Count(inst,p,true)then t.carry=t.carry-n;receipt(t,n);t.deposits=t.deposits or {};local key=tostring(target.GUID);local receipt=t.deposits[key]or {name=target:GetDisplayName(),count=0};receipt.count=receipt.count+n;t.deposits[key]=receipt;act.ybf_cook_verified=true end;return act.ybf_cook_verified or false
 elseif step=='give'then
  local item=act.invobject;local ok=h.work:CanGive({owner=t.owner},item);if not ok then return false end
  local before=I.Count(inst,item.prefab,true);local received=I.Count(t.owner,item.prefab,true)
  local accepted=t.owner.components.trader:AcceptGift(inst,item,1)
  if accepted and before-I.Count(inst,item.prefab,true)==1 and I.Count(t.owner,item.prefab,true)-received==1 then t.carry=t.carry-1;receipt(t,1);t.given_count=(t.given_count or 0)+1;act.ybf_cook_verified=true end;return act.ybf_cook_verified or false
 elseif step=='drop'then
  local point=inst:GetPosition();local map=TheWorld.Map
  if not map:IsPassableAtPoint(point.x,0,point.z)or map.IsPointNearHole and map:IsPointNearHole(point)then return false end
  for _,e in ipairs(TheSim:FindEntities(point.x,0,point.z,4,nil,{'INLIMBO'}))do if e:HasTag('hostile')or e:HasTag('fire')or e:HasTag('burning')then return false end end
  local item=act.invobject;local before=I.Count(inst,item.prefab,true);local part=inst.components.inventory:RemoveItem(item,false);if not part then return false end
  part.Transform:SetPosition(point.x,0,point.z);part.components.inventoryitem:OnDropped(true)
  if part:IsValid()and not part.components.inventoryitem.owner and before-I.Count(inst,item.prefab,true)==1 then t.carry=t.carry-1;receipt(t,1);t.ground_count=(t.ground_count or 0)+1;t.ground={x=point.x,z=point.z};act.ybf_cook_verified=true end;return act.ybf_cook_verified or false
 end
 local pot=t.pot;if target~=pot or not usable(pot)or pots[pot]~=t or opened(h,pot)then return false end
 local s,c=pot.components.stewer,pot.components.container
 if step=='harvest'then
  if not s:IsDone()or s.product~=t.product then return false end
  if t.started and pot.components.ybf_cook_marker.batch~=t.batch then block(t,'锅的批次已变化，不能把别人的产物计入任务');return false end
  local r=require('cooking').GetRecipe(pot.prefab,s.product);local n=r and r.stacksize or 1
  if not I.Room(inst,t.product,n)then return false end
  local before=I.Count(inst,t.product,true);local ok=ACTIONS.HARVEST.fn(act);local delta=I.Count(inst,t.product,true)-before
  if ok and not s:IsDone()and delta==n then
   t.carry=delta;if t.started then t.done=t.done+delta end;t.started=nil;t.plan=nil;t.search=nil;t.pot_id=nil;t.batch=nil;M.Release(t);t.auxiliary=not t.was_requested;t.was_requested=nil;act.ybf_cook_verified=true
  else block(t,'收取结果与实际入包数量不一致，不自动重做')end;return act.ybf_cook_verified or false
 end
 if s:IsCooking()or s:IsDone()then return false end
 if t.expected and fingerprint(pot)~=t.expected then t.plan=nil;t.search=nil;W.Release(t);return false end
 if step=='remove'then local approved_slot;for _,v in ipairs(slots(pot))do if v.item==act.invobject and t.loaded_slots and t.loaded_slots[v.slot]==v.prefab then approved_slot=v.slot end end;act.ybf_cook_verified=transfer(h,t,pot,act.invobject,true);if act.ybf_cook_verified and approved_slot then t.acquired=t.acquired or {};t.acquired[act.invobject.prefab]=(t.acquired[act.invobject.prefab]or 0)+1;t.loaded_slots[approved_slot]=nil end
 elseif step=='load'then
  if t.spec.source=='warehouse_only'and (not t.acquired or (t.acquired[act.invobject.prefab]or 0)<1)then return false end
  act.ybf_cook_verified=transfer(h,t,pot,act.invobject,false,d.slot);if act.ybf_cook_verified then t.loaded_slots=t.loaded_slots or {};t.loaded_slots[d.slot]=act.invobject.prefab end;if act.ybf_cook_verified and t.acquired then t.acquired[act.invobject.prefab]=math.max(0,(t.acquired[act.invobject.prefab]or 0)-1)end
 elseif step=='start'then
  local list={};for _,v in ipairs(slots(pot))do list[#list+1]=v.prefab end
  local candidates=R.Candidates(pot.prefab,list)
  if #candidates~=1 or candidates[1].name~=t.plan.recipe or not s:CanCook()then t.plan=nil;return false end
  local ok=ACTIONS.COOK.fn(act)
  if ok and s:IsCooking()and s.product==t.plan.recipe then
   t.started=true;t.product=s.product;t.batch=pot.components.ybf_cook_marker.batch;t.pot_id=pot.components.ybf_cook_marker.id;t.was_requested=true;t.pot_prepared=nil;t.loaded_slots=nil;t.plan=nil;t.state='waiting';t.expected=nil;t.wait_check=GetTime()+2;W.Release(t);act.ybf_cook_verified=true
   print('[YBF COOK] task='..t.id..' phase=started pot='..pot.GUID..' batch='..t.batch..' product='..t.product)
  end
 end
 if act.ybf_cook_verified and step~='start'then t.expected=fingerprint(pot)end
 return act.ybf_cook_verified or false
end
function M.Poll(h)
 local now=GetTime();for _,t in ipairs(h.tasks)do if t.kind=='cook'and t.started and t.state~='cancelled'and t.state~='completed'and (not t.wait_check or now>=t.wait_check)then
  t.wait_check=now+2;local p=t.pot;if not usable(p)then p=locate(h,t);t.pot=p end
  if not usable(p)then block(t,'原烹饪锅已移除或当前范围无法恢复；不重新消耗材料')
  elseif p.components.ybf_cook_marker.batch~=t.batch or p.components.stewer.product~=t.product then block(t,'原批次产物被取走、腐败或锅被重新操作；不自动重做')
  elseif p.components.stewer:IsDone()and not t.paused and(not live(pots[p])or pots[p]==t)then t.state='queued';pots[p]=t
  elseif not p.components.stewer:IsCooking()and not p.components.stewer:IsDone()then block(t,'原烹饪状态已消失；不自动重做')end
 end end
end
function M.Step(h,t)
 t.friend=h.work.inst;t.external_reservation=true;t.destination_guid=t.spec.destination_guid;t.prefer_ice=true
 if t.world~=P.World()then block(t,'任务属于其他世界分片，不搜索设施');return false end
 if t.carry and t.carry>0 then
  if t.spec.destination=='friend'then h.held_outputs=h.held_outputs or {};h.held_outputs[t.product]=(h.held_outputs[t.product]or 0)+t.carry;receipt(t,t.carry);t.kept_count=(t.kept_count or 0)+t.carry;t.carry=0;return true end
  local item=I.Find(h.work.inst,t.product);if not item then block(t,'已收取产物不在库存，停止自动交付且不重做');return false end
  if t.spec.destination~='player'and t.spec.destination~='ground'then
   local target=W.DepositTargets(h.work.inst,h.work,t,item);if target then return push(h,t,target,'deposit',item)end
  end
  local can=h.work:CanGive({owner=t.owner},item);if can and t.spec.destination~='ground'then return push(h,t,t.owner,'give',item)end
  return push(h,t,h.work.inst,'drop',item)
 end
 if t.done>=t.spec.quantity then t.state='completed';M.Release(t);local locations={};for _,v in pairs(t.deposits or {})do locations[#locations+1]='存入'..v.name..v.count..'份'end;if t.given_count then locations[#locations+1]='交给你'..t.given_count..'份'end;if t.kept_count then locations[#locations+1]='留在我库存'..t.kept_count..'份'end;if t.ground then locations[#locations+1]=string.format('放在附近地面%d份（%.1f，%.1f）',t.ground_count or 0,t.ground.x,t.ground.z)end;h.work:Announce('料理任务完成：本次收取新料理'..t.done..'份、存放/交付'..(t.target_stored or 0)..'份。'..(t.aux_stored and '原锅已有产物另处理'..t.aux_stored..'份。'or '')..table.concat(locations,'；')..'。');return false end
 if t.started then if live(pots[t.pot])and pots[t.pot]~=t then return false end;if t.pot and t.pot.components.stewer:IsDone()then return push(h,t,t.pot,'harvest')end;t.state='waiting';return false end
 if not usable(t.pot)then t.pot=locate(h,t)end
 local pot=t.pot;if not pot then block(t,'附近没有可用的已部署普通锅/便携锅，或锅正在被占用');return false end
 if live(pots[pot])and pots[pot]~=t then t.pot=nil;return false end
 pots[pot]=t
 if not t.watch then t.watch=function()t.wait_check=GetTime()end;pot:ListenForEvent('ybf_cook_change',t.watch);pot:ListenForEvent('onremove',t.watch)end
 if pot.components.stewer:IsCooking()then t.pot=nil;M.Release(t);return false end
 if pot.components.stewer:IsDone()then t.product=pot.components.stewer.product;t.was_requested=false;return push(h,t,pot,'harvest')end
 if opened(h,pot)then block(t,'锅正在被玩家操作，保留现有材料');return false end
 if t.spec.source=='warehouse_only'and not t.pot_prepared then local entries=slots(pot);if #entries>0 then local item=entries[1].item;if not I.Room(h.work.inst,item.prefab,1)then block(t,'背包无法保存锅中原有材料，不能违反只用仓库材料的约束');return false end;t.expected=nil;return push(h,t,pot,'remove',item)end;t.pot_prepared=true end
 if not t.plan then
  if not t.search then local request={};for k,v in pairs(t.spec)do request[k]=v end;request.remaining=t.spec.quantity-t.done;t.search=R.Search(pot.prefab,M.Stock(h,t,pot),request,t.spec.destination=='friend'and h.work.inst or t.owner);t.expected=fingerprint(pot)end
  local ok,plan,why=coroutine.resume(t.search);if not ok then print('[YBF COOK] task='..t.id..' phase=search_error detail='..tostring(plan));block(t,'官方配方求解失败，开发日志已记录，请重新核实');return false end
  if coroutine.status(t.search)~='dead'then return true end
  t.search=nil;if not plan then block(t,why..'；'..R.Gap(pot.prefab,M.Stock(h,t,pot),t.spec)..'不会自行找食材或擅自换菜。');return false end
  t.plan=plan;t.product=plan.recipe;if not reserve(h,t)then t.plan=nil;t.failures=(t.failures or 0)+1;if t.failures>=3 then block(t,'食材被其他任务或玩家取走，请核实后恢复')end;return true end
 end
 if t.plan and t.reserved then for _,source in ipairs(t.reserved)do if source.item:IsValid()and source.item.components.inventoryitem.owner==source.where then W.Reserve(h.work.inst,h.work,t,source.item,source.count)end end end
 if fingerprint(pot)~=t.expected then t.plan=nil;t.search=nil;t.pot_prepared=nil;W.Release(t);return true end
 local need={};for _,p in ipairs(t.plan.ingredients)do need[p]=(need[p]or 0)+1 end
 local occupied={};for _,v in ipairs(slots(pot))do if (need[v.prefab]or 0)>0 then need[v.prefab]=need[v.prefab]-1;occupied[v.slot]=true else if not I.Room(h.work.inst,v.prefab,1)then block(t,'背包无法接收需调整的锅内材料，不清空或销毁');return false end;return push(h,t,pot,'remove',v.item)end end
 for p,n in pairs(need)do if n>0 then
  local item=I.Find(h.work.inst,p);if t.spec.source=='warehouse_only'and(not t.acquired or (t.acquired[p]or 0)<1)then item=nil end;if item then
   local slot;for k=1,pot.components.container.numslots do if not pot.components.container.slots[k]then slot=k;break end end
   if not slot or not pot.components.container:CanTakeItemInSlot(item,slot)then block(t,'锅具当前不接受该材料');return false end
   return push(h,t,pot,'load',item,slot)
  end
  for _,c in ipairs(t.spec.source~='inventory_only'and W.Discover(h.work.inst,t,h.work.radius)or {})do for _,i in pairs(c.components.container.slots)do if i.prefab==p and W.Available(i,t)>0 then return push(h,t,c,'withdraw',i)end end end
  t.plan=nil;t.search=nil;W.Release(t);return true
 end end
 return push(h,t,pot,'start')
end
return M
